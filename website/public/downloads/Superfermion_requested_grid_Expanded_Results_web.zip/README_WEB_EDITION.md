# Superfermion requested-grid archive - web edition

This archive is a subset of `Superfermion_requested_grid_Expanded_Results.zip`
(sha256 `87e11497ef1c1d0f1fa3903408fd1ab0c81279ef49b4eb1ccd7cfcf7917ac429`; 6,006 entries, 42.8 MiB
compressed, 89.3 MiB uncompressed). That full archive
exceeds the 25 MiB per-file limit of the hosting platform, so this edition carries the parts
that the documentation pages cite.

## Included

| Path | Contents |
| --- | --- |
| `Superfermion_Full_Grid_24Q_VQC_VQR_5Steps_RAM_Time_v8.1_desktop_mt16_t20min.ipynb` | Generator notebook for the campaign. |
| `results/figures/` | 214 files: 107 PNG and 107 SVG figures, plus `figure_index.json`. |
| `results/*.csv`, `results/*.json` | 22 CSV tables and 23 JSON summaries at the top level of `results/` (2 text files alongside). |
| `modifications/` | 21 files: the SuperFermion performance patch, source manifest and modified/original sources. |

Every included member is byte-identical to its counterpart in the full archive; nothing inside
a member was edited.

## Omitted from this edition

| Path | Contents |
| --- | --- |
| `results/data/` | 35 `.npz` arrays (17.33 MiB compressed): wine and breast-cancer feature maps. |
| `results/raw/` | 5,633 per-job records (4.65 MiB compressed). |

The omitted paths are only the raw inputs and per-job records. All tables, summaries and
figures computed from them are present above.
