Open MPS_MCM_Benchmark_7Framework.ipynb in Colab (or Jupyter): all tables,
stdout and inline plots are stored in the notebook.
mps_bench8_out/figs/*.png are the same figures as image files.
mps_bench8_out/*.jsonl|*.csv are the raw result rows (one job per line).
Summary: run_summary.json
Full reproducible folder: _dist/mps_bench8_suite_<host>.zip (or mps_bench8_suite.zip).
