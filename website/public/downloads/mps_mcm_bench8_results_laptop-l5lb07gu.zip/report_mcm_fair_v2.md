# MPS + MCM benchmark — report of the recent fixed (fairness-corrected v2) run

Consolidated report of the v2 fairness run: every MCM job class now runs one shot count and one
budget on every lane, and the MPS+MCM scale class covers all three pinned sf builds + aer.
Generated from the raw jsonl (newest terminal row per job key); all times in seconds unless noted.

- host: `laptop-l5lb07gu` | rows window: 2026-10-07T23:03:46 -> 2026-10-12T06:54:51 (UTC rows ts)
- pinned sf sites: `superfermion_optimized` / `superfermion_wheel` / `superfermion_source_baseline` (md5s in probe table)
- thread cap: SF_THREADS=4 every child; Python 3.13; Windows ultrabook (report §9/§10 caveats apply)

Legend: t = wall seconds. `nt` = not_offered, `ob` = over_budget (job did not finish inside its own
budget; killed at budget+30 s cap — a threshold result, not a failure), `err` = error, `—` = row not
in the grid. Non-MCM rows: prep + <Z0*Z_{n-1}>, warm pass + median of 3 timed passes. MCM rows:
full shot-replay wall (single timed run).

## Status

- 264 unique jobs: 221 ok / 26 not_offered / 14 over_budget / 3 error

| lane | jobs | ok | over_budget | error | not_offered |
|---|---|---|---|---|---|
| sf_optimized | 41 | 40 | 1 | 0 | 0 |
| sf_wheel | 41 | 40 | 1 | 0 | 0 |
| sf_source | 41 | 40 | 1 | 0 | 0 |
| aer | 41 | 40 | 1 | 0 | 0 |
| pl | 36 | 31 | 5 | 0 | 0 |
| cirq | 38 | 30 | 5 | 3 | 0 |
| qulacs | 26 | 0 | 0 | 0 | 26 |

## Fairness changes in this run (v1 -> v2)

- teleport m=4: 500 shots / 120 s on **all seven lanes** (v1: sf 500, aer 1000, pl/cirq 200 with 60/60/120/120 s).
- n=24 wall (teleport m=8): 500 shots / 90 s solo on **all seven lanes** (v1: sf lanes only — read as an sf-specific budget).
- MBQC N=17: 200 shots / 120 s on all lanes (v1: pl 240 s, cirq 150 s budgets).
- rep-code: all feed-forward lanes (v1: aer only), probe-validated per engine before queueing.
- MPS+MCM scale (m=10/20/40, 1000 shots): all three sf builds + aer (v1: sf_optimized only).
- Spec-changed v1 rows pruned and re-measured in one session 10-12 06:38-06:55; every row carries
  its own `ts`, `shots`, `budget_s` for audit.

## MPS grids — framework by framework, qubit by qubit

### Validate — GHZ (correctness anchors)

float64 lanes (sf x3, aer, pl) agree to <=4.0e-12 across every validate row; cirq's quimb-contracted expval carries float32 rounding (~2-6e-8) — its only visible departure in the anchors.

| q | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 12 | 0.000145 | 0.000147 | 0.000159 | 0.001606 | 0.04885 | 0.05091 | nt |
| 16 | 0.000176 | 0.000183 | 0.000199 | 0.001612 | 0.03394 | 0.07321 | nt |

### Validate — brick4

| q | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 12 | 0.000668 | 0.000836 | 0.00077 | 0.003687 | 0.07458 | 0.08346 | nt |
| 16 | 0.000975 | 0.000763 | 0.00083 | 0.006275 | 0.08531 | 0.1099 | nt |

### Ladder — GHZ, bond 64

| q | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 50 | 0.000513 | 0.000567 | 0.000979 | 0.003371 | 0.09111 | 0.3311 | nt |
| 100 | 0.00088 | 0.001196 | 0.002225 | 0.005211 | 0.1395 | 0.6951 | nt |
| 200 | 0.001788 | 0.002362 | 0.002421 | 0.005984 | 0.4537 | ob | nt |
| 500 | 0.005105 | 0.006151 | 0.005902 | 0.01704 | 1.157 | 2.415 | nt |
| 1000 | 0.01204 | 0.01274 | 0.01327 | 0.03148 | 3.733 | 5.44 | nt |

### Ladder — brick4, bond 64

| q | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 50 | 0.001412 | 0.001462 | 0.001541 | 0.01736 | 0.2193 | 0.4289 | nt |
| 100 | 0.001773 | 0.002589 | 0.003037 | 0.05349 | 0.4788 | 0.8635 | nt |
| 200 | 0.003783 | 0.004382 | 0.004637 | 0.04615 | 0.9728 | ob | nt |
| 500 | 0.008581 | 0.01456 | 0.01295 | 0.1002 | 3.438 | 3.237 | nt |
| 1000 | 0.02005 | 0.01948 | 0.02229 | 0.2883 | 9.005 | 6.864 | nt |

### Stress — brick12, bond 64

| q | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 200 | 0.4551 | 1.75 | 1.815 | 0.8138 | 71.82 | ob | nt |
| 500 | 1.141 | 4.178 | 4.613 | 1.706 | ob | 35.88 | nt |
| 1000 | 2.36 | 8.465 | 9.265 | 2.88 | ob | ob | nt |

### QFT (shared gate sequence)

cirq quimb: only n=8 completes in the pinned construction; n=20/30/50 are error rows (reproduced).

| q | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 8 | — | — | — | — | — | 0.04124 | — |
| 20 | — | — | — | — | 35.46 | err | — |
| 30 | — | — | — | — | — | err | — |
| 50 | 0.04964 | 0.04211 | 0.03981 | 0.1245 | ob | err | nt |
| 100 | 0.1524 | 0.1666 | 0.1704 | 0.4555 | — | — | — |
| 200 | 0.5864 | 0.6527 | 0.8442 | 2.082 | — | — | — |

### Bond sweep @ n=16 brick4 — TVD vs exact

TVD only where a dense reference exists (sf/aer).

| chi | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 2 | 0.09054 | 0.09054 | 0.09054 | 0.04076 | - | - | — |
| 4 | 7.998e-16 | 9.007e-16 | 9.007e-16 | 4.864e-11 | - | - | — |
| 8 | 7.998e-16 | 9.007e-16 | 9.007e-16 | 4.864e-11 | - | - | — |
| 64 | 7.998e-16 | 9.007e-16 | 9.007e-16 | 4.864e-11 | - | - | — |

### Bond sweep @ n=200 brick12 — discarded weight (sf report)

At chi=8 the expval split is engine-visible: aer 0.13338 / pl 0.13284 / cirq 0.13266 vs sf 0.11196.

| chi | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 8 | 0.2418 | 0.2418 | 0.2418 | - | - | - | — |
| 16 | 0.933 | 0.01071 | 0.01071 | - | - | - | — |
| 32 | 0.5001 | 8.527e-05 | 8.527e-05 | - | - | - | — |
| 64 | 6.65e-14 | 4.451e-07 | 4.451e-07 | - | - | - | — |
| 128 | 6.65e-14 | 1.876e-13 | 1.876e-13 | - | ob | - | — |

## MCM — framework by framework (equal specs per rung)

| case (shots / budget) | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| teleport m=4, n=12 (500 / 120) | 0.06768 | 0.1743 | 1.328 | 0.7899 | 6.304 | 3.088 | nt |
| wall m=8, n=24 (500 / 90 solo) | ob | ob | ob | ob | ob | ob | nt |
| MBQC N=17 (200 / 120) | 2.015 | 3.59 | 3.12 | 12.33 | 69.03 | 4.105 | nt |
| rep-code d=3 (200 / 60) | 0.07639 | 0.2123 | 0.2202 | 0.8945 | 6.537 | 5.353 | nt |

`all_correct` verdicts (every sampled target bit = 1 in every shot):

- 34 ok MCM rows, `all_correct`: 34 True (no exceptions).
- rep-code patterns all-correct per lane: sf_optimized:4/4, sf_wheel:4/4, sf_source:4/4, aer:4/4, pl:4/4, cirq:4/4.

### MPS+MCM scale — aer and sf side by side (merged view)

Filed in the raw data under two engine-specific job-class names: `scale_teleport` (aer's MPS
engine) and `teleport_mps` (sf's MPS engine, all three pinned builds). Same circuit, same n,
same shots, same budgets — shown as one class here. (m=4 is the 100-shot anchor; 10/20/40 are
1000 shots; budgets 60/60/90/150 s.)

| rung | n | shots | aer (scale_teleport) | sf_optimized | sf_wheel | sf_source |
|---|---|---|---|---|---|---|
| m=4 | 12 | 100 | 0.03771 | 0.00698 | 0.02893 | 0.03051 |
| m=10 | 30 | 1000 | 0.2258 | 0.09374 | 1.932 | 2.2 |
| m=20 | 60 | 1000 | 0.3688 | 0.2367 | 7.13 | 11.38 |
| m=40 | 120 | 1000 | 1.015 | 0.318 | 26.58 | 57.25 |

Read-out: at m=40 (n=120, 1000 shots each) sf_optimized 0.318 s vs aer 1.015 s; same-window ABBA
re-measure: 0.36 vs 0.57 s median, ranges disjoint (~1.6x fair margin). The build spread inside
sf is measured, not implied: wheel 26.6 s / source 57.3 s at the same rung (~x180 vs optimized).

## Same-window audit (headline claims re-measured interleaved)

| claim | grid (cross-window) | same-window ABBA | verdict |
|---|---|---|---|
| stress n=1000 | 2.36 vs 2.88 s (−18%) | 2.31 vs 2.37 s med | sf ≈2.5% ahead; ranges overlap |
| stress n=500 | 1.14 vs 1.71 s (−33%) | 1.11 vs 1.24 s med | sf ≈10% ahead; ranges disjoint |
| stress n=200 | 0.46 vs 0.81 s (−44%) | 0.43 vs 0.44 s med | tie |
| teleport m=4 @ 500 shots | 0.068 vs aer 0.790 / cirq 3.09 / pl 6.30 | sf 0.049 / aer 0.462 / cirq 2.15 / pl 3.83 | sf ≥9x vs aer, ~44-93x vs cirq/pl — robust |
| MPS+MCM m=40 | 0.318 vs 1.015 s | 0.36 vs 0.57 s med | sf ≈1.6x — robust |
| MBQC N=17 vs cirq | 2.01 vs 4.10 s | window A: cirq 2.24 vs sf 3.4; window B: sf 1.28 vs cirq 1.81 | direction host-state-dependent; sf-vs-aer/pl margins large in every window |

## Caveats (honest scope)

- MCM rows: 28 of 44 from the fresh 10-12 06:38-06:55 session (re-spec'd or newly added); the
  other 16 kept from the v1 windows at identical specs — all three sf wall rows, the sf/aer MBQC
  rows, sf_optimized teleport_mps m=4/10/20/40, sf_wheel/sf_source teleport_mps m=4, aer scale
  m=10/20/40.
- Ladder/stress/QFT/bonds rows: earlier windows — cross-window composition; headline claims
  re-measured same-window (table above).
- sf lanes are pinned local builds (not the pip package); in Colab all three collapse to the pip build.
- No noise/hardware lanes; simulation-only; wall rows are engine-generic threshold data, not rankings.
- TVD only at n=16 (dense reference); elsewhere quality is engine-reported with engine-specific definitions.
- qulacs: 26 rows, all `not_offered` (no MPS engine, no feed-forward in the binding).

## Artifacts

| artifact | path |
|---|---|
| this report | `report_mcm_fair_v2.md` |
| official full report (all sections) | `report.md` |
| executed notebook (tables + 18 figures embedded) | `_mps_bench8.ipynb` |
| raw rows | `mps_bench8_out/laptop-l5lb07gu_mps8.jsonl` (+ `.csv`) |
| results zip (Colab-ready) | `_dist/mps_mcm_bench8_results_laptop-l5lb07gu.zip` |
| portable suite zip | `_dist/mps_bench8_suite.zip` |
