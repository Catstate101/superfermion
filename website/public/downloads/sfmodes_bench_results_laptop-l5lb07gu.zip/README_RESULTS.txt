sf execution-modes benchmark results bundle (stab / adjoint / dm / clifford)
===========================================================================
sfmodes_bench_out/sfmodes_bench.jsonl          raw rows (all four sections, per-section keys)
sfmodes_bench_out/sfmodes_bench_stab.csv       section 1 table (ghz/brick/randcliff vs stim/aer/pl/cirq)
sfmodes_bench_out/sfmodes_bench_cliff.csv      section 4 table (large-n regime)
sfmodes_bench_out/sfmodes_bench_adj.csv        section 2 table (cat vs qulacs/wheel/sf-ir + gates)
sfmodes_bench_out/sfmodes_bench_dm.csv         section 3 table (sf-ir dm vs sv anchor vs aer + gates)
sfmodes_bench_out/sfmodes_bench_summary.json   verdicts + config + gates + versions + disclosures
sfmodes_bench_out/report.md                    full report (four sections + disclosures)
sfmodes_bench_out/figs/*.png                   figures
Disclosures: cat Mode::Stab/Cliff = ONE Pauli-frame tableau pipeline (plan.rs);
cat Mode::Dm is a documented hold-out -- the dm section benches the sf-ir
simulate_dm engine through the same l1_bench binary, disclosed, never reframed
as a cat-mode win.
Regenerate: open _sfmodes_bench.ipynb (Colab/Jupyter) and Run All; the last cell re-creates this zip.
