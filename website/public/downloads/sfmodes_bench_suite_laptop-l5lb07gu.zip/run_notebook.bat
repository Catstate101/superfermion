@echo off
rem sf execution-modes benchmark suite: headless execute + pack (one command)
cd /d %~dp0
python _sfmodes_bench_exec.py _sfmodes_bench.ipynb
if errorlevel 1 (
    echo EXEC FAILED - inspect the notebook outputs before packing
    exit /b 1
)
python _sfmodes_bench_pack.py
if errorlevel 1 (
    echo PACK FAILED
    exit /b 1
)
echo DONE - see _dist\ for the zips
