"""Build _sfmodes_bench.ipynb -- self-contained sf execution-modes benchmark
(stab / adjoint / dm / clifford), ONE notebook, four sections.

The notebook is the primary artifact and is fully self-contained:
  * competitor lanes (stim / aer / pl / cirq / qulacs) run IN-PROCESS in the kernel,
  * the Rust lanes run via the l1_bench example subprocess (RAYON_NUM_THREADS=4,
    process startup excluded by design):
      - stab / clifford -> default lane: cat_pf (FrameTableau) + sf_ir StabilizerTableau
      - adjoint         -> "mode": "adj"  (cat compile-once handle + sf_ir::adjoint)
      - dm              -> "mode": "dm"   (sf-ir QuantumDAG::simulate_dm vs sv engine)
  * the LAST CELL writes sfmodes_bench_results_<host>.zip with a download link.

Op streams (LAYER_SEED=11, CLIFF_SEED=7, ADJ_SEED=7, depth 8) and lane recipes
are copied VERBATIM from the shipped campaign scripts
(sim4_bench_suite/_sf_cat_l1_ab.py, _sf_cat_adj_ab.py, _sf_cat_stab_randfam_ab.py,
sim4_bench_suite/_r11_cat_dm_ab.py, sf_cat_bench_suite/_sfcat_bench_build.py).

Discipline (disclosed in the report, never blurred):
  * cat Mode::Stab and Mode::Cliff compile to the SAME Pauli-frame tableau
    (plan.rs) -- the stab and clifford sections measure that one pipeline in two
    n-regimes; matching numbers across the two sections are by construction.
  * cat Mode::Dm is a deliberate, documented HOLD-OUT (plan.rs: a feasibility
    probe measured a statistical tie with the routed aer path; keep-only-if-win).
    The dm section therefore benches the sf-ir simulate_dm engine through the
    same l1_bench binary -- an sf-ir result, disclosed, never framed as a cat win.

Usage: python _sfmodes_bench_build.py   (writes _sfmodes_bench.ipynb next to it)
"""
from __future__ import annotations

import pathlib

HERE = pathlib.Path(__file__).resolve().parent
NB = HERE / "_sfmodes_bench.ipynb"
CELLS = []


def md(src):
    CELLS.append({"cell_type": "markdown", "metadata": {}, "source": src})


def code(src):
    CELLS.append({"cell_type": "code", "metadata": {}, "execution_count": None,
                  "outputs": [], "source": src})


md(r'''# sf execution-modes benchmark — stab / adjoint / dm / clifford

**One notebook, four sections** over the SuperFermion Rust stack (`sf-cat` +
`sf-ir`) via the release example `l1_bench` (subprocess, 4-thread RAYON,
in-process timing, process startup excluded by design).

| # | section | Rust lane (l1_bench) | competitors | rungs |
|---|---|---|---|---|
| 1 | stab | default: `cat_pf` (FrameTableau — what `Mode::Stab` executes) + `sf_ir` | stim, aer, pl, cirq | ghz/brick n=64,256; randcliff n=256,1024 |
| 2 | adjoint | `"mode":"adj"`: cat compile-once handle + `sf_ir::adjoint` | qulacs, shipped wheel, FD arbiter | (n=6..20, L=1) + (n=8, L=2/4) |
| 3 | dm | `"mode":"dm"`: sf-ir `QuantumDAG::simulate_dm` vs sv engine | aer `density_matrix` | n=8,10,12 (R6/R8 ladder) |
| 4 | clifford | default: the same `cat_pf` tableau pipeline (`Mode::Cliff`) | stim, pl (aer/cirq capped) | ghz/brick/randcliff n=1024,4096 |

**Discipline up front (full text in the report's disclosure section):**

* `Mode::Stab` and `Mode::Cliff` compile to the **same** Pauli-frame tableau
  (`plan.rs`) — sections 1 and 4 measure that one pipeline across two n-regimes;
  matching numbers across the two sections are by construction, not a lane.
* `Mode::Dm` is a **documented hold-out** in the cat crate (a feasibility probe
  measured a statistical tie with the routed aer path — keep-only-if-win), so
  section 3 benches the **sf-ir** `simulate_dm` engine through the same binary.
  It is an sf-ir result, disclosed as such, never reframed as a cat-mode win.
* Op streams (`ghz`, seeded `brick` depth-8, seeded random-matching
  `randcliff`) are **bit-identical on every engine** (LAYER_SEED=11,
  CLIFF_SEED=7); 2000 shots; ABBA window order per rung; headline = window mean.

**Headline questions:** where does the tableau pipeline (cat_pf) stand vs
stim/aer/pl/cirq at small n and at large n (the #1-preserve regime)? Does the
compile-once cat adjoint handle close on qulacs? Where does the sf-ir dm engine
stand vs aer at purity-1 (ladder) sizes? Every verdict is printed from the
measured rows of this window only.''')

md(r'''## Method, fairness & disclosures

| lane | cold | warm |
|---|---|---|
| `cat_pf` | tableau build + plan + first sample in ONE timed region (strict end-to-end) | sample-only from the prepared sampler; `pack` = raw (shots,n) array class, `counts` = counts-map class (what the product path returns) |
| `stim` | compile_sampler + sample (one region) | sampler reuse (`sample(shots)`) |
| `aer` | build + measure_all + fresh `AerSimulator(method='stabilizer')` per rep | fixed circuit, fresh simulator per rep (worker recipe) |
| `pl` | fresh device + QNode + first call (`default.clifford`) | QNode re-run (tape re-emitted per call) |
| `cirq` | build + fresh `CliffordSimulator` + first run | fresh simulator per rep |
| `sf-ir` | the sf-ir `StabilizerTableau` lane from the SAME l1_bench process | same-window reference |
| cat adj | `"mode":"adj"`: compile-once handle; `compile_ms` and `cold_ms` reported separately from the timed `grad_ms` | in-process `handle.grad()` median |
| qulacs adj | `set_theta` (P setters, -theta sign compensation) + StateVector + update + backprop | per-call median |
| sf wheel adj | `adjoint_grad_vector(qc, "Z"*n, thnames, theta)` — includes its per-call DAG lowering | per-call median |
| sf-ir dm | `"mode":"dm"`: `QuantumDAG::simulate_dm` (streaming pair-pass) medians + sv-engine anchor in the same process | interleaved dm/sv medians |
| aer dm | `AerSimulator(method='density_matrix')` + `save_density_matrix()` (R11 recipe verbatim) | warm-excluded median |

**Fairness / honesty notes**
- `cat_pf` runs 4-thread RAYON (sim4 convention, SF_THREADS=4); competitors run
  their shipped defaults (single-threaded tableau backends).
- The Rust lanes are NOT yet reachable from the Python package — this compares
  engines, not shipped APIs. Product-path numbers are a different lane.
- Per-lane first call is guarded by a **40 s budget**: a lane that exceeds it is
  recorded `over_budget` (it cannot be ranked — no claim is made).
- `cirq` is capped at n<=64 (probe: ghz n=64 = 33.7 s/call; n=256 = 375.4 s) and
  the stabilizer `aer` at n<=256 (probe: brick n=1024 = 102.4 s); above the cap
  the lane is `not_run_capped` — never fabricated. The aer dm lane is NOT
  capped (n=12 ~1.5 s/call, measured probe).
- GHZ support check: every lane that samples GHZ must produce only the
  all-0/all-1 branches (validated live; see `ghz_ok`).
- Adjoint: qulacs backprop is mapped to d/dtheta as `-backprop` (theta=-phi
  sign compensation, probe-verified to 2.7e-11 vs central FD); the cat handle's
  compile-once build is OUTSIDE the timed region and reported as `compile_ms`;
  the FD arbiter runs on (n=8, L=1).
- DM: correctness is layout-invariant — trace(rho)~1, purity Tr(rho^2)~1, and
  the rho diagonal equals |psi|^2 elementwise (engine-order buffer reads).

**Re-run behavior:** rows are appended to `sfmodes_bench_out/sfmodes_bench.jsonl`
with a config hash and a per-section key; re-running the notebook skips
(section x rung) cells already measured and lands new rows in a fresh window.''')

code(r'''# ==== Setup / config ====
import hashlib
import json
import os
import pathlib
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import zipfile

HOST = socket.gethostname().split(".")[0].lower()
HERE = pathlib.Path.cwd()
OUT = HERE / "sfmodes_bench_out"
(OUT / "figs").mkdir(parents=True, exist_ok=True)

# the sf-cat release example binary (Windows dev box default; env-overridable,
# plus a relative fallback so a Linux/macOS build works unmodified)
EXE = pathlib.Path(os.environ.get("L1_BENCH_EXE",
                                  r"D:\sf_cat_target\release\examples\l1_bench.exe"))
if not EXE.exists():
    for cand in ("l1_bench", "_bin/l1_bench", "bin/l1_bench"):
        p = HERE / cand
        if p.exists():
            EXE = p
            break
CAT_OK = EXE.exists() and EXE.is_file()

_win_d = pathlib.Path("D:/")
_default_tmp = (r"D:\sf_cat_bench\tmp" if platform.system() == "Windows" and _win_d.exists()
                else tempfile.gettempdir())
TMP = pathlib.Path(os.environ.get("L1_BENCH_TMP", _default_tmp))
TMP.mkdir(parents=True, exist_ok=True)

GRID = dict(
    stab_rungs=[["ghz", 64], ["ghz", 256], ["brick", 64], ["brick", 256],
                ["randcliff", 256], ["randcliff", 1024]],
    cliff_rungs=[["ghz", 1024], ["ghz", 4096], ["brick", 1024], ["brick", 4096],
                 ["randcliff", 4096]],
    dm_ns=[8, 10, 12],
    adj_rows=[[6, 1], [8, 1], [10, 1], [12, 1], [14, 1], [16, 1], [18, 1], [20, 1],
              [8, 2], [8, 4]],
    depth=8, shots=2000, reps=7, comp_reps=3, comp_cold_reps=2, cirq_reps=1,
    aer_dm_reps=5, budget=40.0, cirq_max_n=64, aer_max_n=256)
LAYER_SEED = 11   # seeded brick H/CX/S flags shared by every engine
CLIFF_SEED = 7    # sampling seed + randcliff family seed
ADJ_SEED = 7      # adjoint theta seed (worker recipe)
REF_GRAD = {1: 0.693213, 2: 0.444292, 4: 0.208356}  # six-lane n=8 |grad| refs
COMPETITORS = ["stim", "aer", "pl", "cirq"]
PROBE_EVIDENCE = {
    "cirq": "cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; "
            "ghz n=256 = 375.4 s -- warm reps=1, no reuse row",
    "aer": "single-call cost probes 2026-10-12: stabilizer brick n=1024 = 102.4 s "
           "(dm n=12 ~1.5 s) -- stabilizer lane capped at 256, dm lane uncapped",
}
EXE_MD5 = hashlib.md5(EXE.read_bytes()).hexdigest()[:12] if CAT_OK else None
CFG_HASH = hashlib.md5(json.dumps(
    [GRID, LAYER_SEED, CLIFF_SEED, ADJ_SEED, EXE_MD5, str(EXE)], sort_keys=True).encode()
).hexdigest()[:10]

print(f"host: {HOST} | python {sys.version.split()[0]} on {platform.system()}")
print(f"cat lane: {'ACTIVE  ' + str(EXE) + '  md5:' + str(EXE_MD5) if CAT_OK else 'NOT AVAILABLE (l1_bench binary not found on this host) -> rust rows recorded not_available'}")
print(f"scratch : {TMP}")
print(f"sections: stab {GRID['stab_rungs']}")
print(f"          cliff {GRID['cliff_rungs']}")
print(f"          dm ns {GRID['dm_ns']} | adj rows {GRID['adj_rows']}")
print(f"grid    : shots={GRID['shots']} reps={GRID['reps']} depth={GRID['depth']} "
      f"seeds L{LAYER_SEED}/C{CLIFF_SEED}/A{ADJ_SEED} cfg_hash={CFG_HASH}")
print(f"caps    : cirq<={GRID['cirq_max_n']}; stabilizer aer<={GRID['aer_max_n']}; "
      f"budget {GRID['budget']:.0f}s per first call")''')

code(r'''# ==== Dependencies (Colab-safe: installs only what is missing) ====
import importlib

INSTALL_IF_MISSING = True
_PIP = {"stim": "stim", "qiskit": "qiskit", "qiskit_aer": "qiskit-aer",
        "pennylane": "pennylane", "cirq": "cirq-core", "qulacs": "qulacs"}
missing = [pkg for mod, pkg in _PIP.items() if importlib.util.find_spec(mod) is None]
if missing and INSTALL_IF_MISSING:
    print("installing lane dependencies:", missing)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", *missing],
                   check=False, capture_output=True)
missing = [mod for mod in _PIP if importlib.util.find_spec(mod) is None]
print("missing lane deps after setup:", missing if missing else "none")

VERSIONS = {}
for mod in ("numpy", "pandas", "matplotlib", "stim", "qiskit", "qiskit_aer",
            "pennylane", "cirq", "qulacs"):
    if importlib.util.find_spec(mod) is not None:
        m = importlib.import_module(mod)
        VERSIONS[mod] = getattr(m, "__version__", "?")
print("versions:", json.dumps(VERSIONS))''')

code(r'''# ==== Shared helpers: op streams, timing, resumable rows ====
# ---- op streams (bit-identical on every engine: LAYER_SEED / CLIFF_SEED) ----
def ghz_ops(n):
    return [("h", 0)] + [("cx", 0, i) for i in range(1, n)]

def brick_ops(n, depth, seed=LAYER_SEED):
    import numpy as np
    rng = np.random.default_rng(seed)
    ops = []
    for _ in range(depth):
        ops += [("h", q) for q in range(n)]
        ops += [("cx", q, q + 1) for q in range(0, n - 1, 2)]
        fl = rng.integers(0, 2, size=n)
        ops += [("s", q) for q in range(n) if fl[q]]
        ops += [("cx", q, q + 1) for q in range(1, n - 1, 2)]
    return ops

def brick_gate_count(n, depth, seed=LAYER_SEED):
    import numpy as np
    rng = np.random.default_rng(seed)
    s_tot = 0
    for _ in range(depth):
        s_tot += int(rng.integers(0, 2, size=n).sum())
    return depth * (n + n // 2 + (n - 1) // 2) + s_tot

def randcliff_ops(n, depth, seed=CLIFF_SEED):
    # seeded random-matching H/S/CX Clifford family (long-range CX); not Haar-uniform
    import numpy as np
    rng = np.random.default_rng(seed)
    ops = []
    for _ in range(depth):
        h_flags = rng.integers(0, 2, size=n)
        ops += [("h", q) for q in range(n) if h_flags[q]]
        perm = rng.permutation(n)
        for k in range(n // 2):
            a, b = int(perm[2 * k]), int(perm[2 * k + 1])
            if rng.integers(0, 2):
                a, b = b, a
            ops.append(("cx", a, b))
        s_flags = rng.integers(0, 2, size=n)
        ops += [("s", q) for q in range(n) if s_flags[q]]
    return ops

def ops_for(circ, n):
    if circ == "ghz":
        return ghz_ops(n)
    if circ == "brick":
        return brick_ops(n, GRID["depth"])
    if circ == "randcliff":
        return randcliff_ops(n, GRID["depth"])
    raise ValueError(circ)

def gates_for(circ, n, ops):
    if circ == "ghz":
        return None
    if circ == "brick":
        return brick_gate_count(n, GRID["depth"])
    return len(ops)

# ---- timing helpers ----
def median(values):
    xs = sorted(values)
    m = len(xs) // 2
    return xs[m] if len(xs) % 2 else 0.5 * (xs[m - 1] + xs[m])

def mean_of(a, b):
    return 0.5 * (a + b)

def timed_reps(fn, reps):
    fn()  # warm pass, excluded
    times = []
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t0)
    return times

class OverBudget(Exception):
    pass

def _probe(fn, budget):
    t0 = time.perf_counter()
    out = fn()
    dt = time.perf_counter() - t0
    if dt > budget:
        raise OverBudget(f"first call {dt:.1f}s > budget {budget:.0f}s")
    return out, dt

def _branch_ok(arr, n):
    import numpy as np
    uniq = np.unique(np.asarray(arr), axis=0)
    ok = all(bool((row == 0).all() or (row == 1).all()) for row in uniq)
    return ok, int(uniq.shape[0])

# ---- resumable row store (one jsonl, per-section keys) ----
ROWS_JSONL = OUT / "sfmodes_bench.jsonl"
rows = []
if ROWS_JSONL.exists():
    for line in ROWS_JSONL.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            if r.get("cfg_hash") == CFG_HASH:
                rows.append(r)
done = {r["ykey"] for r in rows if "ykey" in r}

def append_row(row):
    rows.append(row)
    done.add(row.get("ykey"))
    with ROWS_JSONL.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row) + "\n")

print(f"rows cached for cfg {CFG_HASH}: {len(rows)}")''')

code(r'''# ==== Rust tableau lanes (stab / clifford) ====
# ---- cat_pf / sf-ir lane: the Rust example binary (in-process timing inside;
#      process startup is EXCLUDED by design; two window calls per rung) ----
def rust_lane(ops, n, shots, reps, tag="t"):
    job = {"n": n, "ops": [[o[0], *o[1:]] for o in ops], "shots": shots,
           "reps": reps, "seed": CLIFF_SEED}
    job_path = TMP / f"sfm_{tag}_n{n}.json"
    job_path.write_text(json.dumps(job), encoding="utf-8")
    env = dict(os.environ)
    env["RAYON_NUM_THREADS"] = "4"  # sim4 convention: SF_THREADS=4
    p = subprocess.run([str(EXE), str(job_path)], capture_output=True,
                       text=True, env=env, timeout=1800)
    if p.returncode != 0:
        raise RuntimeError(f"l1_bench failed rc={p.returncode}: {p.stderr[-300:]}")
    line = [l for l in p.stdout.splitlines() if l.strip().startswith("{")][-1]
    return json.loads(line)

# ---- stim lane (worker recipe: compile + sample inside the timed region) ----
def stim_lane(ops, n, shots, reps):
    import stim
    c = stim.Circuit()
    for op in ops:
        name = op[0].lower()
        if name == "h":
            c.append("H", [op[1]])
        elif name == "cx":
            c.append("CX", [op[1], op[2]])
        elif name == "s":
            c.append("S", [op[1]])
        else:
            raise ValueError(name)
    c.append("M", list(range(n)))
    full = timed_reps(lambda: c.compile_sampler().sample(shots=shots), reps)
    samp = c.compile_sampler()
    warm = timed_reps(lambda: samp.sample(shots=shots), reps)
    return {"full_ms": median(full) * 1e3, "sample_ms": median(warm) * 1e3,
            "version": getattr(stim, "__version__", "?")}

# ---- competitor lanes (recipes copied VERBATIM from the shipped worker) ----
def aer_lane(ops, n, shots, reps, cold_reps, budget, circ):
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    out = {"status": "ok", "api": "AerSimulator(method='stabilizer')"}

    def build():
        qc = QuantumCircuit(n)
        for op in ops:
            if op[0] == "h":
                qc.h(op[1])
            elif op[0] == "s":
                qc.s(op[1])
            elif op[0] == "cx":
                qc.cx(op[1], op[2])
            else:
                raise ValueError(str(op))
        qcm = qc.copy()
        qcm.measure_all()
        return qcm

    def fresh_run(qcm):
        return AerSimulator(method="stabilizer").run(
            qcm, shots=shots, seed=CLIFF_SEED).result()

    qcm = build()
    last, _ = _probe(lambda: fresh_run(qcm), budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        fresh_run(build())
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = fresh_run(qcm)
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    sim = AerSimulator(method="stabilizer")
    last = sim.run(qcm, shots=shots, seed=CLIFF_SEED).result()
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = sim.run(qcm, shots=shots, seed=CLIFF_SEED).result()
        ts.append(time.perf_counter() - t0)
    out["reuse_ms"] = median(ts) * 1e3
    cnt = dict(last.get_counts())
    out["keys"] = len(cnt)
    if circ == "ghz":
        out["ghz_ok"] = bool(set(cnt) <= {"0" * n, "1" * n})
    return out

def pl_lane(ops, n, shots, reps, cold_reps, budget, circ):
    import numpy as np
    import pennylane as qml
    out = {"status": "ok", "api": "default.clifford"}

    def emit():
        for op in ops:
            if op[0] == "h":
                qml.Hadamard(op[1])
            elif op[0] == "s":
                qml.S(op[1])
            elif op[0] == "cx":
                qml.CNOT(wires=[op[1], op[2]])
            else:
                raise ValueError(str(op))

    def make():
        dev = qml.device("default.clifford", wires=n, shots=shots)

        @qml.qnode(dev)
        def samp():
            emit()
            return qml.sample(wires=list(range(n)))

        return samp

    samp = make()
    last, _ = _probe(samp, budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        make()()
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = samp()
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    arr = np.asarray(last)
    if circ == "ghz":
        ok, kb = _branch_ok(arr, n)
        out["ghz_ok"] = bool(ok)
        out["ghz_branches"] = kb
    else:
        out["keys"] = int(np.unique(arr, axis=0).shape[0])
    return out

def cirq_lane(ops, n, shots, reps, cold_reps, budget, circ):
    import cirq
    import numpy as np
    out = {"status": "ok", "api": "CliffordSimulator"}
    q = cirq.LineQubit.range(n)

    def build():
        items = []
        for op in ops:
            if op[0] == "h":
                items.append(cirq.H(q[op[1]]))
            elif op[0] == "s":
                items.append(cirq.S(q[op[1]]))
            elif op[0] == "cx":
                items.append(cirq.CNOT(q[op[1]], q[op[2]]))
            else:
                raise ValueError(str(op))
        items.append(cirq.measure(*q, key="m"))
        return cirq.Circuit(items)

    def fresh_run(c):
        return cirq.CliffordSimulator(seed=CLIFF_SEED).run(
            c, repetitions=shots).measurements["m"]

    c = build()
    last, _ = _probe(lambda: fresh_run(c), budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        fresh_run(build())
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = fresh_run(c)
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    out["reuse_ms"] = None  # cirq re-compiles per run; reuse == warm, not measured
    arr = np.asarray(last)
    if circ == "ghz":
        ok, kb = _branch_ok(arr, n)
        out["ghz_ok"] = bool(ok)
        out["ghz_branches"] = kb
    else:
        out["keys"] = int(np.unique(arr, axis=0).shape[0])
    return out

LANE_FN = {"aer": aer_lane, "pl": pl_lane, "cirq": cirq_lane}

def comp_lane(lane, ops, n, shots, reps, cold_reps, budget, circ):
    try:
        return LANE_FN[lane](ops, n, shots, reps, cold_reps, budget, circ)
    except OverBudget as e:
        return {"status": "over_budget", "note": str(e)}
    except Exception as e:  # fail-soft, honest
        return {"status": f"error: {type(e).__name__}: {e}"}

def stim_branch_check(ops, n, shots):
    import stim
    c = stim.Circuit()
    for op in ops:
        if op[0] == "h":
            c.append("H", [op[1]])
        elif op[0] == "cx":
            c.append("CX", [op[1], op[2]])
        elif op[0] == "s":
            c.append("S", [op[1]])
    c.append("M", list(range(n)))
    arr = c.compile_sampler().sample(shots=shots)
    ok, kb = _branch_ok(arr, n)
    return {"ghz_ok": bool(ok), "ghz_branches": kb}

def combine(win_a, win_b, fields):
    out = {}
    for f in fields:
        va, vb = win_a.get(f), win_b.get(f)
        out[f] = (mean_of(va, vb) if isinstance(va, (int, float))
                  and isinstance(vb, (int, float)) else None)
    return out

print("tableau lanes ready | rust lane:", "ACTIVE" if CAT_OK else "not available on this host")''')

code(r'''# ==== Adjoint lanes (recipe copied VERBATIM from _sf_cat_adj_ab.py) ====
def adj_layout(n, layers):
    """RY/RZ per qubit per layer + CX ladder per layer; P = 2*n*layers."""
    ops = []
    p = 0
    for _ in range(layers):
        for i in range(n):
            ops.append(("ry", i, p)); p += 1
            ops.append(("rz", i, p)); p += 1
        ops += [("cx", i, i + 1) for i in range(n - 1)]
    return ops, p

def adj_theta(P):
    import numpy as np
    return np.random.default_rng(ADJ_SEED).uniform(0.1, 1.2, size=P)

def cat_adj_lane(n, L, theta, reps, fd_check, tag):
    """One l1_bench 'adj' process (cat handle + sf-ir lanes in-process)."""
    job = {"mode": "adj", "n": n, "layers": L,
           "theta": [float(x) for x in theta], "reps": reps,
           "fd_check": bool(fd_check)}
    job_path = TMP / f"sfm_adj_n{n}_L{L}_{tag}.json"
    job_path.write_text(json.dumps(job), encoding="utf-8")
    env = dict(os.environ)
    env["RAYON_NUM_THREADS"] = "4"  # sim4 convention: SF_THREADS=4
    p = subprocess.run([str(EXE), str(job_path)], capture_output=True,
                       text=True, env=env, timeout=1800)
    if p.returncode != 0:
        raise RuntimeError(f"l1_bench adj failed rc={p.returncode}: {p.stderr[-300:]}")
    line = [l for l in p.stdout.splitlines() if l.strip().startswith("{")][-1]
    return json.loads(line)

def qulacs_lane(n, L, theta, reps):
    import numpy as np
    import qulacs
    layout, P = adj_layout(n, L)
    c = qulacs.ParametricQuantumCircuit(n)
    for kind, a, b in layout:
        if kind == "ry":
            c.add_parametric_RY_gate(a, 0.0)
        elif kind == "rz":
            c.add_parametric_RZ_gate(a, 0.0)
        else:
            c.add_CNOT_gate(a, b)
    obs = qulacs.Observable(n)
    obs.add_operator(1.0, " ".join(f"Z {i}" for i in range(n)))
    setter = (getattr(c, "set_parametric_rotation_angle", None)
              or getattr(c, "set_parameter", None))
    if setter is None:
        raise AttributeError("qulacs ParametricQuantumCircuit has no angle setter")

    def set_theta(vals):
        # worker compensation: qulacs rotates exp(+i th P/2); the shared
        # ansatz is exp(-i th P/2), so set -theta (probe-verified).
        for j in range(P):
            setter(j, -float(vals[j]))

    def gfn():
        set_theta(theta)
        st = qulacs.StateVector(n)
        c.update_quantum_state(st)
        return np.asarray(c.backprop(obs), dtype=float)

    times = timed_reps(gfn, reps)
    # qulacs backprop returns d/dphi for its own parameter phi; the lane sets
    # phi = -theta (state-convention compensation), so d/dtheta = -backprop
    # (probe-verified to 2.7e-11 vs central FD of qulacs's own expval).
    g = -gfn()
    return {"grad_ms": median(times) * 1e3, "grad": g.tolist(),
            "version": qulacs.__version__}

def wheel_lane(n, L, theta, reps):
    """Shipped superfermion wheel: adjoint_grad_vector per call (historical
    loser lane).  Returns status=not_available if the import fails."""
    try:
        import numpy as np
        import superfermion as sf
        from superfermion.qml.gradient.adjoint import adjoint_grad_vector
        layout, P = adj_layout(n, L)
        thnames = [f"t{j}" for j in range(P)]
        th = [sf.param(k) for k in thnames]
        qc = sf.Circuit(n)
        for kind, a, b in layout:
            if kind == "ry":
                qc = qc.ry(th[b], a)
            elif kind == "rz":
                qc = qc.rz(th[b], a)
            else:
                qc = qc.cx(a, b)

        def gfn():
            return np.asarray(adjoint_grad_vector(qc, "Z" * n, thnames, theta),
                              dtype=float)

        times = timed_reps(gfn, reps)
        g = gfn()
        return {"status": "ok", "grad_ms": median(times) * 1e3,
                "grad": g.tolist()}
    except Exception as e:  # lane presence is environment-dependent
        return {"status": "not_available", "err": str(e)[:200]}

print("adjoint lanes ready | qulacs:", VERSIONS.get("qulacs", "missing"),
      "| wheel: probe at run time")''')

code(r'''# ==== DM lanes (rust lane via l1_bench "dm" mode; aer recipe VERBATIM from _r11_cat_dm_ab.py) ====
def rust_dm_lane(ops, n, reps, tag="t"):
    job = {"mode": "dm", "n": n, "ops": [[o[0], *o[1:]] for o in ops], "reps": reps}
    job_path = TMP / f"sfm_dm_n{n}_{tag}.json"
    job_path.write_text(json.dumps(job), encoding="utf-8")
    env = dict(os.environ)
    env["RAYON_NUM_THREADS"] = "4"
    p = subprocess.run([str(EXE), str(job_path)], capture_output=True,
                       text=True, env=env, timeout=1800)
    if p.returncode != 0:
        raise RuntimeError(f"l1_bench dm failed rc={p.returncode}: {p.stderr[-300:]}")
    line = [l for l in p.stdout.splitlines() if l.strip().startswith("{")][-1]
    return json.loads(line)

def make_aer_dm(n, ops):
    import numpy as np
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    qc = QuantumCircuit(n)
    for op in ops:
        if op[0] == "h":
            qc.h(op[1])
        elif op[0] == "s":
            qc.s(op[1])
        elif op[0] == "cx":
            qc.cx(op[1], op[2])
        else:
            raise ValueError(str(op))
    sim = AerSimulator(method="density_matrix")
    qc_dm = qc.copy()
    qc_dm.save_density_matrix()

    def run():
        rho = sim.run(qc_dm).result().data(0)["density_matrix"]
        return np.asarray(rho, dtype=np.complex128)

    return run, qc

def aer_dm_window(ops, n, reps, budget):
    from qiskit.quantum_info import Statevector
    run, qc = make_aer_dm(n, ops)
    first, dt = _probe(run, budget)
    ts = timed_reps(run, reps)
    rho = run()
    import numpy as np
    trace = float(np.trace(rho).real)
    purity = float(np.vdot(rho, rho).real)      # Tr rho^2 = sum |rho_ij|^2
    psi = Statevector(qc).data
    prob = np.round(rho.diagonal().real, 8)
    prob_ref = np.round(np.abs(psi) ** 2, 8)
    prob_match = bool(np.array_equal(prob, prob_ref))
    import qiskit_aer
    return {"dm_ms": median(ts) * 1e3, "first_ms": dt * 1e3, "trace": trace,
            "purity": purity, "prob_match": prob_match,
            "version": getattr(qiskit_aer, "__version__", "?")}

print("dm lanes ready (rust dm = sf-ir engine via l1_bench mode 'dm'; "
      "cat Mode::Dm is a documented hold-out -- disclosed in the report)")''')

md(r'''## Section 1 — stab (small/mid n, full competitor field)

Exercises the **Pauli-frame tableau pipeline** the cat crate uses for
`Mode::Stab`: rungs `ghz 64/256`, `brick 64/256` and the seeded
random-matching `randcliff 256/1024` (long-range CX topology, not Haar
uniform) — all against **stim / aer / pl / cirq**, ABBA order, two windows
per lane. `cirq` is capped at n<=64 and stabilizer-`aer` at n<=256 (probes);
capped lanes are `not_run_capped`, never fabricated. `cat_pf` cold = tableau
build + plan + first sample in ONE timed region; warm = counts-map class.
Same-window `sf_ir` reference column comes from the SAME l1_bench process.

Looking for: the measured standings at small/mid n in THIS window (the R6
small-n TVD regime — a different workload — showed stim ahead there; the
sf_cat round's cat_pf lane rows are the direct precedent for this table).''')

code(r'''# ==== RUN section 1 — stab ====
def _cat_dict(c1, c2):
    if isinstance(c1, dict) and isinstance(c2, dict) and "cat_pf" in c1 and "cat_pf" in c2:
        a, b = c1["cat_pf"], c2["cat_pf"]
        return {
            "cold_ms": mean_of(a["cold_ms"], b["cold_ms"]),
            "build_ms": mean_of(a["build_ms"], b["build_ms"]),
            "plan_ms": mean_of(a["plan_ms"], b["plan_ms"]),
            "pack_ms": mean_of(a["sample_pack_ms"], b["sample_pack_ms"]),
            "counts_ms": mean_of(a["sample_counts_ms"], b["sample_counts_ms"]),
            "keys": b["keys"],
            "vars": b.get("random_vars"),
        }
    return None

def _assemble_tableau(section, circ, n, gates, wins):
    row = {"section": section, "ykey": f"{section}:{circ}:{n}", "circuit": circ,
           "n": n, "shots": GRID["shots"], "gates": gates, "cfg_hash": CFG_HASH}
    c1, c2 = wins["cat"]
    cat = _cat_dict(c1, c2)
    if cat is None:
        bad = c1 if not (isinstance(c1, dict) and "cat_pf" in c1) else c2
        row["cat_status"] = (bad.get("status") if isinstance(bad, dict) else "not_available")
    s1, s2 = wins["stim"]
    if all(isinstance(x, dict) and "full_ms" in x for x in (s1, s2)):
        stim = combine(s1, s2, ["full_ms", "sample_ms"])
        stim["version"] = s2.get("version")
    else:
        bad = s1 if not (isinstance(s1, dict) and "full_ms" in s1) else s2
        stim = {"status": (bad.get("status") if isinstance(bad, dict) else "error"),
                "note": str(bad)[:200]}
    comp = {}
    for lane in ("aer", "pl", "cirq"):
        a, b = wins[lane]
        if all(isinstance(x, dict) and x.get("status") == "ok" for x in (a, b)):
            d = combine(a, b, ["cold_ms", "warm_ms", "reuse_ms"])
            d["status"] = "ok"
            d["api"] = b.get("api")
            for k in ("ghz_ok", "ghz_branches", "keys"):
                if k in b:
                    d[k] = b[k]
            comp[lane] = d
        else:
            bad = a if not (isinstance(a, dict) and a.get("status") == "ok") else b
            comp[lane] = {"status": (bad.get("status") if isinstance(bad, dict) else "error"),
                          "note": (bad.get("note") if isinstance(bad, dict) else str(bad)[:200])}
    if circ == "ghz" and "full_ms" in stim:
        try:
            stim.update(stim_branch_check(ops_for(circ, n), n, GRID["shots"]))
        except Exception as e:
            stim["ghz_check_error"] = str(e)[:160]
    if cat and circ == "ghz":
        cat["ghz_ok"] = cat["keys"] == 2
    cold_ref = {"stim": stim.get("full_ms")}
    warm_ref = {"stim": stim.get("sample_ms")}
    for lane in ("aer", "pl", "cirq"):
        cold_ref[lane] = comp[lane].get("cold_ms")
        warm_ref[lane] = comp[lane].get("warm_ms")
    avail_cold = [l for l in COMPETITORS if cold_ref.get(l)]
    avail_warm = [l for l in COMPETITORS if warm_ref.get(l)]
    if cat:
        rank_cold = {l: cat["cold_ms"] < cold_ref[l] for l in avail_cold}
        rank_warm = {l: cat["counts_ms"] < warm_ref[l] for l in avail_warm}
        row["win_cold"] = rank_cold
        row["win_warm"] = rank_warm
        row["beats_all_cold"] = all(rank_cold.values()) if len(avail_cold) == len(COMPETITORS) else None
        row["beats_all_warm"] = all(rank_warm.values()) if len(avail_warm) == len(COMPETITORS) else None
        row["beats_available_cold"] = bool(rank_cold) and all(rank_cold.values())
        row["beats_available_warm"] = bool(rank_warm) and all(rank_warm.values())
    else:
        row["win_cold"] = row["win_warm"] = None
        row["beats_all_cold"] = row["beats_all_warm"] = None
        row["beats_available_cold"] = row["beats_available_warm"] = None
    row["unranked"] = [l for l in COMPETITORS if not cold_ref.get(l) or not warm_ref.get(l)]
    row["cat"] = cat
    row["sf_ir"] = c2.get("sf_ir") if isinstance(c2, dict) else None
    row["stim"] = stim
    row["comp"] = comp
    return row

def _win_status(lane, w):
    if lane == "cat":
        return "ok" if isinstance(w, dict) and "cat_pf" in w else str(w.get("status") if isinstance(w, dict) else w)
    if lane == "stim":
        return "ok" if isinstance(w, dict) and "full_ms" in w else str(w.get("status") if isinstance(w, dict) else w)
    return str(w.get("status") if isinstance(w, dict) else w)

def run_tableau_rung(section, circ, n):
    ops = ops_for(circ, n)
    gates = gates_for(circ, n, ops)
    wins = {"cat": [], "stim": [], "aer": [], "pl": [], "cirq": []}
    order = ["cat", "stim", "aer", "pl", "cirq", "cirq", "pl", "aer", "stim", "cat"]
    print(f"[{section}] {circ:9s} n={n:5d} | windows: " + " ".join(order), flush=True)
    for lane in order:
        if lane == "cat":
            if CAT_OK:
                try:
                    wins["cat"].append(rust_lane(ops, n, GRID["shots"], GRID["reps"],
                                                 tag=f"{section}-{circ}"))
                except Exception as e:
                    wins["cat"].append({"status": f"error: {type(e).__name__}: {e}"})
            else:
                wins["cat"].append({"status": "not_available",
                                    "note": "l1_bench example binary not present on this host"})
        elif lane == "stim":
            try:
                wins["stim"].append(stim_lane(ops, n, GRID["shots"], GRID["reps"]))
            except Exception as e:
                wins["stim"].append({"status": f"error: {type(e).__name__}: {e}"})
        else:
            cap = (GRID["cirq_max_n"] if lane == "cirq"
                   else GRID["aer_max_n"] if lane == "aer" else None)
            if cap is not None and n > cap:
                wins[lane].append({
                    "status": "not_run_capped",
                    "note": f"n>{cap}: not attempted in this ladder; {PROBE_EVIDENCE[lane]}"})
                print(f"   [{lane:5s}] {len(wins[lane])}/2 not_run_capped (n>{cap})", flush=True)
                continue
            if lane == "cirq":
                creps, cold = GRID["cirq_reps"], 1
            else:
                creps, cold = GRID["comp_reps"], GRID["comp_cold_reps"]
            wins[lane].append(comp_lane(lane, ops, n, GRID["shots"], creps, cold,
                                        GRID["budget"], circ))
        print(f"   [{lane:5s}] {len(wins[lane])}/2 {_win_status(lane, wins[lane][-1])}", flush=True)
    row = _assemble_tableau(section, circ, n, gates, wins)
    append_row(row)
    fmt = lambda v: f"{v:9.3f}" if isinstance(v, (int, float)) else "      n/a"
    ca = row.get("cat") or {}
    cp = row["comp"]
    cr = row.get("win_cold") or {}
    wr = row.get("win_warm") or {}
    print(f"[{section}] {circ:9s} n={n:5d} | cold ms: cat {fmt(ca.get('cold_ms'))} "
          f"stim {fmt(row['stim'].get('full_ms'))} aer {fmt(cp['aer'].get('cold_ms'))} "
          f"pl {fmt(cp['pl'].get('cold_ms'))} cirq {fmt(cp['cirq'].get('cold_ms'))} | "
          f"warm ms: cat {fmt(ca.get('counts_ms'))} stim {fmt(row['stim'].get('sample_ms'))} "
          f"aer {fmt(cp['aer'].get('warm_ms'))} pl {fmt(cp['pl'].get('warm_ms'))} "
          f"cirq {fmt(cp['cirq'].get('warm_ms'))} | "
          f"cold {sum(cr.values())}/{len(cr)} warm {sum(wr.values())}/{len(wr)}", flush=True)
    return row

for circ, n in GRID["stab_rungs"]:
    ykey = f"stab:{circ}:{n}"
    if ykey in done:
        print(f"[stab] {circ:9s} n={n:5d} | cached (cfg {CFG_HASH})", flush=True)
        continue
    run_tableau_rung("stab", circ, n)
print(f"\nsection stab complete: {sum(1 for r in rows if r.get('section') == 'stab')} rows "
      f"-> {ROWS_JSONL.name}")''')

md(r'''## Section 2 — adjoint (compile-once handle vs qulacs backprop)

Worker ansatz verbatim: per layer RY,RZ on every qubit (params t0.. ascending)
then a CX ladder; P = 2nL; theta = rng(7).uniform(0.1, 1.2, P); observable
Z^n. Rows (n,L): (6,1) (8,1) (10,1) (12,1) (14,1) (16,1) (18,1) (20,1) (8,2)
(8,4). Per row, two interleaved windows `cat -> qulacs -> wheel` x2; headline =
mean of window medians.

Gates on every row: cat-vs-qulacs max abs grad diff, cat-vs-sf_ir parity
(l1_bench internal), and at n=8 the six-lane |grad| reference (L=1/2/4 ->
0.693213/0.444292/0.208356); the central finite-difference arbiter runs at
(n=8, L=1) inside l1_bench. The cat handle's compile-once build is OUTSIDE
the timed region (`compile_ms` reported); qulacs runs `-backprop` (theta=-phi
sign compensation, probe-verified 2.7e-11 vs FD); the shipped wheel runs its
per-call `adjoint_grad_vector` (historical loser lane, fail-soft).''')

code(r'''# ==== RUN section 2 — adjoint ====
def _maxdiff(a, b):
    return max(abs(x - y) for x, y in zip(a, b)) if a and b else float("nan")

def _safe(fn, *a, **k):
    try:
        return fn(*a, **k)
    except Exception as e:
        return {"status": f"error: {type(e).__name__}: {e}"}

_fmt = lambda v: f"{v:9.3f}" if isinstance(v, (int, float)) else "      n/a"

for n, L in GRID["adj_rows"]:
    ykey = f"adj:n{n}:L{L}"
    if ykey in done:
        print(f"[adj] n={n:2d} L={L} | cached (cfg {CFG_HASH})", flush=True)
        continue
    layout, P = adj_layout(n, L)
    theta = adj_theta(P)
    fd = (n == 8 and L == 1)  # worker fd_check row
    if CAT_OK:
        c1 = _safe(cat_adj_lane, n, L, theta, GRID["reps"], fd, "w1")
    else:
        c1 = {"status": "not_available",
              "note": "l1_bench example binary not present on this host"}
    q1 = _safe(qulacs_lane, n, L, theta, GRID["reps"])
    w1 = _safe(wheel_lane, n, L, theta, GRID["reps"])
    if CAT_OK:
        c2 = _safe(cat_adj_lane, n, L, theta, GRID["reps"], fd, "w2")
    else:
        c2 = c1
    q2 = _safe(qulacs_lane, n, L, theta, GRID["reps"])
    w2 = _safe(wheel_lane, n, L, theta, GRID["reps"])

    ok_cat = all(isinstance(x, dict) and isinstance(x.get("cat"), dict) for x in (c1, c2))
    ok_ir = all(isinstance(x, dict) and isinstance(x.get("sf_ir"), dict) for x in (c1, c2))
    ok_q = all(isinstance(x, dict) and "grad_ms" in x for x in (q1, q2))
    ok_w = all(isinstance(x, dict) and x.get("status") == "ok" for x in (w1, w2))

    row = {"section": "adj", "ykey": ykey, "n": n, "layers": L, "p": P,
           "reps": GRID["reps"], "cfg_hash": CFG_HASH}
    if ok_cat:
        row["cat"] = {
            "grad_ms": mean_of(c1["cat"]["grad_ms"], c2["cat"]["grad_ms"]),
            "compile_ms": mean_of(c1["cat"]["compile_ms"], c2["cat"]["compile_ms"]),
            "cold_ms": mean_of(c1["cat"]["cold_ms"], c2["cat"]["cold_ms"]),
            "grad_norm": c2["grad_norm"],  # top-level key per l1_bench adj contract
        }
        row["fd_max_err"] = c2.get("fd_max_err") if fd else None
        row["parity_cat_vs_sfir"] = max(c1.get("parity_max_diff", 0.0),
                                        c2.get("parity_max_diff", 0.0))
        row["expval"] = c2.get("expval")
    else:
        bad = c1 if not (isinstance(c1, dict) and isinstance(c1.get("cat"), dict)) else c2
        row["cat_status"] = (bad.get("status") if isinstance(bad, dict) else "not_available")
    if ok_ir:
        row["sf_ir_rust"] = {"grad_ms": mean_of(c1["sf_ir"]["grad_ms"], c2["sf_ir"]["grad_ms"])}
    if ok_q:
        row["qulacs"] = {"grad_ms": mean_of(q1["grad_ms"], q2["grad_ms"]),
                         "version": q2["version"]}
    else:
        bad = q1 if not (isinstance(q1, dict) and "grad_ms" in q1) else q2
        row["qulacs"] = {"status": (bad.get("status") if isinstance(bad, dict) else "error")}
    if ok_w:
        row["sf_wheel"] = {"grad_ms": mean_of(w1["grad_ms"], w2["grad_ms"])}
    else:
        bad = w1 if not (isinstance(w1, dict) and w1.get("status") == "ok") else w2
        row["sf_wheel"] = {"status": (bad.get("status") if isinstance(bad, dict) else "error"),
                           "err": (bad.get("err") if isinstance(bad, dict) else None)}
    if ok_cat and ok_q:
        row["parity_cat_vs_qulacs"] = _maxdiff(c2["grad"], q2["grad"])
        row["win_cat_vs_qulacs"] = row["cat"]["grad_ms"] < row["qulacs"]["grad_ms"]
    else:
        row["parity_cat_vs_qulacs"] = None
        row["win_cat_vs_qulacs"] = None
    row["win_cat_vs_sfir"] = (row["cat"]["grad_ms"] < row["sf_ir_rust"]["grad_ms"]
                              if ok_cat and ok_ir else None)
    row["win_cat_vs_wheel"] = (row["cat"]["grad_ms"] < row["sf_wheel"]["grad_ms"]
                               if ok_cat and ok_w else None)
    ref = REF_GRAD.get(L) if n == 8 else None
    row["ref_norm_6lane"] = ref
    row["ref_norm_diff"] = (abs(row["cat"]["grad_norm"] - ref)
                            if (ok_cat and ref is not None) else None)
    append_row(row)

    cams = (row.get("cat") or {}).get("grad_ms")
    qms = (row.get("qulacs") or {}).get("grad_ms")
    wms_ = (row.get("sf_wheel") or {}).get("grad_ms")
    part = f"[adj] n={n:2d} L={L}  P={P:2d} | cat {_fmt(cams)}ms | sf_ir(rust) "
    part += f"{_fmt((row.get('sf_ir_rust') or {}).get('grad_ms'))}ms | wheel {_fmt(wms_)} | "
    part += f"qulacs {_fmt(qms)}"
    if cams and qms:
        part += f" | {cams / qms:5.2f}x vs qulacs " + ("WIN" if row["win_cat_vs_qulacs"] else "LOSS")
    if row.get("fd_max_err") is not None:
        part += f" | fd={row['fd_max_err']:.2e}"
    if row.get("ref_norm_diff") is not None:
        part += f" | |g|-ref={row['ref_norm_diff']:.2e}"
    if row.get("parity_cat_vs_qulacs") is not None:
        part += f" | par(cat,qul)={row['parity_cat_vs_qulacs']:.2e}"
    print(part, flush=True)

adj_done = [r for r in rows if r.get("section") == "adj"]
wq = sum(1 for r in adj_done if r.get("win_cat_vs_qulacs"))
wi = sum(1 for r in adj_done if r.get("win_cat_vs_sfir"))
print(f"\nsection adj complete: {len(adj_done)} rows | cat beats qulacs {wq}/{len(adj_done)}, "
      f"sf_ir(rust) {wi}/{len(adj_done)} -> {ROWS_JSONL.name}")''')

md(r'''## Section 3 — dm (sf-ir density-matrix engine vs aer)

**Disclosure first:** cat's own `Mode::Dm` is a **deliberate, documented hold-out**
in `plan.rs` — a feasibility probe measured a statistical tie with the routed
aer path, so per the campaign's keep-only-if-win rule it stays an explicit
non-silent error rather than a shipped mode. This section therefore benches the
**sf-ir `QuantumDAG::simulate_dm`** engine through the same `l1_bench` binary
(`"mode":"dm"`, new additive lane) against **aer `density_matrix`** (R11 recipe
verbatim). It is an sf-ir result — disclosed, never reframed as a cat-mode win.

Noiseless brick depth-8 ladder n = 8/10/12 (the R6/R8 rows; R8's AVX2
`dm_2q_fused` put sf-ir ≈1.39x behind aer at n=12). Per rung: two rust windows
(interleaved dm/sv medians inside one process + cold = build + first
`simulate_dm` in one region) and two aer windows (warm-excluded median of 5).

Correctness gates, layout-invariant: `trace(rho)` ~ 1, purity `Tr rho^2` ~ 1,
and the rho diagonal equals `|psi|^2` elementwise (both engines, read from the
engine-order buffer / aer result). A pure unitary maps to `rho = |psi><psi|`,
so any wrong index order in either engine would fail these gates loudly.''')

code(r'''# ==== RUN section 3 — dm ====
for n in GRID["dm_ns"]:
    ykey = f"dm:n{n}"
    if ykey in done:
        print(f"[dm] n={n:2d} | cached (cfg {CFG_HASH})", flush=True)
        continue
    ops = brick_ops(n, GRID["depth"])
    if CAT_OK:
        r1 = _safe(rust_dm_lane, ops, n, GRID["reps"], "w1")
        r2 = _safe(rust_dm_lane, ops, n, GRID["reps"], "w2")
    else:
        r1 = r2 = {"status": "not_available",
                   "note": "l1_bench example binary not present on this host"}
    a1 = _safe(aer_dm_window, ops, n, GRID["aer_dm_reps"], GRID["budget"])
    a2 = _safe(aer_dm_window, ops, n, GRID["aer_dm_reps"], GRID["budget"])

    ok_r = all(isinstance(x, dict) and x.get("mode") == "dm" for x in (r1, r2))
    ok_a = all(isinstance(x, dict) and "dm_ms" in x for x in (a1, a2))
    row = {"section": "dm", "ykey": ykey, "n": n, "circuit": "brick",
           "depth": GRID["depth"], "ops_len": len(ops), "reps": GRID["reps"],
           "cfg_hash": CFG_HASH}
    if ok_r:
        rust = combine(r1, r2, ["cold_ms", "build_ms", "dm_ms", "sv_ms"])
        rust["trace"] = r2["trace"]
        rust["purity"] = r2["purity"]
        rust["prob_match"] = bool(r1["prob_match"] and r2["prob_match"])
        rust["max_diag_diff"] = max(r1["max_diag_diff"], r2["max_diag_diff"])
        rust["engine"] = r2["engine"]
        rust["cat_dm_status"] = r2["cat_dm_status"]
        rust["rayon_threads"] = r2.get("rayon_threads")
        row["rust"] = rust
        row["sf_over_sv"] = (rust["dm_ms"] / rust["sv_ms"]) if rust["sv_ms"] else None
    else:
        bad = r1 if not (isinstance(r1, dict) and r1.get("mode") == "dm") else r2
        row["rust_status"] = (bad.get("status") if isinstance(bad, dict) else "not_available")
    if ok_a:
        aer = combine(a1, a2, ["dm_ms", "first_ms"])
        aer["trace"] = a2["trace"]
        aer["purity"] = a2["purity"]
        aer["prob_match"] = bool(a1["prob_match"] and a2["prob_match"])
        aer["version"] = a2["version"]
        row["aer"] = aer
        if ok_r:
            row["sf_over_aer"] = row["rust"]["dm_ms"] / aer["dm_ms"]
    else:
        bad = a1 if not (isinstance(a1, dict) and "dm_ms" in a1) else a2
        row["aer"] = {"status": (bad.get("status") if isinstance(bad, dict) else "error")}
    append_row(row)

    ru = row.get("rust") or {}
    ar = row.get("aer") or {}
    ratio = row.get("sf_over_aer")
    part = (f"[dm] n={n:2d} | sf-ir dm {_fmt(ru.get('dm_ms'))}ms "
            f"(sv anchor {_fmt(ru.get('sv_ms'))}ms, cold {_fmt(ru.get('cold_ms'))}ms) | "
            f"aer dm {_fmt(ar.get('dm_ms'))}ms")
    if ratio:
        part += f" | sf/aer {ratio:.3f}x"
    if ru:
        part += (f" | trace {ru.get('trace'):.9f} purity {ru.get('purity'):.9f} "
                 f"pmatch {ru.get('prob_match')} maxdiag {ru.get('max_diag_diff'):.1e}")
    print(part, flush=True)

dm_done = [r for r in rows if r.get("section") == "dm"]
print(f"\nsection dm complete: {len(dm_done)} rows -> {ROWS_JSONL.name}")''')

md(r'''## Section 4 — clifford (large-n #1-preserve regime)

`Mode::Cliff` compiles to the **same** Pauli-frame tableau as `Mode::Stab`
(`plan.rs`: "Both modes compile to the same Pauli-frame tableau"), so this
section runs the same `cat_pf` pipeline at the n = 1024/4096 rungs where the
shipped campaign has SF #1 by ~an order of magnitude vs stim (brick 1024:
0.0082 s vs 0.0247 s; brick 4096: 0.0386 s vs 0.287 s; ghz 4096: 0.0046 s vs
0.203 s). Families: ghz, brick and the third-topology randcliff (all three at
4096; ghz/brick also 1024). `stim` is the primary head-to-head; `pl`
(stim-backed `default.clifford`) runs as a secondary lane; `aer`/`cirq` are
capped at 256/64 with probe evidence — `not_run_capped`, never fabricated.

Matching numbers between sections 1 and 4 at equal (circuit, n) are **by
construction** (same pipeline, same seeds, same streams) — they are one lane
measured twice across regimes, not two independent wins.''')

code(r'''# ==== RUN section 4 — clifford ====
for circ, n in GRID["cliff_rungs"]:
    ykey = f"cliff:{circ}:{n}"
    if ykey in done:
        print(f"[cliff] {circ:9s} n={n:5d} | cached (cfg {CFG_HASH})", flush=True)
        continue
    run_tableau_rung("cliff", circ, n)
cliff_done = [r for r in rows if r.get("section") == "cliff"]
print(f"\nsection clifford complete: {len(cliff_done)} rows -> {ROWS_JSONL.name}")''')

code(r'''# ==== Tables + CSVs + summary JSON ====
import pandas as pd

def _cat_ms(r, f):
    return (r.get("cat") or {}).get(f)

def _fir_ms(r, f):
    return (r.get("sf_ir") or {}).get(f)

def _stim_ms(r, f):
    return (r.get("stim") or {}).get(f)

def _comp_ms(r, lane, f):
    return ((r.get("comp") or {}).get(lane) or {}).get(f)

def flatten_tableau(sec):
    recs = []
    for r in [x for x in rows if x.get("section") == sec]:
        recs.append({
            "circuit": r["circuit"], "n": r["n"], "shots": r.get("shots"),
            "gates": r.get("gates"),
            "cat_cold_ms": _cat_ms(r, "cold_ms"), "cat_build_ms": _cat_ms(r, "build_ms"),
            "cat_plan_ms": _cat_ms(r, "plan_ms"), "cat_pack_ms": _cat_ms(r, "pack_ms"),
            "cat_counts_ms": _cat_ms(r, "counts_ms"), "cat_keys": _cat_ms(r, "keys"),
            "sfir_cold_ms": _fir_ms(r, "cold_ms"), "sfir_sample_ms": _fir_ms(r, "sample_ms"),
            "stim_full_ms": _stim_ms(r, "full_ms"), "stim_sample_ms": _stim_ms(r, "sample_ms"),
            "aer_cold_ms": _comp_ms(r, "aer", "cold_ms"), "aer_warm_ms": _comp_ms(r, "aer", "warm_ms"),
            "pl_cold_ms": _comp_ms(r, "pl", "cold_ms"), "pl_warm_ms": _comp_ms(r, "pl", "warm_ms"),
            "cirq_cold_ms": _comp_ms(r, "cirq", "cold_ms"), "cirq_warm_ms": _comp_ms(r, "cirq", "warm_ms"),
            "cirq_status": _comp_ms(r, "cirq", "status"), "cirq_note": _comp_ms(r, "cirq", "note"),
            "beats_available_cold": r.get("beats_available_cold"),
            "beats_available_warm": r.get("beats_available_warm"),
            "cat_status": ("ok" if r.get("cat") else (r.get("cat_status") or "not_available")),
        })
    return recs

df_stab = pd.DataFrame(flatten_tableau("stab"))
df_cliff = pd.DataFrame(flatten_tableau("cliff"))
df_stab.to_csv(OUT / "sfmodes_bench_stab.csv", index=False)
df_cliff.to_csv(OUT / "sfmodes_bench_cliff.csv", index=False)

adj_recs = []
for r in [x for x in rows if x.get("section") == "adj"]:
    adj_recs.append({
        "n": r["n"], "layers": r["layers"], "p": r["p"],
        "cat_grad_ms": (r.get("cat") or {}).get("grad_ms"),
        "cat_compile_ms": (r.get("cat") or {}).get("compile_ms"),
        "cat_cold_ms": (r.get("cat") or {}).get("cold_ms"),
        "sfir_grad_ms": (r.get("sf_ir_rust") or {}).get("grad_ms"),
        "wheel_grad_ms": (r.get("sf_wheel") or {}).get("grad_ms"),
        "wheel_status": (r.get("sf_wheel") or {}).get("status"),
        "qulacs_grad_ms": (r.get("qulacs") or {}).get("grad_ms"),
        "qulacs_status": (r.get("qulacs") or {}).get("status"),
        "win_cat_vs_qulacs": r.get("win_cat_vs_qulacs"),
        "win_cat_vs_sfir": r.get("win_cat_vs_sfir"),
        "win_cat_vs_wheel": r.get("win_cat_vs_wheel"),
        "grad_norm": (r.get("cat") or {}).get("grad_norm"),
        "ref_norm_diff": r.get("ref_norm_diff"),
        "parity_cat_vs_qulacs": r.get("parity_cat_vs_qulacs"),
        "parity_cat_vs_sfir": r.get("parity_cat_vs_sfir"),
        "fd_max_err": r.get("fd_max_err"),
    })
df_adj = pd.DataFrame(adj_recs)
df_adj.to_csv(OUT / "sfmodes_bench_adj.csv", index=False)

dm_recs = []
for r in [x for x in rows if x.get("section") == "dm"]:
    dm_recs.append({
        "n": r["n"], "ops_len": r.get("ops_len"),
        "sf_dm_ms": (r.get("rust") or {}).get("dm_ms"),
        "sf_sv_ms": (r.get("rust") or {}).get("sv_ms"),
        "sf_cold_ms": (r.get("rust") or {}).get("cold_ms"),
        "sf_trace": (r.get("rust") or {}).get("trace"),
        "sf_purity": (r.get("rust") or {}).get("purity"),
        "sf_prob_match": (r.get("rust") or {}).get("prob_match"),
        "sf_max_diag_diff": (r.get("rust") or {}).get("max_diag_diff"),
        "aer_dm_ms": (r.get("aer") or {}).get("dm_ms"),
        "aer_trace": (r.get("aer") or {}).get("trace"),
        "aer_purity": (r.get("aer") or {}).get("purity"),
        "aer_prob_match": (r.get("aer") or {}).get("prob_match"),
        "sf_over_aer": r.get("sf_over_aer"),
        "sf_over_sv": r.get("sf_over_sv"),
    })
df_dm = pd.DataFrame(dm_recs)
df_dm.to_csv(OUT / "sfmodes_bench_dm.csv", index=False)

_ff = lambda v: f"{v:.4g}"
def _show(df, cols, title):
    print(title)
    if len(df):
        keep = [c for c in cols if c in df.columns]
        print(df[keep].to_string(index=False, float_format=_ff))
    else:
        print("(no rows)")
    print()

_show(df_stab, ["circuit", "n", "cat_cold_ms", "sfir_cold_ms", "stim_full_ms", "aer_cold_ms", "pl_cold_ms", "cirq_cold_ms"], "== stab: cold (ms) ==")
_show(df_stab, ["circuit", "n", "cat_counts_ms", "sfir_sample_ms", "stim_sample_ms", "aer_warm_ms", "pl_warm_ms", "cirq_warm_ms"], "== stab: warm (ms) ==")
_show(df_stab, ["circuit", "n", "cat_status", "cirq_status", "beats_available_cold", "beats_available_warm"], "== stab: verdicts ==")
_show(df_cliff, ["circuit", "n", "cat_cold_ms", "sfir_cold_ms", "stim_full_ms", "pl_cold_ms"], "== cliff: cold (ms) ==")
_show(df_cliff, ["circuit", "n", "cat_counts_ms", "sfir_sample_ms", "stim_sample_ms", "pl_warm_ms"], "== cliff: warm (ms) ==")
_show(df_cliff, ["circuit", "n", "cat_status", "beats_available_cold", "beats_available_warm"], "== cliff: verdicts ==")
_show(df_adj, ["n", "layers", "cat_grad_ms", "sfir_grad_ms", "wheel_grad_ms", "qulacs_grad_ms", "win_cat_vs_qulacs", "parity_cat_vs_qulacs", "fd_max_err"], "== adjoint ==")
_show(df_dm, ["n", "sf_dm_ms", "sf_sv_ms", "aer_dm_ms", "sf_over_aer", "sf_trace", "sf_purity", "sf_prob_match", "aer_trace", "aer_purity", "aer_prob_match"], "== dm ==")

def _verdicts(sec):
    rs = [r for r in rows if r.get("section") == sec]
    if not rs:
        return {"rows": 0}
    return {
        "rows": len(rs),
        "strict_beats_all_cold": f"{sum(1 for r in rs if r.get('beats_all_cold'))}/{len(rs)}",
        "strict_beats_all_warm": f"{sum(1 for r in rs if r.get('beats_all_warm'))}/{len(rs)}",
        "beats_available_cold": f"{sum(1 for r in rs if r.get('beats_available_cold'))}/{len(rs)}",
        "beats_available_warm": f"{sum(1 for r in rs if r.get('beats_available_warm'))}/{len(rs)}",
    }

adj_rows_ = [r for r in rows if r.get("section") == "adj"]
dm_rows_ = [r for r in rows if r.get("section") == "dm"]
SUMMARY = {
    "generated": time.strftime("%Y-%m-%dT%H:%M:%S"), "host": HOST,
    "exe": str(EXE) if CAT_OK else None, "exe_md5": EXE_MD5, "cfg_hash": CFG_HASH,
    "sections": {"stab": _verdicts("stab"), "cliff": _verdicts("cliff")},
    "adj": {
        "rows": len(adj_rows_),
        "win_vs_qulacs": f"{sum(1 for r in adj_rows_ if r.get('win_cat_vs_qulacs'))}/{len(adj_rows_)}",
        "win_vs_sfir": f"{sum(1 for r in adj_rows_ if r.get('win_cat_vs_sfir'))}/{len(adj_rows_)}",
        "win_vs_wheel": f"{sum(1 for r in adj_rows_ if r.get('win_cat_vs_wheel') is True)}"
                        f"/{sum(1 for r in adj_rows_ if r.get('win_cat_vs_wheel') is not None)}",
        "max_parity_vs_qulacs": (max((r.get("parity_cat_vs_qulacs") or 0.0) for r in adj_rows_)
                                 if adj_rows_ else None),
        "fd_max_err": next((r.get("fd_max_err") for r in adj_rows_
                            if r.get("fd_max_err") is not None), None),
    },
    "dm": {
        "rows": len(dm_rows_),
        "sf_over_aer": {str(r["n"]): r.get("sf_over_aer") for r in dm_rows_},
        "gates": {str(r["n"]): {
            "sf": {"trace": (r.get("rust") or {}).get("trace"),
                   "purity": (r.get("rust") or {}).get("purity"),
                   "prob_match": (r.get("rust") or {}).get("prob_match")},
            "aer": {"trace": (r.get("aer") or {}).get("trace"),
                    "purity": (r.get("aer") or {}).get("purity"),
                    "prob_match": (r.get("aer") or {}).get("prob_match")}}
            for r in dm_rows_},
    },
    "grid": {"stab_rungs": GRID["stab_rungs"], "cliff_rungs": GRID["cliff_rungs"],
             "dm_ns": GRID["dm_ns"], "adj_rows": GRID["adj_rows"],
             "shots": GRID["shots"], "reps": GRID["reps"], "depth": GRID["depth"]},
    "seeds": {"layer": LAYER_SEED, "cliff": CLIFF_SEED, "adj": ADJ_SEED},
    "caps": {"cirq_max_n": GRID["cirq_max_n"], "aer_max_n": GRID["aer_max_n"]},
    "probe_evidence": PROBE_EVIDENCE, "versions": VERSIONS,
    "disclosures": [
        "cat Mode::Stab and Mode::Cliff compile to the SAME Pauli-frame tableau (plan.rs) -- stab and clifford sections measure one pipeline in two n-regimes.",
        "cat Mode::Dm is a documented hold-out (feasibility probe measured a tie with the routed aer path; keep-only-if-win) -- the dm section benches the sf-ir simulate_dm engine through the same binary, never framed as a cat-mode win.",
        "cat_pf = 4-thread RAYON; competitors at shipped defaults; Rust lanes not yet reachable from the Python package (engines compared, not shipped APIs).",
        "Per-lane first-call budget 40 s (over = over_budget, unranked); cirq capped n<=64, stabilizer aer capped n<=256 with probe evidence; capped = not_run_capped, never fabricated.",
        "GHZ rungs must sample only the all-0/all-1 branches (ghz_ok, validated live).",
    ],
}
(OUT / "sfmodes_bench_summary.json").write_text(json.dumps(SUMMARY, indent=2), encoding="utf-8")
print("verdicts:", json.dumps({"stab": SUMMARY["sections"]["stab"], "cliff": SUMMARY["sections"]["cliff"],
                               "adj": SUMMARY["adj"], "dm": SUMMARY["dm"]["sf_over_aer"]}, default=str))
print("wrote:", "sfmodes_bench_stab.csv", "+", "sfmodes_bench_cliff.csv", "+",
      "sfmodes_bench_adj.csv", "+", "sfmodes_bench_dm.csv", "+", "sfmodes_bench_summary.json")''')

code(r'''# ==== Figures (png files + inline display) ====
try:
    import warnings
    warnings.filterwarnings("ignore")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from IPython.display import Image, display

    fig_paths = []

    def _save(fig, name):
        p = OUT / "figs" / name
        fig.tight_layout()
        fig.savefig(p, dpi=140)
        display(Image(str(p)))
        plt.close(fig)
        fig_paths.append(p)

    def _num(v):
        return v if isinstance(v, (int, float)) else float("nan")

    # ---- section 1 (stab): cold + warm grouped bars, warm ratio vs stim ----
    st = [r for r in rows if r.get("section") == "stab"]
    if st:
        labels = [f"{r['circuit']} {r['n']}" for r in st]
        lanes = ["cat_pf", "stim", "aer", "pl", "cirq"]

        def _v(r, lane, kind):
            if lane == "cat_pf":
                return (r.get("cat") or {}).get("cold_ms" if kind == "cold" else "counts_ms")
            if lane == "stim":
                return (r.get("stim") or {}).get("full_ms" if kind == "cold" else "sample_ms")
            return _comp_ms(r, lane, "cold_ms" if kind == "cold" else "warm_ms")

        for kind, fname in (("cold", "fig_stab_cold_ms.png"),
                            ("warm", "fig_stab_warm_ms.png")):
            x = np.arange(len(labels))
            w = 0.16
            fig, ax = plt.subplots(figsize=(12, 5))
            for i, lane in enumerate(lanes):
                vals = [_num(_v(r, lane, kind)) for r in st]
                ax.bar(x + (i - 2) * w, vals, w, label=lane)
            ax.set_yscale("log")
            ax.set_xticks(x)
            ax.set_xticklabels(labels, rotation=15)
            ax.set_ylabel(f"{kind} time (ms, log)")
            ax.set_title(f"Section 1 stab — {kind} (missing bar = capped / not available)")
            ax.legend(ncol=5, fontsize=9)
            ax.grid(axis="y", alpha=0.3)
            _save(fig, fname)

        ratios = []
        for r in st:
            c = (r.get("cat") or {}).get("counts_ms")
            s = (r.get("stim") or {}).get("sample_ms")
            ratios.append((s / c) if (c and s) else float("nan"))
        fig, ax = plt.subplots(figsize=(12, 4))
        ax.bar(np.arange(len(labels)), ratios, 0.5)
        ax.axhline(1.0, color="k", lw=0.8)
        ax.set_xticks(np.arange(len(labels)))
        ax.set_xticklabels(labels, rotation=15)
        ax.set_ylabel("stim / cat speed-up (warm; >1 = cat faster)")
        ax.set_title("Section 1 stab — warm ratio vs stim")
        ax.grid(axis="y", alpha=0.3)
        _save(fig, "fig_stab_warm_ratio_vs_stim.png")

    # ---- section 2 (adjoint): per-row bars ----
    aj = [r for r in rows if r.get("section") == "adj"]
    if aj:
        labels = [f"n{r['n']}L{r['layers']}" for r in aj]
        series = [
            ("cat (rust)", [(r.get("cat") or {}).get("grad_ms") for r in aj]),
            ("wheel (py)", [(r.get("sf_wheel") or {}).get("grad_ms") for r in aj]),
            ("qulacs (py)", [(r.get("qulacs") or {}).get("grad_ms") for r in aj]),
        ]
        x = np.arange(len(labels))
        w = 0.27
        fig, ax = plt.subplots(figsize=(12, 4.5))
        for i, (lab, vals) in enumerate(series):
            ax.bar(x + (i - 1) * w, [_num(v) for v in vals], w, label=lab)
        ax.set_yscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=15)
        ax.set_ylabel("grad median (ms, log)")
        ax.set_title("Section 2 adjoint — per-row grad time")
        ax.legend(fontsize=9)
        ax.grid(axis="y", alpha=0.3)
        _save(fig, "fig_adj_grad_ms.png")

    # ---- section 3 (dm): per-n bars + sf/aer ratio text ----
    dm = [r for r in rows if r.get("section") == "dm"]
    if dm:
        labels = [f"n={r['n']}" for r in dm]
        series = [
            ("sf-ir dm (rust)", [(r.get("rust") or {}).get("dm_ms") for r in dm]),
            ("sf-ir sv anchor", [(r.get("rust") or {}).get("sv_ms") for r in dm]),
            ("aer dm", [(r.get("aer") or {}).get("dm_ms") for r in dm]),
        ]
        x = np.arange(len(labels))
        w = 0.27
        fig, ax = plt.subplots(figsize=(9, 4.5))
        for i, (lab, vals) in enumerate(series):
            ax.bar(x + (i - 1) * w, [_num(v) for v in vals], w, label=lab)
        ax.set_yscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_ylabel("median time (ms, log)")
        ax.set_title("Section 3 dm — sf-ir simulate_dm vs sv anchor vs aer (brick depth-8)")
        for i, r in enumerate(dm):
            ration = r.get("sf_over_aer")
            if ration:
                ax.text(x[i], ax.get_ylim()[0] * 1.6, f"sf/aer {ration:.2f}x",
                        ha="center", fontsize=8)
        ax.legend(fontsize=9)
        ax.grid(axis="y", alpha=0.3)
        _save(fig, "fig_dm_ms.png")

    # ---- section 4 (clifford): cold+warm ratio vs stim ----
    cf = [r for r in rows if r.get("section") == "cliff"]
    if cf:
        labels = [f"{r['circuit']} {r['n']}" for r in cf]
        rc, rw = [], []
        for r in cf:
            c = (r.get("cat") or {}).get("cold_ms")
            s = (r.get("stim") or {}).get("full_ms")
            rc.append((s / c) if (c and s) else float("nan"))
            cw = (r.get("cat") or {}).get("counts_ms")
            sw = (r.get("stim") or {}).get("sample_ms")
            rw.append((sw / cw) if (cw and sw) else float("nan"))
        x = np.arange(len(labels))
        w = 0.35
        fig, ax = plt.subplots(figsize=(12, 4.5))
        ax.bar(x - w / 2, rc, w, label="cold: stim/cat")
        ax.bar(x + w / 2, rw, w, label="warm: stim/cat")
        ax.axhline(1.0, color="k", lw=0.8)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=15)
        ax.set_ylabel("speed-up (>1 = cat faster)")
        ax.set_title("Section 4 clifford — stim/cat speed-up (large-n regime)")
        ax.legend(fontsize=9)
        ax.grid(axis="y", alpha=0.3)
        _save(fig, "fig_cliff_ratio_vs_stim.png")

    print("figures saved:", [p.name for p in fig_paths])
except Exception as e:
    print("figures skipped:", type(e).__name__, e)''')

code(r'''# ==== Report (report.md) ====
def _md_table(cols, headers, recs_, float_fmt=".4g"):
    lines = ["| " + " | ".join(headers) + " |", "|" + "---|" * len(headers)]
    for r in recs_:
        cells = []
        for c in cols:
            v = r.get(c)
            if isinstance(v, bool):
                cells.append("yes" if v else "no")
            elif isinstance(v, float):
                cells.append(f"{v:{float_fmt}}")
            elif v is None:
                cells.append("—")
            else:
                cells.append(str(v))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)

rep = []
rep.append("# sf execution-modes benchmark — stab / adjoint / dm / clifford\n")
rep.append(f"Generated {SUMMARY['generated']} on host **{HOST}** — cfg `{CFG_HASH}`, "
           f"l1_bench md5 `{EXE_MD5}`, shots={GRID['shots']}, depth={GRID['depth']}, "
           f"seeds L{LAYER_SEED}/C{CLIFF_SEED}/A{ADJ_SEED}.\n")
rep.append("One notebook, four sections. Every number is a same-window, warm-pass-"
           "excluded median from THIS run (ABBA-ordered per rung, window mean); no "
           "competitor is ranked on a fabricated or extrapolated row.\n")

rep.append("\n## Section 1 — stab (small/mid n, full competitor field)\n")
rep.append("Verdicts (vs stim/aer/pl/cirq): strict beats ALL (incl. capped) cold "
           f"**{SUMMARY['sections']['stab'].get('strict_beats_all_cold', '—')}**, warm "
           f"**{SUMMARY['sections']['stab'].get('strict_beats_all_warm', '—')}**; beats every "
           f"lane that produced data: cold **{SUMMARY['sections']['stab'].get('beats_available_cold', '—')}**, "
           f"warm **{SUMMARY['sections']['stab'].get('beats_available_warm', '—')}** (ABBA order, "
           "cat_pf 4-thread RAYON, competitors shipped defaults).\n")
if len(df_stab):
    rep.append("\nCold (ms):\n\n" + _md_table(
        ["circuit", "n", "cat_cold_ms", "sfir_cold_ms", "stim_full_ms", "aer_cold_ms", "pl_cold_ms", "cirq_cold_ms"],
        ["circuit", "n", "cat_pf cold", "sf-ir cold", "stim full", "aer cold", "pl cold", "cirq cold"],
        df_stab.to_dict("records")))
    rep.append("\n\nWarm (ms):\n\n" + _md_table(
        ["circuit", "n", "cat_counts_ms", "sfir_sample_ms", "stim_sample_ms", "aer_warm_ms", "pl_warm_ms", "cirq_warm_ms"],
        ["circuit", "n", "cat_pf counts", "sf-ir sample", "stim sample", "aer warm", "pl warm", "cirq warm"],
        df_stab.to_dict("records")))
    over_st = [r for r in df_stab.to_dict("records") if r.get("cirq_status") not in (None, "ok")]
    rep.append("\n\nCirq-lane non-ok rows (guard results, not failures): "
               + ("; ".join(f"{r['circuit']} n={r['n']}: `{r['cirq_status']}`" for r in over_st) if over_st else "(none)")
               + "\n")

rep.append("\n## Section 2 — adjoint (compile-once handle)\n")
rep.append(f"Verdicts: cat beats qulacs **{SUMMARY['adj']['win_vs_qulacs']}** rows, "
           f"sf_ir(rust) **{SUMMARY['adj']['win_vs_sfir']}**, shipped wheel "
           f"**{SUMMARY['adj']['win_vs_wheel']}** (rows where wheel loaded). "
           f"max |cat-qulacs| grad diff {SUMMARY['adj']['max_parity_vs_qulacs']}; "
           f"FD arbiter (n=8 L=1) max err {SUMMARY['adj']['fd_max_err']}.\n")
if len(df_adj):
    rep.append("\n| n | L | P | cat grad ms | cat compile ms | sf-ir grad ms | wheel ms | qulacs ms | win vs qulacs | parity cat/qulacs | \\|g\\| ref diff |")
    rep.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in df_adj.to_dict("records"):
        def _f(v, fmt=".4g"):
            return "—" if v is None else f"{v:{fmt}}"
        rep.append(f"| {r['n']} | {r['layers']} | {r['p']} | {_f(r['cat_grad_ms'])} | "
                   f"{_f(r['cat_compile_ms'])} | {_f(r['sfir_grad_ms'])} | {_f(r['wheel_grad_ms'])} | "
                   f"{_f(r['qulacs_grad_ms'])} | {'yes' if r['win_cat_vs_qulacs'] else ('no' if r['win_cat_vs_qulacs'] is not None else '—')} | "
                   f"{_f(r['parity_cat_vs_qulacs'], '.2e')} | {_f(r['ref_norm_diff'], '.2e')} |")
    rep.append("")
rep.append("Protocol: two interleaved windows cat/qulacs/wheel per row, mean of medians; "
           "cat compile-once build OUTSIDE the timed region (compile_ms reported); qulacs "
           "d/dtheta = -backprop (theta=-phi compensation, probe-verified 2.7e-11 vs FD); "
           "wheel lane fail-soft (environment-dependent).\n")

rep.append("\n## Section 3 — dm (sf-ir simulate_dm vs aer density_matrix)\n")
rep.append("**Disclosure (critical):** cat's `Mode::Dm` is a documented, deliberate "
           "hold-out in the cat crate — the plan records that a feasibility probe "
           "measured a statistical tie with the routed aer path, so per keep-only-if-win "
           "it stays an explicit non-silent error. This section therefore measures the "
           "**sf-ir** `QuantumDAG::simulate_dm` engine through the same l1_bench binary "
           "(`\"mode\":\"dm\"`, added additively for this suite). It is an sf-ir result, "
           "disclosed as such, never reframed as a cat-mode win. R8 context: the AVX2 "
           "`dm_2q_fused` kernel had narrowed aer's n=12 lead to ~1.39x.\n")
if len(df_dm):
    rep.append("\n" + _md_table(
        ["n", "sf_dm_ms", "sf_sv_ms", "aer_dm_ms", "sf_over_aer", "sf_trace", "sf_purity", "sf_prob_match", "aer_trace", "aer_purity", "aer_prob_match"],
        ["n", "sf-ir dm ms", "sf-ir sv anchor ms", "aer dm ms", "sf/aer", "sf trace", "sf purity", "sf pmatch", "aer trace", "aer purity", "aer pmatch"],
        df_dm.to_dict("records")) + "\n")
rep.append("Gates are layout-invariant: trace(rho) ~ 1, purity Tr rho^2 ~ 1, rho diagonal "
           "== |psi|^2 elementwise (engine-order buffer for sf-ir; aer result for aer). "
           f"sf-ir gate margin (max diag diff): "
           + ", ".join(f"n={r['n']}: {r['sf_max_diag_diff']:.1e}" for r in df_dm.to_dict("records"))
           + ".\n")

rep.append("\n## Section 4 — clifford (large-n #1-preserve regime)\n")
rep.append("`Mode::Cliff` compiles to the SAME Pauli-frame tableau as `Mode::Stab` "
           "(plan.rs) — this section is that one pipeline at n=1024/4096, where the "
           "shipped campaign recorded SF #1 by ~an order of magnitude vs stim. "
           "Matching numbers between sections 1 and 4 at equal (circuit,n) are by "
           "construction.\n")
rep.append(f"Verdicts vs stim/aer/pl/cirq: strict cold "
           f"**{SUMMARY['sections']['cliff'].get('strict_beats_all_cold', '—')}**, warm "
           f"**{SUMMARY['sections']['cliff'].get('strict_beats_all_warm', '—')}**; beats "
           f"available cold **{SUMMARY['sections']['cliff'].get('beats_available_cold', '—')}**, "
           f"warm **{SUMMARY['sections']['cliff'].get('beats_available_warm', '—')}**.\n")
if len(df_cliff):
    rep.append("\nCold (ms):\n\n" + _md_table(
        ["circuit", "n", "cat_cold_ms", "sfir_cold_ms", "stim_full_ms", "pl_cold_ms"],
        ["circuit", "n", "cat_pf cold", "sf-ir cold", "stim full", "pl cold"],
        df_cliff.to_dict("records")))
    rep.append("\n\nWarm (ms):\n\n" + _md_table(
        ["circuit", "n", "cat_counts_ms", "sfir_sample_ms", "stim_sample_ms", "pl_warm_ms"],
        ["circuit", "n", "cat_pf counts", "sf-ir sample", "stim sample", "pl warm"],
        df_cliff.to_dict("records")))
    rep.append("\n")
    for r in df_cliff.to_dict("records"):
        c = r.get("cat_cold_ms"); s = r.get("stim_full_ms")
        cw = r.get("cat_counts_ms"); sw = r.get("stim_sample_ms")
        if c and s:
            rep.append(f"- {r['circuit']} n={r['n']}: stim/cat cold **{s / c:.2f}x**"
                       + (f", warm **{sw / cw:.2f}x**" if (cw and sw) else "") + "\n")

rep.append("\n## Disclosures (all sections)\n")
for d in SUMMARY["disclosures"]:
    rep.append(f"- {d}\n")
rep.append(f"- versions: {json.dumps(VERSIONS)}\n")
rep.append("\n## Artifacts\n")
rep.append("- `sfmodes_bench.jsonl` raw rows (all four sections) · `sfmodes_bench_stab.csv` / "
           "`sfmodes_bench_cliff.csv` / `sfmodes_bench_adj.csv` / `sfmodes_bench_dm.csv` flattened "
           "tables · `sfmodes_bench_summary.json` verdicts+config+gates · `figs/*.png` figures · "
           "this report.\n")
(OUT / "report.md").write_text("\n".join(rep), encoding="utf-8")
print("report.md written:", len("\n".join(rep)), "bytes")
print("\n".join(rep)[:1500])''')

code(r'''# ==== Package results zip (the deliverable this notebook produces) ====
from IPython.display import FileLink, display

ZIP = HERE / f"sfmodes_bench_results_{HOST}.zip"
summary = json.loads((OUT / "sfmodes_bench_summary.json").read_text(encoding="utf-8"))
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(OUT.rglob("*")):
        if f.is_file():
            z.write(f, str(f.relative_to(HERE)))
    z.writestr("README_RESULTS.txt", (
        "sf execution-modes benchmark results bundle (stab / adjoint / dm / clifford)\n"
        "===========================================================================\n"
        "sfmodes_bench_out/sfmodes_bench.jsonl          raw rows (all four sections, per-section keys)\n"
        "sfmodes_bench_out/sfmodes_bench_stab.csv       section 1 table (ghz/brick/randcliff vs stim/aer/pl/cirq)\n"
        "sfmodes_bench_out/sfmodes_bench_cliff.csv      section 4 table (large-n regime)\n"
        "sfmodes_bench_out/sfmodes_bench_adj.csv        section 2 table (cat vs qulacs/wheel/sf-ir + gates)\n"
        "sfmodes_bench_out/sfmodes_bench_dm.csv         section 3 table (sf-ir dm vs sv anchor vs aer + gates)\n"
        "sfmodes_bench_out/sfmodes_bench_summary.json   verdicts + config + gates + versions + disclosures\n"
        "sfmodes_bench_out/report.md                    full report (four sections + disclosures)\n"
        "sfmodes_bench_out/figs/*.png                   figures\n"
        "Disclosures: cat Mode::Stab/Cliff = ONE Pauli-frame tableau pipeline (plan.rs);\n"
        "cat Mode::Dm is a documented hold-out -- the dm section benches the sf-ir\n"
        "simulate_dm engine through the same l1_bench binary, disclosed, never reframed\n"
        "as a cat-mode win.\n"
        "Regenerate: open _sfmodes_bench.ipynb (Colab/Jupyter) and Run All; the last cell re-creates this zip.\n"
        "Outputs only: run _sfmodes_bench_pack.py after saving to ship the executed notebook.\n"))
    z.writestr("run_summary.json", json.dumps(summary, indent=2))
# A cell cannot embed its own outputs, so this archive holds outputs only by design.
# _sfmodes_bench_pack.py runs after the kernel saves the notebook and packs the
# deliverable that carries it -- the same split the MPS/MCM bundle cell uses.
print(f"results zip: {ZIP.name}  {ZIP.stat().st_size // 1024} KB")
print("NOTE: this zip holds outputs only -- the on-disk notebook does not yet carry")
print("      this cell's outputs. Run _sfmodes_bench_pack.py after saving to pack")
print("      SF_MODES_Benchmark.ipynb (every cell's output) alongside these files.")
print("bundled:", ", ".join(sorted(p.relative_to(HERE).as_posix() for p in OUT.rglob("*") if p.is_file())))
_dist = HERE.parent / "_dist"
if _dist.is_dir():
    shutil.copy2(ZIP, _dist / ZIP.name)
    print("mirrored to:", _dist / ZIP.name)
display(FileLink(ZIP.name))
print("DONE — open _sfmodes_bench.ipynb in Colab to view all outputs as executed, or re-run to reproduce.")''')

code(r'''# ==== Colab note ====
print("On Colab the rust lanes report not_available unless L1_BENCH_EXE (or ./l1_bench) "
      "points at a built binary; competitor lanes and all tables/report still run. "
      "To reproduce fully, build: cargo build --release -p sf-cat --example l1_bench")''')


def main():
    import nbformat
    nb = nbformat.v4.new_notebook()
    for c in CELLS:
        if c["cell_type"] == "markdown":
            nb.cells.append(nbformat.v4.new_markdown_cell(c["source"]))
        else:
            nb.cells.append(nbformat.v4.new_code_cell(c["source"]))
    nb.metadata["kernelspec"] = {"display_name": "sfdev", "language": "python",
                                "name": "sfdev"}
    nb.metadata["language_info"] = {"name": "python"}
    nbformat.write(nb, str(NB))
    print(f"wrote {NB.name}: {len(nb.cells)} cells")


if __name__ == "__main__":
    main()
