# sf execution-modes benchmark — stab / adjoint / dm / clifford

Generated 2026-10-12T17:43:15 on host **laptop-l5lb07gu** — cfg `3b88281923`, l1_bench md5 `c0c9679b215e`, shots=2000, depth=8, seeds L11/C7/A7.

One notebook, four sections. Every number is a same-window, warm-pass-excluded median from THIS run (ABBA-ordered per rung, window mean); no competitor is ranked on a fabricated or extrapolated row.


## Section 1 — stab (small/mid n, full competitor field)

Verdicts (vs stim/aer/pl/cirq): strict beats ALL (incl. capped) cold **1/6**, warm **1/6**; beats every lane that produced data: cold **2/6**, warm **5/6** (ABBA order, cat_pf 4-thread RAYON, competitors shipped defaults).


Cold (ms):

| circuit | n | cat_pf cold | sf-ir cold | stim full | aer cold | pl cold | cirq cold |
|---|---|---|---|---|---|---|---|
| ghz | 64 | 0.2255 | 0.38 | 0.4263 | 224.9 | 16.31 | 2.769e+04 |
| ghz | 256 | 1.274 | 1.786 | 2.23 | 4661 | 52.76 | nan |
| brick | 64 | 2.027 | 2.06 | 0.3666 | 294.5 | 55.57 | nan |
| brick | 256 | 9.047 | 9.024 | 2.648 | 3626 | 381.9 | nan |
| randcliff | 256 | 11.47 | 8.467 | 3.654 | 7534 | 180.9 | nan |
| randcliff | 1024 | 210 | 188.9 | 54.92 | nan | 746.5 | nan |


Warm (ms):

| circuit | n | cat_pf counts | sf-ir sample | stim sample | aer warm | pl warm | cirq warm |
|---|---|---|---|---|---|---|---|
| ghz | 64 | 0.06543 | 0.1865 | 0.3435 | 232.9 | 11.99 | 2.553e+04 |
| ghz | 256 | 0.2036 | 0.3565 | 2.058 | 4817 | 52.02 | nan |
| brick | 64 | 0.5228 | 0.8207 | 0.2366 | 270.6 | 54.26 | nan |
| brick | 256 | 2.008 | 1.475 | 2.114 | 3419 | 237.7 | nan |
| randcliff | 256 | 1.512 | 1.564 | 2.112 | 7432 | 125.3 | nan |
| randcliff | 1024 | 3.986 | 4.639 | 10.56 | nan | 661 | nan |


Cirq-lane non-ok rows (guard results, not failures): ghz n=256: `not_run_capped`; brick n=64: `over_budget`; brick n=256: `not_run_capped`; randcliff n=256: `not_run_capped`; randcliff n=1024: `not_run_capped`


## Section 2 — adjoint (compile-once handle)

Verdicts: cat beats qulacs **10/10** rows, sf_ir(rust) **9/10**, shipped wheel **9/10** (rows where wheel loaded). max |cat-qulacs| grad diff 2.8171909249863347e-15; FD arbiter (n=8 L=1) max err 3.9036898713540324e-11.


| n | L | P | cat grad ms | cat compile ms | sf-ir grad ms | wheel ms | qulacs ms | win vs qulacs | parity cat/qulacs | \|g\| ref diff |
|---|---|---|---|---|---|---|---|---|---|---|
| 6 | 1 | 12 | 0.0184 | 0.04255 | 0.08235 | 0.1553 | 0.0739 | yes | 4.44e-16 | nan |
| 8 | 1 | 16 | 0.04165 | 0.0563 | 0.1697 | 0.3175 | 0.2203 | yes | 4.44e-16 | 8.83e-10 |
| 10 | 1 | 20 | 0.252 | 0.2064 | 0.4396 | 0.6292 | 0.3196 | yes | 3.89e-16 | nan |
| 12 | 1 | 24 | 0.6909 | 0.6925 | 1.518 | 1.653 | 181.7 | yes | 1.51e-16 | nan |
| 14 | 1 | 28 | 5.301 | 3.699 | 7.995 | 9.057 | 102.8 | yes | 2.50e-16 | nan |
| 16 | 1 | 32 | 19.82 | 15.88 | 27.45 | 26.55 | 23.17 | yes | 2.78e-16 | nan |
| 18 | 1 | 36 | 191.3 | 63.93 | 163.9 | 174.1 | 245 | yes | 1.29e-15 | nan |
| 20 | 1 | 40 | 923.8 | 363.9 | 1093 | 1097 | 1264 | yes | 2.82e-15 | nan |
| 8 | 2 | 32 | 0.0855 | 0.164 | 0.2129 | 0.4131 | 0.2176 | yes | 1.67e-16 | 8.90e-08 |
| 8 | 4 | 64 | 0.1485 | 0.08495 | 0.5326 | 0.7487 | 0.3698 | yes | 1.40e-16 | 3.36e-07 |

Protocol: two interleaved windows cat/qulacs/wheel per row, mean of medians; cat compile-once build OUTSIDE the timed region (compile_ms reported); qulacs d/dtheta = -backprop (theta=-phi compensation, probe-verified 2.7e-11 vs FD); wheel lane fail-soft (environment-dependent).


## Section 3 — dm (sf-ir simulate_dm vs aer density_matrix)

**Disclosure (critical):** cat's `Mode::Dm` is a documented, deliberate hold-out in the cat crate — the plan records that a feasibility probe measured a statistical tie with the routed aer path, so per keep-only-if-win it stays an explicit non-silent error. This section therefore measures the **sf-ir** `QuantumDAG::simulate_dm` engine through the same l1_bench binary (`"mode":"dm"`, added additively for this suite). It is an sf-ir result, disclosed as such, never reframed as a cat-mode win. R8 context: the AVX2 `dm_2q_fused` kernel had narrowed aer's n=12 lead to ~1.39x.


| n | sf-ir dm ms | sf-ir sv anchor ms | aer dm ms | sf/aer | sf trace | sf purity | sf pmatch | aer trace | aer purity | aer pmatch |
|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 28.42 | 0.5535 | 49.22 | 0.5775 | 1 | 1 | yes | 1 | 1 | yes |
| 10 | 815.9 | 1.459 | 659.1 | 1.238 | 1 | 1 | yes | 1 | 1 | no |
| 12 | 1.424e+04 | 2.728 | 9193 | 1.549 | 1 | 1 | yes | 1 | 1 | yes |

Gates are layout-invariant: trace(rho) ~ 1, purity Tr rho^2 ~ 1, rho diagonal == |psi|^2 elementwise (engine-order buffer for sf-ir; aer result for aer). sf-ir gate margin (max diag diff): n=8: 4.3e-19, n=10: 2.2e-19, n=12: 0.0e+00.


## Section 4 — clifford (large-n #1-preserve regime)

`Mode::Cliff` compiles to the SAME Pauli-frame tableau as `Mode::Stab` (plan.rs) — this section is that one pipeline at n=1024/4096, where the shipped campaign recorded SF #1 by ~an order of magnitude vs stim. Matching numbers between sections 1 and 4 at equal (circuit,n) are by construction.

Verdicts vs stim/aer/pl/cirq: strict cold **0/5**, warm **0/5**; beats available cold **2/5**, warm **5/5**.


Cold (ms):

| circuit | n | cat_pf cold | sf-ir cold | stim full | pl cold |
|---|---|---|---|---|---|
| ghz | 1024 | 8.678 | 14.1 | 13.83 | 355.9 |
| ghz | 4096 | 116.2 | 245.5 | 149.6 | 3524 |
| brick | 1024 | 119.2 | 139.9 | 20.37 | 1190 |
| brick | 4096 | 2106 | 2122 | 231.2 | 7231 |
| randcliff | 4096 | 9397 | 1.254e+04 | 4413 | 9547 |


Warm (ms):

| circuit | n | cat_pf counts | sf-ir sample | stim sample | pl warm |
|---|---|---|---|---|---|
| ghz | 1024 | 0.8224 | 1.135 | 10.75 | 345.8 |
| ghz | 4096 | 2.653 | 4.951 | 76.53 | 3181 |
| brick | 1024 | 4.676 | 4.734 | 14.36 | 1267 |
| brick | 4096 | 17.28 | 18.61 | 93.33 | 6917 |
| randcliff | 4096 | 14.08 | 16.29 | 94.05 | 9599 |


- ghz n=1024: stim/cat cold **1.59x**, warm **13.07x**

- ghz n=4096: stim/cat cold **1.29x**, warm **28.85x**

- brick n=1024: stim/cat cold **0.17x**, warm **3.07x**

- brick n=4096: stim/cat cold **0.11x**, warm **5.40x**

- randcliff n=4096: stim/cat cold **0.47x**, warm **6.68x**


## Disclosures (all sections)

- cat Mode::Stab and Mode::Cliff compile to the SAME Pauli-frame tableau (plan.rs) -- stab and clifford sections measure one pipeline in two n-regimes.

- cat Mode::Dm is a documented hold-out (feasibility probe measured a tie with the routed aer path; keep-only-if-win) -- the dm section benches the sf-ir simulate_dm engine through the same binary, never framed as a cat-mode win.

- cat_pf = 4-thread RAYON; competitors at shipped defaults; Rust lanes not yet reachable from the Python package (engines compared, not shipped APIs).

- Per-lane first-call budget 40 s (over = over_budget, unranked); cirq capped n<=64, stabilizer aer capped n<=256 with probe evidence; capped = not_run_capped, never fabricated.

- GHZ rungs must sample only the all-0/all-1 branches (ghz_ok, validated live).

- versions: {"numpy": "2.5.3", "pandas": "2.3.2", "matplotlib": "3.10.6", "stim": "1.16.0", "qiskit": "2.1.2", "qiskit_aer": "0.17.2", "pennylane": "0.45.0", "cirq": "1.6.1", "qulacs": "0.6.14"}


## Artifacts

- `sfmodes_bench.jsonl` raw rows (all four sections) · `sfmodes_bench_stab.csv` / `sfmodes_bench_cliff.csv` / `sfmodes_bench_adj.csv` / `sfmodes_bench_dm.csv` flattened tables · `sfmodes_bench_summary.json` verdicts+config+gates · `figs/*.png` figures · this report.
