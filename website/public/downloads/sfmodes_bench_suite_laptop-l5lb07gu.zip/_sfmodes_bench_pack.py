"""Package sf execution-modes bench (stab/adjoint/dm/clifford): results zip + suite zip.

Run AFTER the notebook execution finishes:
    python _sfmodes_bench_pack.py

Two auto-detected modes:
  * workspace (repo root with nested sf_modes_bench_suite/): refreshes the nested
    folder, then zips it
  * suite    (inside a copied sf_modes_bench_suite/ folder): packs itself

Creates:
  _dist/sfmodes_bench_results_<host>.zip   executed notebook + report + figs + csv/jsonl
                                           (upload the ipynb to Colab: outputs visible)
  _dist/sfmodes_bench_suite[_<host>].zip   the copyable suite folder (scripts + results +
                                           executed notebook)
"""
import json
import pathlib
import shutil
import socket
import zipfile
from collections import Counter
from datetime import datetime

HERE = pathlib.Path(__file__).resolve().parent
HOST = socket.gethostname().split(".")[0].lower()
NB = HERE / "_sfmodes_bench.ipynb"
OUT = HERE / "sfmodes_bench_out"
JSONL = OUT / "sfmodes_bench.jsonl"
DIST = HERE / "_dist"
NESTED = HERE / "sf_modes_bench_suite"
WORKSPACE = NESTED.exists()
SUITE = NESTED if WORKSPACE else HERE
if not WORKSPACE and not ((HERE / "run_notebook.bat").exists()
                          and (HERE / "requirements.txt").exists()):
    raise SystemExit("not a workspace (no sf_modes_bench_suite/) nor a suite folder "
                     "(no run_notebook.bat) - aborting")

# ---- 0) freshness checks -------------------------------------------------
import nbformat

if not NB.exists():
    raise SystemExit(f"missing {NB.name} - build it first (python _sfmodes_bench_build.py)")
nb = nbformat.read(str(NB), as_version=4)
n_out = sum(len(c.get("outputs", [])) for c in nb.cells)
err_cells = sum(1 for c in nb.cells
                if any(o.get("output_type") == "error" for o in c.get("outputs", [])))
rows = [json.loads(l) for l in JSONL.read_text(encoding="utf-8").splitlines()
        if l.strip()] if JSONL.exists() else []
sec_counts = dict(Counter(r.get("section", "?") for r in rows))
verdict = {}
sm_path = OUT / "sfmodes_bench_summary.json"
if sm_path.exists():
    sm = json.loads(sm_path.read_text(encoding="utf-8"))
    verdict = {"sections": sm.get("sections"), "adj": sm.get("adj"),
               "dm_sf_over_aer": (sm.get("dm") or {}).get("sf_over_aer")}
print(f"pack mode: {'workspace' if WORKSPACE else 'suite'} | host: {HOST}")
print(f"notebook: {len(nb.cells)} cells | {n_out} outputs | {err_cells} error cells")
print(f"rows: {len(rows)} {sec_counts} | verdict: {json.dumps(verdict, default=str)[:400]}")
if n_out == 0:
    print("WARNING: notebook has no outputs -- run _sfmodes_bench_exec.py first")
if err_cells:
    print("WARNING: executed notebook has error cells -- inspect before shipping")

summary = {
    "host": HOST,
    "packed_at": datetime.now().isoformat(timespec="seconds"),
    "cells": len(nb.cells), "outputs": n_out, "error_cells": err_cells,
    "rows": len(rows), "section_counts": sec_counts, "verdict": verdict,
}

# ---- 1) results zip (what you open in Colab) -----------------------------
DIST.mkdir(exist_ok=True)
rzip = DIST / f"sfmodes_bench_results_{HOST}.zip"
with zipfile.ZipFile(rzip, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(NB, "SF_MODES_Benchmark.ipynb")
    rp = OUT / "report.md"
    if rp.exists():
        z.write(rp, "report.md")
    for f in sorted(OUT.glob("*.jsonl")) + sorted(OUT.glob("*.csv")) + sorted(OUT.glob("*.json")):
        z.write(f, f"sfmodes_bench_out/{f.name}")
    figs = OUT / "figs"
    if figs.exists():
        for f in sorted(figs.iterdir()):
            if f.is_file():
                z.write(f, f"sfmodes_bench_out/figs/{f.name}")
    z.writestr("run_summary.json", json.dumps(summary, indent=2))
    z.writestr("README_RESULTS.txt", (
        "Open SF_MODES_Benchmark.ipynb in Colab (or Jupyter):\n"
        "all tables, stdout and inline plots are stored in the notebook.\n"
        "sfmodes_bench_out/figs/*.png are the same figures as image files.\n"
        "sfmodes_bench_out/sfmodes_bench.jsonl is the raw row stream (all four sections).\n"
        "sfmodes_bench_out/sfmodes_bench_stab.csv / _cliff.csv / _adj.csv / _dm.csv are the tables.\n"
        "sfmodes_bench_out/sfmodes_bench_summary.json carries verdicts + config + gates + disclosures.\n"
        "report.md is the full report.\n"
        "Disclosure: cat Mode::Stab/Cliff = one Pauli-frame pipeline (plan.rs); cat Mode::Dm is a\n"
        "documented hold-out -- the dm section benches the sf-ir simulate_dm engine, disclosed.\n"
        "Summary: run_summary.json\n"
        "Full reproducible folder: _dist/sfmodes_bench_suite[_<host>].zip.\n"))
print("results zip:", rzip.name, f"{rzip.stat().st_size // 1024} KB")

# ---- 2) suite folder (portable to another desktop) -----------------------
SUITE.mkdir(exist_ok=True)
SUITE_OUT = SUITE / "sfmodes_bench_out"


def portable_copy(src, dst_name=None):
    shutil.copy2(src, SUITE / (dst_name or src.name))


if WORKSPACE:
    shutil.copy2(NB, SUITE / "_sfmodes_bench.ipynb")
    for _tool in ("_sfmodes_bench_build.py", "_sfmodes_bench_exec.py", "_sfmodes_bench_pack.py",
                  "README.md", "requirements.txt", "run_notebook.bat"):
        if (HERE / _tool).exists():
            portable_copy(HERE / _tool)
    if SUITE_OUT.exists():
        shutil.rmtree(SUITE_OUT)
    shutil.copytree(OUT, SUITE_OUT)
else:
    print("suite mode: running inside the suite folder -- files already in place")
(SUITE / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

szip = (DIST / "sfmodes_bench_suite.zip") if WORKSPACE else (DIST / f"sfmodes_bench_suite_{HOST}.zip")
with zipfile.ZipFile(szip, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(SUITE.rglob("*")):
        if not f.is_file():
            continue
        top = f.relative_to(SUITE).parts[0]
        if top in ("_dist", "__pycache__") or top.startswith("_run"):
            continue
        z.write(f, f.relative_to(HERE))
print("suite zip:", szip.name, f"{szip.stat().st_size // 1024} KB")
print("suite folder:", SUITE)
print("PACK_OK")
