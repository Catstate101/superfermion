# sf execution-modes benchmark suite — stab / adjoint / dm / clifford

One self-contained notebook, four sections, all over the SuperFermion Rust
stack via the `sf-cat` release example `l1_bench` (subprocess, 4-thread
RAYON, in-process timing, process startup excluded).

| # | section | Rust lane (l1_bench) | competitors | rungs |
|---|---|---|---|---|
| 1 | stab | default `cat_pf` (FrameTableau — what `Mode::Stab` executes) + `sf_ir` | stim, aer, pl, cirq | ghz/brick 64,256; randcliff 256,1024 |
| 2 | adjoint | `"mode":"adj"` — cat compile-once handle + `sf_ir::adjoint` | qulacs, shipped wheel, FD arbiter | (6..20, L=1) + (8, L=2/4) |
| 3 | dm | `"mode":"dm"` — sf-ir `QuantumDAG::simulate_dm` vs sv engine | aer `density_matrix` | n=8,10,12 |
| 4 | clifford | default `cat_pf` (the same tableau pipeline as `Mode::Cliff`) | stim, pl (aer/cirq capped) | ghz/brick/randcliff 1024,4096 |

Op streams (`ghz`, seeded `brick` depth-8, seeded random-matching `randcliff`)
are bit-identical on every engine (LAYER_SEED=11, CLIFF_SEED=7, ADJ_SEED=7);
2000 shots; ABBA window order per rung; headline = window mean.

## Quick start (Windows / any desktop with the binary)

    python _sfmodes_bench_exec.py _sfmodes_bench.ipynb     # headless execute (~15-25 min)
    python _sfmodes_bench_pack.py                          # results zip + suite zip

or double-click / run:

    run_notebook.bat

## Colab / Jupyter

Open `_sfmodes_bench.ipynb` — all outputs (tables, figures, verdicts) are
already embedded from the executed run. **Run All** to reproduce on your own
host (the notebook pip-installs any missing lane dependency itself):

* competitor lanes (stim / aer / pl / cirq / qulacs) run in-process,
* the Rust lanes need the `l1_bench` release binary — set `L1_BENCH_EXE`
  (default `D:\sf_cat_target\release\examples\l1_bench.exe`); without it the
  Rust rows are recorded as `not_available` and everything else still runs,
* the **last cell** writes `sfmodes_bench_results_<host>.zip` with a download
  link.

## Disclosures (read these)

* `Mode::Stab` and `Mode::Cliff` compile to the **same** Pauli-frame tableau
  (`plan.rs`) — sections 1 and 4 measure that one pipeline in two n-regimes;
  matching numbers across sections at equal (circuit, n) are by construction.
* `Mode::Dm` is a **documented, deliberate hold-out** in the cat crate (the
  plan records a feasibility probe measuring a statistical tie with the routed
  aer path; keep-only-if-win). Section 3 therefore benches the **sf-ir**
  `simulate_dm` engine through the same `l1_bench` binary — an sf-ir result,
  disclosed, never reframed as a cat-mode win.
* `cat_pf` runs 4-thread RAYON; competitors run shipped defaults; the Rust
  lanes are not yet reachable from the Python package (engines compared, not
  shipped APIs).
* Guards: per-lane first-call budget 40 s (`over_budget` = unranked); cirq
  capped n<=64, stabilizer aer capped n<=256 (probe evidence in the summary
  json) — capped = `not_run_capped`, never fabricated.
* DM gates are layout-invariant: trace(rho) ~ 1, purity Tr rho^2 ~ 1, rho
  diagonal == |psi|^2 elementwise (both engines).
* Adjoint: cat compile-once build OUTSIDE the timed region (`compile_ms`
  reported); qulacs d/dtheta = -backprop (probe-verified 2.7e-11 vs FD); FD
  arbiter at (n=8, L=1); six-lane |grad| refs at n=8.

## Artifacts

* `_sfmodes_bench.ipynb` — executed notebook (the primary artifact)
* `sfmodes_bench_out/` — `sfmodes_bench.jsonl` (raw rows), four section CSVs,
  `sfmodes_bench_summary.json`, `report.md`, `figs/*.png`
* `sfmodes_bench_results_<host>.zip` — the results bundle (written by the
  notebook's last cell)
* `_dist/` — pack output: results zip (executed notebook + data) and
  `sfmodes_bench_suite_<host>.zip` (this whole folder, copyable)

## Files

    _sfmodes_bench_build.py    regenerates the notebook
    _sfmodes_bench_exec.py     headless execution (no per-cell timeout)
    _sfmodes_bench_pack.py     results zip + suite folder zip
    requirements.txt           lane dependencies
    run_notebook.bat           one-command execute + pack
