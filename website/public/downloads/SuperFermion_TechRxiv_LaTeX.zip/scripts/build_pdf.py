"""Compile the included scientific manuscript using a standard TeX installation."""
import argparse
from pathlib import Path
import shutil
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--package-dir",type=Path,default=Path(__file__).resolve().parents[1])
parser.add_argument("--output-file",type=Path,default=Path("build/SuperFermion_TechRxiv_Paper.pdf"))
args=parser.parse_args()
package=args.package_dir.resolve()
output=args.output_file.resolve()
output.parent.mkdir(parents=True,exist_ok=True)
for number,command in enumerate([
    ["pdflatex","-interaction=nonstopmode","-halt-on-error","main.tex"],
    ["bibtex","main"],
    ["pdflatex","-interaction=nonstopmode","-halt-on-error","main.tex"],
    ["pdflatex","-interaction=nonstopmode","-halt-on-error","main.tex"],
],1):
    log=package/f"build_pass_{number}.log"
    with log.open("w") as handle:
        result=subprocess.run(command,cwd=package,stdout=handle,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"{command[0]} failed; inspect {log}")
    print(f"Completed {command[0]} pass {number}",flush=True)
shutil.copy2(package/"main.pdf",output)
print(f"Built {output}")
