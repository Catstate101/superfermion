"""Reconcile saved mode results and draw publication figures; no simulator runs."""
from pathlib import Path
from zipfile import ZipFile
from collections import Counter
import argparse, csv, hashlib, json, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.patches import FancyBboxPatch
import numpy as np

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--package-dir',type=Path,default=Path(__file__).resolve().parents[1])
p=parser.parse_args().package_dir.resolve();data=p/'data';figures=p/'figures'
source=p/'source_modes/suite/sfmodes_bench_out'
rows=[json.loads(line) for line in (source/'sfmodes_bench.jsonl').read_text().splitlines() if line.strip()]
summary=json.loads((source/'sfmodes_bench_summary.json').read_text())
assert len(rows)==len({r['ykey'] for r in rows})==24
assert Counter(r['section'] for r in rows)=={'stab':6,'cliff':5,'adj':10,'dm':3}
assert {r['cfg_hash'] for r in rows}=={summary['cfg_hash']}
bysection={s:[r for r in rows if r['section']==s] for s in ['stab','cliff','adj','dm']}
aliases={'cat':'SuperFermion','stim':'Stim','aer':'Qiskit Aer','pl':'PennyLane','cirq':'Cirq','qulacs':'Qulacs'}
fw=['cat','stim','aer','pl','cirq']
colors={'cat':'#151515','stim':'#56B4E9','aer':'#D55E00','pl':'#CC79A7','cirq':'#8a7b22','qulacs':'#0072B2'}
markers={'cat':'*','stim':'s','aer':'^','pl':'v','cirq':'P','qulacs':'o'}
manifest=[];observations=[];tables=[];csv_checks=[]

def get(record,path):
 for key in path.split('.'):
  if not isinstance(record,dict):return None
  record=record.get(key)
 return record

def equal(actual,expected):
 if actual=='':return expected is None
 if isinstance(expected,bool):return actual.lower()==str(expected).lower()
 if isinstance(expected,(int,float)):
  return math.isclose(float(actual),float(expected),rel_tol=2e-12,abs_tol=1e-13)
 return actual==str(expected)

mapping={
 'stab':{'n':'n','shots':'shots','gates':'gates','cat_cold_ms':'cat.cold_ms','cat_build_ms':'cat.build_ms','cat_plan_ms':'cat.plan_ms','cat_pack_ms':'cat.pack_ms','cat_counts_ms':'cat.counts_ms','cat_keys':'cat.keys','sfir_cold_ms':'sf_ir.cold_ms','sfir_sample_ms':'sf_ir.sample_ms','stim_full_ms':'stim.full_ms','stim_sample_ms':'stim.sample_ms','aer_cold_ms':'comp.aer.cold_ms','aer_warm_ms':'comp.aer.warm_ms','pl_cold_ms':'comp.pl.cold_ms','pl_warm_ms':'comp.pl.warm_ms','cirq_cold_ms':'comp.cirq.cold_ms','cirq_warm_ms':'comp.cirq.warm_ms','cirq_status':'comp.cirq.status','beats_available_cold':'beats_available_cold','beats_available_warm':'beats_available_warm'},
 'adj':{'n':'n','layers':'layers','p':'p','cat_grad_ms':'cat.grad_ms','cat_compile_ms':'cat.compile_ms','cat_cold_ms':'cat.cold_ms','sfir_grad_ms':'sf_ir_rust.grad_ms','wheel_grad_ms':'sf_wheel.grad_ms','qulacs_grad_ms':'qulacs.grad_ms','win_cat_vs_qulacs':'win_cat_vs_qulacs','win_cat_vs_sfir':'win_cat_vs_sfir','win_cat_vs_wheel':'win_cat_vs_wheel','grad_norm':'cat.grad_norm','ref_norm_diff':'ref_norm_diff','parity_cat_vs_qulacs':'parity_cat_vs_qulacs','parity_cat_vs_sfir':'parity_cat_vs_sfir','fd_max_err':'fd_max_err'},
 'dm':{'n':'n','ops_len':'ops_len','sf_dm_ms':'rust.dm_ms','sf_sv_ms':'rust.sv_ms','sf_cold_ms':'rust.cold_ms','sf_trace':'rust.trace','sf_purity':'rust.purity','sf_prob_match':'rust.prob_match','sf_max_diag_diff':'rust.max_diag_diff','aer_dm_ms':'aer.dm_ms','aer_trace':'aer.trace','aer_purity':'aer.purity','aer_prob_match':'aer.prob_match','sf_over_aer':'sf_over_aer','sf_over_sv':'sf_over_sv'}}
mapping['cliff']=mapping['stab']
for section in bysection:
 with (source/f'sfmodes_bench_{section}.csv').open(newline='') as handle:flat=list(csv.DictReader(handle))
 assert len(flat)==len(bysection[section])
 for r,flatrow in zip(bysection[section],flat):
  if section in ['stab','cliff']:assert flatrow['circuit']==r['circuit']
  for col,path in mapping[section].items():assert equal(flatrow[col],get(r,path)),(r['ykey'],col,flatrow[col],get(r,path))
 csv_checks.append({'section':section,'rows':len(flat),'checked_fields':len(mapping[section]),'passed':True})

# The nested results ZIP is a second byte-identical copy of the data, not a new study.
nested=p/'source_modes/suite/sfmodes_bench_results_laptop-l5lb07gu.zip'
with ZipFile(nested) as z:
 for file in list(source.glob('*.csv'))+[source/'sfmodes_bench.jsonl',source/'sfmodes_bench_summary.json']:
  matches=[n for n in z.namelist() if n.endswith('/'+file.name) or n==file.name]
  assert len(matches)==1 and z.read(matches[0])==file.read_bytes(),file.name
notebook=json.loads((p/'source_modes/suite/_sfmodes_bench.ipynb').read_text())
errors=[i for i,c in enumerate(notebook['cells']) if any(o.get('output_type')=='error' for o in c.get('outputs',[]))]
assert not errors

def lane(r,key):
 if key=='cat':return {'status':'ok','cold':r['cat']['cold_ms'],'warm':r['cat']['counts_ms'],'reuse':None}
 if key=='stim':return {'status':'ok','cold':r['stim']['full_ms'],'warm':r['stim']['sample_ms'],'reuse':None}
 d=r['comp'][key]
 return {'status':d['status'],'cold':d.get('cold_ms'),'warm':d.get('warm_ms'),'reuse':d.get('reuse_ms')}

def table(label,title,columns,body,note,widths):
 item=dict(type='table',label=label,title=title,columns=columns,rows=body,note=note,widths=widths)
 tables.append(item);return item

def number(v):return 'N/A' if v is None else f'{v:.6g}'
status_labels={'ok':'OK','not_run_capped':'Capped','over_budget':'Budget'}
tableau=bysection['stab']+bysection['cliff'];counts=Counter();wins={}
for r in tableau:
 for key in fw:
  d=lane(r,key);counts[d['status']]+=1
  for field in ['cold','warm']:
   if d['status']=='ok':assert isinstance(d[field],(int,float)) and d[field]>0
  observations.append(dict(condition_id=r['ykey'],section=r['section'],circuit=r['circuit'],n_qubits=r['n'],shots=r['shots'],framework=aliases[key],status=d['status'],cold_ms=d['cold'],warm_ms=d['warm'],extra_reuse_ms=d['reuse'],ram_mib=None))
 body=[[aliases[k],number(lane(r,k)['cold']),number(lane(r,k)['warm']),number(lane(r,k)['reuse']),status_labels[lane(r,k)['status']]] for k in fw]
 table('modes_'+r['ykey'].replace(':','_'),f"{r['circuit'].upper() if r['circuit']=='ghz' else ('Random Clifford' if r['circuit']=='randcliff' else 'Brickwork')} sampling at {r['n']:,} qubits",['Framework','Cold\n(ms)','Warm\n(ms)','Extra reuse\n(ms)','Outcome'],body,'2,000 shots per recorded window. Timings are means of two window medians; cold and warm contracts vary by adapter. Extra reuse is the separately recorded Aer simulator-reuse observation. Capped and budget rows have no assigned time. RAM was not measured.',[1.55,1.0,1.0,1.25,1.7])
 for phase in ['cold','warm']:
  rivals=[lane(r,k)[phase] for k in fw[1:] if lane(r,k)['status']=='ok']
  win=all(lane(r,'cat')[phase]<v for v in rivals)
  assert win==r['beats_available_'+phase]
for section in ['stab','cliff']:
 rr=bysection[section]
 wins[section]={phase:sum(r['beats_available_'+phase] for r in rr) for phase in ['cold','warm']}
 assert wins[section]['cold']==int(summary['sections'][section]['beats_available_cold'].split('/')[0])
 assert wins[section]['warm']==int(summary['sections'][section]['beats_available_warm'].split('/')[0])
assert counts=={'ok':39,'not_run_capped':15,'over_budget':1}

amortization=[]
for r in bysection['adj']:
 g=r['cat']['grad_ms'];c=r['cat']['compile_ms'];q=r['qulacs']['grad_ms']
 assert r['p']==2*r['n']*r['layers'] and 0<g<q
 ratio=q/g;k=math.floor(c/(q-g))+1
 amortization.append(dict(n_qubits=r['n'],layers=r['layers'],parameters=r['p'],sf_gradient_ms=g,sf_compile_ms=c,qulacs_gradient_ms=q,qulacs_over_sf=ratio,estimated_calls_to_amortize=k,max_gradient_difference=r['parity_cat_vs_qulacs']))
 for key,t in [('cat',g),('qulacs',q)]:observations.append(dict(condition_id=r['ykey'],section='adj',n_qubits=r['n'],layers=r['layers'],parameters=r['p'],framework=aliases[key],status='ok',gradient_ms=t,compile_ms=c if key=='cat' else None,ram_mib=None))
 body=[['SuperFermion',number(g),number(c),number(r['parity_cat_vs_qulacs'])],['Qulacs',number(q),'N/A','Reference']]
 table('modes_'+r['ykey'].replace(':','_'),f"Adjoint gradient at {r['n']} qubits and {r['layers']} layer{'s' if r['layers']!=1 else ''}",['Framework','Gradient\n(ms)','Separate compile\n(ms)','Maximum gradient\ndifference'],body,f"P = {r['p']} parameters; observable is the full Z product. SuperFermion uses a compiled handle; construction is outside gradient timing. Qulacs timing includes parameter setters, state preparation, execution and backpropagation. The parity field is the saved component-wise maximum from the retained second comparison window. RAM was not measured.",[1.6,1.2,1.6,2.1])
for r in bysection['dm']:
 assert math.isclose(r['rust']['dm_ms']/r['aer']['dm_ms'],r['sf_over_aer'],rel_tol=1e-14)
 for key,alias in [('rust','SuperFermion'),('aer','Qiskit Aer')]:
  d=r[key];observations.append(dict(condition_id=r['ykey'],section='dm',n_qubits=r['n'],framework=alias,status='ok',dm_ms=d['dm_ms'],trace=d['trace'],purity=d['purity'],diagonal_check=d['prob_match'],ram_mib=None))
 body=[[name,number(r[key]['dm_ms']),number(abs(r[key]['trace']-1)),number(abs(r[key]['purity']-1)),'Pass' if r[key]['prob_match'] else 'Flagged'] for key,name in [('rust','SuperFermion'),('aer','Qiskit Aer')]]
 table('modes_'+r['ykey'].replace(':','_'),f"Density matrix evaluation at {r['n']} qubits",['Framework','Time\n(ms)','Trace deviation','Purity deviation','Diagonal check'],body,'Noiseless depth-eight brickwork. SuperFermion is the native dense-core density-matrix engine, not the held-out density-matrix planner mode. Aer compares diagonals after rounding to eight decimals; the saved SuperFermion flag comes from its native worker. Trace and purity do not establish complete density-matrix equality. The flagged 10-qubit comparison is unranked. RAM was not measured.',[1.55,1.05,1.25,1.25,1.4])
assert len(tables)==24 and len(observations)==81

plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'legend.fontsize':8,'xtick.labelsize':8.5,'ytick.labelsize':8.5,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'grid.color':'#bbbbbb','grid.linewidth':.5})
def save(fig,label,caption):
 for ext in ['pdf','svg','png']:fig.savefig(figures/f'{label}.{ext}',dpi=260,bbox_inches='tight',facecolor='white')
 plt.close(fig);manifest.append(dict(type='figure',label=label,file=f'figures/{label}.pdf',png=f'figures/{label}.png',caption=caption))
labels=[f"{'GHZ' if r['circuit']=='ghz' else ('Random' if r['circuit']=='randcliff' else 'Brick')} {r['n']:,}" for r in tableau]

fig,ax=plt.subplots(figsize=(6.5,2.7));ax.axis('off');ax.set_xlim(0,6.5);ax.set_ylim(0,2.7)
boxes=[(.05,2.1,2.00,'Clifford\ncircuits','Binary stabilizer tableau\nAffine measurement plan\n64-shot sampling lanes'),(2.25,2.1,2.00,'Bounded\nentanglement','MPS canonical tensors\nLocal two-site split\nSequential conditionals'),(4.45,2.1,2.00,'Variational\ncircuits','Dense statevector\nCompiled adjoint handle\nReverse gradient sweep')]
for x,y,w,title,body in boxes:
 ax.add_patch(FancyBboxPatch((x,.75),w,1.55,boxstyle='round,pad=.02',facecolor='#f3f4f5',edgecolor='#8d959d',linewidth=.7))
 ax.text(x+w/2,y,title,ha='center',va='top',fontsize=9,fontweight='bold',linespacing=1.2)
 ax.text(x+w/2,1.45,body,ha='center',va='top',fontsize=8.3,linespacing=1.45)
ax.text(3.25,.26,'Dense density matrices use a separate native-core path',ha='center',fontsize=9)
save(fig,'modes_regimes','Representations associated with the reported execution paths. Stabilizer and Clifford mode labels share one tableau engine; the adjoint handle uses a different statevector path. MPS mechanisms are described in the methods report and are not benchmarked by the new mode suite. The density-matrix observations exercise a separate native-core path.')

fig,axes=plt.subplots(1,2,figsize=(6.5,5.6));norm=LogNorm(vmin=1/16,vmax=524288);cmap=plt.get_cmap('Blues').copy();cmap.set_bad('#e5e7e9')
for ax,phase in zip(axes,['cold','warm']):
 matrix=np.full((len(tableau),4),np.nan)
 for i,r in enumerate(tableau):
  for j,key in enumerate(fw[1:]):
   if lane(r,key)['status']=='ok':matrix[i,j]=lane(r,key)[phase]/lane(r,'cat')[phase]
 im=ax.imshow(np.ma.masked_invalid(matrix),cmap=cmap,norm=norm,aspect='auto')
 for i,r in enumerate(tableau):
  for j,key in enumerate(fw[1:]):
   v=matrix[i,j]
   text=(f'{v/1000:.3g}kx' if v>=1000 else f'{v:.3g}x') if math.isfinite(v) else ('Budget' if lane(r,key)['status']=='over_budget' else 'Capped')
   ax.text(j,i,text,ha='center',va='center',fontsize=8.5,color='white' if math.isfinite(v) and norm(v)>.53 else '#222222')
 ax.set(xticks=range(4),yticks=range(len(tableau)),title='(a) Cold' if phase=='cold' else '(b) Prepared warm')
 ax.set_xticklabels(['Stim','Aer','PennyLane','Cirq'],rotation=45,ha='right')
 ax.set_yticklabels(labels if phase=='cold' else []);ax.grid(False)
fig.subplots_adjust(left=.17,right=.86,wspace=.10,bottom=.19,top=.91)
cax=fig.add_axes([.89,.20,.025,.69]);bar=fig.colorbar(im,cax=cax,ticks=[1/16,1,16,256,4096,65536,524288]);bar.ax.set_yticklabels(['0.0625','1','16','256','4,096','65,536','524,288']);bar.set_label('Comparator / SuperFermion time; log scale',fontsize=8)
save(fig,'modes_tableau_heatmaps','Recorded comparator-to-SuperFermion time ratios for 2,000 shots. Values above one favor SuperFermion; k means one thousand. Both panels use one logarithmic color scale and include every reviewed condition. Gray cells distinguish capped jobs and the recorded budget outcome. Ratios compare the saved output and preparation contracts, with unequal concurrency settings; they are not significance tests.')

fig,axes=plt.subplots(1,2,figsize=(6.5,4.8),sharey=True)
for j,key in enumerate(fw):
 offset=(j-2)*.12
 for ax,phase in zip(axes,['cold','warm']):
  xs=[lane(r,key)[phase] if lane(r,key)['status']=='ok' else np.nan for r in tableau]
  ax.scatter(xs,np.arange(len(tableau))+offset,label=aliases[key],color=colors[key],marker=markers[key],s=27 if key=='cat' else 20)
for ax,phase in zip(axes,['cold','warm']):ax.set(xscale='log',xlabel='Recorded time (ms; log scale)',title='(a) Cold' if phase=='cold' else '(b) Prepared warm',xlim=(.015,70000))
axes[0].invert_yaxis()
axes[0].set_yticks(range(len(tableau)),labels);h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.53,1.035));fig.tight_layout(rect=(0,0,1,.90),w_pad=2)
save(fig,'modes_tableau_times','Cold and prepared warm sampling times for all five included tableau-framework configurations. Discrete conditions use unconnected markers. Missing capped or budget measurements have no plotted time. Cold compilation boundaries and warm output contracts are adapter-specific, as defined in the protocol.')

fig,axes=plt.subplots(1,2,figsize=(6.5,3.2))
for ax,rr,xfield,title in [(axes[0],[r for r in amortization if r['layers']==1],'n_qubits','(a) One layer'),(axes[1],[r for r in amortization if r['n_qubits']==8],'parameters','(b) Eight qubits')]:
 x=[r[xfield] for r in rr]
 for key,col,label in [('cat','sf_gradient_ms','SuperFermion gradient'),('qulacs','qulacs_gradient_ms','Qulacs gradient')]:ax.plot(x,[r[col] for r in rr],color=colors[key],marker=markers[key],lw=1.2,label=label)
 ax.plot(x,[r['sf_compile_ms'] for r in rr],color='#888888',marker='^',ls='--',lw=1.2,label='Separate SF compile')
 ax.set(yscale='log',xticks=x,title=title,xlabel='Qubits' if xfield=='n_qubits' else 'Parameters',ylabel='Time (ms; log scale)')
h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.53,1.04));fig.tight_layout(rect=(0,0,1,.84),w_pad=1.6)
save(fig,'modes_adjoint_scaling','Prepared gradient timings and separately recorded SuperFermion handle-compilation cost. The one-layer grid spans 6 to 20 qubits; the eight-qubit grid has 16, 32 and 64 parameters. Curves connect tested conditions only. Qulacs includes per-call state preparation and backpropagation; SuperFermion construction is outside gradient timing.')

fig,axes=plt.subplots(1,2,figsize=(6.5,4.4),sharey=True);alabels=[f"n={r['n_qubits']}, L={r['layers']}" for r in amortization];y=np.arange(10)
axes[0].scatter([r['qulacs_over_sf'] for r in amortization],y,color=colors['qulacs'],s=25)
axes[0].axvline(1,color='#777777',ls='--',lw=.8);axes[0].set(xscale='log',xlabel='Qulacs / SuperFermion gradient time',title='(a) Prepared-time ratio',xlim=(.8,400))
axes[1].scatter([r['estimated_calls_to_amortize'] for r in amortization],y,color='#151515',marker='*',s=35);axes[1].set(xlim=(0,6),xticks=range(0,7),xlabel='Estimated repeated gradient calls',title='(b) Compile amortization')
axes[0].invert_yaxis()
axes[0].set_yticks(y,alabels);fig.tight_layout(w_pad=1.8)
save(fig,'modes_adjoint_ratios','Each left-panel ratio is a saved Qulacs gradient time divided by the SuperFermion prepared-handle time. The right panel is a calculation, not a cold-run measurement: it is the smallest integer K for which C + K g < K q, using the recorded SF compile cost C and per-call times g and q. Qulacs setup cost is not added because it was not measured separately.')

fig,axes=plt.subplots(1,2,figsize=(6.5,3.2));dm=bysection['dm'];x=[r['n'] for r in dm]
for key,label,color,marker in [('rust','SuperFermion','#151515','*'),('aer','Qiskit Aer','#D55E00','^')]:axes[0].plot(x,[r[key]['dm_ms'] for r in dm],color=color,marker=marker,lw=1.2,label=label)
axes[0].scatter([10],[dm[1]['aer']['dm_ms']],s=60,marker='^',facecolors='white',edgecolors='#D55E00',zorder=5)
ratios=[r['aer']['dm_ms']/r['rust']['dm_ms'] for r in dm]
for i,r in enumerate(dm):axes[1].scatter(r['n'],ratios[i],color='#151515' if r['aer']['prob_match'] else '#aaaaaa',marker='o' if r['aer']['prob_match'] else 'x',s=40)
axes[1].axhline(1,color='#777777',lw=.8,ls='--');axes[1].text(10,ratios[1]+.12,'Flagged',ha='center',fontsize=8)
axes[0].set(yscale='log',ylabel='Time (ms; log scale)',title='(a) Dense-core timings');axes[1].set(ylabel='Aer / SuperFermion time',title='(b) Ratio with check status',ylim=(.45,1.95))
for ax in axes:ax.set(xlabel='Qubits',xticks=x)
axes[0].legend(frameon=False);fig.tight_layout(w_pad=1.9)
save(fig,'modes_density_matrix','Recorded density-matrix times for noiseless depth-eight circuits. The hollow Aer marker and gray ratio marker identify its 10-qubit diagonal-check flag; that point is not used as a validated performance ranking. At 8 and 12 qubits both saved diagonal flags pass. These are dense-core observations, not a result for the held-out density-matrix planner mode.')

def writecsv(name,items):
 fields=list(dict.fromkeys(k for item in items for k in item))
 with (data/name).open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(items)
writecsv('selected_mode_observations.csv',observations);writecsv('adjoint_amortization.csv',amortization)
maxparity=max(r['parity_cat_vs_qulacs'] for r in bysection['adj']);fd=[r['fd_max_err'] for r in bysection['adj'] if r['fd_max_err'] is not None]
assert maxparity==summary['adj']['max_parity_vs_qulacs'] and fd==[summary['adj']['fd_max_err']]
failed_dm=[r['n'] for r in bysection['dm'] if not r['aer']['prob_match']];assert failed_dm==[10]
def keys(value):
 if isinstance(value,dict):
  for key,v in value.items():yield key;yield from keys(v)
 elif isinstance(value,list):
  for v in value:yield from keys(v)
assert not any(any(t in key.lower() for t in ['rss','peak_ram','memory_bytes']) for key in keys(rows))
hashes={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in (p/'source_modes').rglob('*') if f.is_file()}
audit=dict(raw_conditions=24,selected_framework_observations=81,section_counts=dict(Counter(r['section'] for r in rows)),csv_jsonl_reconciliation=csv_checks,nested_results_same_dataset=True,source_hashes=hashes,notebook_error_cells=errors,tableau_selected_outcomes=dict(counts),wins_against_all_available=wins,full_four_competitor_conditions=sum(all(lane(r,k)['status']=='ok' for k in fw[1:]) for r in tableau),adjoint_win_vs_qulacs=10,max_gradient_parity=maxparity,finite_difference_error=fd[0],finite_difference_condition={'n':8,'layers':1},aer_diagonal_flagged_qubits=failed_dm,ram_measured=False,raw_per_call_values_available=False,benchmarks_rerun=False,source_native_implementation_included=False,tableau_execution_order='SuperFermion, Stim, Aer, PennyLane, Cirq, Cirq, PennyLane, Aer, Stim, SuperFermion',gradient_execution_order='two forward comparison cycles',density_execution_order='two SuperFermion windows followed by two Aer windows',figures=len(manifest),detailed_tables=len(tables))
(data/'mode_analysis_checks.json').write_text(json.dumps(audit,indent=2)+'\n')
(data/'mode_detailed_tables.json').write_text(json.dumps(tables,indent=2)+'\n')
(data/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(data/'mode_summary.json').write_text(json.dumps(dict(tableau_wins=wins,adjoint=amortization,dm=bysection['dm'],software_versions=summary['versions']),indent=2)+'\n')
print(json.dumps({k:audit[k] for k in ['raw_conditions','selected_framework_observations','tableau_selected_outcomes','wins_against_all_available','adjoint_win_vs_qulacs','aer_diagonal_flagged_qubits','figures','detailed_tables','ram_measured']},indent=2))
