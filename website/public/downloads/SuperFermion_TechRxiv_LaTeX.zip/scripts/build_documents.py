"""Build LaTeX source and editable Word manuscript from shared content."""
from __future__ import annotations
import argparse
from copy import deepcopy
import json
from pathlib import Path
import re
import subprocess
from zipfile import ZipFile

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from lxml import etree
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--package-dir", type=Path, default=ROOT)
parser.add_argument("--output-dir", type=Path, default=ROOT/"output")
parser.add_argument("--latex-only", action="store_true", help="Regenerate LaTeX without rebuilding Word")
parser.add_argument("--output-stem", default="SuperFermion_TechRxiv_Paper")
args = parser.parse_args()
PKG = args.package_dir.resolve()
OUT = args.output_dir.resolve()
OUT.mkdir(parents=True,exist_ok=True)
DOCX_PATH = OUT/(args.output_stem+".docx")
content = json.loads((PKG/"data"/"manuscript.json").read_text())
blocks = content["blocks"]
by_key = {r["key"]: r for r in content["references"]}
citations = []
for block in blocks:
    for text in (block.get("text",""),block.get("caption",""),block.get("note","")):
        for match in re.finditer(r"\{\{cite:([^}]+)\}\}",text):
            for key in match.group(1).split(","):
                assert key in by_key, key
                if key not in citations:
                    citations.append(key)
citation_numbers = {k:i+1 for i,k in enumerate(citations)}
table_numbers = {b["label"]:i+1 for i,b in enumerate(b for b in blocks if b["type"]=="table")}
figure_numbers = {b["label"]:i+1 for i,b in enumerate(b for b in blocks if b["type"]=="figure")}
assert len(table_numbers)==sum(b["type"]=="table" for b in blocks)
assert len(figure_numbers)==sum(b["type"]=="figure" for b in blocks)

def escape(text):
    mapping={"\\":r"\textbackslash{}","&":r"\&","%":r"\%","$":r"\$","#":r"\#","_":r"\_",
             "{":r"\{","}":r"\}","~":r"\textasciitilde{}","^":r"\textasciicircum{}",
             "<":r"\ensuremath{<}",">":r"\ensuremath{>}"}
    return "".join(mapping.get(c,c) for c in str(text))

token_pattern = re.compile(r"\{\{(cite|fig|tab):([^}]+)\}\}")
WORD_PENDING_BREAK = False
def latex_text(text):
    output=[];start=0
    for m in token_pattern.finditer(text):
        output.append(escape(text[start:m.start()]))
        typ,value=m.groups()
        if typ=="cite":
            output.append(r"\cite{"+value+"}")
        else:
            assert value in (figure_numbers if typ=="fig" else table_numbers),value
            output.append(r"\ref{"+typ+":"+value+"}")
        start=m.end()
    output.append(escape(text[start:]))
    return "".join(output)

def word_text(text):
    def replace(m):
        typ,value=m.groups()
        if typ=="cite":
            return "["+", ".join(str(citation_numbers[k]) for k in value.split(","))+"]"
        return str((figure_numbers if typ=="fig" else table_numbers)[value])
    return token_pattern.sub(replace,str(text))

def bibliography_text(r):
    s=f'{r["author"]}. {r["title"]}. {r["venue"]} ({r["year"]}).'
    if r.get("doi"):
        s+=" https://doi.org/"+r["doi"]
    elif r.get("url"):
        s+=" "+r["url"]
    return s

def write_bib():
    lines=[]
    for r in content["references"]:
        fields=dict(author=r["bibauthor"],title="{"+escape(r["title"])+"}",year=r["year"])
        for field in ("journal","volume","pages","doi","url"):
            if field in r: fields[field]=r[field]
        note=escape(r["venue"]) if r["kind"]=="misc" else ""
        url=("https://doi.org/"+r["doi"]) if r.get("doi") else r.get("url")
        if url:note+=(" " if note else "")+r"\url{"+url+"}"
        if note:fields["note"]=note
        lines.append("@"+r["kind"]+"{"+r["key"]+",\n"+
                     ",\n".join("  "+k+" = {"+v+"}" for k,v in fields.items())+"\n}")
    (PKG/"references.bib").write_text("\n\n".join(lines)+"\n")

def write_latex():
    # Fixed numeric columns, full-width tables, and unbroken table/figure blocks.
    preamble=r"""\documentclass[11pt,letterpaper]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,graphicx,booktabs,tabularx,array,caption}
\usepackage{xurl}
\usepackage[hidelinks]{hyperref}
\usepackage{needspace}
\captionsetup{font=small,labelfont=bf,justification=raggedright,singlelinecheck=false,hypcap=false}
\setlength{\parindent}{0pt}
\setlength{\parskip}{5pt}
\setlength{\emergencystretch}{2em}
\renewcommand{\arraystretch}{1.13}
\newcolumntype{L}[1]{>{\raggedright\arraybackslash}p{#1}}
\newcolumntype{C}[1]{>{\centering\arraybackslash}p{#1}}
\begin{document}
"""
    authors=content.get("authors") or []
    names="; ".join(a["name"] for a in authors)
    pdfmeta=r"\hypersetup{pdftitle={"+escape(content["title"])+r"},pdfauthor={"+escape(names)+"}}"
    preamble=preamble.replace(r"\begin{document}",pdfmeta+"\n"+r"\begin{document}")
    header=[r"\begin{center}{\Large\bfseries "+escape(content["title"])+r"\par}\vspace{6pt}",
            r"{\small "+escape(content["subtitle"])+r"\par}\vspace{8pt}"]
    for a in authors:
        header.append(r"{\normalsize\bfseries "+escape(a["name"])+r"\par}")
        details=(escape(a["affiliation"])+r"\quad \href{mailto:"+a["email"]+"}{"+escape(a["email"])+"}"+
                 r"\quad \href{"+a["orcid"]+"}{ORCID: "+a["orcid"].rsplit("/",1)[1]+"}")
        header.append(r"{\small "+details+r"\par}\vspace{6pt}")
    header.append(r"{\small\itshape Preprint\par}\end{center}")
    parts=[preamble,"\n".join(header),
           r"\begin{abstract}"+latex_text(content["abstract"])+r"\end{abstract}",
           r"\noindent\textbf{Keywords:} "+escape(content["keywords"])+r"\par\vspace{6pt}"]
    for b in blocks:
        typ=b["type"]
        if typ=="heading":
            cmd="section" if b["level"]==1 else "subsection"
            parts.append("\\"+cmd+"{"+escape(b["text"])+"}")
        elif typ=="paragraph":
            parts.append(latex_text(b["text"])+"\n")
        elif typ=="equation":
            parts.append(r"\begin{equation}\label{eq:"+b["label"]+"}\n"+b["tex"]+"\n"+r"\end{equation}")
        elif typ=="figure":
            parts.append(r"\par\addvspace{7pt}\noindent\begin{minipage}{\textwidth}"+
                         "\n"+r"\centering\includegraphics[width=\linewidth,height=5.8in,keepaspectratio]{"+b["file"]+"}\n"+
                         r"\captionof{figure}{"+latex_text(b["caption"])+"}"+r"\label{fig:"+b["label"]+"}\n"+
                         r"\end{minipage}\par\addvspace{7pt}")
        elif typ=="table":
            n=len(b["columns"]);widths=b.get("widths")
            if not widths:widths=[1.55]+[(6.5-1.55)/(n-1)]*(n-1)
            # Reserve intercolumn padding within the specified text width.
            pad=.08
            usable=[max(.4,w-2*pad) for w in widths]
            spec="".join(("L" if i==0 or (n==2 and i==1) else "C")+"{"+f"{w:.3f}in"+"}" for i,w in enumerate(usable))
            header=" & ".join(r"\textbf{"+escape(x).replace("\n",r"\newline ")+"}" for x in b["columns"])+r" \\"
            rows=[]
            for row in b["rows"]:
                values=[escape(v).replace("\n",r"\newline ") for v in row]
                if row[0]=="SuperFermion":values=[r"\textbf{"+v+"}" for v in values]
                rows.append(" & ".join(values)+r" \\")
            chunk=(r"\par\addvspace{7pt}\noindent\begin{minipage}{\textwidth}"+"\n"+
                   r"\captionof{table}{"+escape(b["title"])+"}"+r"\label{tab:"+b["label"]+"}\n"+
                   r"\centering\fontsize{9}{11}\selectfont\setlength{\tabcolsep}{"+f"{pad:.2f}in"+"}\n"+
                   r"\begin{tabular}{"+spec+"}\n"+r"\toprule"+"\n"+header+"\n"+r"\midrule"+"\n"+
                   "\n".join(rows)+"\n"+r"\bottomrule"+"\n"+r"\end{tabular}"+"\n"+
                   r"\par\vspace{4pt}\raggedright\footnotesize "+latex_text(b["note"])+"\n"+
                   r"\end{minipage}\par\addvspace{7pt}")
            (PKG/"tables"/(b["label"]+".tex")).write_text(chunk+"\n")
            parts.append(r"\input{tables/"+b["label"]+".tex}")
        elif typ=="bibliography":
            parts.append(r"\clearpage\begingroup\fontsize{9}{11}\selectfont\setlength{\parskip}{0pt}\let\originalthebibliography\thebibliography\renewcommand{\thebibliography}[1]{\originalthebibliography{#1}\setlength{\itemsep}{1pt}\setlength{\parsep}{0pt}}"+"\n"+r"\bibliographystyle{unsrt}"+"\n"+r"\bibliography{references}"+"\n"+r"\endgroup")
        elif typ=="appendix":
            parts.append(r"\appendix")
        elif typ=="pagebreak":
            parts.append(r"\clearpage")
        else:raise ValueError(typ)
    parts.append(r"\end{document}")
    (PKG/"main.tex").write_text("\n\n".join(parts)+"\n")
    write_bib()

def set_font(run,name="Times New Roman",size=11,bold=None):
    run.font.name=name;run.font.size=Pt(size);run.font.color.rgb=RGBColor(0,0,0)
    if bold is not None:run.bold=bold
    rpr=run._element.get_or_add_rPr()
    fonts=rpr.find(qn("w:rFonts"))
    if fonts is None:fonts=OxmlElement("w:rFonts");rpr.insert(0,fonts)
    for attr in ("ascii","hAnsi","eastAsia","cs"):fonts.set(qn("w:"+attr),name)

def add_hyperlink(p,url,label):
    from docx.opc.constants import RELATIONSHIP_TYPE as RT
    rid=p.part.relate_to(url,RT.HYPERLINK,is_external=True)
    link=OxmlElement("w:hyperlink");link.set(qn("r:id"),rid)
    run=OxmlElement("w:r");props=OxmlElement("w:rPr")
    fonts=OxmlElement("w:rFonts");fonts.set(qn("w:ascii"),"Times New Roman");fonts.set(qn("w:hAnsi"),"Times New Roman")
    props.append(fonts)
    size=OxmlElement("w:sz");size.set(qn("w:val"),"18");props.append(size)
    run.append(props);t=OxmlElement("w:t");t.text=label;run.append(t);link.append(run);p._p.append(link)

def paragraph(doc,text,style=None,size=None):
    global WORD_PENDING_BREAK
    p=doc.add_paragraph(style=style);run=p.add_run(word_text(text))
    set_font(run,size=size or 11)
    if WORD_PENDING_BREAK:
        p.paragraph_format.page_break_before=True
        WORD_PENDING_BREAK=False
    return p

def word_table(doc,b):
    number=table_numbers[b["label"]]
    cap=paragraph(doc,f'Table {number}. {b["title"]}',"Caption",10)
    cap.runs[0].bold=True;cap.paragraph_format.keep_with_next=True
    n=len(b["columns"]);widths=b.get("widths") or [1.55]+[(6.5-1.55)/(n-1)]*(n-1)
    t=doc.add_table(rows=1,cols=n);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    pr=t._tbl.tblPr
    borders=OxmlElement("w:tblBorders")
    for edge in ("top","left","bottom","right","insideH","insideV"):
        e=OxmlElement("w:"+edge)
        e.set(qn("w:val"),"single");e.set(qn("w:sz"),"4");e.set(qn("w:color"),"D9D9D9")
        borders.append(e)
    pr.append(borders)
    margins=OxmlElement("w:tblCellMar")
    for edge,value in (("top",65),("bottom",65),("left",75),("right",75)):
        e=OxmlElement("w:"+edge);e.set(qn("w:w"),str(value));e.set(qn("w:type"),"dxa");margins.append(e)
    pr.append(margins)
    for col,width in zip(t.columns,widths):col.width=Inches(width)
    allrows=[b["columns"]]+b["rows"]
    for i,rowdata in enumerate(allrows):
        row=t.rows[0] if i==0 else t.add_row()
        trpr=row._tr.get_or_add_trPr()
        nosplit=OxmlElement("w:cantSplit");trpr.append(nosplit)
        if i==0:
            repeat=OxmlElement("w:tblHeader");trpr.append(repeat)
        for j,value in enumerate(rowdata):
            cell=row.cells[j];cell.width=Inches(widths[j]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p=cell.paragraphs[0];p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0)
            p.paragraph_format.line_spacing=1.0
            p.paragraph_format.keep_with_next=True
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 or (n==2) else WD_ALIGN_PARAGRAPH.CENTER
            r=p.add_run(word_text(value));set_font(r,size=9 if n<6 else 8.5,bold=i==0 or rowdata[0]=="SuperFermion")
            if i==0:
                shade=OxmlElement("w:shd");shade.set(qn("w:fill"),"EDEFF2");cell._tc.get_or_add_tcPr().append(shade)
    note=paragraph(doc,b["note"],"Table Note",9)
    note.paragraph_format.keep_with_next=False
    note.paragraph_format.keep_together=True
    spacer=doc.add_paragraph();spacer.paragraph_format.space_after=Pt(1);spacer.paragraph_format.space_before=Pt(0)
    spacer.paragraph_format.line_spacing=Pt(1)

def math_objects():
    math_blocks=[b for b in blocks if b["type"]=="equation"]
    tmp=OUT.parent/"work"/"math"
    tmp.mkdir(parents=True,exist_ok=True)
    markdown="\n\n".join("$$\n"+b["tex"]+"\n$$" for b in math_blocks)
    path=tmp/"native_equations.docx"
    result=subprocess.run(["pandoc","--from=markdown","--to=docx","--output",str(path)],
                          input=markdown,text=True,capture_output=True,check=True)
    if result.stderr:print(result.stderr.strip())
    with ZipFile(path) as z:
        root=etree.fromstring(z.read("word/document.xml"))
    ns={"m":"http://schemas.openxmlformats.org/officeDocument/2006/math"}
    objects=root.findall(".//m:oMath",ns)
    assert len(objects)==len(math_blocks),(len(objects),len(math_blocks))
    return dict(zip([b["label"] for b in math_blocks],objects))

def write_docx():
    global WORD_PENDING_BREAK
    WORD_PENDING_BREAK=False
    doc=Document();section=doc.sections[0]
    section.page_width=Inches(8.5);section.page_height=Inches(11)
    section.top_margin=section.bottom_margin=Inches(1)
    section.left_margin=section.right_margin=Inches(1)
    section.header_distance=section.footer_distance=Inches(.5)
    for style in ("Normal","Title","Subtitle","Heading 1","Heading 2","Caption"):
        s=doc.styles[style];s.font.name="Times New Roman";s.font.color.rgb=RGBColor(0,0,0)
        if s.element.rPr is not None:
            fonts=s.element.rPr.find(qn("w:rFonts"))
            if fonts is not None:
                fonts.set(qn("w:ascii"),"Times New Roman");fonts.set(qn("w:hAnsi"),"Times New Roman")
    normal=doc.styles["Normal"];normal.font.size=Pt(11)
    normal.paragraph_format.line_spacing=1.08;normal.paragraph_format.space_after=Pt(6)
    normal.paragraph_format.widow_control=True
    normal.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    for sty,size in (("Heading 1",14),("Heading 2",12)):
        s=doc.styles[sty];s.font.size=Pt(size);s.font.bold=True
        s.paragraph_format.space_before=Pt(12);s.paragraph_format.space_after=Pt(6)
        s.paragraph_format.keep_with_next=True;s.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
    doc.styles["Title"].font.size=Pt(19);doc.styles["Title"].font.bold=True
    doc.styles["Title"].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    doc.styles["Subtitle"].font.size=Pt(11)
    doc.styles["Subtitle"].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    doc.styles["Caption"].font.size=Pt(10);doc.styles["Caption"].font.italic=False
    doc.styles["Caption"].font.bold=False
    doc.styles["Caption"].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
    doc.styles["Caption"].paragraph_format.space_after=Pt(5)
    doc.styles["Caption"].paragraph_format.keep_together=True
    for style in doc.styles:
        ppr=style.element.find(qn("w:pPr"))
        if ppr is not None:
            for border in list(ppr.findall(qn("w:pBdr"))):ppr.remove(border)
    if "Table Note" not in doc.styles:
        from docx.enum.style import WD_STYLE_TYPE
        s=doc.styles.add_style("Table Note",WD_STYLE_TYPE.PARAGRAPH)
        s.base_style=normal;s.font.size=Pt(9)
        s.paragraph_format.line_spacing=1.0;s.paragraph_format.space_after=Pt(7)
        s.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
    p=section.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement("w:fldSimple");field.set(qn("w:instr"),"PAGE");p._p.append(field)
    p=paragraph(doc,content["title"],"Title",19);p.runs[0].bold=True
    paragraph(doc,content["subtitle"],"Subtitle",11)
    for a in content.get("authors") or []:
        p=paragraph(doc,a["name"],size=12);p.runs[0].bold=True
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(1)
        p.paragraph_format.keep_with_next=True
        p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_after=Pt(6)
        p.paragraph_format.keep_with_next=True
        set_font(p.add_run(a["affiliation"]+" | "),size=9)
        add_hyperlink(p,"mailto:"+a["email"],a["email"])
        set_font(p.add_run(" | ORCID: "),size=9)
        add_hyperlink(p,a["orcid"],a["orcid"].rsplit("/",1)[1])
    p=paragraph(doc,"Preprint",size=9);p.runs[0].italic=True
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
    p=paragraph(doc,"Abstract",size=11);p.runs[0].bold=True;p.paragraph_format.keep_with_next=True
    paragraph(doc,content["abstract"])
    p=paragraph(doc,"Keywords: "+content["keywords"],size=10)
    p.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
    math=math_objects();eqno=0
    sectionno=0;subno=0;appendix=False;appendixno=0
    for b in blocks:
        typ=b["type"]
        if typ=="heading":
            if b["level"]==1:
                subno=0
                if appendix:
                    appendixno+=1;prefix=chr(64+appendixno)
                else:
                    sectionno+=1;prefix=str(sectionno)
            else:
                subno+=1;prefix=(chr(64+appendixno) if appendix else str(sectionno))+"."+str(subno)
            paragraph(doc,prefix+". "+b["text"],"Heading "+str(b["level"]),14 if b["level"]==1 else 12).runs[0].bold=True
        elif typ=="paragraph":
            paragraph(doc,b["text"])
        elif typ=="equation":
            eqno+=1;p=doc.add_paragraph()
            p.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before=Pt(4);p.paragraph_format.space_after=Pt(7)
            p._p.append(deepcopy(math[b["label"]]))
            set_font(p.add_run("   ("+str(eqno)+")"),size=10)
        elif typ=="figure":
            p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(6);p.paragraph_format.space_after=Pt(4)
            imagepath=PKG/b["png"]
            with Image.open(imagepath) as im:ratio=im.height/im.width
            width=min(6.5,5.8/ratio)
            p.add_run().add_picture(str(imagepath),width=Inches(width))
            cap=paragraph(doc,f'Figure {figure_numbers[b["label"]]}. '+b["caption"],"Caption",9.5)
            cap.paragraph_format.keep_with_next=False
            cap.paragraph_format.keep_together=True
        elif typ=="table":
            word_table(doc,b)
        elif typ=="bibliography":
            p=paragraph(doc,"References","Heading 1",14);p.runs[0].bold=True
            p.paragraph_format.page_break_before=True
            for key in citations:
                ref=by_key[key];text=bibliography_text(ref)
                p=doc.add_paragraph()
                p.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
                p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_after=Pt(6)
                p.paragraph_format.left_indent=Inches(.3);p.paragraph_format.first_line_indent=Inches(-.3)
                url=("https://doi.org/"+ref["doi"]) if ref.get("doi") else ref.get("url")
                start=f'[{citation_numbers[key]}] '
                if url:
                    set_font(p.add_run(start+text.rsplit(" ",1)[0]+" "),size=9)
                    add_hyperlink(p,url,url)
                else:set_font(p.add_run(start+text),size=9)
        elif typ=="pagebreak":
            WORD_PENDING_BREAK=True
        elif typ=="appendix":
            appendix=True
        else:raise ValueError(typ)
    doc.core_properties.title=content["title"]
    doc.core_properties.subject=content["subtitle"]
    doc.core_properties.author="; ".join(a["name"] for a in content.get("authors") or [])
    doc.core_properties.keywords=content["keywords"]
    doc.core_properties.comments="Integrated statevector MPS and execution-mode studies; benchmarks were not rerun."
    doc.save(DOCX_PATH)
    # Structural verification of editable equations, tables, and images.
    with ZipFile(DOCX_PATH) as z:
        xml=z.read("word/document.xml").decode()
        assert xml.count("<w:tbl>")==len(table_numbers)
        assert xml.count("<m:oMath>")==sum(b["type"]=="equation" for b in blocks)
        assert xml.count("<w:drawing>")==len(figure_numbers)
        assert "{{" not in xml
    return dict(tables=len(table_numbers),figures=len(figure_numbers),native_equations=sum(b["type"]=="equation" for b in blocks),citations=len(citations))

write_latex()
if args.latex_only:
    print("Regenerated integrated LaTeX")
else:
    print(json.dumps(write_docx(),indent=2))
(PKG/"data"/"document_index.json").write_text(json.dumps(dict(
    tables=table_numbers,figures=figure_numbers,citations=citation_numbers),indent=2))
