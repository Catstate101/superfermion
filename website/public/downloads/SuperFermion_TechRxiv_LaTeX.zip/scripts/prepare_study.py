"""Audit the selected studies and regenerate publication figures.

Inputs are saved reports and the replacement MPS archive. No simulator is run.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math
from collections import Counter
from pathlib import Path
from statistics import median
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import NullFormatter
import numpy as np
import pandas as pd

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--package-dir",type=Path,default=Path(__file__).resolve().parents[1])
p=parser.parse_args().package_dir.resolve();data=p/"data";figs=p/"figures"
SV=["superfermion_optimized","qulacs","qiskit","pennylane","cirq","cirq_f64"]
NAMES={"superfermion_optimized":"SuperFermion","qulacs":"Qulacs","qiskit":"Qiskit",
 "pennylane":"PennyLane","cirq":"Cirq f32","cirq_f64":"Cirq f64","analytical_angle":"Analytical angle"}
COLORS={"superfermion_optimized":"#151515","qulacs":"#0072B2","qiskit":"#D55E00",
 "pennylane":"#CC79A7","cirq":"#8a7b22","cirq_f64":"#526b2d","analytical_angle":"#744fa0"}
MARKERS=dict(zip(SV,["*","o","^","v","P","X"]));STYLES=dict(zip(SV,["-","-","--","-.",":","--"]))
TASKS=["qsvm","qkrr","qkpca","vqc","vqr","qaoa_fs","maxcut","vqe","gradient","circuit"]
TNAMES=["QSVM","QKRR","QKPCA","VQC","VQR","QAOA FS","MaxCut","VQE","Gradient","Circuit"]
Q=[4,8,12,16,20];KEYS=["task","dataset","variant","map","track","qubits","batch","depth"]
plt.rcParams.update({"font.family":"DejaVu Serif","font.size":9,"axes.titlesize":10,
 "axes.labelsize":9,"legend.fontsize":8,"xtick.labelsize":8.5,"ytick.labelsize":8.5,
 "pdf.fonttype":42,"ps.fonttype":42,"axes.spines.top":False,"axes.spines.right":False,
 "axes.grid":True,"grid.alpha":.2,"grid.color":"#bbbbbb","grid.linewidth":.5})
manifest=[]
def save(fig,label,caption):
 for suffix in ["pdf","svg","png"]:fig.savefig(figs/f"{label}.{suffix}",dpi=260,bbox_inches="tight",facecolor="white")
 plt.close(fig)
 manifest.append(dict(type="figure",label=label,title=label.replace("_"," "),file=f"figures/{label}.pdf",png=f"figures/{label}.png",caption=caption))
def csvwrite(name,rows):
 if isinstance(rows,pd.DataFrame):rows.to_csv(data/name,index=False,float_format="%.12g");return
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with (data/name).open("w",newline="",encoding="utf-8") as f:
  w=csv.DictWriter(f,fields);w.writeheader()
  for r in rows:w.writerow({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()})

# Reconstruct the original report, retaining only the six included configurations.
records=[];framework=None;raw_count=0
for lineno,line in enumerate((p/"source_reports/report4to20q.md").read_text().splitlines(),1):
 if line.startswith("## "):framework=line[3:].split(" - ")[0];continue
 if not framework or not line.startswith("| "):continue
 c=[s.strip() for s in line.strip().strip("|").split("|")]
 if len(c)!=10 or c[0]=="Task":continue
 raw_count+=1
 if framework not in SV+["classical","analytical_angle"]:continue
 number,unit=c[8].split();denom=1000 if unit=="ms" else 1
 seconds=float(number)/denom;digits=len(number.split(".")[1]) if "." in number else 0
 half=.5*10**(-digits)/denom
 rn,ru=c[9].split();scale=1024 if ru=="GiB" else 1
 rd=len(rn.split(".")[1]) if "." in rn else 0;rh=.5*10**(-rd)*scale
 r=dict(zip(KEYS,c[:8]));r.update({k:int(r[k]) for k in ["qubits","batch","depth"]})
 r.update(framework=framework,reported_latency=c[8],latency_s=seconds,
  latency_lower_s=max(0,seconds-half),latency_upper_s=seconds+half,rounded_zero=seconds==0,
  reported_ram=c[9],worker_peak_rss_mib=float(rn)*scale,rss_lower_mib=max(0,float(rn)*scale-rh),
  rss_upper_mib=float(rn)*scale+rh,source_file="report4to20q.md",source_line=lineno)
 records.append(r)
df=pd.DataFrame(records);assert raw_count==2156 and len(df)==1652
assert not df.duplicated(["framework"]+KEYS).any()
sf=df[df.framework==SV[0]];sfkeys=set(map(tuple,sf[KEYS].to_numpy()))
for fw in SV:
 g=df[df.framework==fw];assert len(g)==252 and set(map(tuple,g[KEYS].to_numpy()))==sfkeys
paired=df[df.framework.isin(SV[1:])].merge(sf[KEYS+["latency_s","worker_peak_rss_mib"]],on=KEYS,suffixes=("","_sf"),validate="many_to_one")
paired["time_ratio"]=np.where((paired.latency_s>0)&(paired.latency_s_sf>0),paired.latency_s/paired.latency_s_sf,np.nan)
paired["ram_ratio"]=paired.worker_peak_rss_mib/paired.worker_peak_rss_mib_sf
paired["sf_ram_saving_pct"]=100*(1-paired.worker_peak_rss_mib_sf/paired.worker_peak_rss_mib)
assert len(paired)==1260
csvwrite("reported_job_records.csv",df);csvwrite("paired_reconstructed_records.csv",paired)
summaries=[]
for fw in SV:
 g=df[df.framework==fw];b=paired[paired.framework==fw]
 summaries.append(dict(framework=fw,name=NAMES[fw],conditions=len(g),compute_sum_s=g.latency_s.sum(),
  compute_sum_min=g.latency_s.sum()/60,median_compute_ms=g.latency_s.median()*1000,
  median_peak_rss_mib=g.worker_peak_rss_mib.median(),maximum_peak_rss_mib=g.worker_peak_rss_mib.max(),
  ratio_compute_sum_vs_sf=g.latency_s.sum()/sf.latency_s.sum(),
  median_positive_paired_time_ratio=None if fw==SV[0] else b.time_ratio.median(),
  positive_time_pairs=252 if fw==SV[0] else int(b.time_ratio.notna().sum()),
  paired_ram_saving_pct=0 if fw==SV[0] else b.sf_ram_saving_pct.median()))
csvwrite("framework_summary.csv",summaries)
leaders=Counter();unresolved=0
for _,g in df[df.framework.isin(SV)].groupby(KEYS,dropna=False):
 winners=[r.framework for r in g.itertuples() if all(r.latency_upper_s<t.latency_lower_s for t in g.itertuples() if t.framework!=r.framework)]
 if len(winners)==1:leaders[winners[0]]+=1
 else:unresolved+=1
assert sum(leaders.values())+unresolved==252

# Conceptual software execution diagram, with no device descriptions.
fig,ax=plt.subplots(figsize=(6.5,2.8));ax.set(xlim=(0,10),ylim=(0,4));ax.axis("off")
boxes=[(.2,1.5,2,1,"Circuit and\nparameters"),(3.1,1.5,2.3,1,"Prepared native\nexecution plan"),
 (6.8,2.4,2.7,1,"Exported\nstatevectors"),(6.8,.3,2.7,1,"Native\nobservable readout")]
for x,y,w,h,text in boxes:
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.10",facecolor="#f5f5f5",edgecolor="#777777"));ax.text(x+w/2,y+h/2,text,ha="center",va="center",fontsize=10)
for a,b in [((2.3,2),(3,2)),((5.5,2),(6.65,2.9)),((5.5,2),(6.65,.8))]:ax.annotate("",xy=b,xytext=a,arrowprops=dict(arrowstyle="->",color="#555555",lw=1.3))
ax.text(4.25,.65,"Reuse parameters and batch inputs",ha="center",fontsize=9)
save(fig,"execution_path","Conceptual organization of prepared circuit execution and its two output contracts. This schematic describes the software design; the saved measurements do not isolate each component's contribution.")

fig,axes=plt.subplots(1,2,figsize=(6.5,3.2))
for ax,col,title in [(axes[0],"compute_sum_min","(a) Matched compute totals"),(axes[1],"median_peak_rss_mib","(b) Median process memory")]:
 vals=[r[col] for r in summaries];ax.barh(range(len(SV)),vals,color=[COLORS[f] for f in SV]);ax.invert_yaxis()
 ax.set_yticks(range(len(SV)),[NAMES[f] for f in SV]);ax.set_title(title)
 for i,v in enumerate(vals):ax.text(v+max(vals)*.015,i,f"{v:.1f}",va="center",fontsize=8)
 ax.set_xlim(0,max(vals)*1.23)
axes[0].set_xlabel("Successful compute sum (min)");axes[1].set_xlabel("Median worker peak RSS (MiB)")
fig.tight_layout(w_pad=1.8)
save(fig,"overall_compute_ram","Six included simulator configurations evaluated on the same 252 conditions. Compute totals sum the reported primary stage and exclude startup, imports and retries. Memory is the median whole-worker peak RSS. Cirq f32 is a mixed-precision comparison.")

heatrows=[];pairaudit={}
for fw in SV[1:]:
 name=NAMES[fw];g=paired[paired.framework==fw];v=g[(g.latency_s>0)&(g.latency_s_sf>0)]
 fig,axes=plt.subplots(1,2,figsize=(6.5,3.0))
 for track,marker,color in [("statevector","o","#0072B2"),("native_readout","^","#D55E00")]:
  t=v[v.track==track];r=g[g.track==track]
  axes[0].scatter(t.latency_s_sf,t.latency_s,s=15,marker=marker,color=color,alpha=.65,label=track.replace("_"," "))
  axes[1].scatter(r.worker_peak_rss_mib_sf,r.worker_peak_rss_mib,s=15,marker=marker,color=color,alpha=.65)
 lo=min(v.latency_s.min(),v.latency_s_sf.min())*.6;hi=max(v.latency_s.max(),v.latency_s_sf.max())*1.5
 axes[0].plot([lo,hi],[lo,hi],"--",color="#555555",lw=.9)
 axes[0].set(xscale="log",yscale="log",xlim=(lo,hi),ylim=(lo,hi),xlabel="SuperFermion compute time (s)",ylabel=name+" compute time (s)",title="(a) Matched computation")
 axes[0].legend(loc="upper left",fontsize=7.3)
 rlo=min(g.worker_peak_rss_mib.min(),g.worker_peak_rss_mib_sf.min())*.9
 rhi=np.ceil(max(g.worker_peak_rss_mib.max(),g.worker_peak_rss_mib_sf.max())*1.08/100)*100
 axes[1].plot([rlo,rhi],[rlo,rhi],"--",color="#555555",lw=.9)
 axes[1].set(xlim=(rlo,rhi),ylim=(rlo,rhi),xlabel="SuperFermion peak RSS (MiB)",ylabel=name+" peak RSS (MiB)",title="(b) Matched process memory")
 fig.tight_layout(w_pad=1.3)
 save(fig,f"matched_{fw}",f"Matched {name} and SuperFermion observations. The logarithmic time panel retains {len(v)} of 252 pairs; {len(g)-len(v)} displayed-zero pairs are omitted. All 252 memory pairs are shown. Points above the equality lines favor SuperFermion. Markers distinguish output contracts. RSS is whole-worker memory; there is one fresh-process repetition per condition.")
 matrix=np.full((10,5),np.nan)
 for i,task in enumerate(TASKS):
  for j,q in enumerate(Q):
   a=sf[(sf.task==task)&(sf.qubits==q)];b=df[(df.framework==fw)&(df.task==task)&(df.qubits==q)]
   assert len(a)==len(b)
   value=b.latency_s.sum()/a.latency_s.sum() if len(a) else np.nan
   if len(a):assert .5<=value<=512
   else:assert task in ["vqc","vqr"] and q in [16,20]
   matrix[i,j]=value
   heatrows.append(dict(framework=fw,task=task,qubits=q,conditions_per_lane=len(a),status="ok" if len(a) else "not_planned",ratio=None if not len(a) else value,sf_compute_sum_s=None if not len(a) else a.latency_s.sum(),comparator_compute_sum_s=None if not len(a) else b.latency_s.sum()))
 fig,ax=plt.subplots(figsize=(6.5,3.9));cmap=plt.get_cmap("Blues").copy();cmap.set_bad("#eeeeee")
 im=ax.imshow(matrix,cmap=cmap,norm=LogNorm(vmin=.5,vmax=512),aspect="auto");ax.grid(False)
 ax.set_xticks(range(5),[str(q) for q in Q]);ax.set_yticks(range(10),TNAMES)
 ax.set(xlabel="Qubits",title=name+" / SuperFermion ratios of task-specific compute sums")
 for i in range(10):
  for j in range(5):
   z=matrix[i,j];ax.text(j,i,"Not planned" if np.isnan(z) else f"{z:.3g}x",ha="center",va="center",fontsize=8.2,color="white" if not np.isnan(z) and z>40 else "#111111")
 cb=fig.colorbar(im,ax=ax,pad=.025,ticks=[.5,1,2,8,32,128,512]);cb.ax.set_yticklabels(["0.5","1","2","8","32","128","512"]);cb.set_label("Ratio; logarithmic color scale")
 fig.tight_layout()
 save(fig,f"heatmap_{fw}",f"{name}/SuperFermion ratios of summed primary compute time for matching task and qubit cohorts. Values above one favor SuperFermion; values below one favor {name}. Cells pool matching datasets, maps and output tracks. All five heatmaps share the 0.5 to 512 logarithmic scale. Unplanned VQC/VQR cells retain their status. These are workload-total ratios, not medians of individual speedups.")
 pairaudit[fw]=dict(pairs=252,positive_time_pairs=len(v),omitted_time_pairs=len(g)-len(v),memory_pairs=252)
csvwrite("task_qubit_ratios.csv",heatrows);assert len(heatrows)==250

def line(ax,x,y,fw,scale=1):
 y=np.asarray(y,dtype=float)*scale;low=(y==0)&np.isfinite(y)
 ax.plot(x,np.where(low,np.nan,y),color=COLORS[fw],marker=MARKERS.get(fw,"D"),linestyle=STYLES.get(fw,"-"),linewidth=1.8 if fw==SV[0] else 1.2,markersize=5 if fw==SV[0] else 4,label=NAMES[fw])
 if low.any():ax.scatter(np.asarray(x)[low],np.full(low.sum(),.05),facecolors="none",edgecolors=COLORS[fw],marker="v",s=35)
for task in TASKS:
 qs=[4,8,12] if task in ["vqc","vqr"] else Q
 slices=[("angle","map","Angle map"),("zz","map","ZZ map")] if task in ["qsvm","qkrr"] else [(None,None,"Matched cohort")] if task in ["qkpca","circuit"] else [("statevector","track","Statevector output"),("native_readout","track","Native readout")]
 fig,axes=plt.subplots(len(slices),2,figsize=(6.5,2.8*len(slices)+.35),squeeze=False)
 for i,(value,column,title) in enumerate(slices):
  for fw in SV:
   g=df[(df.framework==fw)&(df.task==task)]
   if column:g=g[g[column]==value]
   med=g.groupby("qubits").agg(time=("latency_s","median"),ram=("worker_peak_rss_mib","median")).reindex(qs)
   line(axes[i,0],qs,med.time,fw,1000);line(axes[i,1],qs,med.ram,fw)
  axes[i,0].set(yscale="log",ylabel="Compute time (ms; log scale)",xlabel="Qubits",xticks=qs,title=title+" time")
  axes[i,1].set(ylabel="Peak RSS (MiB)",xlabel="Qubits",xticks=qs,title=title+" RAM")
 handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc="upper center",ncol=3,frameon=False,bbox_to_anchor=(.53,1.025),fontsize=8)
 fig.tight_layout(rect=(0,0,1,.89 if len(slices)==1 else .94),w_pad=1.8,h_pad=1.8)
 caption=f"Compute-time and whole-worker memory scaling for {TNAMES[TASKS.index(task)]}. Points summarize matched dataset or circuit cohorts; feature maps or output contracts remain separate. Curves connect measured sizes. One fresh-process repetition is available per condition, so no confidence bands are inferred."
 if task in ["vqc","vqr"]:caption+=" Training uses five updates at 4, 8 and 12 qubits."
 if task=="circuit":caption+=" Open downward triangles denote cohort medians rounded to zero at the 0.05 ms display bound."
 save(fig,f"scaling_{task}",caption)
fig,axes=plt.subplots(1,2,figsize=(6.5,3.1))
for fw in [SV[0],"qulacs","analytical_angle"]:
 g=df[(df.framework==fw)&(df.task=="qsvm")&(df.dataset=="breast_cancer")&(df["map"]=="angle")].sort_values("qubits")
 line(axes[0],g.qubits,g.latency_s,fw,1000);line(axes[1],g.qubits,g.worker_peak_rss_mib,fw)
axes[0].set(xlabel="Qubits",ylabel="Compute time (ms; log scale)",yscale="log",xticks=Q,title="(a) Angle kernel");axes[1].set(xlabel="Qubits",ylabel="Peak RSS (MiB)",xticks=Q,title="(b) Process memory")
axes[0].legend(fontsize=7.5);fig.tight_layout()
save(fig,"analytical_angle_control","Breast-cancer angle-map QSVM observations. The analytical control evaluates the separable kernel formula and is kept outside general-simulator rankings. At 20 qubits it takes 64.2 ms, versus 212.6 s for SuperFermion and 218.2 s for Qulacs. Memory includes work outside the kernel stage.")
fig,ax=plt.subplots(figsize=(6.5,3.4))
ax.plot(Q,[16*2**q/2**20 for q in Q],"s-",color="#777777",label="One complex128 state (theory)")
ax.plot(Q,[.1,1.6,25,360,512],"D-",color="#744fa0",label="Reported median exported bank")
for fw in [SV[0],"qulacs","qiskit"]:
 g=df[(df.framework==fw)&(df.task=="qsvm")].groupby("qubits").worker_peak_rss_mib.median().reindex(Q)
 line(ax,Q,g,fw)
ax.axhline(512,ls="--",color="#555555",lw=.9,label="Exported-bank cap only")
ax.set(xlabel="Qubits",ylabel="Memory (MiB; log scale)",yscale="log",xticks=Q)
ax.legend(ncol=2,fontsize=7.5,loc="lower left",bbox_to_anchor=(0,1.02),frameon=False);fig.tight_layout()
save(fig,"statebank_and_worker_memory","Theoretical dense-state storage, attributed exported-bank medians and reconstructed QSVM worker medians measure different objects. The 512 MiB cap limits the exported bank; it does not cap total RSS or remove exponential dense-state storage.")
fig,axes=plt.subplots(2,2,figsize=(6.5,5.1))
for i,models in enumerate([["rbf_svc","logistic","rf_classifier"],["ridge","rbf_krr","rf_regressor"]]):
 for j,model in enumerate(models):
  g=df[(df.framework=="classical")&(df.variant==model)].groupby("qubits").agg(time=("latency_s","median"),ram=("worker_peak_rss_mib","median")).reindex(Q)
  for ax,col,scale in [(axes[i,0],"time",1000),(axes[i,1],"ram",1)]:ax.plot(Q,g[col]*scale,color=["#0072B2","#D55E00","#526b2d"][j],marker=["o","s","^"][j],label=model.replace("_"," "))
 axes[i,0].set(yscale="log",ylabel="Compute time (ms; log scale)",title="Classification" if i==0 else "Regression")
 axes[i,1].set(ylabel="Peak RSS (MiB)",title="Classification" if i==0 else "Regression")
 for ax in axes[i]:ax.set(xlabel="Nominal qubit setting",xticks=Q)
 axes[i,0].legend(fontsize=7.5)
fig.tight_layout()
save(fig,"classical_controls","Classical estimators over five classification or two regression datasets. The nominal qubit axis identifies paired study settings; these estimators allocate no quantum qubits. Time and RAM do not measure predictive accuracy.")

# Replacement MPS archive only. Reconcile latest JSONL jobs with the supplied CSV.
src=p/"source_mps";rawpath=next((src/"mps_bench8_out").glob("*_mps8.jsonl"))
MF=["sf_optimized","aer","pl","cirq","qulacs"]
MN={"sf_optimized":"SuperFermion","aer":"Qiskit Aer","pl":"PennyLane","cirq":"Cirq quimb","qulacs":"Qulacs"}
MC={"sf_optimized":"#151515","aer":"#D55E00","pl":"#CC79A7","cirq":"#8a7b22","qulacs":"#0072B2"};MM=dict(zip(MF,["*","^","v","P","o"]))
KF=["framework","circuit","n_qubits","bond","method","mcm_case","mcm_param","mode"]
def key(r):
 return tuple("" if r.get(k) is None or r.get(k)=="" else str(int(float(r[k]))) if k in ["n_qubits","bond","mcm_param"] else str(r[k]) for k in KF)
raw=[json.loads(l) for l in rawpath.read_text().splitlines() if l.strip()];latest={key(r):r for r in raw}
csvrows=list(csv.DictReader(rawpath.with_suffix(".csv").open(encoding="utf-8-sig",newline="")))
assert len(raw)==282 and len(latest)==len(csvrows)==264
assert set(latest)=={key(r) for r in csvrows}
for row in csvrows:
 r=latest[key(row)];assert row["status"]==r["status"]
 for col in ["t_expval_total_s","peak_rss_mb","expval_z0zlast"]:
  if row.get(col) and r.get(col) is not None:assert abs(float(row[col])-r[col])<1e-8
mps=[r.copy() for r in latest.values() if r["framework"] in MF]
assert len(mps)==182 and Counter(r["status"] for r in mps)==Counter(ok=141,over_budget=12,error=3,not_offered=26)
for r in mps:
 if r["status"]=="ok":
  if r.get("trials"):assert abs(r["t_expval_total_s"]-median(r["trials"]))<1e-6
  if r["mode"]=="mcm":assert r["all_correct"] is True
csvwrite("mps_selected_records.csv",mps)
def quality(r):
 q=r.get("quality") or {};return json.loads(q) if isinstance(q,str) else q
def mselect(**k):return [r for r in mps if all(r.get(c)==v for c,v in k.items())]
def mline(ax,x,y,fw,label=True):
 ax.plot(x,y,color=MC[fw],marker=MM[fw],lw=1.8 if fw==MF[0] else 1.2,markersize=5 if fw==MF[0] else 4,label=MN[fw] if label else None)
def legend(fig,ax,rect=.88):
 h,l=ax.get_legend_handles_labels();fig.legend(h,l,loc="upper center",ncol=4,frameon=False,bbox_to_anchor=(.53,1.025),fontsize=8);fig.tight_layout(rect=(0,0,1,rect),w_pad=1.8)
def curve(label,mode,circuit,field,grid,extra=None):
 fig,axes=plt.subplots(1,2,figsize=(6.5,3.25))
 for fw in MF[:-1]:
  rr=mselect(framework=fw,mode=mode,circuit=circuit,**(extra or {}));lookup={r[field]:r for r in rr}
  for ax,col in [(axes[0],"t_expval_total_s"),(axes[1],"peak_rss_mb")]:
   y=[lookup.get(x,{}).get(col) if lookup.get(x,{}).get("status")=="ok" else np.nan for x in grid]
   y=[np.nan if v is None else v for v in y]
   if np.isfinite(y).any():mline(ax,grid,y,fw)
  for ax in axes:
   ax.set(xscale="log",yscale="log",xticks=grid)
   ax.set_xticklabels([str(x) for x in grid])
   ax.xaxis.set_minor_formatter(NullFormatter())
 axes[0].set(title="(a) Recorded execution",ylabel="Adapter time (s; log scale)")
 axes[1].set(title="(b) Process memory",ylabel="Peak RSS (MiB; log scale)")
 for ax in axes:ax.set_xlabel("Maximum bond dimension" if field=="bond" else "Qubits")
 legend(fig,axes[0]);save(fig,label,"Recorded adapter time and process peak RSS for matching circuit conditions. Only successful observations are plotted; absent, not-offered, error and budget outcomes remain missing. Sampling time is excluded from the execution metric but can contribute to recorded RSS. Output and validation contracts vary across adapters.")
curve("mps_ghz_time_ram","ladder","ghz","n_qubits",[50,100,200,500,1000])
curve("mps_brick4_time_ram","ladder","brick4","n_qubits",[50,100,200,500,1000])
curve("mps_stress_time_ram","stress","brick12","n_qubits",[200,500,1000])
curve("mps_qft_time_ram","qft","qft","n_qubits",[8,20,30,50,100,200])
curve("mps_bonds16_time_ram","bonds","brick4","bond",[2,4,8,64],{"n_qubits":16})
curve("mps_bonds200_time_ram","bonds","brick12","bond",[8,16,32,64,128],{"n_qubits":200})
fig,axes=plt.subplots(1,2,figsize=(6.5,3.25))
for ax,n,circuit,metric,grid in [(axes[0],16,"brick4","tvd_vs_exact",[2,4,8,64]),(axes[1],200,"brick12","discarded_weight",[8,16,32,64,128])]:
 for fw in MF[:-1]:
  lookup={r["bond"]:r for r in mselect(framework=fw,mode="bonds",circuit=circuit,n_qubits=n) if r["status"]=="ok"}
  vals=[quality(lookup[b]).get(metric,np.nan) if b in lookup else np.nan for b in grid]
  if np.isfinite(vals).any():mline(ax,grid,vals,fw)
 ax.set(xscale="log",yscale="log",xticks=grid,xlabel="Maximum bond dimension");ax.set_xticklabels([str(b) for b in grid])
axes[0].set(title="(a) Sixteen qubits",ylabel="TVD versus exact probabilities");axes[1].set(title="(b) Two hundred qubits",ylabel="Reported discarded weight")
legend(fig,axes[0]);save(fig,"mps_truncation_quality","TVD at 16 qubits compares full output probabilities with a dense reference. At 200 qubits, discarded weight is an engine diagnostic with no dense reference in this sweep. Missing fields are not zero. The non-monotonic low-bond SuperFermion sequence is retained.")
def logical(r):return "mps_teleport" if r.get("mcm_case") in ["teleport_mps","scale_teleport"] else r.get("mcm_case","")
classes=[("teleport",12),("teleport",24),("mbqc",17),("repcode",12),("mps_teleport",12),("mps_teleport",30),("mps_teleport",60),("mps_teleport",120)]
labels=["TP 12","TP 24","Wire 17","Rep 12","MPS 12","MPS 30","MPS 60","MPS 120"]
fig,axes=plt.subplots(1,2,figsize=(6.5,3.5))
for fw in MF[:-1]:
 rr=mselect(framework=fw,mode="mcm");lookup={(logical(r),r["n_qubits"]):r for r in rr}
 for ax,col in [(axes[0],"t_expval_total_s"),(axes[1],"peak_rss_mb")]:
  vals=[lookup.get(k,{}).get(col) if lookup.get(k,{}).get("status")=="ok" else np.nan for k in classes]
  vals=[np.nan if v is None else v for v in vals]
  ax.scatter(range(len(classes)),vals,color=MC[fw],marker=MM[fw],s=32 if fw==MF[0] else 24,label=MN[fw])
 for ax in axes:ax.set(yscale="log",xticks=range(len(classes)));ax.set_xticklabels(labels,rotation=45,ha="right",fontsize=8.5)
axes[0].set(title="(a) Matched shot replay",ylabel="Full replay wall (s; log scale)");axes[1].set(title="(b) Process memory",ylabel="Peak RSS (MiB; log scale)")
legend(fig,axes[0],.88);save(fig,"mps_mcm_time_ram","Dynamic replay and process memory from the replacement archive. TP uses 500 shots; Wire 17 uses 200; Rep 12 tests four patterns with 200 shots each. Native MPS teleportation uses 100 shots at 12 qubits and 1,000 at 30, 60 and 120. Counts match within each case. Successful target-bit checks pass for the tested inputs. The common 24-qubit budget boundary has no assigned runtime.")
fig,axes=plt.subplots(1,2,figsize=(6.5,3.25));ns=[12,30,60,120]
for fw in ["sf_optimized","aer"]:
 rr=[r for r in mselect(framework=fw,mode="mcm") if logical(r)=="mps_teleport" and r["status"]=="ok"]
 look={r["n_qubits"]:r for r in rr};assert set(look)==set(ns)
 for ax,col in [(axes[0],"t_expval_total_s"),(axes[1],"peak_rss_mb")]:mline(ax,ns,[look[n][col] for n in ns],fw)
axes[0].set(yscale="log",ylabel="Replay wall (s; log scale)",title="(a) Native MPS teleportation");axes[1].set(ylabel="Peak RSS (MiB)",title="(b) Process memory")
for ax in axes:ax.set(xlabel="Qubits",xticks=ns)
legend(fig,axes[0]);save(fig,"mps_dynamic_scaling","Native MPS teleportation with matched shots within each qubit count: 100 shots at 12 qubits and 1,000 at 30, 60 and 120. Curves connect tested conditions and do not isolate qubit scaling from the shot-count change. One timed replay is recorded per condition; both paths pass the target-bit check.")
fig,axes=plt.subplots(2,2,figsize=(6.5,5.5));conditions=[("ghz",12),("ghz",16),("brick4",12),("brick4",16)]
for i,method in enumerate(["dense","mps"]):
 for fw in MF[:-1]:
  look={(r["circuit"],r["n_qubits"]):r for r in mselect(framework=fw,mode="validate",method=method) if r["status"]=="ok"}
  for ax,col in [(axes[i,0],"t_expval_total_s"),(axes[i,1],"peak_rss_mb")]:
   vals=[look.get(k,{}).get(col) for k in conditions];vals=[np.nan if v is None else v for v in vals]
   if np.isfinite(vals).any():mline(ax,range(4),vals,fw)
 for ax in axes[i]:ax.set(xticks=range(4));ax.set_xticklabels(["GHZ 12","GHZ 16","Brick4 12","Brick4 16"])
 axes[i,0].set(yscale="log",ylabel="Time (s; log scale)",title=method+" recorded validation time")
 axes[i,1].set(ylabel="Peak RSS (MiB)",title=method+" process memory")
h,l=axes[1,0].get_legend_handles_labels();fig.legend(h,l,loc="upper center",ncol=4,frameon=False,bbox_to_anchor=(.53,1.015),fontsize=8);fig.tight_layout(rect=(0,0,1,.95),w_pad=1.8,h_pad=1.6)
save(fig,"mps_validation_time_ram","Dense and MPS correctness-anchor costs. Successful dense-reference rows without recorded timing remain missing from time panels, while their measured RSS is retained. These paths have different validation and extraction contracts and are not ranked as equivalent simulation outputs.")
fig,ax=plt.subplots(figsize=(6.5,2.8));left=np.zeros(5)
statuses=[("ok","#526b2d","OK"),("over_budget","#D55E00","Budget"),("error","#CC79A7","Error"),("not_offered","#cbd0d5","Not offered")]
for status,color,label in statuses:
 vals=[sum(r["framework"]==fw and r["status"]==status for r in mps) for fw in MF]
 ax.barh(range(5),vals,left=left,color=color,label=label);left+=vals
ax.set_yticks(range(5),[MN[f] for f in MF]);ax.invert_yaxis();ax.set_xlabel("Unique recorded jobs")
ax.legend(ncol=4,loc="lower left",bbox_to_anchor=(0,1.01),frameon=False,fontsize=8);fig.tight_layout()
save(fig,"mps_job_status","Outcomes after retry deduplication and selection of the included MPS configurations: 182 jobs, comprising 141 OK, 12 budget, three error and 26 not-offered results. Coverage differs across adapters. Counts describe the planned interface, not general framework success or speed.")

# Detailed MPS tables; every selected record must occur once.
statusmap={"ok":"OK","over_budget":"OB","error":"E","not_offered":"NO"}
def num(v):return "N/A" if v is None or (isinstance(v,float) and not math.isfinite(v)) else f"{v:.6g}"
used=[];mt=[]
note="Time is recorded adapter execution in seconds; RAM is process peak RSS in MiB. OK: completed; OB: budget limit; E: adapter error; NO: not offered; NT: no recorded job. N/A is unrecorded, never zero."
def detail(label,title,rr,metric="expval_z0zlast",mcm=False):
 rows=[]
 for fw in MF:
  hit=[r for r in rr if r["framework"]==fw];assert len(hit)<=1
  r=hit[0] if hit else None
  if r:used.append(key(r))
  if not r:rows.append([MN[fw],"N/A","N/A","N/A","N/A","NT"] if mcm else [MN[fw],"N/A","N/A","N/A","NT"]);continue
  time=num(r.get("t_expval_total_s")) if r["status"]=="ok" else "N/A"
  ram=num(r.get("peak_rss_mb"));status=statusmap[r["status"]]
  if mcm:rows.append([MN[fw],time,ram,str(r.get("shots",0))+("/pattern" if logical(r)=="repcode" else ""),"Yes" if r.get("all_correct") is True else "N/A",status])
  else:rows.append([MN[fw],time,ram,num(r.get(metric) if metric=="expval_z0zlast" else quality(r).get(metric)),status])
 metricname={"expval_z0zlast":"Z0 Zlast","tvd_vs_exact":"TVD","discarded_weight":"Discarded\nweight"}[metric]
 cols=["Framework","Wall (s)","RAM (MiB)","Shots","Correct","Outcome"] if mcm else ["Framework","Time (s)","RAM (MiB)",metricname,"Outcome"]
 extra=" Target-bit checks cover only the tested inputs." if mcm else " A single correlation does not establish full-state equality."
 if mcm and any(logical(r)=="repcode" for r in rr):extra+=" Four error patterns are replayed with 200 shots per pattern (800 total per completed row)."
 mt.append(dict(type="table",label=label,title=title,columns=cols,rows=rows,note=note+extra,widths=[1.5,.95,.95,1.05,.8,1.25] if mcm else [1.5,1.05,1.05,1.5,1.4]))
for circ in ["ghz","brick4"]:
 for n in [12,16]:
  for method in ["dense","mps"]:detail(f"mps_validate_{circ}_{n}_{method}",f"{circ.upper() if circ=='ghz' else 'Brick4'} correctness anchor at {n} qubits using {method}",mselect(mode="validate",circuit=circ,n_qubits=n,method=method))
for circ in ["ghz","brick4"]:
 for n in [50,100,200,500,1000]:detail(f"mps_ladder_{circ}_{n}",f"{circ.upper() if circ=='ghz' else 'Brick4'} at {n} qubits and maximum bond 64",mselect(mode="ladder",circuit=circ,n_qubits=n))
for n in [200,500,1000]:detail(f"mps_stress_brick12_{n}",f"Brick12 stress at {n} qubits and maximum bond 64",mselect(mode="stress",n_qubits=n))
for n in [8,20,30,50,100,200]:detail(f"mps_qft_{n}",f"QFT at {n} qubits and maximum bond 64",mselect(mode="qft",n_qubits=n))
for n,circ,grid,metric in [(16,"brick4",[2,4,8,64],"tvd_vs_exact"),(200,"brick12",[8,16,32,64,128],"discarded_weight")]:
 for b in grid:detail(f"mps_bonds_{n}_{b}",f"{circ.capitalize()} at {n} qubits and maximum bond {b}",mselect(mode="bonds",n_qubits=n,bond=b),metric)
for case,n in classes:
 rr=[r for r in mselect(mode="mcm",n_qubits=n) if logical(r)==case]
 title={"teleport":"Ordinary teleportation","mbqc":"Measurement based wire","repcode":"Repetition code","mps_teleport":"Native MPS teleportation"}[case]
 detail(f"mps_mcm_{case}_{n}",f"{title} at {n} qubits",rr,mcm=True)
assert len(mt)==44 and len(used)==len(set(used))==182 and set(used)=={key(r) for r in mps}
(data/"mps_detailed_tables.json").write_text(json.dumps(mt,indent=2)+"\n")
builds=Counter(r.get("engine_md5") or "unrecorded" for r in mps if r["framework"]=="sf_optimized")
missing=sum(r["status"]=="ok" and r.get("t_expval_total_s") is None for r in mps)
parity={}
for fw in MF[:-1]:
 diffs=[]
 for circ,n in conditions:
  d=mselect(framework=fw,mode="validate",method="dense",circuit=circ,n_qubits=n)
  a=mselect(framework=fw,mode="validate",method="mps",circuit=circ,n_qubits=n)
  if d and a and d[0]["status"]==a[0]["status"]=="ok":diffs.append(abs(d[0]["expval_z0zlast"]-a[0]["expval_z0zlast"]))
 parity[fw]=max(diffs)
sources={str(f.relative_to(p)):{"sha256":hashlib.sha256(f.read_bytes()).hexdigest(),"bytes":f.stat().st_size} for root in [p/"source_reports",src] for f in root.rglob("*") if f.is_file()}
audit=dict(selected_statevector_records=1652,simulator_records=1512,controls=140,conditions_per_configuration=252,
 included_statevector_configurations=SV,matched_pairs=1260,pair_plot_counts=pairaudit,
 display_rounding_separated_leaders=dict(leaders),display_rounding_unresolved_conditions=unresolved,
 selected_zero_latency_rows=int(df.rounded_zero.sum()),replacement_mps_raw_rows=282,replacement_mps_unique_rows=264,
 selected_mps_jobs=182,selected_mps_outcomes=dict(Counter(r["status"] for r in mps)),
 mps_lane_outcomes={MN[fw]:dict(Counter(r["status"] for r in mps if r["framework"]==fw)) for fw in MF},
 successful_mps_rows_without_time=missing,mps_dense_reference_max_correlation_errors=parity,
 superfermion_mps_build_counts=dict(builds),mps_csv_matches_latest_jsonl=True,mps_trial_medians_match=True,
 successful_mcm_target_checks_pass=True,every_selected_mps_job_tabulated_once=True,
 source_sha256=sources,benchmarks_rerun=False,heatmap_cells=250,planned_heatmap_cells=230,
 heatmap_color_range=[.5,512],figures=len(manifest),mps_detailed_tables=44,
 interleaved_note="Report-level summaries only; supplementary call-level files are not included in the replacement archive and are not used in the primary numeric tables or figures.")
assert len(manifest)==36
(data/"figure_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
(data/"analysis_checks.json").write_text(json.dumps(audit,indent=2)+"\n")
print(json.dumps({k:audit[k] for k in ["selected_statevector_records","matched_pairs","selected_mps_jobs","selected_mps_outcomes","successful_mps_rows_without_time","figures","mps_detailed_tables"]},indent=2))
