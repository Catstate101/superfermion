"""Validate the integrated manuscript against source records and final documents."""
from pathlib import Path
from zipfile import ZipFile
from collections import Counter
from copy import deepcopy
import argparse, hashlib, json, re
import fitz
from docx import Document
from lxml import etree

def validate(pkg, pdf, docx, word_pdf=None):
    m=json.loads((pkg/'data/manuscript.json').read_text())
    blocks=m['blocks'];counts=Counter(b['type'] for b in blocks)
    assert (counts['table'],counts['figure'],counts['equation'])==(132,42,17)
    assert len(m['references'])==21
    refs={r['key'] for r in m['references']}
    assert len(refs)==21
    labels=[b['label'] for b in blocks if 'label' in b]
    assert len(labels)==len(set(labels))
    base=json.loads((pkg/'data/base_manuscript.json').read_text())
    for typ in ('table','figure','equation'):
        old={b['label']:b for b in base['blocks'] if b['type']==typ}
        now={b['label']:b for b in blocks if b['type']==typ}
        for k,v in old.items():
            expected=deepcopy(v)
            if typ=='table' and k=='mps_software':
                expected['rows'][0][1]='0.1.15'
                expected['title']='MPS software versions and execution paths'
                expected['note']=('The SuperFermion release label is updated to 0.1.15 for this preprint revision; '
                    'the benchmark values are retained from the archived runs and were not remeasured for the release update. '+v['note'])
            assert now[k]==expected,(typ,k)
    tables=[b for b in blocks if b['type']=='table']
    figures=[b for b in blocks if b['type']=='figure']
    equations=[b for b in blocks if b['type']=='equation']
    index=json.loads((pkg/'data/document_index.json').read_text())
    assert list(index['tables'].values())==list(range(1,133))
    assert list(index['figures'].values())==list(range(1,43))
    for b in blocks:
        for field in ('text','caption','note'):
            for kind,keys in re.findall(r'\{\{(cite|fig|tab):([^}]+)\}\}',b.get(field,'')):
                if kind=='cite':assert set(keys.split(','))<=refs
                else:assert keys in index['figures' if kind=='fig' else 'tables']
    modes=json.loads((pkg/'data/mode_analysis_checks.json').read_text())
    assert modes['raw_conditions']==24 and modes['selected_framework_observations']==81
    assert all(x['passed'] for x in modes['csv_jsonl_reconciliation'])
    assert modes['aer_diagonal_flagged_qubits']==[10]
    assert modes['ram_measured'] is False and modes['benchmarks_rerun'] is False
    earlier=json.loads((pkg/'data/analysis_checks.json').read_text())
    assert earlier['mps_csv_matches_latest_jsonl'] and earlier['mps_trial_medians_match']
    assert earlier['every_selected_mps_job_tabulated_once'] and earlier['successful_mcm_target_checks_pass']
    for rel,meta in earlier['source_sha256'].items():
        raw=(pkg/rel).read_bytes()
        assert len(raw)==meta['bytes']
        assert hashlib.sha256(raw).hexdigest()==meta['sha256'],rel
    for rel,meta in modes['source_hashes'].items():
        raw=(pkg/rel).read_bytes()
        assert len(raw)==meta['bytes']
        assert hashlib.sha256(raw).hexdigest()==meta['sha256'],rel
    details=json.loads((pkg/'data/mode_detailed_tables.json').read_text())
    tmap={b['label']:b for b in tables}
    assert len(details)==24
    for b in details:
        assert tmap[b['label']]['columns']==b['columns']
        assert tmap[b['label']]['rows']==b['rows']
    for b in figures:
        for ext in ('.png','.svg','.pdf'):
            assert (pkg/Path(b['file']).with_suffix(ext)).stat().st_size>1000
    d=Document(docx)
    assert len(d.tables)==132 and len(d.inline_shapes)==42
    for n,(actual,expected) in enumerate(zip(d.tables,tables),1):
        cells=[[c.text for c in r.cells] for r in actual.rows]
        assert cells==[expected['columns']]+expected['rows'],('Word table',n)
    with ZipFile(docx) as z:
        xml=etree.fromstring(z.read('word/document.xml'))
    ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    assert len(xml.findall('.//m:oMath',ns))==17
    assert not any('{{' in p.text for p in d.paragraphs)
    paragraphs=[p.text for p in d.paragraphs]
    assert [int(x[1]) for p in paragraphs if (x:=re.match(r'Table (\d+)\.',p))]==list(range(1,133))
    assert [int(x[1]) for p in paragraphs if (x:=re.match(r'Figure (\d+)\.',p))]==list(range(1,43))
    results={}
    for kind,path in [('latex_pdf',pdf),('word_render',word_pdf)]:
        if path is None:continue
        f=fitz.open(path);text='\n'.join(p.get_text() for p in f)
        tables_found=[int(v) for v in re.findall(r'Table\s+(\d+)[.:]',text)]
        figures_found=[int(v) for v in re.findall(r'Figure\s+(\d+)[.:]',text)]
        assert tables_found==list(range(1,133)),(kind,'table captions',tables_found)
        assert figures_found==list(range(1,43)),(kind,'figure captions',figures_found)
        assert not any(x in text for x in ('\ufffd','{{','[?]'))
        assert 'Execution mode comparisons by condition' in text
        assert 'retained second comparison window' in text.replace('\n',' ')
        issues=[];pages=[]
        for i,p in enumerate(f,1):
            spans=[s for b in p.get_text('dict')['blocks'] if b['type']==0 for l in b['lines'] for s in l['spans'] if s['text'].strip()]
            for s in spans:
                x0,y0,x1,y1=s['bbox']
                if x0<59 or x1>p.rect.width-59 or y0<57 or y1>p.rect.height-27:
                    issues.append({'page':i,'text':s['text'],'bbox':s['bbox']})
            assert spans,(kind,'blank page',i)
            pages.append({'page':i,'characters':len(p.get_text()),'text_spans':len(spans),
                          'min_y':round(min(s['bbox'][1] for s in spans),2),
                          'max_y':round(max(s['bbox'][3] for s in spans),2)})
        assert not issues,(kind,'text outside bounds',issues)
        results[kind]={'pages':len(f),'all_captions_present':True,'text_bounds_clear':True,'page_checks':pages}
    log=(pkg/'main.log').read_text(errors='replace')
    bad=re.findall(r'(?:Overfull [^\n]+|LaTeX Warning: (?:Reference|Citation)[^\n]+|Missing character:[^\n]+|^! [^\n]+)',log,re.M)
    assert not bad,bad
    return {'passed':True,'tables':132,'figures':42,'editable_word_equations':17,'references':21,
            'original_numerical_tables_figures_equations_preserved':True,'word_table_cells_match_shared_source':True,
            'all_source_hashes_match':True,'later_source_hashes_match':True,'later_conditions':24,'later_diagonal_flag_preserved':True,
            'benchmarks_rerun':False,'pdf_checks':results,'visual_review_completed':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--package-dir',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--pdf',type=Path,required=True);p.add_argument('--docx',type=Path,required=True)
    p.add_argument('--word-pdf',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args();r=validate(a.package_dir,a.pdf,a.docx,a.word_pdf)
    if a.output:a.output.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k!='pdf_checks'},indent=2))
    print(json.dumps({k:{'pages':v['pages'],'all_captions_present':v['all_captions_present'],'text_bounds_clear':v['text_bounds_clear']} for k,v in r['pdf_checks'].items()},indent=2))
