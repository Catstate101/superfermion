# SF optimization methods at the math level — MPS engine vs cat (Clifford) engine

Scope: what SuperFermion actually does inside the two engines, expressed as the
mathematical objects and algorithms in the source, plus an honest "which is
better" that respects the different computational classes involved.

Sources (all read from this workspace):

- `superfermion/crates/sf-ir/src/mps.rs` (2700 lines) — the MPS engine.
- `superfermion/crates/sf-ir/src/stabilizer.rs` (1531 lines) — the reference
  Aaronson–Gottesman (AG) tableau.
- `superfermion/crates/sf-cat/src/paulframe.rs` (1503 lines) — the cat
  Pauli-frame/tableau engine (the mode used by `Mode::Stab` and `Mode::Cliff`).
- `superfermion/crates/sf-cat/src/plan.rs` — the cat mode planner.
- `sf_modes_bench_suite/sfmodes_bench_out/report.md` — the measured standings
  quoted in Section 3 (same machine, ABBA-interleaved, medians).

Everything below is anchored to code; numeric claims labelled "internal" are
measured values recorded in the Rust source comments themselves, not re-run here.

---

## 1. MPS engine — what SF optimizes, mathematically

### 1.1 Representation

State = matrix product state \(|\psi\rangle = \sum_{s} \mathrm{Tr}(A^{s_1} \cdots A^{s_n})|s\rangle\).
In code each site is one matrix \(T\) of shape \((D_L \cdot 2,\; D_R)\)
(`mps.rs` L151–160), i.e. the two physical blocks \(T^{s=0}, T^{s=1}\) stacked
vertically; bonds are capped at `bond_dim` (default 64) and complex64 entries.

### 1.2 Canonical forms, gauge, and lazy repair

- **Left canonicalization**: left-to-right QR sweep, \(T_i = QR\), keep \(Q\),
  absorb \(R\) into site \(i+1\) (`canonicalize_left`, L232, cost \(O(n\chi^3)\)).
- **Right canonicalization** (isometry \(\sum_s B^s B^{s\dagger} = I\)): right-to-left
  LQ sweep on the reshaped \((D_L, 2D_R)\) form (`canonicalize_right_range`, L303).
- **Dirty-window bookkeeping**: `rc_start` (L161–166) is the first site whose
  suffix is guaranteed right-isometric. A 2q gate rewrites only its two sites,
  so `rc_start = max(q1,q2)+1` (L504–507); a measurement repairs only the
  window `(site+1, rc_start)` instead of resweeping the chain (L1988–1992).
- **Cached left environment** for sequential (left-to-right) measurements:
  \(v'[r] = \sum_l v[l]\,(T[l,r] + T[l+D_L,r])\) (`contract_site_into`, L2047),
  accumulated across a whole measurement sequence (`meas_env_extend_to`, L2064)
  and invalidated only when a rewrite below the frontier makes it stale (L2085).
  Total cost of a full measurement pass becomes one site-contraction per site.

### 1.3 Two-qubit gate application — the core merge

Merging the two sites and applying the gate \(g\) gives magnitude

\[
M[(o_1,l),(o_2,r)] \;=\; \sum_{i_1,i_2} g[2o_1+o_2,\;2i_1+i_2]\;
T_1^{i_1}[l,\cdot]\; T_2^{i_2}[\cdot,r],
\]

built as four block matmuls (\(2d_{l1} \times 2d_{r2}\)), then split back. The
split policy is selected once from `SF_MPS_TRUNCATION` (L98–119):

1. **Exact block-diagonal split** (`blockdiag_exact_split`, L922) — whenever the
   4×4 gate satisfies \(g[o,i]=0\) unless \((o\!\gg\!1)=(i\!\gg\!1)\) (all
   diagonal-type gates: rzz, crz, cz, cp, cu1, …). Then exactly
   \(M = \mathrm{blockdiag}(T_1^0, T_1^1)\,B\), whose middle index carries only
   \(2\cdot\min(d_{l1}, d_m, d_{r2})\) entries, so \(\mathrm{rank}(M)\le 2\min(d_{l1},d_m,d_{r2})\).
   If that bound fits the cap the merge is exactly representable: two thin QRs,
   two half-size matmuls, drop rows below \(10^{-12}\|C\|_F\) (float phantoms) —
   no SVD needed, machine-precision exactness on the dominant 2q-gate class.
2. **Default policy: thin SVD truncation** (`svd_truncate_merged`, L1412).
   Compute \(M = U\Sigma V^\dagger\); keep the \(k=\min(\text{bond},\ \#\{\sigma>\tau\})\)
   largest singular values with \(\tau = 10^{-12}\,\|M\|_F\) (\(\|M\|_F\) measured
   from the entries, not from the reported σ). The factors are built purely on
   the \(v\)-side: \(w_c = M v_c\), left column \(w_c/\|w_c\|\), right row
   \(\|w_c\|\,\overline{v_c}^T\), so the pair reproduces \(M(V_kV_k^\dagger)\)
   without using the backend's \(u()\), and the retained mass
   \(\sum_c \|M v_c\|^2\) is always *measured*, never inferred from reported σ.
   Guard: if the reported singular values are inconsistent (faer degenerate
   spectra mispair σ with v — documented with a minimal repro in L1516–1544),
   the kept columns are re-selected by measured \(\|M v_c\|\).
   Discarded fraction per step: \(\varepsilon = \sum_{\text{disc}}\sigma^2 / \sum \sigma^2\).
3. **Legacy path** (`SF_MPS_TRUNCATION=qr|legacy`): historical unpivoted
   Householder QR position cut. Measured worse and kept only for
   reproducibility: on brick12@n=200 it produced a dirty bond ladder
   {34,42,52,64} with 180 guard fires and ε≈5.2e-4 at 2.18 s, while the
   all-SVD default measured 1.04 s with Σε≈6.7e-14 and a clean \(2^k\) ladder.
   On brick12@26 cap 64 the default fixed err 4.2e-6 → 3.6e-14 and
   Σε 6.7e-2 → 1.1e-16 (internal measurements, source comments L108–119).

### 1.4 Numerics: BLAS-quality kernels

faer is used for the heavy matmul *and* the QR/SVD factorizations
(`ThinSvd`, `FaerQr`, L6–15): cache-blocked AVX-2 microkernels reach ~8 GFLOPS
where nalgebra runs ~1 GFLOPS at \(D=64\), and the \(O(D^2)\) conversion cost is
amortized over the \(O(D^3)\) factorization. Rayon parallelism engages at
\(d_m \ge 64\) (L371–375, L985–989), i.e. exactly where the matmul cost
justifies the thread-pool dispatch.

### 1.5 Routing

- **Full routing** (`apply_2q_gate_routed`, L458): SWAP chain of adjacent
  2-site gates to bring distant qubits together, gate, SWAP back.
- **Lazy-SWAP routing** (`apply_gate_lazy_routed`, L430–453): a virtual↔physical
  permutation `(perm, perm_inv)` is tracked; a distant gate moves the higher
  virtual qubit leftward one physical swap at a time and *no swap-back* — the
  qubit keeps its new site. Each step is one exact SWAP application plus an
  \(O(1)\) permutation update.

### 1.6 Measurement, sampling, expectation values

- **Projective Z measurement** (`measure_site`, L1981): outcome weights
  \(p_p = \bigl\|\sum_l v_l\, T[p\,D_L + l,\ :]\bigr\|^2\) using the cached left
  environment and the right-isometric tail (so no conditioning on earlier
  sites); collapse zeroes the other physical block and rescales the survivor by
  \(\sqrt{(p_0+p_1)/p_p}\) — norm-preserving. `reset_site` = measure + conditional X (L2094).
- **Sampling** (`sample_one_with_rng`, L1908): exact sequential conditionals —
  at each site draw bit \(b\) with \(P(b)=\text{prob}_b/(\text{prob}_0+\text{prob}_1)\),
  project the left vector onto the outcome, renormalize, continue. This is the
  chain-rule decomposition \(P(s) = \prod_i P(s_i\,|\,s_{<i})\), cost
  \(O(n\chi^2)\) per shot, with **no statevector materialization** — the point of
  MPS sampling.
- **Pauli expectation values** (`pauli_expval`, L2110): boundary-contraction
  transfer matrix \(L_{\text{new}} = \overline{T}_{\text{top}}^{\,\dagger} L\,a
  + \overline{T}_{\text{bot}}^{\,\dagger} L\,b\) per site, where the Pauli acts
  by swapping the top/bottom blocks (X), a sign (Z), or \(\mp i\) (Y); the final
  1×1 matrix is \(\langle\psi|P|\psi\rangle\). No \(2^n\) object ever exists.

### 1.7 Truncation telemetry

Per-step ε accumulates into `discarded_weight` (Σε), with
`max_discarded_weight` and `truncation_events` (L173–184, `record_discard` L515).
`fidelity_lower_bound = 1 − Σε` is documented as a **conservative union-bound
metric, not a certified bound** (L527–539) — compounding truncation error is not
controlled, and the code says so. Telemetry surfaces to Python via
`truncation_report()`, a `RuntimeWarning`, and `SF_MPS_STRICT=1` (raise).

---

## 2. cat engine — what SF optimizes, mathematically

cat's `Mode::Stab` and `Mode::Cliff` compile to the same Pauli-frame tableau
(`plan.rs` L72–79); anything non-Clifford is an explicit build-time error, never
a wrong sample. `Mode::Dm` is a documented hold-out (`plan.rs` L60).

### 2.1 The algebra

- Pauli group \(P_n = \langle iI, X_j, Z_j\rangle\); a stabilizer state is the
  \(+1\) eigenspace of an abelian subgroup \(S \subset P_n\) with \(-I\notin S\).
- **Tableau (AG 2004)**: \(2n\) rows — destabilizers \(X_q\) (rows \(0..n\)),
  stabilizers \(Z_q\) (rows \(n..2n\)) — as a binary \((x|z)\) matrix plus a
  phase bit \(r\) per row. Rows are stored **flattened into u64 words**
  (`words = ⌈n/64⌉`, `paulframe.rs` L83–90), so one gate costs
  \(O(n^2/64)\) word operations.

### 2.2 Gate updates as GF(2) row operations

From `stabilizer.rs` (identical kernels ported bit-for-bit into
`paulframe::apply_row`):

- **H(q)**: for every row, \(r \mathrel{\oplus}= x_q \wedge z_q\), then swap the
  q-th bits of x and z (L165–177) — the conjugation X↔Z, Z↔X, Y↦−Y.
- **S(q)**: \(r \mathrel{\oplus}= x_q \wedge z_q\); \(z_q \mathrel{\oplus}= x_q\) (L179–188).
- **CNOT(a,b)**: \(r \mathrel{\oplus}= x_a\, z_b\,(x_b \oplus z_a \oplus 1)\);
  \(x_b \mathrel{\oplus}= x_a\); \(z_a \mathrel{\oplus}= z_b\) (L226–244).
- CZ/CY/SX/SXDG are expanded into these primitives at flatten time
  (`paulframe.rs` L138–150), so the hot loop has one tiny op vocabulary.

**Phase of a Pauli product** (`phase_of_product`, L113–131) is computed word-level:
three bit-masks pick the pair patterns that contribute \(i\), three others the
patterns that contribute \(i^3\), and the phase in units of \(i \bmod 4\) is
\(\bigl[\sum_w \#c_1(w) + 3\,\#c_3(w)\bigr] \bmod 4\) via `count_ones()` —
64× fewer loop iterations than a per-bit implementation, and zero words are
skipped outright.

### 2.3 Fused row-major build

`apply_cops` (L583): the whole op list is applied to **one tableau row at a
time** (row x/z/r slices local to the loop), instead of gate-by-gate. Cost
\(O(2n \cdot m \cdot n/64)\) word ops for \(m\) gates, with rayon row-chunk
parallelism above `rows × ops ≥ 2^18` (env `SF_CAT_STAB_PAR_MIN`).

### 2.4 Measurement plan = affine GF(2) forms (the key trick)

`build_plan` (L633) runs the AG measurement of \(Z_q,\ q=0..n-1\) **once** and
records the *symbolic* outcome of every qubit:

- **Random branch**: let \(p \ge n\) be a stabilizer row with \(x[p][q]=1\).
  The measurement outcome is genuinely random — register a fresh variable
  `PEntry::Random{var}`; restructure the tableau (copy row p into the
  destabilizer slot p−n, overwrite slot p with \(Z_q\), set the row's phase
  mask to \(e_{\text{var}}\)), invalidate the column index (L705–798).
- **Determined branch**: accumulate the destabilizer rows \(i\) with
  \(x[i][q]=1\) by XOR, thread the phase through `popp&1`, `popp>>1` and the
  carry of repeated \(i\)-contributions (L799–878), and emit
  `PEntry::Determined{vars, c}` where `vars` is the **sparse index list**
  (`mask_to_vars`, L279) of drawn variables. The outcome is the affine form
  \[
  y_q = c_q \oplus \bigoplus_{r \in A_q} y_r .
  \]

Why this is mathematically valid: the AG measurement rule guarantees each
\(Z_q\) either anticommutes with the current stabilizer group (fresh
independent bit) or commutes and its outcome is fixed by the parity of the
earlier random outcomes through the stabilizer subgroup — exactly an affine
function of the previously drawn variables. Sparse lists exploit the
light-cone: GHZ outcomes depend on one variable; depth-8 brickwork outcomes on
a bounded window.

An advisory **column index** (`colidx`, L651–682) stores, per (word, bit), the
bitmask of rows with \(x[\cdot][q]=1\), so "which rows have x=1 at q" is
set-bit iteration instead of scanning \(2n\) rows (the measured plan bottleneck
at n ≥ 1024).

### 2.5 Bulk sampling in 64-shot lanes

`sample_packed` (L938): process 64 shots per block and put **one shot per bit
of a u64**:

1. Draw `var_count` u64 words from the RNG — each word is one bit per shot
   ("lane") for one random variable.
2. Evaluate the plan once per qubit into a u64 lane: `Random` → the variable's
   word; `Determined` → `c ⊕ XOR` of the referenced variable words — one word
   XOR per dependency, 64 shots at a time.
3. Transpose the n lanes (n bits × 64 shots) into packed keys, branchless, with
   an optional additive C++ kernel when `SF_CAT_KERNEL` is set and a Rust
   fallback otherwise (L995–1009). GHZ special case: identical lanes are
   broadcast through the n-bit mask in one copy (L979–994).
4. Rayon over blocks above `shots × n ≥ 2^20` (env `SF_CAT_SAMPLE_PAR_MIN`).

Per-shot cost collapses to ≈ (number of variable references + O(n)) / 64 u64
operations — versus the naive per-shot AG procedure (O(n²) word ops per
measurement × n measurements).

### 2.6 Counting and string I/O

Keys are hashed with an in-file FxHash-style hasher (L43–78; no adversarial
input), strings are materialized once per **distinct** key (`key_to_string`,
L293), and the BMI2 path expands 8 key bits into 8 ASCII `'0'/'1'` bytes
branchlessly with `pdep` (L317–347), with a portable scalar fallback. The cat
cell has **no 4096-qubit cap** (the sf-ir tableau asserts n ≤ 4096; this cell
does not, L18–20).

---

## 3. "Which is better?" — the honest regime answer

### 3.1 They are not interchangeable: different computational classes

- **cat** *exactly* simulates the **Clifford class** (Gottesman–Knill):
  polynomial in n for any Clifford circuit, no error, but **cannot represent a
  single T gate** (a non-Clifford rotation lifts the state into a stabilizer-rank
  superposition with rank growing like 2^t).
- **MPS** *approximately* simulates the **general class** with truncation:
  cost polynomial in n and χ, error controlled (not certified) by Σε; it
  handles arbitrary rotations but is defeated by volume-law entanglement,
  where χ must grow like 2^{Ω(n)} (even for Clifford circuits: random
  Clifford / deep brickwork).

### 3.2 Where cat is better — and it is, within its class

Any Clifford workload: cat is exact and cheaper by construction. The clearest
mathematical witness is volume-law entanglement, where an MPS at χ=64 simply
cannot represent the state, while the tableau doesn't care. Measured in this
workspace's suite (`sf_modes_bench`, same machine, ABBA, medians):

- Warm counting, cat vs stim: **5/5** cliff-regime rows faster —
  13.07× (ghz n=1024), 28.85× (ghz n=4096), 3.07× (brick n=1024),
  5.40× (brick n=4096), 6.68× (randcliff n=4096); and **5/6** stab rows
  (the loss: brick n=64, 0.45×).
- Cold full-pipeline cat is **not** ahead everywhere: it loses 3/5 cliff cold
  rows to stim (0.11×–0.47×), and one stab cold row. The suite discloses the
  asymmetry: cat ran 4-thread RAYON, competitors at shipped defaults (stim
  single-threaded), 2000 shots, first-call budget 40 s.

### 3.3 Where MPS is better

Circuits that are not Clifford — arbitrary RY/RZ/T layers, variational ansätze
— where cat cannot run at all. Within its class the engine is quantitative:
GHZ to 200 qubits at bond 64 is exact (discarded weight 0 in the guard sweep);
short-depth brickwork runs with the SVD τ-prune driving Σε to ~1e-14–1e-16 on
the recorded test cases (internal measurements, Section 1.3). SF does not
bench MPS against other tensor-network engines in this suite — that comparison
was not measured here, and no claim is made.

### 3.4 Verdict

"cat vs MPS" has no single winner: **cat is the better engine for Clifford
circuits** (that is what it is built and tuned for, and it beats stim warm in
our runs with disclosed threading), **MPS is the only option for non-Clifford
weakly-entangled circuits** (with approximate, disclosed-truncation results).
Framing either as "better" outside its class would be a category error — the
same conclusion `plan.rs` encodes by routing Clifford circuits to the
Pauli-frame cell and keeping DM (and non-Clifford statevector work) on other
engines.

---

## 4. Method → code map (quick reference)

| Method (math) | What it buys | Where |
|---|---|---|
| MPS canonical QR/LQ sweeps, isometry | stable sampling/measurement, gauge | mps.rs L232, L303 |
| Dirty-window `rc_start` + env caching | avoid full re-canonicalization | mps.rs L161–170, L2047–2089 |
| Merge formula + 3-way split policy | O(χ³) exact-or-optimal per 2q gate | mps.rs L98–119, L541–560, L922, L1412 |
| Block-diagonal exact split (diagonal gates) | machine-exact, no SVD | mps.rs L900–920 |
| τ-pruned thin SVD + measured-mass guard | optimal truncation, honest ε | mps.rs L1412–1544 |
| faer AVX-2 matmul/QR/SVD, Rayon ≥ D=64 | ~8 GFLOPS vs ~1 GFLOPS | mps.rs L6–15, L371 |
| Lazy-SWAP permutation routing | O(1) bookkeeping, no swap-back | mps.rs L419–453 |
| Sequential conditional sampling | O(nχ²)/shot, no statevector | mps.rs L1908–1969 |
| Transfer-matrix Pauli expval | ⟨P⟩ without 2^n objects | mps.rs L2110–2190 |
| Σε telemetry + strict mode | honest, non-silent truncation | mps.rs L173–184, L515–539 |
| Word-packed GF(2) tableau (AG 2004) | O(n²/64) per Clifford gate | paulframe.rs L83–131; stabilizer.rs L165–251 |
| Popcount phase forms (mod 4 in units of i) | 64× fewer iterations | paulframe.rs L113–131 |
| Fused row-major build + Rayon rows | cache-friendly, thresholded parallel | paulframe.rs L583–626 |
| Measurement plan as affine GF(2) forms | shots = XOR evaluation, not tableau replay | paulframe.rs L633–922 |
| Sparse variable lists (light-cone) | GHZ: weight 1 | paulframe.rs L279–290 |
| 64-shot u64 lanes + branchless transpose | 64 shots per word op | paulframe.rs L938–1029 |
| FxHash keys, once-per-key strings, BMI2 pdep | counting/IO off the hot path | paulframe.rs L43–78, L293–347 |

---

## 5. Disclosures / what was NOT measured

- All cat-vs-competitor numbers come from one suite run on one machine with the
  disclosed protocol (ABBA windows, medians, 2000 shots, per-lane first-call
  budget 40 s); cat ran 4-thread RAYON while competitors used shipped defaults.
  Cold full-pipeline cat loses on several rows — quoted here, not hidden.
- MPS quality numbers (ε values, the 1.04 s vs 2.18 s comparison) are internal
  measurements recorded in the Rust source comments; they were not re-run as
  part of this report.
- No head-to-head cat-vs-MPS benchmark on a shared circuit class exists here
  (and cannot meaningfully exist for non-trivial circuits — the classes only
  intersect on circuits both engines can represent, where cat is exact and
  MPS is approximate).
- The 4096-qubit cat cap is Python-side only; the Rust cell has none. The
  sf-ir tableau asserts n ≤ 4096.
