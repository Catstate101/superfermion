# v8 Local Grid Benchmark — Partial Report (cell 41, till 2026-10-05)

*Generated automatically from the study's raw result files. This is a live snapshot; the run is still in progress (q20 tail + q24 + cells 43–49 pending).*

## 1. Scope & status

- Committed campaign results covered here: **742** of 1080 (cell 41: kernel & classical).
- Status: 738 ok, 4 error (timeouts, listed in section 9).
- Levels q4–q16 complete (720 jobs); q20 partial; q24 not started; cells 43–49 not started.

## 2. Provenance & environment

- Notebook: `Superfermion_Full_Grid_24Q_Local_v8.2.ipynb` sha256 `dddc4abea49d71cd098434d75430c26a8b8dfe525c90f7008a2b1a137d29b150`
- Chain manifest sha256: `c186549cb5eea8ed48a8a3531f0cb4582749ced8562e16b1e79b1233615d8aef`
- Correctness gate: 288 independent checks passed; configuration_sha256 `5168bb722b9078acdf4241557d94b9c33abc8b616689c2685d5d4a247317a2f7`
- Timeout profile: `timeout_s=900` (cell 41 ran at 1800; cells 43–49 will run at 900)
- Statebank cap: 536870912 bytes (512 MiB); kernel row caps: {'24': 32}
- Python 3.13.3 on Windows-11-10.0.26100-SP0 | cpu_count=8 | threads=1 (single-thread lanes)

## 3. Methodology & honesty notes

- Metric: `end_to_end_s` = wall time around the job's compute inside the worker; medians shown, min/max and every individual value are in Appendix A. `worker_peak_rss_mib` = peak RSS of the dedicated worker process.
- Values in matrices are **medians across config variants** (feature-map/depth/batch/etc.), with n(ok) in parentheses; `+kE` marks k timeout errors.
- Timeouts (1800 s cap) are recorded as missing data points, never as wins; frameworks/lane-timeouts are listed explicitly.
- The 3 SF lanes are all Superfermion 0.1.14: PyPI wheel / source baseline / source+embedded patch ('optimized').
- Known measurement-window notes: the correctness gate was regenerated twice at below-normal priority (~05:58–06:07 and ~10:42–10:46 local) overlapping a small number of long jobs; effect is expected to be negligible but is disclosed. The mid-run chain repair relabels cell-41 rows M1→M2 after the cell ends (pending; raw values unaffected).
- HONESTY: accuracy metrics agree exactly across full simulators where measured (section 8); where another lane wins or ties, it is stated in section 6.

## 4. Progress accounting

- qsvm: 357
- qkrr: 136
- qkpca: 163
- classical: 86
- Total committed: 742

## 5. Time results (median end_to_end_s, single run per config; n in parentheses)

### qsvm / breast_cancer

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.1 (2) | 0.1 (2) | 0.9 (2) | 9.1 (2) | 1095.6 (1) | — |
| sf_optimized (patched) | 0.0 (2) | 0.1 (2) | 0.8 (2) | 7.3 (2) | 952.8 (1) | — |
| sf_source_baseline | 0.1 (2) | 0.1 (2) | 0.9 (2) | 8.7 (2) | 1065.6 (1) | — |
| analytical_angle | 0.0 (1) | 0.1 (1) | 0.1 (1) | 0.1 (1) | — | — |
| qiskit | 0.1 (2) | 0.1 (2) | 1.3 (2) | 16.5 (2) | 1694.5 (1) | — |
| pennylane | 0.2 (2) | 0.3 (2) | 1.4 (2) | 14.7 (2) | — +1E | — |
| cirq | 0.5 (2) | 1.0 (2) | 2.2 (2) | 12.0 (2) | 1060.1 (1) | — |
| cirq (f64) | 1.0 (2) | 1.9 (2) | 4.0 (2) | 22.0 (2) | — +1E | — |
| qulacs | 0.0 (2) | 0.1 (2) | 0.8 (2) | 8.3 (2) | — +1E | — |

### qsvm / digits_01

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (2) | 0.1 (2) | 0.4 (2) | 5.4 (2) | — | — |
| sf_optimized (patched) | 0.0 (2) | 0.0 (2) | 0.3 (2) | 5.1 (2) | — | — |
| sf_source_baseline | 0.0 (2) | 0.1 (2) | 0.3 (2) | 5.7 (2) | — | — |
| analytical_angle | 0.0 (1) | 0.0 (1) | 0.0 (1) | 0.0 (1) | — | — |
| qiskit | 0.1 (2) | 0.1 (2) | 0.6 (2) | 6.6 (2) | — | — |
| pennylane | 0.1 (2) | 0.2 (2) | 0.7 (2) | 6.8 (2) | — | — |
| cirq | 0.4 (2) | 0.6 (2) | 1.2 (2) | 5.8 (2) | — | — |
| cirq (f64) | 0.7 (2) | 1.2 (2) | 2.1 (2) | 8.6 (2) | — | — |
| qulacs | 0.0 (2) | 0.0 (2) | 0.3 (2) | 5.9 (2) | — | — |

### qsvm / iris

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (2) | 0.0 (2) | 0.1 (2) | 1.2 (2) | — | — |
| sf_optimized (patched) | 0.0 (2) | 0.0 (2) | 0.1 (2) | 1.1 (2) | — | — |
| sf_source_baseline | 0.0 (2) | 0.0 (2) | 0.1 (2) | 1.2 (2) | — | — |
| analytical_angle | 0.0 (1) | 0.0 (1) | 0.0 (1) | 0.0 (1) | — | — |
| qiskit | 0.0 (2) | 0.0 (2) | 0.2 (2) | 2.1 (2) | — | — |
| pennylane | 0.1 (2) | 0.1 (2) | 0.3 (2) | 1.8 (2) | — | — |
| cirq | 0.2 (2) | 0.2 (2) | 0.5 (2) | 1.9 (2) | — | — |
| cirq (f64) | 0.3 (2) | 0.5 (2) | 0.9 (2) | 2.6 (2) | — | — |
| qulacs | 0.0 (2) | 0.0 (2) | 0.1 (2) | 1.2 (2) | — | — |

### qsvm / moons

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (2) | 0.1 (2) | 0.4 (2) | 6.1 (2) | 213.2 (1) | — |
| sf_optimized (patched) | 0.0 (2) | 0.0 (2) | 0.4 (2) | 5.9 (2) | 171.0 (1) | — |
| sf_source_baseline | 0.0 (2) | 0.1 (2) | 0.5 (2) | 6.9 (2) | 200.4 (1) | — |
| analytical_angle | 0.0 (1) | 0.0 (1) | 0.0 (1) | 0.2 (1) | 0.0 (1) | — |
| qiskit | 0.1 (2) | 0.1 (2) | 0.7 (2) | 9.5 (2) | 589.0 (1) | — |
| pennylane | 0.1 (2) | 0.2 (2) | 0.8 (2) | 7.8 (2) | 730.8 (1) | — |
| cirq | 0.4 (2) | 0.6 (2) | 1.5 (2) | 8.0 (2) | 505.6 (1) | — |
| cirq (f64) | 0.7 (2) | 1.3 (2) | 2.7 (2) | 11.0 (2) | 840.5 (1) | — |
| qulacs | 0.0 (2) | 0.0 (2) | 0.4 (2) | 6.2 (2) | 511.7 (1) | — |

### qsvm / wine

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (2) | 0.0 (2) | 0.1 (2) | 2.2 (2) | — | — |
| sf_optimized (patched) | 0.0 (2) | 0.0 (2) | 0.1 (2) | 1.8 (2) | — | — |
| sf_source_baseline | 0.0 (2) | 0.0 (2) | 0.1 (2) | 1.9 (2) | — | — |
| analytical_angle | 0.0 (1) | 0.0 (1) | 0.0 (1) | 0.0 (1) | — | — |
| qiskit | 0.0 (2) | 0.0 (2) | 0.3 (2) | 2.7 (2) | — | — |
| pennylane | 0.1 (2) | 0.1 (2) | 0.3 (2) | 2.6 (2) | — | — |
| cirq | 0.2 (2) | 0.3 (2) | 0.6 (2) | 2.5 (2) | — | — |
| cirq (f64) | 0.3 (2) | 0.6 (2) | 1.1 (2) | 4.3 (2) | — | — |
| qulacs | 0.0 (2) | 0.0 (2) | 0.1 (2) | 1.9 (2) | — | — |

### qkrr / diabetes

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (2) | 0.1 (2) | 0.7 (2) | 10.1 (2) | — | — |
| sf_optimized (patched) | 0.0 (2) | 0.1 (2) | 0.5 (2) | 7.6 (2) | — | — |
| sf_source_baseline | 0.1 (2) | 0.1 (2) | 0.6 (2) | 9.3 (2) | — | — |
| analytical_angle | 0.0 (1) | 0.0 (1) | 0.1 (1) | 0.1 (1) | — | — |
| qiskit | 0.1 (2) | 0.1 (2) | 0.9 (2) | 9.9 (2) | — | — |
| pennylane | 0.2 (2) | 0.3 (2) | 1.1 (2) | 11.0 (2) | — | — |
| cirq | 0.5 (2) | 0.7 (2) | 1.8 (2) | 9.8 (2) | — | — |
| cirq (f64) | 0.8 (2) | 1.5 (2) | 3.2 (2) | 12.8 (2) | — | — |
| qulacs | 0.0 (2) | 0.0 (2) | 0.5 (2) | 8.0 (2) | — | — |

### qkrr / friedman1

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (2) | 0.1 (2) | 0.4 (2) | 6.6 (2) | — | — |
| sf_optimized (patched) | 0.0 (2) | 0.0 (2) | 0.4 (2) | 6.2 (2) | — | — |
| sf_source_baseline | 0.0 (2) | 0.1 (2) | 0.4 (2) | 6.7 (2) | — | — |
| analytical_angle | 0.0 (1) | 0.0 (1) | 0.1 (1) | 0.1 (1) | — | — |
| qiskit | 0.1 (2) | 0.1 (2) | 0.7 (2) | 8.1 (2) | — | — |
| pennylane | 0.1 (2) | 0.2 (2) | 0.8 (2) | 8.7 (2) | — | — |
| cirq | 0.4 (2) | 0.6 (2) | 1.4 (2) | 8.7 (2) | — | — |
| cirq (f64) | 0.7 (2) | 1.4 (2) | 2.7 (2) | 10.2 (2) | — | — |
| qulacs | 0.0 (2) | 0.0 (2) | 0.4 (2) | 6.6 (2) | — | — |

### qkpca / breast_cancer

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.1 (1) | 0.2 (1) | 1.3 (1) | 10.1 (1) | 1603.6 (1) | — |
| sf_optimized (patched) | 0.1 (1) | 0.1 (1) | 0.9 (1) | 8.6 (1) | 1336.6 (1) | — |
| sf_source_baseline | 0.1 (1) | 0.2 (1) | 1.0 (1) | 14.0 (1) | — | — |
| qiskit | 0.1 (1) | 0.2 (1) | 1.7 (1) | 23.3 (1) | — +1E | — |
| pennylane | 0.3 (1) | 0.5 (1) | 2.2 (1) | 22.1 (1) | — | — |
| cirq | 0.8 (1) | 1.3 (1) | 3.0 (1) | 13.8 (1) | — | — |
| cirq (f64) | 1.3 (1) | 2.4 (1) | 5.7 (1) | 27.7 (1) | — | — |
| qulacs | 0.1 (1) | 0.1 (1) | 1.1 (1) | 9.7 (1) | — | — |

### qkpca / digits_01

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.1 (1) | 0.1 (1) | 0.5 (1) | 6.3 (1) | — | — |
| sf_optimized (patched) | 0.0 (1) | 0.1 (1) | 0.4 (1) | 6.4 (1) | — | — |
| sf_source_baseline | 0.1 (1) | 0.1 (1) | 0.4 (1) | 6.4 (1) | — | — |
| qiskit | 0.1 (1) | 0.1 (1) | 0.8 (1) | 7.8 (1) | — | — |
| pennylane | 0.2 (1) | 0.3 (1) | 3.0 (1) | 8.8 (1) | — | — |
| cirq | 0.5 (1) | 0.8 (1) | 1.8 (1) | 6.7 (1) | — | — |
| cirq (f64) | 0.8 (1) | 1.5 (1) | 3.6 (1) | 11.9 (1) | — | — |
| qulacs | 0.0 (1) | 0.1 (1) | 0.4 (1) | 6.2 (1) | — | — |

### qkpca / iris

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (1) | 0.0 (1) | 0.1 (1) | 1.3 (1) | — | — |
| sf_optimized (patched) | 0.0 (1) | 0.0 (1) | 0.1 (1) | 1.5 (1) | — | — |
| sf_source_baseline | 0.0 (1) | 0.0 (1) | 0.1 (1) | 1.2 (1) | — | — |
| qiskit | 0.0 (1) | 0.0 (1) | 0.2 (1) | 2.4 (1) | — | — |
| pennylane | 0.2 (1) | 0.1 (1) | 0.3 (1) | 2.1 (1) | — | — |
| cirq | 0.2 (1) | 0.4 (1) | 0.6 (1) | 2.9 (1) | — | — |
| cirq (f64) | 0.4 (1) | 0.6 (1) | 1.1 (1) | 3.0 (1) | — | — |
| qulacs | 0.0 (1) | 0.0 (1) | 0.1 (1) | 1.4 (1) | — | — |

### qkpca / moons

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.1 (1) | 0.1 (1) | 0.4 (1) | 8.3 (1) | — | — |
| sf_optimized (patched) | 0.0 (1) | 0.1 (1) | 0.4 (1) | 7.7 (1) | — | — |
| sf_source_baseline | 0.1 (1) | 0.1 (1) | 0.5 (1) | 8.4 (1) | — | — |
| qiskit | 0.1 (1) | 0.1 (1) | 0.8 (1) | 17.2 (1) | — | — |
| pennylane | 0.2 (1) | 0.3 (1) | 1.1 (1) | 10.9 (1) | — | — |
| cirq | 0.6 (1) | 0.9 (1) | 1.7 (1) | 11.6 (1) | — | — |
| cirq (f64) | 1.1 (1) | 1.7 (1) | 3.1 (1) | 13.3 (1) | — | — |
| qulacs | 0.0 (1) | 0.1 (1) | 0.4 (1) | 8.3 (1) | — | — |

### qkpca / wine

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 0.0 (1) | 0.1 (1) | 0.2 (1) | 2.0 (1) | — | — |
| sf_optimized (patched) | 0.0 (1) | 0.0 (1) | 0.1 (1) | 1.8 (1) | — | — |
| sf_source_baseline | 0.0 (1) | 0.0 (1) | 0.2 (1) | 2.0 (1) | — | — |
| qiskit | 0.0 (1) | 0.1 (1) | 0.4 (1) | 3.0 (1) | — | — |
| pennylane | 0.1 (1) | 0.1 (1) | 0.4 (1) | 3.6 (1) | — | — |
| cirq | 0.4 (1) | 0.4 (1) | 0.8 (1) | 2.5 (1) | — | — |
| cirq (f64) | 0.4 (1) | 0.8 (1) | 1.6 (1) | 5.0 (1) | — | — |
| qulacs | 0.0 (1) | 0.0 (1) | 0.1 (1) | 2.0 (1) | — | — |

### classical / breast_cancer

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| classical | 0.0 (3) | 0.0 (3) | 0.0 (3) | 0.0 (3) | — | — |

### classical / diabetes

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| classical | 0.1 (3) | 0.0 (3) | 0.0 (3) | 0.2 (3) | — | — |

### classical / digits_01

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| classical | 0.2 (3) | 0.0 (3) | 0.0 (3) | 0.0 (3) | 0.2 (1) | — |

### classical / friedman1

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| classical | 0.0 (3) | 0.0 (3) | 0.1 (3) | 0.1 (3) | 0.3 (1) | — |

### classical / iris

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| classical | 0.0 (3) | 0.0 (3) | 0.0 (3) | 0.1 (3) | — | — |

### classical / moons

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| classical | 0.0 (3) | 0.0 (3) | 0.0 (3) | 0.1 (3) | — | — |

### classical / wine

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| classical | 0.0 (3) | 0.0 (3) | 0.0 (3) | 0.1 (3) | — | — |

## 6. Key findings so far

- Patch effect (sf_optimized vs sf_wheel PyPI): qsvm q20 moons **19.8% faster**; breast_cancer **13.0% faster**.
- qsvm q20 moons: sf_optimized is faster than qiskit 3.44×, pennylane 4.27×, cirq 2.96×, cirq_f64 4.92×, qulacs 2.99× (ratio = their median / sf_optimized).
- qsvm q20 breast_cancer: sf_optimized vs qiskit 1.78×; cirq comes closest among others.
- q4–q16: margins vs competitors are small (1.1–1.7×); qulacs edges SF on qkpca q16 (6.2 s vs 6.4 s) — stated for balance.
- Memory: SF lanes are the leanest full simulators so far; cirq(f64) is the largest consumer (section 7).

## 7. Memory results (median worker_peak_rss_mib, MB)

### qsvm / breast_cancer

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 151 | 152 | 186 | 533 | 917 | — |
| sf_optimized (patched) | 151 | 152 | 187 | 534 | 918 | — |
| sf_source_baseline | 151 | 152 | 186 | 533 | 917 | — |
| analytical_angle | 155 | 168 | 181 | 194 | — | — |
| qiskit | 186 | 188 | 235 | 563 | 944 | — |
| pennylane | 268 | 272 | 323 | 652 | — | — |
| cirq | 229 | 232 | 311 | 724 | 1250 | — |
| cirq (f64) | 229 | 235 | 389 | 1071 | — | — |
| qulacs | 150 | 151 | 185 | 533 | — | — |

### qsvm / digits_01

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 147 | 149 | 170 | 516 | — | — |
| sf_optimized (patched) | 148 | 149 | 171 | 517 | — | — |
| sf_source_baseline | 148 | 148 | 170 | 516 | — | — |
| analytical_angle | 148 | 153 | 158 | 164 | — | — |
| qiskit | 180 | 183 | 215 | 754 | — | — |
| pennylane | 265 | 267 | 300 | 843 | — | — |
| cirq | 225 | 227 | 278 | 1047 | — | — |
| cirq (f64) | 225 | 230 | 327 | 1838 | — | — |
| qulacs | 147 | 148 | 169 | 515 | — | — |

### qsvm / iris

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 145 | 146 | 155 | 304 | — | — |
| sf_optimized (patched) | 146 | 146 | 156 | 305 | — | — |
| sf_source_baseline | 145 | 146 | 155 | 304 | — | — |
| analytical_angle | 144 | 145 | 145 | 157 | — | — |
| qiskit | 176 | 177 | 191 | 415 | — | — |
| pennylane | 262 | 263 | 279 | 504 | — | — |
| cirq | 222 | 224 | 244 | 557 | — | — |
| cirq (f64) | 222 | 225 | 264 | 893 | — | — |
| qulacs | 145 | 146 | 155 | 304 | — | — |

### qsvm / moons

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 148 | 149 | 173 | 556 | 930 | — |
| sf_optimized (patched) | 149 | 149 | 174 | 557 | 931 | — |
| sf_source_baseline | 148 | 149 | 174 | 556 | 930 | — |
| analytical_angle | 149 | 155 | 161 | 168 | 339 | — |
| qiskit | 182 | 184 | 216 | 818 | 942 | — |
| pennylane | 266 | 268 | 305 | 907 | 1047 | — |
| cirq | 226 | 228 | 282 | 1108 | 1127 | — |
| cirq (f64) | 226 | 231 | 336 | 1865 | 1793 | — |
| qulacs | 148 | 149 | 173 | 556 | 930 | — |

### qsvm / wine

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 145 | 147 | 158 | 332 | — | — |
| sf_optimized (patched) | 146 | 147 | 158 | 332 | — | — |
| sf_source_baseline | 146 | 147 | 157 | 332 | — | — |
| analytical_angle | 144 | 145 | 146 | 158 | — | — |
| qiskit | 176 | 177 | 194 | 461 | — | — |
| pennylane | 262 | 264 | 280 | 548 | — | — |
| cirq | 222 | 224 | 249 | 630 | — | — |
| cirq (f64) | 222 | 226 | 272 | 1063 | — | — |
| qulacs | 146 | 146 | 157 | 332 | — | — |

### qkrr / diabetes

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 150 | 151 | 176 | 598 | — | — |
| sf_optimized (patched) | 151 | 152 | 177 | 600 | — | — |
| sf_source_baseline | 151 | 151 | 177 | 599 | — | — |
| analytical_angle | 150 | 158 | 166 | 173 | — | — |
| qiskit | 182 | 185 | 221 | 884 | — | — |
| pennylane | 269 | 271 | 309 | 974 | — | — |
| cirq | 229 | 231 | 290 | 1227 | — | — |
| cirq (f64) | 229 | 232 | 354 | 2193 | — | — |
| qulacs | 150 | 150 | 176 | 599 | — | — |

### qkrr / friedman1

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 150 | 151 | 173 | 556 | — | — |
| sf_optimized (patched) | 150 | 151 | 173 | 557 | — | — |
| sf_source_baseline | 150 | 151 | 174 | 557 | — | — |
| analytical_angle | 149 | 155 | 162 | 168 | — | — |
| qiskit | 181 | 184 | 216 | 818 | — | — |
| pennylane | 268 | 270 | 305 | 907 | — | — |
| cirq | 228 | 229 | 284 | 1136 | — | — |
| cirq (f64) | 228 | 231 | 341 | 2071 | — | — |
| qulacs | 150 | 150 | 172 | 556 | — | — |

### qkpca / breast_cancer

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 158 | 159 | 186 | 533 | 917 | — |
| sf_optimized (patched) | 159 | 160 | 187 | 534 | 918 | — |
| sf_source_baseline | 159 | 159 | 186 | 533 | — | — |
| qiskit | 190 | 191 | 237 | 564 | — | — |
| pennylane | 276 | 279 | 325 | 653 | — | — |
| cirq | 237 | 239 | 318 | 741 | — | — |
| cirq (f64) | 236 | 241 | 400 | 1106 | — | — |
| qulacs | 158 | 158 | 185 | 534 | — | — |

### qkpca / digits_01

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 151 | 151 | 170 | 515 | — | — |
| sf_optimized (patched) | 150 | 151 | 171 | 517 | — | — |
| sf_source_baseline | 151 | 151 | 170 | 516 | — | — |
| qiskit | 181 | 182 | 212 | 753 | — | — |
| pennylane | 268 | 270 | 301 | 843 | — | — |
| cirq | 227 | 229 | 282 | 1090 | — | — |
| cirq (f64) | 228 | 230 | 334 | 1930 | — | — |
| qulacs | 150 | 150 | 170 | 516 | — | — |

### qkpca / iris

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 146 | 147 | 155 | 304 | — | — |
| sf_optimized (patched) | 147 | 147 | 156 | 304 | — | — |
| sf_source_baseline | 147 | 147 | 155 | 304 | — | — |
| qiskit | 176 | 177 | 191 | 416 | — | — |
| pennylane | 263 | 264 | 281 | 504 | — | — |
| cirq | 223 | 225 | 247 | 583 | — | — |
| cirq (f64) | 222 | 225 | 267 | 947 | — | — |
| qulacs | 146 | 146 | 155 | 304 | — | — |

### qkpca / moons

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 152 | 152 | 173 | 556 | — | — |
| sf_optimized (patched) | 153 | 152 | 174 | 557 | — | — |
| sf_source_baseline | 151 | 152 | 173 | 556 | — | — |
| qiskit | 183 | 184 | 217 | 819 | — | — |
| pennylane | 269 | 271 | 306 | 910 | — | — |
| cirq | 229 | 230 | 290 | 1189 | — | — |
| cirq (f64) | 229 | 232 | 347 | 1973 | — | — |
| qulacs | 151 | 152 | 173 | 556 | — | — |

### qkpca / wine

| lane | q4 | q8 | q12 | q16 | q20 | q24 |
|---|---|---|---|---|---|---|
| sf_wheel (PyPI) | 147 | 147 | 157 | 332 | — | — |
| sf_optimized (patched) | 147 | 148 | 158 | 333 | — | — |
| sf_source_baseline | 147 | 147 | 157 | 332 | — | — |
| qiskit | 177 | 177 | 194 | 461 | — | — |
| pennylane | 263 | 264 | 281 | 549 | — | — |
| cirq | 223 | 225 | 252 | 650 | — | — |
| cirq (f64) | 222 | 227 | 276 | 1079 | — | — |
| qulacs | 146 | 147 | 157 | 332 | — | — |

## 8. Accuracy agreement (identical across engines where measured)

Presented per dataset so lanes that lost jobs to timeouts are not compared on different coverage.

- qsvm breast_cancer q16: sfW 0.6360 · sfO 0.6360 · sfB 0.6360 · analytic 0.6404 · qiskit 0.6360 · pennylane 0.6360 · cirq 0.6360 · cirq_f64 0.6360 · qulacs 0.6360
- qsvm digits_01 q16: sfW 0.8264 · sfO 0.8264 · sfB 0.8264 · analytic 0.8750 · qiskit 0.8264 · pennylane 0.8264 · cirq 0.8264 · cirq_f64 0.8264 · qulacs 0.8264
- qsvm iris q16: sfW 0.7833 · sfO 0.7833 · sfB 0.7833 · analytic 0.9667 · qiskit 0.7833 · pennylane 0.7833 · cirq 0.7833 · cirq_f64 0.7833 · qulacs 0.7833
- qsvm moons q16: sfW 0.7875 · sfO 0.7875 · sfB 0.7875 · analytic 0.9125 · qiskit 0.7875 · pennylane 0.7875 · cirq 0.7875 · cirq_f64 0.7875 · qulacs 0.7875
- qsvm wine q16: sfW 0.4444 · sfO 0.4444 · sfB 0.4444 · analytic 0.5000 · qiskit 0.4444 · pennylane 0.4444 · cirq 0.4444 · cirq_f64 0.4444 · qulacs 0.4444
- qsvm breast_cancer q20: sfW 0.6316 · sfO 0.6316 · sfB 0.6316 · qiskit 0.6316 · cirq 0.6316 — all lanes identical
- qsvm moons q20: sfW 0.9125 · sfO 0.9125 · sfB 0.9125 · analytic 0.9125 · qiskit 0.9125 · pennylane 0.9125 · cirq 0.9125 · cirq_f64 0.9125 · qulacs 0.9125 — all lanes identical

## 9. Errors / timeouts

- `2caa6466` qkpca/breast_cancer/q20/qiskit: timeout (result written 11:15:43)
- `be7b5f26` qsvm/breast_cancer/q20/cirq (f64): timeout (result written 08:40:16)
- `c3d07c8d` qsvm/breast_cancer/q20/qulacs: timeout (result written 10:27:05)
- `efd4a1d0` qsvm/breast_cancer/q20/pennylane: timeout (result written 09:28:24)

## 10. Appendix A — full per-job data (all committed jobs)

| # | id | finished | task | dataset | fm | depth | batch | iters | q | lane | status | e2e_s | enc_s | kernel_s | wall_s | rss_mb | acc | bal_acc | calls | error |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `2c53cced` | 10-05 05:21 | classical | breast_cancer | angle | 1 | 6 | 5 | 4 | classical | ok | 0.3 |  |  | 3.8 | 143.9 | 0.9123 | 0.9107 |  |  |
| 2 | `b8d04fa5` | 10-05 05:24 | classical | breast_cancer | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.1 | 143.4 | 0.9561 | 0.9504 |  |  |
| 3 | `b93b88a6` | 10-05 05:28 | classical | breast_cancer | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.1 | 143.4 | 0.9474 | 0.9435 |  |  |
| 4 | `0034838c` | 10-05 05:22 | classical | diabetes | angle | 1 | 6 | 5 | 4 | classical | ok | 0.1 |  |  | 3.2 | 147.0 |  |  |  |  |
| 5 | `492d6efa` | 10-05 05:28 | classical | diabetes | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.2 | 142.3 |  |  |  |  |
| 6 | `39f6bfc5` | 10-05 05:33 | classical | diabetes | angle | 1 | 6 | 5 | 4 | classical | ok | 0.2 |  |  | 3.0 | 145.5 |  |  |  |  |
| 7 | `dc1e1cb1` | 10-05 05:22 | classical | digits_01 | angle | 1 | 6 | 5 | 4 | classical | ok | 0.2 |  |  | 3.3 | 143.6 | 0.9861 | 0.9861 |  |  |
| 8 | `281c3cf9` | 10-05 05:26 | classical | digits_01 | angle | 1 | 6 | 5 | 4 | classical | ok | 0.2 |  |  | 3.4 | 143.8 | 1.0 | 1.0 |  |  |
| 9 | `b646e7a9` | 10-05 05:28 | classical | digits_01 | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.1 | 143.7 | 0.9861 | 0.9861 |  |  |
| 10 | `8db4d4dd` | 10-05 05:30 | classical | friedman1 | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.0 | 146.7 |  |  |  |  |
| 11 | `39d271d2` | 10-05 05:30 | classical | friedman1 | angle | 1 | 6 | 5 | 4 | classical | ok | 0.3 |  |  | 3.4 | 145.5 |  |  |  |  |
| 12 | `67565b43` | 10-05 05:33 | classical | friedman1 | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 2.9 | 142.3 |  |  |  |  |
| 13 | `5cc3c259` | 10-05 05:24 | classical | iris | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.0 | 142.8 | 1.0 | 1.0 |  |  |
| 14 | `f896eba1` | 10-05 05:24 | classical | iris | angle | 1 | 6 | 5 | 4 | classical | ok | 0.2 |  |  | 3.4 | 143.7 | 0.9333 | 0.9333 |  |  |
| 15 | `b658c86a` | 10-05 05:27 | classical | iris | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.2 | 142.5 | 0.9667 | 0.9667 |  |  |
| 16 | `9a8714c7` | 10-05 05:28 | classical | moons | angle | 1 | 6 | 5 | 4 | classical | ok | 0.2 |  |  | 3.5 | 144.2 | 0.9375 | 0.9375 |  |  |
| 17 | `833fb59d` | 10-05 05:30 | classical | moons | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.1 | 142.5 | 0.95 | 0.95 |  |  |
| 18 | `0076d3af` | 10-05 05:34 | classical | moons | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 2.8 | 143.0 | 0.9625 | 0.9625 |  |  |
| 19 | `b89f1f19` | 10-05 05:23 | classical | wine | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.1 | 142.7 | 0.9722 | 0.9667 |  |  |
| 20 | `77c74948` | 10-05 05:26 | classical | wine | angle | 1 | 6 | 5 | 4 | classical | ok | 0.2 |  |  | 4.2 | 143.4 | 0.9167 | 0.9151 |  |  |
| 21 | `faafe541` | 10-05 05:30 | classical | wine | angle | 1 | 6 | 5 | 4 | classical | ok | 0.0 |  |  | 3.2 | 142.8 | 1.0 | 1.0 |  |  |
| 22 | `a007f9c8` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.8 | 0.7 | 0.0 | 6.1 | 236.7 | 0.7018 | 0.6597 | 569 |  |
| 23 | `35088b55` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 1.3 | 1.3 | 0.0 | 6.6 | 236.2 | 0.7018 | 0.6597 | 569 |  |
| 24 | `2659986e` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.3 | 0.2 | 0.0 | 7.1 | 275.5 | 0.7018 | 0.6597 | 569 |  |
| 25 | `c46551e1` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.1 | 0.0 | 4.2 | 190.2 | 0.7018 | 0.6597 | 569 |  |
| 26 | `521e99e1` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.1 | 0.0 | 0.0 | 3.1 | 157.6 | 0.7018 | 0.6597 | 569 |  |
| 27 | `ddf234d8` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.4 | 158.5 | 0.7018 | 0.6597 | 569 |  |
| 28 | `93c664a4` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 3.2 | 158.7 | 0.7018 | 0.6597 | 569 |  |
| 29 | `7c20fa47` | 10-05 05:24 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 3.2 | 157.9 | 0.7018 | 0.6597 | 569 |  |
| 30 | `9152262a` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.5 | 0.5 | 0.0 | 5.9 | 227.5 | 0.875 | 0.875 | 360 |  |
| 31 | `660fc5ce` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.8 | 0.7 | 0.0 | 6.4 | 228.1 | 0.875 | 0.875 | 360 |  |
| 32 | `5c975a2e` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.2 | 0.0 | 8.2 | 267.6 | 0.875 | 0.875 | 360 |  |
| 33 | `7a9e9961` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.0 | 0.0 | 4.0 | 180.7 | 0.875 | 0.875 | 360 |  |
| 34 | `83eb8d2c` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 150.4 | 0.875 | 0.875 | 360 |  |
| 35 | `7017e3de` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.3 | 150.4 | 0.875 | 0.875 | 360 |  |
| 36 | `82482c10` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 3.6 | 150.9 | 0.875 | 0.875 | 360 |  |
| 37 | `46412d82` | 10-05 05:28 | qkpca | digits_01 | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.5 | 150.7 | 0.875 | 0.875 | 360 |  |
| 38 | `2fea05f3` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.2 | 0.2 | 0.0 | 5.5 | 223.0 | 0.6667 | 0.6667 | 150 |  |
| 39 | `ad934690` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.4 | 0.3 | 0.0 | 5.7 | 222.4 | 0.6667 | 0.6667 | 150 |  |
| 40 | `72276ec5` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.1 | 0.0 | 7.0 | 262.6 | 0.6667 | 0.6667 | 150 |  |
| 41 | `b85bfb39` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.0 | 0.0 | 0.0 | 4.0 | 176.0 | 0.6667 | 0.6667 | 150 |  |
| 42 | `d3a93838` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 145.9 | 0.6667 | 0.6667 | 150 |  |
| 43 | `fb2196c1` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 146.9 | 0.6667 | 0.6667 | 150 |  |
| 44 | `710e99e2` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.3 | 146.8 | 0.6667 | 0.6667 | 150 |  |
| 45 | `9df45747` | 10-05 05:23 | qkpca | iris | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 146.3 | 0.6667 | 0.6667 | 150 |  |
| 46 | `fe1fbf51` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.6 | 0.5 | 0.0 | 6.0 | 229.2 | 0.575 | 0.575 | 400 |  |
| 47 | `0f194fbf` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 1.1 | 1.1 | 0.0 | 7.2 | 229.4 | 0.575 | 0.575 | 400 |  |
| 48 | `f116aa70` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.2 | 0.0 | 7.3 | 268.9 | 0.575 | 0.575 | 400 |  |
| 49 | `80771081` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.1 | 0.0 | 4.3 | 182.7 | 0.575 | 0.575 | 400 |  |
| 50 | `0ed7004e` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.4 | 151.1 | 0.575 | 0.575 | 400 |  |
| 51 | `5f70a4ad` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.4 | 152.7 | 0.575 | 0.575 | 400 |  |
| 52 | `8084b4a4` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 3.3 | 151.2 | 0.575 | 0.575 | 400 |  |
| 53 | `b989f1f3` | 10-05 05:22 | qkpca | moons | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.4 | 151.9 | 0.575 | 0.575 | 400 |  |
| 54 | `e181c243` | 10-05 05:31 | qkpca | wine | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.4 | 0.4 | 0.0 | 5.8 | 223.0 | 0.5833 | 0.5595 | 178 |  |
| 55 | `c22dd5b4` | 10-05 05:30 | qkpca | wine | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.4 | 0.4 | 0.0 | 5.7 | 222.3 | 0.5833 | 0.5595 | 178 |  |
| 56 | `b497aba6` | 10-05 05:31 | qkpca | wine | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.9 | 263.3 | 0.5833 | 0.5595 | 178 |  |
| 57 | `6e8da96a` | 10-05 05:31 | qkpca | wine | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.0 | 0.0 | 0.0 | 4.0 | 177.3 | 0.5833 | 0.5595 | 178 |  |
| 58 | `33141e39` | 10-05 05:31 | qkpca | wine | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 146.5 | 0.5833 | 0.5595 | 178 |  |
| 59 | `2a9ba000` | 10-05 05:31 | qkpca | wine | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 147.2 | 0.5833 | 0.5595 | 178 |  |
| 60 | `350b88a3` | 10-05 05:31 | qkpca | wine | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.1 | 146.5 | 0.5833 | 0.5595 | 178 |  |
| 61 | `08df822f` | 10-05 05:31 | qkpca | wine | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 146.7 | 0.5833 | 0.5595 | 178 |  |
| 62 | `20257bd9` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.4 | 150.4 |  |  | 0 |  |
| 63 | `1c47516f` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.7 | 0.7 | 0.0 | 6.3 | 229.4 |  |  | 442 |  |
| 64 | `4fea81e8` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | cirq | ok | 0.3 | 0.3 | 0.0 | 5.7 | 228.9 |  |  | 442 |  |
| 65 | `6833ae2c` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 1.0 | 0.9 | 0.0 | 6.2 | 228.6 |  |  | 442 |  |
| 66 | `d17974b2` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.6 | 0.6 | 0.0 | 5.9 | 229.3 |  |  | 442 |  |
| 67 | `98c2cb51` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.2 | 0.0 | 7.1 | 268.2 |  |  | 442 |  |
| 68 | `02796821` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 7.2 | 269.0 |  |  | 442 |  |
| 69 | `5b2137cb` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.1 | 0.0 | 4.1 | 182.5 |  |  | 442 |  |
| 70 | `d746ce1d` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.0 | 0.0 | 4.0 | 182.4 |  |  | 442 |  |
| 71 | `9d4956c7` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.2 | 150.4 |  |  | 442 |  |
| 72 | `483e3e62` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 150.2 |  |  | 442 |  |
| 73 | `4343f114` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.5 | 150.9 |  |  | 442 |  |
| 74 | `e327fb9e` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 150.5 |  |  | 442 |  |
| 75 | `59eb1435` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 3.3 | 150.8 |  |  | 442 |  |
| 76 | `2896b548` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 150.3 |  |  | 442 |  |
| 77 | `980a5c0e` | 10-05 05:25 | qkrr | diabetes | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.1 | 150.7 |  |  | 442 |  |
| 78 | `7d899cb2` | 10-05 05:26 | qkrr | diabetes | angle | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 150.2 |  |  | 442 |  |
| 79 | `61e8fc76` | 10-05 05:31 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.3 | 149.0 |  |  | 0 |  |
| 80 | `9a2d2dd6` | 10-05 05:31 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | cirq | ok | 0.3 | 0.2 | 0.0 | 5.8 | 227.5 |  |  | 400 |  |
| 81 | `4ae72b4b` | 10-05 05:33 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.5 | 0.4 | 0.0 | 5.5 | 227.7 |  |  | 400 |  |
| 82 | `e0832d32` | 10-05 05:31 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.6 | 0.5 | 0.0 | 5.9 | 227.8 |  |  | 400 |  |
| 83 | `4df3776d` | 10-05 05:33 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.8 | 0.8 | 0.0 | 5.6 | 228.3 |  |  | 400 |  |
| 84 | `e7c7e442` | 10-05 05:31 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 7.2 | 267.7 |  |  | 400 |  |
| 85 | `168ba4cd` | 10-05 05:33 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.1 | 0.0 | 6.4 | 267.6 |  |  | 400 |  |
| 86 | `9f50f2a4` | 10-05 05:32 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.0 | 0.0 | 3.9 | 181.2 |  |  | 400 |  |
| 87 | `0f8ef080` | 10-05 05:32 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.0 | 0.0 | 3.7 | 181.4 |  |  | 400 |  |
| 88 | `2206f8bf` | 10-05 05:32 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.2 | 149.6 |  |  | 400 |  |
| 89 | `b0b93b6a` | 10-05 05:33 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.0 | 149.6 |  |  | 400 |  |
| 90 | `a0b9964b` | 10-05 05:31 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 150.4 |  |  | 400 |  |
| 91 | `8c8e5c68` | 10-05 05:33 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 150.4 |  |  | 400 |  |
| 92 | `0a14dc64` | 10-05 05:31 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 149.6 |  |  | 400 |  |
| 93 | `34793ede` | 10-05 05:32 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 2.9 | 150.1 |  |  | 400 |  |
| 94 | `1b2fbda2` | 10-05 05:32 | qkrr | friedman1 | angle | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 150.1 |  |  | 400 |  |
| 95 | `ca6c2801` | 10-05 05:32 | qkrr | friedman1 | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 150.2 |  |  | 400 |  |
| 96 | `910f82a4` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.9 | 155.2 | 0.8947 | 0.8819 | 0 |  |
| 97 | `1e9b192b` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.7 | 0.7 | 0.0 | 6.0 | 229.1 | 0.7982 | 0.7808 | 569 |  |
| 98 | `5f478804` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | cirq | ok | 0.3 | 0.3 | 0.0 | 5.3 | 228.0 | 0.8947 | 0.8819 | 569 |  |
| 99 | `5f4933ca` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 1.2 | 1.2 | 0.0 | 6.5 | 229.1 | 0.7982 | 0.7808 | 569 |  |
| 100 | `929146e1` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.8 | 0.7 | 0.0 | 6.4 | 229.2 | 0.8947 | 0.8819 | 569 |  |
| 101 | `1e97147b` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.2 | 0.0 | 7.2 | 268.7 | 0.7982 | 0.7808 | 569 |  |
| 102 | `335b26be` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.3 | 267.6 | 0.8947 | 0.8819 | 569 |  |
| 103 | `4926314b` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.1 | 0.0 | 4.3 | 185.8 | 0.7982 | 0.7808 | 569 |  |
| 104 | `2fda3fe1` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.7 | 185.6 | 0.8947 | 0.8819 | 569 |  |
| 105 | `aa1b3e9d` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 150.5 | 0.7982 | 0.7808 | 569 |  |
| 106 | `0b7c9430` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.0 | 150.0 | 0.8947 | 0.8819 | 569 |  |
| 107 | `44a23473` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 151.3 | 0.7982 | 0.7808 | 569 |  |
| 108 | `4ab5ee0d` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 151.5 | 0.8947 | 0.8819 | 569 |  |
| 109 | `b6576889` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 3.3 | 151.3 | 0.7982 | 0.7808 | 569 |  |
| 110 | `21510d59` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.1 | 150.9 | 0.8947 | 0.8819 | 569 |  |
| 111 | `f333774a` | 10-05 05:21 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.2 | 151.1 | 0.7982 | 0.7808 | 569 |  |
| 112 | `abf3010b` | 10-05 05:32 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 150.6 | 0.8947 | 0.8819 | 569 |  |
| 113 | `82ad1c1a` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.9 | 147.5 | 1.0 | 1.0 | 0 |  |
| 114 | `db36b9ef` | 10-05 05:27 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.5 | 0.5 | 0.0 | 5.8 | 224.8 | 0.9444 | 0.9444 | 360 |  |
| 115 | `854117b7` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | cirq | ok | 0.2 | 0.2 | 0.0 | 5.0 | 224.8 | 1.0 | 1.0 | 360 |  |
| 116 | `dd001f0f` | 10-05 05:27 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.9 | 0.9 | 0.0 | 6.1 | 225.6 | 0.9444 | 0.9444 | 360 |  |
| 117 | `0d95af8b` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.4 | 0.4 | 0.0 | 5.3 | 225.4 | 1.0 | 1.0 | 360 |  |
| 118 | `ce97d9d7` | 10-05 05:27 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.1 | 0.0 | 7.0 | 264.8 | 0.9444 | 0.9444 | 360 |  |
| 119 | `57ae8083` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.3 | 265.0 | 1.0 | 1.0 | 360 |  |
| 120 | `a2422f72` | 10-05 05:27 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.0 | 0.0 | 4.0 | 180.4 | 0.9444 | 0.9444 | 360 |  |
| 121 | `0d2ac882` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.6 | 180.5 | 1.0 | 1.0 | 360 |  |
| 122 | `c7394415` | 10-05 05:27 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 147.2 | 0.9444 | 0.9444 | 360 |  |
| 123 | `36450959` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.2 | 1.0 | 1.0 | 360 |  |
| 124 | `808b75ac` | 10-05 05:27 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.3 | 148.0 | 0.9444 | 0.9444 | 360 |  |
| 125 | `bba9007c` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 148.1 | 1.0 | 1.0 | 360 |  |
| 126 | `de97b197` | 10-05 05:27 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 147.8 | 0.9444 | 0.9444 | 360 |  |
| 127 | `03cd7832` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.7 | 1.0 | 1.0 | 360 |  |
| 128 | `2d618ba2` | 10-05 05:28 | qsvm | digits_01 | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 147.2 | 0.9444 | 0.9444 | 360 |  |
| 129 | `3905271e` | 10-05 05:33 | qsvm | digits_01 | angle | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.4 | 1.0 | 1.0 | 360 |  |
| 130 | `e0e81dc5` | 10-05 05:23 | qsvm | iris | angle | 1 | 6 | 5 | 4 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.1 | 143.9 | 0.9667 | 0.9667 | 0 |  |
| 131 | `d0420f62` | 10-05 05:23 | qsvm | iris | angle | 1 | 6 | 5 | 4 | cirq | ok | 0.1 | 0.1 | 0.0 | 5.4 | 221.8 | 0.9667 | 0.9667 | 150 |  |
| 132 | `5768f373` | 10-05 05:27 | qsvm | iris | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.2 | 0.2 | 0.0 | 5.5 | 222.2 | 0.6 | 0.6 | 150 |  |
| 133 | `4a4422eb` | 10-05 05:22 | qsvm | iris | angle | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.2 | 0.2 | 0.0 | 5.5 | 221.3 | 0.9667 | 0.9667 | 150 |  |
| 134 | `50d47cd1` | 10-05 05:27 | qsvm | iris | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.4 | 0.3 | 0.0 | 5.7 | 221.8 | 0.6 | 0.6 | 150 |  |
| 135 | `b5132942` | 10-05 05:23 | qsvm | iris | angle | 1 | 6 | 5 | 4 | pennylane | ok | 0.0 | 0.0 | 0.0 | 7.2 | 261.4 | 0.9667 | 0.9667 | 150 |  |
| 136 | `67872046` | 10-05 05:27 | qsvm | iris | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 7.0 | 262.1 | 0.6 | 0.6 | 150 |  |
| 137 | `ff1c7351` | 10-05 05:23 | qsvm | iris | angle | 1 | 6 | 5 | 4 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.9 | 175.6 | 0.9667 | 0.9667 | 150 |  |
| 138 | `928b5d55` | 10-05 05:27 | qsvm | iris | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.9 | 175.8 | 0.6 | 0.6 | 150 |  |
| 139 | `517cd06e` | 10-05 05:23 | qsvm | iris | angle | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 145.2 | 0.9667 | 0.9667 | 150 |  |
| 140 | `a26ff13c` | 10-05 05:26 | qsvm | iris | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.0 | 145.0 | 0.6 | 0.6 | 150 |  |
| 141 | `fa4ef2fc` | 10-05 05:22 | qsvm | iris | angle | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 145.6 | 0.9667 | 0.9667 | 150 |  |
| 142 | `5f61337f` | 10-05 05:26 | qsvm | iris | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 146.2 | 0.6 | 0.6 | 150 |  |
| 143 | `734b09b9` | 10-05 05:22 | qsvm | iris | angle | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 145.0 | 0.9667 | 0.9667 | 150 |  |
| 144 | `115bf675` | 10-05 05:27 | qsvm | iris | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 145.5 | 0.6 | 0.6 | 150 |  |
| 145 | `9f968547` | 10-05 05:22 | qsvm | iris | angle | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 145.2 | 0.9667 | 0.9667 | 150 |  |
| 146 | `f9d15682` | 10-05 05:26 | qsvm | iris | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 145.1 | 0.6 | 0.6 | 150 |  |
| 147 | `fffa1226` | 10-05 05:25 | qsvm | moons | angle | 1 | 6 | 5 | 4 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.1 | 149.4 | 0.9125 | 0.9125 | 0 |  |
| 148 | `10791b30` | 10-05 05:25 | qsvm | moons | angle | 1 | 6 | 5 | 4 | cirq | ok | 0.3 | 0.3 | 0.0 | 5.6 | 225.8 | 0.9125 | 0.9125 | 400 |  |
| 149 | `230531b9` | 10-05 05:29 | qsvm | moons | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.5 | 0.5 | 0.0 | 5.9 | 226.3 | 0.6625 | 0.6625 | 400 |  |
| 150 | `cab8795a` | 10-05 05:25 | qsvm | moons | angle | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.5 | 0.5 | 0.0 | 5.8 | 225.7 | 0.9125 | 0.9125 | 400 |  |
| 151 | `014ff1ad` | 10-05 05:29 | qsvm | moons | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.8 | 0.8 | 0.0 | 6.4 | 226.3 | 0.6625 | 0.6625 | 400 |  |
| 152 | `5d5926e9` | 10-05 05:24 | qsvm | moons | angle | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 7.1 | 265.6 | 0.9125 | 0.9125 | 400 |  |
| 153 | `b6270f93` | 10-05 05:29 | qsvm | moons | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.2 | 0.2 | 0.0 | 7.2 | 266.4 | 0.6625 | 0.6625 | 400 |  |
| 154 | `3cbccaa3` | 10-05 05:25 | qsvm | moons | angle | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.0 | 0.0 | 4.0 | 181.6 | 0.9125 | 0.9125 | 400 |  |
| 155 | `2fc45f15` | 10-05 05:29 | qsvm | moons | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.1 | 0.1 | 0.0 | 4.1 | 181.5 | 0.6625 | 0.6625 | 400 |  |
| 156 | `7c831f35` | 10-05 05:25 | qsvm | moons | angle | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.3 | 147.7 | 0.9125 | 0.9125 | 400 |  |
| 157 | `70e8d7d2` | 10-05 05:28 | qsvm | moons | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.3 | 148.1 | 0.6625 | 0.6625 | 400 |  |
| 158 | `2f8769a0` | 10-05 05:24 | qsvm | moons | angle | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.4 | 148.0 | 0.9125 | 0.9125 | 400 |  |
| 159 | `a4292ecd` | 10-05 05:28 | qsvm | moons | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.4 | 149.8 | 0.6625 | 0.6625 | 400 |  |
| 160 | `54f62934` | 10-05 05:24 | qsvm | moons | angle | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 148.0 | 0.9125 | 0.9125 | 400 |  |
| 161 | `8aa0733c` | 10-05 05:29 | qsvm | moons | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 148.4 | 0.6625 | 0.6625 | 400 |  |
| 162 | `a9315887` | 10-05 05:25 | qsvm | moons | angle | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 148.5 | 0.9125 | 0.9125 | 400 |  |
| 163 | `a4b23dcd` | 10-05 05:29 | qsvm | moons | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.2 | 147.6 | 0.6625 | 0.6625 | 400 |  |
| 164 | `74fe6c1a` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.0 | 144.5 | 0.8889 | 0.8817 | 0 |  |
| 165 | `4532f75f` | 10-05 05:29 | qsvm | wine | zz | 1 | 6 | 5 | 4 | cirq | ok | 0.3 | 0.3 | 0.0 | 6.0 | 222.0 | 0.6111 | 0.5897 | 178 |  |
| 166 | `0fd4914e` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | cirq | ok | 0.1 | 0.1 | 0.0 | 5.8 | 222.0 | 0.8889 | 0.8817 | 178 |  |
| 167 | `3df408f6` | 10-05 05:29 | qsvm | wine | zz | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.4 | 0.4 | 0.0 | 6.1 | 222.0 | 0.6111 | 0.5897 | 178 |  |
| 168 | `b6f2c63c` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | cirq (f64) | ok | 0.3 | 0.3 | 0.0 | 5.7 | 221.4 | 0.8889 | 0.8817 | 178 |  |
| 169 | `4bca6dc4` | 10-05 05:29 | qsvm | wine | zz | 1 | 6 | 5 | 4 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.9 | 262.7 | 0.6111 | 0.5897 | 178 |  |
| 170 | `8c8c2eef` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | pennylane | ok | 0.0 | 0.0 | 0.0 | 7.0 | 261.9 | 0.8889 | 0.8817 | 178 |  |
| 171 | `99b23b21` | 10-05 05:29 | qsvm | wine | zz | 1 | 6 | 5 | 4 | qiskit | ok | 0.0 | 0.0 | 0.0 | 4.0 | 176.6 | 0.6111 | 0.5897 | 178 |  |
| 172 | `8d04113e` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | qiskit | ok | 0.0 | 0.0 | 0.0 | 4.0 | 176.3 | 0.8889 | 0.8817 | 178 |  |
| 173 | `e99a4529` | 10-05 05:30 | qsvm | wine | zz | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 145.5 | 0.6111 | 0.5897 | 178 |  |
| 174 | `6432a5e0` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | qulacs | ok | 0.0 | 0.0 | 0.0 | 3.1 | 146.2 | 0.8889 | 0.8817 | 178 |  |
| 175 | `364be2ca` | 10-05 05:29 | qsvm | wine | zz | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 146.2 | 0.6111 | 0.5897 | 178 |  |
| 176 | `b2082338` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 145.4 | 0.8889 | 0.8817 | 178 |  |
| 177 | `3a478ba9` | 10-05 05:29 | qsvm | wine | zz | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.2 | 145.4 | 0.6111 | 0.5897 | 178 |  |
| 178 | `228f15f8` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.1 | 145.9 | 0.8889 | 0.8817 | 178 |  |
| 179 | `1c0f8fc7` | 10-05 05:30 | qsvm | wine | zz | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.2 | 145.6 | 0.6111 | 0.5897 | 178 |  |
| 180 | `7f2ca73f` | 10-05 05:30 | qsvm | wine | angle | 1 | 6 | 5 | 4 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.1 | 145.4 | 0.8889 | 0.8817 | 178 |  |
| 181 | `1369e671` | 10-05 05:42 | classical | breast_cancer | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.9 | 143.4 | 0.9649 | 0.9673 |  |  |
| 182 | `1201317b` | 10-05 05:43 | classical | breast_cancer | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.9 | 143.4 | 0.9474 | 0.9435 |  |  |
| 183 | `3293035c` | 10-05 05:44 | classical | breast_cancer | angle | 1 | 6 | 5 | 8 | classical | ok | 0.2 |  |  | 3.3 | 144.4 | 0.9123 | 0.9107 |  |  |
| 184 | `897b04ac` | 10-05 05:34 | classical | diabetes | angle | 1 | 6 | 5 | 8 | classical | ok | 0.3 |  |  | 3.1 | 146.1 |  |  |  |  |
| 185 | `ff9928f3` | 10-05 05:39 | classical | diabetes | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.8 | 147.6 |  |  |  |  |
| 186 | `8b6c3bef` | 10-05 05:42 | classical | diabetes | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.7 | 142.4 |  |  |  |  |
| 187 | `c5f7bc99` | 10-05 05:36 | classical | digits_01 | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 3.3 | 143.1 | 1.0 | 1.0 |  |  |
| 188 | `8a290c3e` | 10-05 05:39 | classical | digits_01 | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.8 | 143.1 | 1.0 | 1.0 |  |  |
| 189 | `ccf6cf92` | 10-05 05:40 | classical | digits_01 | angle | 1 | 6 | 5 | 8 | classical | ok | 0.2 |  |  | 3.1 | 143.9 | 1.0 | 1.0 |  |  |
| 190 | `9f1e7ced` | 10-05 05:34 | classical | friedman1 | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.8 | 146.2 |  |  |  |  |
| 191 | `bf8ba310` | 10-05 05:37 | classical | friedman1 | angle | 1 | 6 | 5 | 8 | classical | ok | 0.3 |  |  | 3.1 | 145.4 |  |  |  |  |
| 192 | `91e3c144` | 10-05 05:42 | classical | friedman1 | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.8 | 142.6 |  |  |  |  |
| 193 | `311915f5` | 10-05 05:37 | classical | iris | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.7 | 142.9 | 0.9667 | 0.9667 |  |  |
| 194 | `e7e5fe7b` | 10-05 05:39 | classical | iris | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.8 | 143.1 | 1.0 | 1.0 |  |  |
| 195 | `755b3328` | 10-05 05:42 | classical | iris | angle | 1 | 6 | 5 | 8 | classical | ok | 0.2 |  |  | 3.2 | 144.0 | 0.9333 | 0.9333 |  |  |
| 196 | `cc46e281` | 10-05 05:37 | classical | moons | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.7 | 143.0 | 0.9625 | 0.9625 |  |  |
| 197 | `e9133739` | 10-05 05:39 | classical | moons | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.8 | 143.0 | 0.95 | 0.95 |  |  |
| 198 | `f1fed221` | 10-05 05:41 | classical | moons | angle | 1 | 6 | 5 | 8 | classical | ok | 0.2 |  |  | 3.1 | 143.8 | 0.9375 | 0.9375 |  |  |
| 199 | `7a2b4316` | 10-05 05:36 | classical | wine | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 3.3 | 142.5 | 0.9444 | 0.9429 |  |  |
| 200 | `4be8de56` | 10-05 05:36 | classical | wine | angle | 1 | 6 | 5 | 8 | classical | ok | 0.2 |  |  | 3.7 | 143.8 | 0.9167 | 0.9151 |  |  |
| 201 | `771e0d44` | 10-05 05:39 | classical | wine | angle | 1 | 6 | 5 | 8 | classical | ok | 0.0 |  |  | 2.7 | 143.0 | 1.0 | 1.0 |  |  |
| 202 | `7b2c1b06` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | cirq | ok | 1.3 | 1.2 | 0.0 | 6.1 | 239.1 | 0.6316 | 0.5 | 569 |  |
| 203 | `d9049128` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 2.4 | 2.4 | 0.0 | 7.3 | 240.8 | 0.6316 | 0.5 | 569 |  |
| 204 | `dd0474e7` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.5 | 0.4 | 0.0 | 6.6 | 278.6 | 0.6316 | 0.5 | 569 |  |
| 205 | `e9846563` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.2 | 0.1 | 0.0 | 4.0 | 191.1 | 0.6316 | 0.5 | 569 |  |
| 206 | `bf3d6e7d` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.1 | 0.0 | 0.0 | 2.9 | 158.4 | 0.6316 | 0.5 | 569 |  |
| 207 | `81a66140` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.1 | 159.8 | 0.6316 | 0.5 | 569 |  |
| 208 | `05a31548` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.2 | 0.1 | 0.0 | 3.0 | 158.7 | 0.6316 | 0.5 | 569 |  |
| 209 | `1476c3f4` | 10-05 05:43 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.2 | 0.1 | 0.0 | 3.1 | 158.7 | 0.6316 | 0.5 | 569 |  |
| 210 | `dae6444a` | 10-05 05:45 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.8 | 0.8 | 0.0 | 5.7 | 229.2 | 0.75 | 0.75 | 360 |  |
| 211 | `57df0090` | 10-05 05:45 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.5 | 1.5 | 0.0 | 6.3 | 230.4 | 0.75 | 0.75 | 360 |  |
| 212 | `3e975612` | 10-05 05:45 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.3 | 0.2 | 0.0 | 7.0 | 269.5 | 0.75 | 0.75 | 360 |  |
| 213 | `bbe0b78a` | 10-05 05:44 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 4.3 | 182.5 | 0.75 | 0.75 | 360 |  |
| 214 | `a3bf90eb` | 10-05 05:44 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.1 | 0.0 | 0.0 | 3.5 | 150.3 | 0.75 | 0.75 | 360 |  |
| 215 | `7ce6efb1` | 10-05 05:45 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.0 | 151.3 | 0.75 | 0.75 | 360 |  |
| 216 | `f7f8b3f9` | 10-05 05:45 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 3.2 | 150.8 | 0.75 | 0.75 | 360 |  |
| 217 | `a9af1778` | 10-05 05:45 | qkpca | digits_01 | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 3.0 | 150.8 | 0.75 | 0.75 | 360 |  |
| 218 | `1810f4af` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.4 | 0.3 | 0.0 | 5.2 | 224.6 | 0.6667 | 0.6667 | 150 |  |
| 219 | `bc67a68e` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.6 | 0.6 | 0.0 | 5.5 | 225.5 | 0.6667 | 0.6667 | 150 |  |
| 220 | `7dac34cb` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.1 | 263.6 | 0.6667 | 0.6667 | 150 |  |
| 221 | `7a670eaf` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.6 | 176.9 | 0.6667 | 0.6667 | 150 |  |
| 222 | `8dbe81f5` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.9 | 145.9 | 0.6667 | 0.6667 | 150 |  |
| 223 | `3da54c22` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.0 | 146.6 | 0.6667 | 0.6667 | 150 |  |
| 224 | `a1d3e20a` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 2.9 | 146.8 | 0.6667 | 0.6667 | 150 |  |
| 225 | `2f550876` | 10-05 05:37 | qkpca | iris | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.1 | 0.6667 | 0.6667 | 150 |  |
| 226 | `34b07ec9` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.9 | 0.9 | 0.0 | 5.7 | 230.4 | 0.575 | 0.575 | 400 |  |
| 227 | `718a1763` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.7 | 1.7 | 0.0 | 6.6 | 231.7 | 0.575 | 0.575 | 400 |  |
| 228 | `abee600e` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.3 | 0.3 | 0.0 | 6.5 | 271.2 | 0.575 | 0.575 | 400 |  |
| 229 | `a802686c` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.7 | 183.8 | 0.575 | 0.575 | 400 |  |
| 230 | `8fb4a2d4` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.1 | 0.0 | 0.0 | 2.8 | 151.6 | 0.575 | 0.575 | 400 |  |
| 231 | `e6453e9f` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.1 | 152.4 | 0.575 | 0.575 | 400 |  |
| 232 | `bcc23977` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 2.9 | 152.1 | 0.575 | 0.575 | 400 |  |
| 233 | `d2c34625` | 10-05 05:44 | qkpca | moons | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 2.9 | 151.9 | 0.575 | 0.575 | 400 |  |
| 234 | `bd51767e` | 10-05 05:35 | qkpca | wine | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.4 | 0.4 | 0.0 | 5.4 | 224.6 | 0.3889 | 0.3333 | 178 |  |
| 235 | `55b13f10` | 10-05 05:36 | qkpca | wine | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.8 | 0.8 | 0.0 | 5.6 | 226.6 | 0.3889 | 0.3333 | 178 |  |
| 236 | `2342af9a` | 10-05 05:36 | qkpca | wine | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.5 | 264.3 | 0.3889 | 0.3333 | 178 |  |
| 237 | `b44211f5` | 10-05 05:35 | qkpca | wine | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.0 | 0.0 | 3.5 | 177.2 | 0.3889 | 0.3333 | 178 |  |
| 238 | `f157bf86` | 10-05 05:36 | qkpca | wine | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.9 | 146.9 | 0.3889 | 0.3333 | 178 |  |
| 239 | `1b005f81` | 10-05 05:36 | qkpca | wine | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 147.8 | 0.3889 | 0.3333 | 178 |  |
| 240 | `d92e1793` | 10-05 05:36 | qkpca | wine | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 2.9 | 146.8 | 0.3889 | 0.3333 | 178 |  |
| 241 | `5ba127d0` | 10-05 05:35 | qkpca | wine | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 2.8 | 146.9 | 0.3889 | 0.3333 | 178 |  |
| 242 | `3fbbfb7b` | 10-05 05:36 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.9 | 158.1 |  |  | 0 |  |
| 243 | `b61e6293` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | cirq | ok | 1.0 | 1.0 | 0.0 | 6.0 | 230.7 |  |  | 442 |  |
| 244 | `7a1cf4c9` | 10-05 05:36 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | cirq | ok | 0.4 | 0.4 | 0.0 | 5.3 | 230.6 |  |  | 442 |  |
| 245 | `44fecfe4` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.8 | 1.8 | 0.0 | 6.8 | 232.9 |  |  | 442 |  |
| 246 | `80c40455` | 10-05 05:37 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.1 | 1.0 | 0.0 | 6.0 | 231.3 |  |  | 442 |  |
| 247 | `eb054814` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.3 | 0.3 | 0.0 | 6.9 | 271.7 |  |  | 442 |  |
| 248 | `dc89b394` | 10-05 05:36 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | pennylane | ok | 0.2 | 0.1 | 0.0 | 6.6 | 270.3 |  |  | 442 |  |
| 249 | `b6788f8b` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.6 | 184.9 |  |  | 442 |  |
| 250 | `6f5b2689` | 10-05 05:36 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.7 | 185.2 |  |  | 442 |  |
| 251 | `9f2c2f62` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.1 | 0.0 | 0.0 | 2.9 | 150.5 |  |  | 442 |  |
| 252 | `3229b414` | 10-05 05:37 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.9 | 150.4 |  |  | 442 |  |
| 253 | `ac91d373` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.0 | 152.1 |  |  | 442 |  |
| 254 | `bc5862c8` | 10-05 05:36 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 150.9 |  |  | 442 |  |
| 255 | `23979b15` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 2.9 | 151.5 |  |  | 442 |  |
| 256 | `c1075b9d` | 10-05 05:36 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 3.0 | 150.7 |  |  | 442 |  |
| 257 | `e28a9bb7` | 10-05 05:35 | qkrr | diabetes | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 2.9 | 151.3 |  |  | 442 |  |
| 258 | `7f587ef2` | 10-05 05:36 | qkrr | diabetes | angle | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.0 | 151.0 |  |  | 442 |  |
| 259 | `40c21936` | 10-05 05:46 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.7 | 155.4 |  |  | 0 |  |
| 260 | `a3b4835b` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.9 | 0.8 | 0.0 | 5.7 | 229.6 |  |  | 400 |  |
| 261 | `5d375045` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | cirq | ok | 0.4 | 0.4 | 0.0 | 5.1 | 229.2 |  |  | 400 |  |
| 262 | `840063fd` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.9 | 1.9 | 0.0 | 6.7 | 231.5 |  |  | 400 |  |
| 263 | `bd79a1ab` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.9 | 0.9 | 0.0 | 5.7 | 230.1 |  |  | 400 |  |
| 264 | `f11a4067` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.3 | 0.3 | 0.0 | 6.5 | 270.4 |  |  | 400 |  |
| 265 | `516b4dc2` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | pennylane | ok | 0.2 | 0.2 | 0.0 | 6.5 | 269.2 |  |  | 400 |  |
| 266 | `0a70e02d` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.7 | 183.6 |  |  | 400 |  |
| 267 | `4507520a` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.0 | 0.0 | 3.6 | 183.8 |  |  | 400 |  |
| 268 | `2bce9ccb` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 149.6 |  |  | 400 |  |
| 269 | `7cf6632d` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.9 | 149.8 |  |  | 400 |  |
| 270 | `9571ca48` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.1 | 151.0 |  |  | 400 |  |
| 271 | `a7bbc2c2` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 150.2 |  |  | 400 |  |
| 272 | `dbd9731b` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 2.9 | 151.0 |  |  | 400 |  |
| 273 | `f142c92b` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 2.9 | 150.0 |  |  | 400 |  |
| 274 | `31e66bb0` | 10-05 05:42 | qkrr | friedman1 | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 3.0 | 151.1 |  |  | 400 |  |
| 275 | `a611e715` | 10-05 05:45 | qkrr | friedman1 | angle | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 2.9 | 150.0 |  |  | 400 |  |
| 276 | `b5f3bb8e` | 10-05 05:38 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | analytical_angle | ok | 0.1 | 0.0 | 0.1 | 2.9 | 168.4 | 0.9561 | 0.9554 | 0 |  |
| 277 | `880ae707` | 10-05 05:37 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | cirq | ok | 0.7 | 0.6 | 0.0 | 5.8 | 231.1 | 0.9561 | 0.9554 | 569 |  |
| 278 | `ad071bd2` | 10-05 05:40 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | cirq | ok | 1.2 | 1.2 | 0.0 | 6.2 | 232.4 | 0.7368 | 0.6776 | 569 |  |
| 279 | `c7c6ad7f` | 10-05 05:38 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.3 | 1.3 | 0.0 | 6.4 | 234.0 | 0.9561 | 0.9554 | 569 |  |
| 280 | `4a319b93` | 10-05 05:40 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 2.5 | 2.4 | 0.0 | 7.4 | 236.3 | 0.7368 | 0.6776 | 569 |  |
| 281 | `d9ca7956` | 10-05 05:38 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | pennylane | ok | 0.3 | 0.2 | 0.0 | 6.3 | 270.6 | 0.9561 | 0.9554 | 569 |  |
| 282 | `3d5b8af5` | 10-05 05:40 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.4 | 0.4 | 0.0 | 6.6 | 272.4 | 0.7368 | 0.6776 | 569 |  |
| 283 | `c4fb57ca` | 10-05 05:38 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.8 | 187.7 | 0.9561 | 0.9554 | 569 |  |
| 284 | `f93faebd` | 10-05 05:39 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.2 | 0.1 | 0.0 | 4.1 | 189.0 | 0.7368 | 0.6776 | 569 |  |
| 285 | `74de1bb9` | 10-05 05:38 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | qulacs | ok | 0.1 | 0.0 | 0.0 | 3.0 | 150.8 | 0.9561 | 0.9554 | 569 |  |
| 286 | `06f09386` | 10-05 05:39 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.1 | 0.0 | 0.0 | 2.9 | 151.6 | 0.7368 | 0.6776 | 569 |  |
| 287 | `0e3793d0` | 10-05 05:38 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.1 | 152.1 | 0.9561 | 0.9554 | 569 |  |
| 288 | `3943c6ca` | 10-05 05:40 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.0 | 152.7 | 0.7368 | 0.6776 | 569 |  |
| 289 | `a6461b66` | 10-05 05:37 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 3.0 | 151.3 | 0.9561 | 0.9554 | 569 |  |
| 290 | `21d250db` | 10-05 05:40 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.2 | 0.1 | 0.0 | 3.0 | 152.1 | 0.7368 | 0.6776 | 569 |  |
| 291 | `c46f96e6` | 10-05 05:38 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 2.9 | 151.4 | 0.9561 | 0.9554 | 569 |  |
| 292 | `6ab2039b` | 10-05 05:40 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 3.0 | 152.2 | 0.7368 | 0.6776 | 569 |  |
| 293 | `90cc4aed` | 10-05 05:39 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.8 | 152.9 | 1.0 | 1.0 | 0 |  |
| 294 | `2d93ed11` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | cirq | ok | 0.4 | 0.3 | 0.0 | 5.3 | 227.0 | 1.0 | 1.0 | 360 |  |
| 295 | `c3f8b653` | 10-05 05:43 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.8 | 0.8 | 0.0 | 5.6 | 227.6 | 0.9306 | 0.9306 | 360 |  |
| 296 | `e163dbf1` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.8 | 0.8 | 0.0 | 5.6 | 229.0 | 1.0 | 1.0 | 360 |  |
| 297 | `2e716e2e` | 10-05 05:43 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.5 | 1.5 | 0.0 | 6.3 | 230.5 | 0.9306 | 0.9306 | 360 |  |
| 298 | `6bef9d92` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | pennylane | ok | 0.2 | 0.1 | 0.0 | 6.3 | 266.7 | 1.0 | 1.0 | 360 |  |
| 299 | `a961ba67` | 10-05 05:44 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.3 | 0.2 | 0.0 | 6.4 | 267.9 | 0.9306 | 0.9306 | 360 |  |
| 300 | `6673f331` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.0 | 0.0 | 3.6 | 182.4 | 1.0 | 1.0 | 360 |  |
| 301 | `03efeaf6` | 10-05 05:43 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.6 | 182.9 | 0.9306 | 0.9306 | 360 |  |
| 302 | `091fcde3` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.5 | 1.0 | 1.0 | 360 |  |
| 303 | `2410fced` | 10-05 05:44 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.8 | 0.9306 | 0.9306 | 360 |  |
| 304 | `744f162b` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 148.4 | 1.0 | 1.0 | 360 |  |
| 305 | `cead857b` | 10-05 05:43 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 148.7 | 0.9306 | 0.9306 | 360 |  |
| 306 | `2090fa38` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 2.8 | 148.2 | 1.0 | 1.0 | 360 |  |
| 307 | `fdb12817` | 10-05 05:44 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 3.0 | 148.5 | 0.9306 | 0.9306 | 360 |  |
| 308 | `48b5cfd4` | 10-05 05:38 | qsvm | digits_01 | angle | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.0 | 148.0 | 1.0 | 1.0 | 360 |  |
| 309 | `fbe6ff9e` | 10-05 05:44 | qsvm | digits_01 | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 2.9 | 149.1 | 0.9306 | 0.9306 | 360 |  |
| 310 | `5f030f50` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.8 | 145.0 | 0.9667 | 0.9667 | 0 |  |
| 311 | `22e15a6a` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | cirq | ok | 0.2 | 0.1 | 0.0 | 5.0 | 223.9 | 0.9667 | 0.9667 | 150 |  |
| 312 | `39c762ad` | 10-05 05:40 | qsvm | iris | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.3 | 0.3 | 0.0 | 5.2 | 224.6 | 0.6 | 0.6 | 150 |  |
| 313 | `f8557c85` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.4 | 0.4 | 0.0 | 5.3 | 224.6 | 0.9667 | 0.9667 | 150 |  |
| 314 | `afa70038` | 10-05 05:40 | qsvm | iris | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.6 | 0.6 | 0.0 | 5.4 | 224.8 | 0.6 | 0.6 | 150 |  |
| 315 | `4cc668ef` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.3 | 262.8 | 0.9667 | 0.9667 | 150 |  |
| 316 | `d583aff3` | 10-05 05:40 | qsvm | iris | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.6 | 263.5 | 0.6 | 0.6 | 150 |  |
| 317 | `06ed081f` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.7 | 176.3 | 0.9667 | 0.9667 | 150 |  |
| 318 | `c883a6c8` | 10-05 05:41 | qsvm | iris | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.6 | 176.8 | 0.6 | 0.6 | 150 |  |
| 319 | `bc69f591` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 146.0 | 0.9667 | 0.9667 | 150 |  |
| 320 | `259c52be` | 10-05 05:40 | qsvm | iris | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 145.9 | 0.6 | 0.6 | 150 |  |
| 321 | `4df93d9b` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 146.5 | 0.9667 | 0.9667 | 150 |  |
| 322 | `ad50d642` | 10-05 05:40 | qsvm | iris | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.0 | 146.3 | 0.6 | 0.6 | 150 |  |
| 323 | `f23d6901` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 2.8 | 146.0 | 0.9667 | 0.9667 | 150 |  |
| 324 | `b97b6178` | 10-05 05:40 | qsvm | iris | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.0 | 0.6 | 0.6 | 150 |  |
| 325 | `8aa1f579` | 10-05 05:34 | qsvm | iris | angle | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 145.7 | 0.9667 | 0.9667 | 150 |  |
| 326 | `fc917be5` | 10-05 05:40 | qsvm | iris | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.0 | 146.4 | 0.6 | 0.6 | 150 |  |
| 327 | `d3bff3f4` | 10-05 05:42 | qsvm | moons | angle | 1 | 6 | 5 | 8 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.8 | 155.4 | 0.9125 | 0.9125 | 0 |  |
| 328 | `4dc4165f` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.9 | 0.8 | 0.0 | 5.8 | 227.8 | 0.6625 | 0.6625 | 400 |  |
| 329 | `21a70213` | 10-05 05:41 | qsvm | moons | angle | 1 | 6 | 5 | 8 | cirq | ok | 0.4 | 0.4 | 0.0 | 5.2 | 227.6 | 0.9125 | 0.9125 | 400 |  |
| 330 | `445b74fa` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.6 | 1.6 | 0.0 | 6.7 | 231.6 | 0.6625 | 0.6625 | 400 |  |
| 331 | `a706c51f` | 10-05 05:42 | qsvm | moons | angle | 1 | 6 | 5 | 8 | cirq (f64) | ok | 1.0 | 1.0 | 0.0 | 6.0 | 229.9 | 0.9125 | 0.9125 | 400 |  |
| 332 | `d5415fe0` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.3 | 0.3 | 0.0 | 6.5 | 268.8 | 0.6625 | 0.6625 | 400 |  |
| 333 | `9293d8e0` | 10-05 05:41 | qsvm | moons | angle | 1 | 6 | 5 | 8 | pennylane | ok | 0.2 | 0.1 | 0.0 | 6.4 | 267.4 | 0.9125 | 0.9125 | 400 |  |
| 334 | `2ed1fb3a` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.7 | 184.8 | 0.6625 | 0.6625 | 400 |  |
| 335 | `36bbffa3` | 10-05 05:42 | qsvm | moons | angle | 1 | 6 | 5 | 8 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.6 | 183.7 | 0.9125 | 0.9125 | 400 |  |
| 336 | `70278a2f` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 149.0 | 0.6625 | 0.6625 | 400 |  |
| 337 | `8d166ad3` | 10-05 05:41 | qsvm | moons | angle | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.9 | 148.5 | 0.9125 | 0.9125 | 400 |  |
| 338 | `8646c3bf` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 149.9 | 0.6625 | 0.6625 | 400 |  |
| 339 | `75e510f3` | 10-05 05:41 | qsvm | moons | angle | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 149.0 | 0.9125 | 0.9125 | 400 |  |
| 340 | `71cc2469` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 2.9 | 149.4 | 0.6625 | 0.6625 | 400 |  |
| 341 | `71299d9b` | 10-05 05:41 | qsvm | moons | angle | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 2.8 | 148.8 | 0.9125 | 0.9125 | 400 |  |
| 342 | `7772af2f` | 10-05 05:39 | qsvm | moons | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 3.0 | 148.7 | 0.6625 | 0.6625 | 400 |  |
| 343 | `f451c875` | 10-05 05:42 | qsvm | moons | angle | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 2.9 | 149.2 | 0.9125 | 0.9125 | 400 |  |
| 344 | `5fe5ab9d` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.8 | 144.6 | 0.8333 | 0.8167 | 0 |  |
| 345 | `5ac9510a` | 10-05 05:35 | qsvm | wine | zz | 1 | 6 | 5 | 8 | cirq | ok | 0.4 | 0.4 | 0.0 | 5.2 | 224.7 | 0.5 | 0.4484 | 178 |  |
| 346 | `9a57967c` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | cirq | ok | 0.2 | 0.2 | 0.0 | 5.0 | 223.9 | 0.8333 | 0.8167 | 178 |  |
| 347 | `8507a8b5` | 10-05 05:35 | qsvm | wine | zz | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.7 | 0.7 | 0.0 | 5.6 | 226.0 | 0.5 | 0.4484 | 178 |  |
| 348 | `fb493c4e` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | cirq (f64) | ok | 0.5 | 0.5 | 0.0 | 5.3 | 225.3 | 0.8333 | 0.8167 | 178 |  |
| 349 | `030de4ea` | 10-05 05:34 | qsvm | wine | zz | 1 | 6 | 5 | 8 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.4 | 263.9 | 0.5 | 0.4484 | 178 |  |
| 350 | `1ad68ca3` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | pennylane | ok | 0.1 | 0.1 | 0.0 | 6.4 | 263.2 | 0.8333 | 0.8167 | 178 |  |
| 351 | `04965391` | 10-05 05:34 | qsvm | wine | zz | 1 | 6 | 5 | 8 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.6 | 177.2 | 0.5 | 0.4484 | 178 |  |
| 352 | `5af3d1f5` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | qiskit | ok | 0.0 | 0.0 | 0.0 | 3.6 | 176.8 | 0.8333 | 0.8167 | 178 |  |
| 353 | `166edac7` | 10-05 05:34 | qsvm | wine | zz | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 146.3 | 0.5 | 0.4484 | 178 |  |
| 354 | `6ca9c937` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | qulacs | ok | 0.0 | 0.0 | 0.0 | 2.8 | 145.8 | 0.8333 | 0.8167 | 178 |  |
| 355 | `5e891890` | 10-05 05:35 | qsvm | wine | zz | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 2.8 | 147.0 | 0.5 | 0.4484 | 178 |  |
| 356 | `98599e20` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | sf_optimized (patched) | ok | 0.0 | 0.0 | 0.0 | 3.0 | 147.1 | 0.8333 | 0.8167 | 178 |  |
| 357 | `0d4fb93a` | 10-05 05:34 | qsvm | wine | zz | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 3.0 | 147.2 | 0.5 | 0.4484 | 178 |  |
| 358 | `594e7cf8` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | sf_source_baseline | ok | 0.0 | 0.0 | 0.0 | 2.9 | 146.9 | 0.8333 | 0.8167 | 178 |  |
| 359 | `f4995026` | 10-05 05:34 | qsvm | wine | zz | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 3.0 | 146.8 | 0.5 | 0.4484 | 178 |  |
| 360 | `2c7cd40b` | 10-05 05:41 | qsvm | wine | angle | 1 | 6 | 5 | 8 | sf_wheel (PyPI) | ok | 0.0 | 0.0 | 0.0 | 2.9 | 146.3 | 0.8333 | 0.8167 | 178 |  |
| 361 | `1dfc2ed2` | 10-05 05:47 | classical | breast_cancer | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.8 | 143.9 | 0.9561 | 0.9603 |  |  |
| 362 | `05b1f03c` | 10-05 05:51 | classical | breast_cancer | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.9 | 143.5 | 0.9649 | 0.9623 |  |  |
| 363 | `60bc2ef1` | 10-05 05:55 | classical | breast_cancer | angle | 1 | 6 | 5 | 12 | classical | ok | 0.3 |  |  | 4.0 | 144.5 | 0.9211 | 0.9226 |  |  |
| 364 | `035a985d` | 10-05 05:49 | classical | diabetes | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.8 | 143.0 |  |  |  |  |
| 365 | `641e796e` | 10-05 05:51 | classical | diabetes | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.8 | 147.9 |  |  |  |  |
| 366 | `0b280a5b` | 10-05 05:58 | classical | diabetes | angle | 1 | 6 | 5 | 12 | classical | ok | 0.5 |  |  | 3.8 | 145.4 |  |  |  |  |
| 367 | `bba95f9d` | 10-05 05:53 | classical | digits_01 | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 3.5 | 143.6 | 1.0 | 1.0 |  |  |
| 368 | `f32217e4` | 10-05 05:54 | classical | digits_01 | angle | 1 | 6 | 5 | 12 | classical | ok | 0.2 |  |  | 3.7 | 143.5 | 1.0 | 1.0 |  |  |
| 369 | `a5340b94` | 10-05 06:00 | classical | digits_01 | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.8 | 143.8 | 1.0 | 1.0 |  |  |
| 370 | `3b99c0c3` | 10-05 05:51 | classical | friedman1 | angle | 1 | 6 | 5 | 12 | classical | ok | 0.3 |  |  | 3.2 | 145.7 |  |  |  |  |
| 371 | `dee98a68` | 10-05 05:58 | classical | friedman1 | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 3.2 | 142.3 |  |  |  |  |
| 372 | `43435062` | 10-05 06:00 | classical | friedman1 | angle | 1 | 6 | 5 | 12 | classical | ok | 0.1 |  |  | 3.0 | 147.0 |  |  |  |  |
| 373 | `14bfcfa8` | 10-05 05:48 | classical | iris | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.7 | 143.2 | 0.9667 | 0.9667 |  |  |
| 374 | `d73197cd` | 10-05 05:49 | classical | iris | angle | 1 | 6 | 5 | 12 | classical | ok | 0.2 |  |  | 3.1 | 143.9 | 0.9333 | 0.9333 |  |  |
| 375 | `df3dc2aa` | 10-05 05:55 | classical | iris | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 3.2 | 142.8 | 1.0 | 1.0 |  |  |
| 376 | `cf0ff759` | 10-05 05:46 | classical | moons | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.8 | 143.1 | 0.95 | 0.95 |  |  |
| 377 | `beea767a` | 10-05 05:46 | classical | moons | angle | 1 | 6 | 5 | 12 | classical | ok | 0.2 |  |  | 3.1 | 143.6 | 0.9375 | 0.9375 |  |  |
| 378 | `2edbaec9` | 10-05 05:58 | classical | moons | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 3.2 | 142.5 | 0.9625 | 0.9625 |  |  |
| 379 | `4ba5b698` | 10-05 05:50 | classical | wine | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 2.8 | 142.6 | 0.9444 | 0.9429 |  |  |
| 380 | `34032e6f` | 10-05 05:50 | classical | wine | angle | 1 | 6 | 5 | 12 | classical | ok | 0.2 |  |  | 3.0 | 143.7 | 0.9444 | 0.9484 |  |  |
| 381 | `64073f22` | 10-05 05:55 | classical | wine | angle | 1 | 6 | 5 | 12 | classical | ok | 0.0 |  |  | 3.2 | 142.5 | 0.9722 | 0.9667 |  |  |
| 382 | `22836c0f` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | cirq | ok | 3.0 | 2.2 | 0.7 | 8.8 | 317.7 | 0.6316 | 0.5 | 569 |  |
| 383 | `5edaab6e` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 5.7 | 5.0 | 0.7 | 11.3 | 399.8 | 0.6316 | 0.5 | 569 |  |
| 384 | `811aaa5f` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | pennylane | ok | 2.2 | 1.3 | 0.9 | 9.5 | 324.8 | 0.6316 | 0.5 | 569 |  |
| 385 | `9be06c5f` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | qiskit | ok | 1.7 | 0.9 | 0.7 | 6.1 | 236.9 | 0.6316 | 0.5 | 569 |  |
| 386 | `51ac2b5a` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | qulacs | ok | 1.1 | 0.1 | 0.9 | 4.3 | 185.3 | 0.6316 | 0.5 | 569 |  |
| 387 | `024e9491` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.9 | 0.2 | 0.7 | 4.2 | 186.5 | 0.6316 | 0.5 | 569 |  |
| 388 | `7ec6122c` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 1.0 | 0.3 | 0.7 | 4.4 | 186.1 | 0.6316 | 0.5 | 569 |  |
| 389 | `a5b6f268` | 10-05 05:53 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 1.3 | 0.3 | 0.8 | 5.1 | 186.2 | 0.6316 | 0.5 | 569 |  |
| 390 | `d8969dd7` | 10-05 06:00 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | cirq | ok | 1.8 | 1.4 | 0.4 | 7.5 | 282.4 | 0.6111 | 0.6111 | 360 |  |
| 391 | `5e1190c5` | 10-05 05:59 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 3.6 | 3.3 | 0.3 | 9.2 | 334.4 | 0.6111 | 0.6111 | 360 |  |
| 392 | `c1015e91` | 10-05 06:00 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | pennylane | ok | 3.0 | 2.7 | 0.3 | 12.7 | 301.1 | 0.6111 | 0.6111 | 360 |  |
| 393 | `4fa6e5f9` | 10-05 06:00 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.8 | 0.5 | 0.2 | 4.2 | 212.2 | 0.6111 | 0.6111 | 360 |  |
| 394 | `5c6b3190` | 10-05 05:59 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.4 | 0.1 | 0.3 | 3.6 | 169.5 | 0.6111 | 0.6111 | 360 |  |
| 395 | `0eeb52f3` | 10-05 05:59 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.4 | 0.1 | 0.3 | 3.6 | 171.1 | 0.6111 | 0.6111 | 360 |  |
| 396 | `fda07626` | 10-05 06:00 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.4 | 0.2 | 0.3 | 8.9 | 170.4 | 0.6111 | 0.6111 | 360 |  |
| 397 | `9cd2c34d` | 10-05 05:59 | qkpca | digits_01 | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.5 | 0.2 | 0.3 | 3.8 | 170.3 | 0.6111 | 0.6111 | 360 |  |
| 398 | `ff35be53` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | cirq | ok | 0.6 | 0.5 | 0.0 | 5.5 | 246.7 | 0.6667 | 0.6667 | 150 |  |
| 399 | `8cdb4ac1` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 1.1 | 1.1 | 0.0 | 6.0 | 267.3 | 0.6667 | 0.6667 | 150 |  |
| 400 | `7c71bb4f` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | pennylane | ok | 0.3 | 0.2 | 0.0 | 6.4 | 281.5 | 0.6667 | 0.6667 | 150 |  |
| 401 | `0b17fbc2` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.2 | 0.2 | 0.0 | 3.8 | 190.6 | 0.6667 | 0.6667 | 150 |  |
| 402 | `3ba3ca16` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.1 | 0.0 | 0.0 | 2.9 | 154.7 | 0.6667 | 0.6667 | 150 |  |
| 403 | `de67aace` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 2.8 | 155.8 | 0.6667 | 0.6667 | 150 |  |
| 404 | `493ce841` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 3.1 | 155.3 | 0.6667 | 0.6667 | 150 |  |
| 405 | `02aa55bb` | 10-05 05:51 | qkpca | iris | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 3.0 | 155.2 | 0.6667 | 0.6667 | 150 |  |
| 406 | `b54b363c` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | cirq | ok | 1.7 | 1.4 | 0.3 | 6.6 | 290.1 | 0.575 | 0.575 | 400 |  |
| 407 | `459d3cb1` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 3.1 | 2.8 | 0.3 | 8.0 | 347.0 | 0.575 | 0.575 | 400 |  |
| 408 | `cf261a92` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | pennylane | ok | 1.1 | 0.6 | 0.4 | 7.4 | 305.7 | 0.575 | 0.575 | 400 |  |
| 409 | `beffa2f6` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.8 | 0.4 | 0.3 | 4.4 | 217.4 | 0.575 | 0.575 | 400 |  |
| 410 | `7df16abd` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.4 | 0.1 | 0.3 | 3.2 | 172.6 | 0.575 | 0.575 | 400 |  |
| 411 | `ac2caf95` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.4 | 0.1 | 0.3 | 3.2 | 174.2 | 0.575 | 0.575 | 400 |  |
| 412 | `379ec66e` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.5 | 0.1 | 0.3 | 3.3 | 173.2 | 0.575 | 0.575 | 400 |  |
| 413 | `841d47c8` | 10-05 05:50 | qkpca | moons | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.4 | 0.1 | 0.3 | 3.2 | 173.2 | 0.575 | 0.575 | 400 |  |
| 414 | `36a89c86` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | cirq | ok | 0.8 | 0.7 | 0.1 | 6.4 | 251.6 | 0.3889 | 0.3333 | 178 |  |
| 415 | `c788e33a` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 1.6 | 1.5 | 0.1 | 7.4 | 276.1 | 0.3889 | 0.3333 | 178 |  |
| 416 | `366ba2dc` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | pennylane | ok | 0.4 | 0.3 | 0.1 | 7.7 | 281.0 | 0.3889 | 0.3333 | 178 |  |
| 417 | `afca7235` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.4 | 0.3 | 0.1 | 4.5 | 194.3 | 0.3889 | 0.3333 | 178 |  |
| 418 | `a78f54ca` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.1 | 0.0 | 0.1 | 3.5 | 156.7 | 0.3889 | 0.3333 | 178 |  |
| 419 | `cc9abc97` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.1 | 3.6 | 157.6 | 0.3889 | 0.3333 | 178 |  |
| 420 | `151cc1b8` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.2 | 0.1 | 0.1 | 3.5 | 157.2 | 0.3889 | 0.3333 | 178 |  |
| 421 | `a0f62908` | 10-05 05:57 | qkpca | wine | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.2 | 0.1 | 0.1 | 3.4 | 157.1 | 0.3889 | 0.3333 | 178 |  |
| 422 | `9b9bb5b0` | 10-05 05:58 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | analytical_angle | ok | 0.1 | 0.0 | 0.1 | 3.3 | 165.7 |  |  | 0 |  |
| 423 | `3f93d64d` | 10-05 05:55 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | cirq | ok | 2.3 | 1.8 | 0.5 | 8.3 | 296.9 |  |  | 442 |  |
| 424 | `2b9bdb32` | 10-05 05:59 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | cirq | ok | 1.2 | 0.8 | 0.4 | 6.7 | 284.0 |  |  | 442 |  |
| 425 | `db2ab7f2` | 10-05 05:55 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 4.1 | 3.7 | 0.4 | 9.8 | 360.6 |  |  | 442 |  |
| 426 | `95e96f4c` | 10-05 05:59 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | cirq (f64) | ok | 2.3 | 1.8 | 0.4 | 8.1 | 346.7 |  |  | 442 |  |
| 427 | `d9ced7cf` | 10-05 05:55 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | pennylane | ok | 1.4 | 0.9 | 0.5 | 8.8 | 310.0 |  |  | 442 |  |
| 428 | `8ba4ce70` | 10-05 05:59 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | pennylane | ok | 0.8 | 0.4 | 0.4 | 8.0 | 308.3 |  |  | 442 |  |
| 429 | `1e2a8f64` | 10-05 05:55 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | qiskit | ok | 1.1 | 0.7 | 0.4 | 5.2 | 222.6 |  |  | 442 |  |
| 430 | `03622363` | 10-05 05:59 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | qiskit | ok | 0.7 | 0.2 | 0.4 | 4.8 | 219.5 |  |  | 442 |  |
| 431 | `87da38d1` | 10-05 05:54 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.6 | 0.1 | 0.4 | 3.9 | 176.4 |  |  | 442 |  |
| 432 | `23d0133e` | 10-05 05:59 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | qulacs | ok | 0.5 | 0.1 | 0.4 | 3.7 | 175.8 |  |  | 442 |  |
| 433 | `0c11a1de` | 10-05 05:55 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.6 | 0.1 | 0.4 | 3.9 | 177.6 |  |  | 442 |  |
| 434 | `070d1153` | 10-05 05:58 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.5 | 0.1 | 0.4 | 3.8 | 176.5 |  |  | 442 |  |
| 435 | `289e04fb` | 10-05 05:54 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.7 | 0.2 | 0.4 | 4.0 | 177.1 |  |  | 442 |  |
| 436 | `11a5d2ee` | 10-05 05:59 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.5 | 0.1 | 0.4 | 3.9 | 176.6 |  |  | 442 |  |
| 437 | `2cad7c98` | 10-05 05:55 | qkrr | diabetes | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.7 | 0.2 | 0.4 | 3.9 | 176.8 |  |  | 442 |  |
| 438 | `86005a7f` | 10-05 05:59 | qkrr | diabetes | angle | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.7 | 0.1 | 0.6 | 4.2 | 175.9 |  |  | 442 |  |
| 439 | `eede221a` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | analytical_angle | ok | 0.1 | 0.0 | 0.0 | 2.8 | 161.8 |  |  | 0 |  |
| 440 | `1545a934` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | cirq | ok | 0.9 | 0.6 | 0.3 | 5.9 | 278.1 |  |  | 400 |  |
| 441 | `69c6daf0` | 10-05 05:56 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | cirq | ok | 1.9 | 1.5 | 0.3 | 7.4 | 289.5 |  |  | 400 |  |
| 442 | `949d87ba` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | cirq (f64) | ok | 1.7 | 1.4 | 0.3 | 6.6 | 335.2 |  |  | 400 |  |
| 443 | `92b657b3` | 10-05 05:56 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 3.8 | 3.4 | 0.3 | 9.5 | 347.6 |  |  | 400 |  |
| 444 | `5caf82cb` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | pennylane | ok | 0.6 | 0.3 | 0.3 | 6.8 | 304.1 |  |  | 400 |  |
| 445 | `c1b9b8d9` | 10-05 05:56 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | pennylane | ok | 1.1 | 0.8 | 0.3 | 8.2 | 305.5 |  |  | 400 |  |
| 446 | `f8316d62` | 10-05 05:48 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | qiskit | ok | 0.5 | 0.2 | 0.3 | 4.2 | 216.1 |  |  | 400 |  |
| 447 | `3c66ee2e` | 10-05 05:55 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | qiskit | ok | 1.0 | 0.7 | 0.3 | 5.4 | 215.6 |  |  | 400 |  |
| 448 | `c7b3fe48` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | qulacs | ok | 0.4 | 0.0 | 0.3 | 3.2 | 172.1 |  |  | 400 |  |
| 449 | `d6a92c5f` | 10-05 05:56 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.4 | 0.1 | 0.3 | 3.8 | 172.6 |  |  | 400 |  |
| 450 | `f9be8600` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.3 | 0.0 | 0.3 | 3.2 | 173.1 |  |  | 400 |  |
| 451 | `0c8c77da` | 10-05 05:56 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.5 | 0.1 | 0.3 | 3.7 | 173.7 |  |  | 400 |  |
| 452 | `134bfdfb` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.3 | 0.1 | 0.3 | 3.2 | 173.5 |  |  | 400 |  |
| 453 | `3ef83024` | 10-05 05:56 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.5 | 0.2 | 0.3 | 4.0 | 173.7 |  |  | 400 |  |
| 454 | `e20b7e99` | 10-05 05:49 | qkrr | friedman1 | angle | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.4 | 0.1 | 0.3 | 3.2 | 173.3 |  |  | 400 |  |
| 455 | `330ef048` | 10-05 05:56 | qkrr | friedman1 | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.5 | 0.2 | 0.3 | 3.8 | 172.9 |  |  | 400 |  |
| 456 | `a433df01` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | analytical_angle | ok | 0.1 | 0.0 | 0.1 | 3.3 | 181.0 | 0.8246 | 0.7669 | 0 |  |
| 457 | `f209fded` | 10-05 05:47 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | cirq | ok | 2.5 | 1.9 | 0.6 | 7.5 | 318.0 | 0.6316 | 0.5 | 569 |  |
| 458 | `1dea6737` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | cirq | ok | 1.8 | 1.1 | 0.6 | 7.5 | 303.2 | 0.8246 | 0.7669 | 569 |  |
| 459 | `fa7c1f88` | 10-05 05:46 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 4.7 | 4.1 | 0.6 | 9.6 | 399.9 | 0.6316 | 0.5 | 569 |  |
| 460 | `371177bc` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | cirq (f64) | ok | 3.3 | 2.5 | 0.8 | 9.4 | 377.2 | 0.8246 | 0.7669 | 569 |  |
| 461 | `adc049f3` | 10-05 05:47 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | pennylane | ok | 1.5 | 0.8 | 0.6 | 7.8 | 324.9 | 0.6316 | 0.5 | 569 |  |
| 462 | `0ee93835` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | pennylane | ok | 1.2 | 0.5 | 0.7 | 8.6 | 321.6 | 0.8246 | 0.7669 | 569 |  |
| 463 | `89c48b8e` | 10-05 05:47 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | qiskit | ok | 1.4 | 0.8 | 0.6 | 5.1 | 236.4 | 0.6316 | 0.5 | 569 |  |
| 464 | `0fb3dee5` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | qiskit | ok | 1.2 | 0.3 | 0.8 | 5.3 | 234.4 | 0.8246 | 0.7669 | 569 |  |
| 465 | `eff522c7` | 10-05 05:46 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.9 | 0.1 | 0.7 | 3.7 | 184.8 | 0.6316 | 0.5 | 569 |  |
| 466 | `0766d562` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | qulacs | ok | 0.8 | 0.1 | 0.7 | 4.0 | 185.2 | 0.8246 | 0.7669 | 569 |  |
| 467 | `96908efe` | 10-05 05:47 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.8 | 0.1 | 0.6 | 3.7 | 187.0 | 0.6316 | 0.5 | 569 |  |
| 468 | `35bb43c1` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.8 | 0.1 | 0.7 | 3.9 | 186.6 | 0.8246 | 0.7669 | 569 |  |
| 469 | `f8d63e22` | 10-05 05:47 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.9 | 0.2 | 0.6 | 3.7 | 186.3 | 0.6316 | 0.5 | 569 |  |
| 470 | `ad84614d` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.8 | 0.1 | 0.7 | 4.1 | 185.4 | 0.8246 | 0.7669 | 569 |  |
| 471 | `f40bc9b9` | 10-05 05:47 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.8 | 0.2 | 0.5 | 3.7 | 186.1 | 0.6316 | 0.5 | 569 |  |
| 472 | `26dc508a` | 10-05 05:54 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 1.0 | 0.1 | 0.8 | 4.3 | 185.3 | 0.8246 | 0.7669 | 569 |  |
| 473 | `299be434` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.7 | 158.1 | 1.0 | 1.0 | 0 |  |
| 474 | `1ba1adc2` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | cirq | ok | 0.8 | 0.6 | 0.2 | 5.7 | 272.9 | 1.0 | 1.0 | 360 |  |
| 475 | `4cd918f9` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | cirq | ok | 1.5 | 1.2 | 0.2 | 6.2 | 282.8 | 0.875 | 0.875 | 360 |  |
| 476 | `70791dcf` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | cirq (f64) | ok | 1.5 | 1.2 | 0.2 | 6.3 | 319.3 | 1.0 | 1.0 | 360 |  |
| 477 | `6a50b27f` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 2.8 | 2.6 | 0.2 | 7.6 | 334.1 | 0.875 | 0.875 | 360 |  |
| 478 | `8c919366` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | pennylane | ok | 0.5 | 0.3 | 0.2 | 6.9 | 299.7 | 1.0 | 1.0 | 360 |  |
| 479 | `8e1caf9b` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | pennylane | ok | 0.9 | 0.6 | 0.3 | 7.0 | 300.6 | 0.875 | 0.875 | 360 |  |
| 480 | `daac901a` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | qiskit | ok | 0.4 | 0.2 | 0.2 | 4.0 | 214.4 | 1.0 | 1.0 | 360 |  |
| 481 | `8c53766d` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.8 | 0.5 | 0.2 | 4.3 | 215.2 | 0.875 | 0.875 | 360 |  |
| 482 | `84c0c00a` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | qulacs | ok | 0.3 | 0.0 | 0.2 | 3.1 | 169.5 | 1.0 | 1.0 | 360 |  |
| 483 | `ae03b53a` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.3 | 0.1 | 0.2 | 3.1 | 169.5 | 0.875 | 0.875 | 360 |  |
| 484 | `61e958a9` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.3 | 0.0 | 0.2 | 3.2 | 171.0 | 1.0 | 1.0 | 360 |  |
| 485 | `008312e1` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.3 | 0.1 | 0.2 | 3.2 | 171.3 | 0.875 | 0.875 | 360 |  |
| 486 | `cb24d3ae` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.3 | 0.1 | 0.2 | 3.1 | 170.2 | 1.0 | 1.0 | 360 |  |
| 487 | `1357a663` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.4 | 0.1 | 0.2 | 3.3 | 170.4 | 0.875 | 0.875 | 360 |  |
| 488 | `f7447a37` | 10-05 05:46 | qsvm | digits_01 | angle | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.3 | 0.1 | 0.2 | 3.3 | 169.7 | 1.0 | 1.0 | 360 |  |
| 489 | `14728288` | 10-05 05:48 | qsvm | digits_01 | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.4 | 0.2 | 0.2 | 3.3 | 170.3 | 0.875 | 0.875 | 360 |  |
| 490 | `364ad5d2` | 10-05 05:51 | qsvm | iris | angle | 1 | 6 | 5 | 12 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.8 | 144.9 | 0.9667 | 0.9667 | 0 |  |
| 491 | `2a7ca5ca` | 10-05 05:52 | qsvm | iris | angle | 1 | 6 | 5 | 12 | cirq | ok | 0.3 | 0.2 | 0.0 | 5.1 | 241.1 | 0.9667 | 0.9667 | 150 |  |
| 492 | `099756de` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | cirq | ok | 0.7 | 0.7 | 0.0 | 6.5 | 246.4 | 0.6 | 0.6 | 150 |  |
| 493 | `602796e2` | 10-05 05:51 | qsvm | iris | angle | 1 | 6 | 5 | 12 | cirq (f64) | ok | 0.6 | 0.5 | 0.0 | 5.5 | 260.1 | 0.9667 | 0.9667 | 150 |  |
| 494 | `ab676c3e` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 1.3 | 1.3 | 0.0 | 7.3 | 267.5 | 0.6 | 0.6 | 150 |  |
| 495 | `f2cfafe5` | 10-05 05:52 | qsvm | iris | angle | 1 | 6 | 5 | 12 | pennylane | ok | 0.2 | 0.1 | 0.0 | 6.4 | 276.5 | 0.9667 | 0.9667 | 150 |  |
| 496 | `8a7ef15f` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | pennylane | ok | 0.3 | 0.3 | 0.0 | 7.4 | 281.5 | 0.6 | 0.6 | 150 |  |
| 497 | `cddbeb75` | 10-05 05:52 | qsvm | iris | angle | 1 | 6 | 5 | 12 | qiskit | ok | 0.1 | 0.1 | 0.0 | 3.6 | 190.7 | 0.9667 | 0.9667 | 150 |  |
| 498 | `3619e343` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.3 | 0.2 | 0.1 | 4.6 | 190.7 | 0.6 | 0.6 | 150 |  |
| 499 | `1fe612cf` | 10-05 05:51 | qsvm | iris | angle | 1 | 6 | 5 | 12 | qulacs | ok | 0.1 | 0.0 | 0.0 | 2.8 | 154.7 | 0.9667 | 0.9667 | 150 |  |
| 500 | `e3a4fc8c` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.1 | 0.0 | 0.0 | 3.4 | 154.8 | 0.6 | 0.6 | 150 |  |
| 501 | `5db4f8f5` | 10-05 05:51 | qsvm | iris | angle | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.0 | 155.6 | 0.9667 | 0.9667 | 150 |  |
| 502 | `e203ced2` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.0 | 3.4 | 155.8 | 0.6 | 0.6 | 150 |  |
| 503 | `7e9fcce3` | 10-05 05:51 | qsvm | iris | angle | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.1 | 0.0 | 0.0 | 2.9 | 155.1 | 0.9667 | 0.9667 | 150 |  |
| 504 | `24088afb` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.1 | 0.1 | 0.0 | 3.4 | 155.2 | 0.6 | 0.6 | 150 |  |
| 505 | `05b72fdb` | 10-05 05:52 | qsvm | iris | angle | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.0 | 3.3 | 155.0 | 0.9667 | 0.9667 | 150 |  |
| 506 | `f501daa5` | 10-05 05:58 | qsvm | iris | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.1 | 0.1 | 0.0 | 3.3 | 155.2 | 0.6 | 0.6 | 150 |  |
| 507 | `ba267a54` | 10-05 05:47 | qsvm | moons | angle | 1 | 6 | 5 | 12 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.8 | 161.4 | 0.9125 | 0.9125 | 0 |  |
| 508 | `6cdce7d9` | 10-05 05:48 | qsvm | moons | angle | 1 | 6 | 5 | 12 | cirq | ok | 0.9 | 0.6 | 0.3 | 5.7 | 275.3 | 0.9125 | 0.9125 | 400 |  |
| 509 | `9a8556b9` | 10-05 05:56 | qsvm | moons | zz | 1 | 6 | 5 | 12 | cirq | ok | 2.1 | 1.7 | 0.3 | 7.7 | 289.4 | 0.6625 | 0.6625 | 400 |  |
| 510 | `75468918` | 10-05 05:47 | qsvm | moons | angle | 1 | 6 | 5 | 12 | cirq (f64) | ok | 1.7 | 1.4 | 0.3 | 6.5 | 326.2 | 0.9125 | 0.9125 | 400 |  |
| 511 | `dde2854b` | 10-05 05:57 | qsvm | moons | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 3.7 | 3.3 | 0.3 | 9.5 | 346.3 | 0.6625 | 0.6625 | 400 |  |
| 512 | `08684683` | 10-05 05:47 | qsvm | moons | angle | 1 | 6 | 5 | 12 | pennylane | ok | 0.6 | 0.3 | 0.3 | 6.6 | 303.3 | 0.9125 | 0.9125 | 400 |  |
| 513 | `54084b53` | 10-05 05:56 | qsvm | moons | zz | 1 | 6 | 5 | 12 | pennylane | ok | 1.1 | 0.7 | 0.3 | 8.3 | 305.7 | 0.6625 | 0.6625 | 400 |  |
| 514 | `801396fb` | 10-05 05:47 | qsvm | moons | angle | 1 | 6 | 5 | 12 | qiskit | ok | 0.5 | 0.2 | 0.3 | 4.0 | 215.2 | 0.9125 | 0.9125 | 400 |  |
| 515 | `1bfd3abc` | 10-05 05:56 | qsvm | moons | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.8 | 0.5 | 0.3 | 5.0 | 217.1 | 0.6625 | 0.6625 | 400 |  |
| 516 | `8032f3f2` | 10-05 05:47 | qsvm | moons | angle | 1 | 6 | 5 | 12 | qulacs | ok | 0.3 | 0.0 | 0.3 | 3.2 | 172.7 | 0.9125 | 0.9125 | 400 |  |
| 517 | `2230c0b0` | 10-05 05:56 | qsvm | moons | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.4 | 0.1 | 0.3 | 3.8 | 172.5 | 0.6625 | 0.6625 | 400 |  |
| 518 | `92af9990` | 10-05 05:48 | qsvm | moons | angle | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.3 | 0.0 | 0.3 | 3.2 | 173.8 | 0.9125 | 0.9125 | 400 |  |
| 519 | `9eccbc0c` | 10-05 05:57 | qsvm | moons | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.5 | 0.1 | 0.4 | 3.7 | 173.8 | 0.6625 | 0.6625 | 400 |  |
| 520 | `40838bc4` | 10-05 05:48 | qsvm | moons | angle | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.6 | 0.1 | 0.5 | 3.5 | 173.5 | 0.9125 | 0.9125 | 400 |  |
| 521 | `60b3b54a` | 10-05 05:57 | qsvm | moons | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.5 | 0.2 | 0.3 | 3.7 | 173.9 | 0.6625 | 0.6625 | 400 |  |
| 522 | `f22a1094` | 10-05 05:47 | qsvm | moons | angle | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.3 | 0.1 | 0.3 | 3.2 | 172.6 | 0.9125 | 0.9125 | 400 |  |
| 523 | `37e81990` | 10-05 05:57 | qsvm | moons | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.5 | 0.2 | 0.3 | 3.7 | 173.8 | 0.6625 | 0.6625 | 400 |  |
| 524 | `9c04b0f9` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.5 | 146.4 | 0.5 | 0.4444 | 0 |  |
| 525 | `ed38b65f` | 10-05 05:50 | qsvm | wine | zz | 1 | 6 | 5 | 12 | cirq | ok | 0.6 | 0.6 | 0.1 | 5.4 | 251.2 | 0.3889 | 0.3333 | 178 |  |
| 526 | `267b292e` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | cirq | ok | 0.5 | 0.4 | 0.1 | 6.2 | 246.5 | 0.5 | 0.4444 | 178 |  |
| 527 | `5db43621` | 10-05 05:50 | qsvm | wine | zz | 1 | 6 | 5 | 12 | cirq (f64) | ok | 1.3 | 1.2 | 0.1 | 6.2 | 276.0 | 0.3889 | 0.3333 | 178 |  |
| 528 | `ea3acf82` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | cirq (f64) | ok | 0.9 | 0.8 | 0.1 | 6.5 | 268.3 | 0.5 | 0.4444 | 178 |  |
| 529 | `4427bae2` | 10-05 05:49 | qsvm | wine | zz | 1 | 6 | 5 | 12 | pennylane | ok | 0.3 | 0.3 | 0.1 | 6.7 | 280.5 | 0.3889 | 0.3333 | 178 |  |
| 530 | `7791c1a3` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | pennylane | ok | 0.2 | 0.2 | 0.1 | 7.5 | 279.8 | 0.5 | 0.4444 | 178 |  |
| 531 | `175251bb` | 10-05 05:49 | qsvm | wine | zz | 1 | 6 | 5 | 12 | qiskit | ok | 0.3 | 0.3 | 0.1 | 3.8 | 193.9 | 0.3889 | 0.3333 | 178 |  |
| 532 | `dc78efea` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | qiskit | ok | 0.2 | 0.1 | 0.1 | 4.2 | 193.9 | 0.5 | 0.4444 | 178 |  |
| 533 | `cf8a3764` | 10-05 05:50 | qsvm | wine | zz | 1 | 6 | 5 | 12 | qulacs | ok | 0.1 | 0.0 | 0.1 | 2.9 | 157.1 | 0.3889 | 0.3333 | 178 |  |
| 534 | `3e2d5872` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | qulacs | ok | 0.1 | 0.0 | 0.1 | 3.6 | 156.0 | 0.5 | 0.4444 | 178 |  |
| 535 | `b0ea665a` | 10-05 05:49 | qsvm | wine | zz | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.1 | 3.0 | 158.2 | 0.3889 | 0.3333 | 178 |  |
| 536 | `16f907fe` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | sf_optimized (patched) | ok | 0.1 | 0.0 | 0.1 | 3.3 | 157.4 | 0.5 | 0.4444 | 178 |  |
| 537 | `1678d465` | 10-05 05:49 | qsvm | wine | zz | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.1 | 0.1 | 0.1 | 3.0 | 157.4 | 0.3889 | 0.3333 | 178 |  |
| 538 | `d00e0d83` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | sf_source_baseline | ok | 0.1 | 0.0 | 0.1 | 3.4 | 157.3 | 0.5 | 0.4444 | 178 |  |
| 539 | `10700ed1` | 10-05 05:49 | qsvm | wine | zz | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.2 | 0.1 | 0.1 | 3.0 | 157.7 | 0.3889 | 0.3333 | 178 |  |
| 540 | `c8af89a1` | 10-05 05:52 | qsvm | wine | angle | 1 | 6 | 5 | 12 | sf_wheel (PyPI) | ok | 0.1 | 0.0 | 0.1 | 3.4 | 157.4 | 0.5 | 0.4444 | 178 |  |
| 541 | `b5792ac2` | 10-05 06:18 | classical | breast_cancer | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 3.2 | 143.2 | 0.9737 | 0.9742 |  |  |
| 542 | `5f0e8240` | 10-05 06:18 | classical | breast_cancer | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 3.5 | 143.8 | 0.9825 | 0.9812 |  |  |
| 543 | `8c81c76b` | 10-05 06:18 | classical | breast_cancer | angle | 1 | 6 | 5 | 16 | classical | ok | 0.5 |  |  | 4.1 | 143.7 | 0.9386 | 0.9415 |  |  |
| 544 | `43e13d70` | 10-05 06:01 | classical | diabetes | angle | 1 | 6 | 5 | 16 | classical | ok | 0.2 |  |  | 3.0 | 147.7 |  |  |  |  |
| 545 | `01345194` | 10-05 06:06 | classical | diabetes | angle | 1 | 6 | 5 | 16 | classical | ok | 0.1 |  |  | 3.3 | 142.9 |  |  |  |  |
| 546 | `5a23f6ff` | 10-05 06:21 | classical | diabetes | angle | 1 | 6 | 5 | 16 | classical | ok | 0.3 |  |  | 2.8 | 145.9 |  |  |  |  |
| 547 | `f5b14b0d` | 10-05 06:07 | classical | digits_01 | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 2.7 | 142.8 | 1.0 | 1.0 |  |  |
| 548 | `3c8cbb0e` | 10-05 06:07 | classical | digits_01 | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 2.7 | 143.3 | 1.0 | 1.0 |  |  |
| 549 | `1388ade5` | 10-05 06:26 | classical | digits_01 | angle | 1 | 6 | 5 | 16 | classical | ok | 0.2 |  |  | 2.7 | 144.0 | 1.0 | 1.0 |  |  |
| 550 | `32cccf48` | 10-05 06:18 | classical | friedman1 | angle | 1 | 6 | 5 | 16 | classical | ok | 0.1 |  |  | 3.3 | 146.6 |  |  |  |  |
| 551 | `d4f291bc` | 10-05 06:18 | classical | friedman1 | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 3.5 | 142.7 |  |  |  |  |
| 552 | `5cdf9391` | 10-05 06:18 | classical | friedman1 | angle | 1 | 6 | 5 | 16 | classical | ok | 0.5 |  |  | 3.9 | 144.9 |  |  |  |  |
| 553 | `c32ae8ca` | 10-05 06:07 | classical | iris | angle | 1 | 6 | 5 | 16 | classical | ok | 0.1 |  |  | 2.7 | 143.0 | 1.0 | 1.0 |  |  |
| 554 | `99896d74` | 10-05 06:16 | classical | iris | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 2.7 | 142.4 | 0.9667 | 0.9667 |  |  |
| 555 | `d2d239f7` | 10-05 06:31 | classical | iris | angle | 1 | 6 | 5 | 16 | classical | ok | 0.3 |  |  | 2.8 | 143.5 | 0.9333 | 0.9333 |  |  |
| 556 | `66c5c1aa` | 10-05 06:06 | classical | moons | angle | 1 | 6 | 5 | 16 | classical | ok | 0.4 |  |  | 4.8 | 143.7 | 0.9375 | 0.9375 |  |  |
| 557 | `0df0c30a` | 10-05 06:16 | classical | moons | angle | 1 | 6 | 5 | 16 | classical | ok | 0.1 |  |  | 2.7 | 142.7 | 0.95 | 0.95 |  |  |
| 558 | `50855bfd` | 10-05 06:21 | classical | moons | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 2.4 | 143.3 | 0.9625 | 0.9625 |  |  |
| 559 | `79b279ea` | 10-05 06:07 | classical | wine | angle | 1 | 6 | 5 | 16 | classical | ok | 0.2 |  |  | 3.1 | 143.3 | 0.9444 | 0.9484 |  |  |
| 560 | `7fb3dfd6` | 10-05 06:12 | classical | wine | angle | 1 | 6 | 5 | 16 | classical | ok | 0.0 |  |  | 2.6 | 142.8 | 1.0 | 1.0 |  |  |
| 561 | `6bb676a1` | 10-05 06:21 | classical | wine | angle | 1 | 6 | 5 | 16 | classical | ok | 0.1 |  |  | 2.5 | 142.9 | 0.9167 | 0.9095 |  |  |
| 562 | `3562046d` | 10-05 06:20 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | cirq | ok | 13.8 | 9.9 | 3.4 | 18.7 | 740.5 | 0.6316 | 0.5 | 1508 |  |
| 563 | `2bdba4a9` | 10-05 06:20 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 27.7 | 24.0 | 3.2 | 32.2 | 1105.9 | 0.6316 | 0.5 | 1508 |  |
| 564 | `4a5b7b30` | 10-05 06:20 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | pennylane | ok | 22.1 | 17.9 | 3.6 | 30.1 | 652.8 | 0.6316 | 0.5 | 1508 |  |
| 565 | `87c805e6` | 10-05 06:19 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | qiskit | ok | 23.3 | 18.1 | 4.4 | 28.0 | 564.1 | 0.6316 | 0.5 | 1508 |  |
| 566 | `ebc381d0` | 10-05 06:21 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | qulacs | ok | 9.7 | 6.0 | 3.2 | 12.4 | 533.6 | 0.6316 | 0.5 | 1508 |  |
| 567 | `5d615ce5` | 10-05 06:21 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 8.6 | 4.9 | 3.2 | 11.3 | 534.4 | 0.6316 | 0.5 | 1508 |  |
| 568 | `ea8e19da` | 10-05 06:19 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 14.0 | 9.0 | 4.4 | 17.8 | 533.4 | 0.6316 | 0.5 | 1508 |  |
| 569 | `603cda51` | 10-05 06:21 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 10.1 | 6.3 | 3.3 | 12.7 | 533.0 | 0.6316 | 0.5 | 1508 |  |
| 570 | `77e9da3c` | 10-05 06:08 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | cirq | ok | 6.7 | 2.5 | 4.1 | 11.6 | 1090.1 | 0.5 | 0.5 | 360 |  |
| 571 | `7d86d82a` | 10-05 06:08 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 11.9 | 8.0 | 3.7 | 17.1 | 1930.5 | 0.5 | 0.5 | 360 |  |
| 572 | `fbe479bc` | 10-05 06:07 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | pennylane | ok | 8.8 | 3.9 | 4.6 | 15.1 | 843.4 | 0.5 | 0.5 | 360 |  |
| 573 | `efdf0a42` | 10-05 06:07 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | qiskit | ok | 7.8 | 3.2 | 4.4 | 11.5 | 753.3 | 0.5 | 0.5 | 360 |  |
| 574 | `b054ce10` | 10-05 06:08 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | qulacs | ok | 6.2 | 1.5 | 4.5 | 9.1 | 515.7 | 0.5 | 0.5 | 360 |  |
| 575 | `2f0d6bc6` | 10-05 06:08 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 6.4 | 1.5 | 4.7 | 9.4 | 516.7 | 0.5 | 0.5 | 360 |  |
| 576 | `0b20b9d4` | 10-05 06:08 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 6.4 | 1.7 | 4.5 | 9.5 | 515.8 | 0.5 | 0.5 | 360 |  |
| 577 | `f65211e1` | 10-05 06:08 | qkpca | digits_01 | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 6.3 | 1.8 | 4.4 | 9.7 | 515.3 | 0.5 | 0.5 | 360 |  |
| 578 | `b527f236` | 10-05 06:29 | qkpca | iris | zz | 1 | 6 | 5 | 16 | cirq | ok | 2.9 | 2.0 | 0.9 | 8.0 | 583.0 | 0.6667 | 0.6667 | 150 |  |
| 579 | `3561c2ea` | 10-05 06:29 | qkpca | iris | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 3.0 | 2.3 | 0.6 | 7.3 | 947.1 | 0.6667 | 0.6667 | 150 |  |
| 580 | `8ad81c71` | 10-05 06:29 | qkpca | iris | zz | 1 | 6 | 5 | 16 | pennylane | ok | 2.1 | 1.4 | 0.7 | 8.0 | 504.0 | 0.6667 | 0.6667 | 150 |  |
| 581 | `27164739` | 10-05 06:29 | qkpca | iris | zz | 1 | 6 | 5 | 16 | qiskit | ok | 2.4 | 1.5 | 0.9 | 6.3 | 416.2 | 0.6667 | 0.6667 | 150 |  |
| 582 | `3f33db34` | 10-05 06:29 | qkpca | iris | zz | 1 | 6 | 5 | 16 | qulacs | ok | 1.4 | 0.6 | 0.7 | 4.5 | 303.7 | 0.6667 | 0.6667 | 150 |  |
| 583 | `a6fbab94` | 10-05 06:29 | qkpca | iris | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 1.5 | 0.5 | 0.9 | 4.4 | 303.8 | 0.6667 | 0.6667 | 150 |  |
| 584 | `e34aa132` | 10-05 06:28 | qkpca | iris | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 1.2 | 0.5 | 0.7 | 3.8 | 303.8 | 0.6667 | 0.6667 | 150 |  |
| 585 | `72c94b39` | 10-05 06:29 | qkpca | iris | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 1.3 | 0.6 | 0.7 | 4.6 | 303.7 | 0.6667 | 0.6667 | 150 |  |
| 586 | `72c9c968` | 10-05 06:06 | qkpca | moons | zz | 1 | 6 | 5 | 16 | cirq | ok | 11.6 | 5.8 | 5.5 | 17.5 | 1188.9 | 0.575 | 0.575 | 400 |  |
| 587 | `0ad933b4` | 10-05 06:03 | qkpca | moons | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 13.3 | 7.9 | 4.6 | 22.6 | 1973.3 | 0.575 | 0.575 | 400 |  |
| 588 | `c999993f` | 10-05 06:04 | qkpca | moons | zz | 1 | 6 | 5 | 16 | pennylane | ok | 10.9 | 5.2 | 5.5 | 46.1 | 909.5 | 0.575 | 0.575 | 400 |  |
| 589 | `d4ab3d81` | 10-05 06:05 | qkpca | moons | zz | 1 | 6 | 5 | 16 | qiskit | ok | 17.2 | 10.9 | 5.8 | 22.2 | 818.9 | 0.575 | 0.575 | 400 |  |
| 590 | `5b305203` | 10-05 06:05 | qkpca | moons | zz | 1 | 6 | 5 | 16 | qulacs | ok | 8.3 | 2.1 | 5.9 | 19.2 | 556.0 | 0.575 | 0.575 | 400 |  |
| 591 | `bd744fd7` | 10-05 06:05 | qkpca | moons | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 7.7 | 1.3 | 6.3 | 11.6 | 557.4 | 0.575 | 0.575 | 400 |  |
| 592 | `518736cd` | 10-05 06:04 | qkpca | moons | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 8.4 | 1.8 | 6.5 | 12.2 | 555.7 | 0.575 | 0.575 | 400 |  |
| 593 | `432f436a` | 10-05 06:04 | qkpca | moons | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 8.3 | 1.8 | 6.3 | 12.2 | 556.1 | 0.575 | 0.575 | 400 |  |
| 594 | `6cb25f5d` | 10-05 06:01 | qkpca | wine | zz | 1 | 6 | 5 | 16 | cirq | ok | 2.5 | 1.3 | 1.1 | 7.8 | 650.1 | 0.3889 | 0.3333 | 178 |  |
| 595 | `e118f231` | 10-05 06:00 | qkpca | wine | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 5.0 | 3.9 | 1.0 | 10.2 | 1078.9 | 0.3889 | 0.3333 | 178 |  |
| 596 | `0bc3942d` | 10-05 06:01 | qkpca | wine | zz | 1 | 6 | 5 | 16 | pennylane | ok | 3.6 | 2.1 | 1.4 | 11.7 | 548.6 | 0.3889 | 0.3333 | 178 |  |
| 597 | `675f5c3f` | 10-05 06:00 | qkpca | wine | zz | 1 | 6 | 5 | 16 | qiskit | ok | 3.0 | 1.8 | 1.1 | 6.9 | 461.1 | 0.3889 | 0.3333 | 178 |  |
| 598 | `6fa6aca3` | 10-05 06:01 | qkpca | wine | zz | 1 | 6 | 5 | 16 | qulacs | ok | 2.0 | 0.8 | 1.1 | 5.1 | 332.2 | 0.3889 | 0.3333 | 178 |  |
| 599 | `22fa09d3` | 10-05 06:01 | qkpca | wine | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 1.8 | 0.6 | 1.1 | 5.1 | 332.6 | 0.3889 | 0.3333 | 178 |  |
| 600 | `46a4a067` | 10-05 06:01 | qkpca | wine | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 2.0 | 0.8 | 1.1 | 5.3 | 332.0 | 0.3889 | 0.3333 | 178 |  |
| 601 | `7b9203b7` | 10-05 06:01 | qkpca | wine | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 2.0 | 0.8 | 1.1 | 5.2 | 332.0 | 0.3889 | 0.3333 | 178 |  |
| 602 | `f95d2039` | 10-05 06:14 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | analytical_angle | ok | 0.1 | 0.0 | 0.1 | 3.5 | 173.4 |  |  | 0 |  |
| 603 | `5455f893` | 10-05 06:10 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | cirq | ok | 11.4 | 4.0 | 7.2 | 17.7 | 1288.7 |  |  | 442 |  |
| 604 | `2b15638c` | 10-05 06:15 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | cirq | ok | 8.1 | 1.8 | 6.2 | 12.9 | 1166.0 |  |  | 442 |  |
| 605 | `53056c3d` | 10-05 06:09 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 14.9 | 8.8 | 5.8 | 20.8 | 2227.3 |  |  | 442 |  |
| 606 | `c02db7d1` | 10-05 06:15 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | cirq (f64) | ok | 10.7 | 4.9 | 5.6 | 16.4 | 2159.1 |  |  | 442 |  |
| 607 | `3b99eecf` | 10-05 06:10 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | pennylane | ok | 11.4 | 4.4 | 6.8 | 19.6 | 975.6 |  |  | 442 |  |
| 608 | `9d674d5c` | 10-05 06:14 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | pennylane | ok | 10.7 | 2.5 | 7.9 | 17.9 | 972.6 |  |  | 442 |  |
| 609 | `3963178d` | 10-05 06:11 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | qiskit | ok | 10.6 | 3.9 | 6.6 | 15.9 | 883.4 |  |  | 442 |  |
| 610 | `52a1878b` | 10-05 06:16 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | qiskit | ok | 9.1 | 2.6 | 6.3 | 12.5 | 884.4 |  |  | 442 |  |
| 611 | `43842517` | 10-05 06:09 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | qulacs | ok | 8.4 | 1.8 | 6.4 | 11.9 | 598.8 |  |  | 442 |  |
| 612 | `19937152` | 10-05 06:15 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | qulacs | ok | 7.6 | 0.9 | 6.5 | 10.2 | 598.3 |  |  | 442 |  |
| 613 | `51fb19e6` | 10-05 06:10 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 8.1 | 1.4 | 6.6 | 11.5 | 600.5 |  |  | 442 |  |
| 614 | `b06036a1` | 10-05 06:16 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 7.0 | 0.5 | 6.3 | 9.7 | 599.4 |  |  | 442 |  |
| 615 | `929d4fd6` | 10-05 06:09 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 9.3 | 2.0 | 7.0 | 12.7 | 598.8 |  |  | 442 |  |
| 616 | `ac268143` | 10-05 06:14 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 9.3 | 1.3 | 7.8 | 12.8 | 598.8 |  |  | 442 |  |
| 617 | `1a9b8a9f` | 10-05 06:09 | qkrr | diabetes | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 10.7 | 2.4 | 8.1 | 14.9 | 598.1 |  |  | 442 |  |
| 618 | `6d8521e1` | 10-05 06:15 | qkrr | diabetes | angle | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 9.5 | 1.3 | 8.0 | 13.0 | 598.7 |  |  | 442 |  |
| 619 | `d7290e3b` | 10-05 06:16 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | analytical_angle | ok | 0.1 | 0.0 | 0.0 | 2.7 | 167.6 |  |  | 0 |  |
| 620 | `cbb53240` | 10-05 06:14 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | cirq | ok | 10.4 | 3.6 | 6.6 | 16.0 | 1188.8 |  |  | 400 |  |
| 621 | `e3484031` | 10-05 06:17 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | cirq | ok | 6.9 | 1.8 | 4.9 | 11.6 | 1083.0 |  |  | 400 |  |
| 622 | `d3825de3` | 10-05 06:13 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 12.0 | 7.2 | 4.5 | 16.9 | 2154.1 |  |  | 400 |  |
| 623 | `aa881183` | 10-05 06:17 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | cirq (f64) | ok | 8.5 | 3.8 | 4.5 | 13.1 | 1988.8 |  |  | 400 |  |
| 624 | `0abdb441` | 10-05 06:13 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | pennylane | ok | 10.2 | 4.9 | 5.2 | 17.3 | 908.4 |  |  | 400 |  |
| 625 | `fcfb4c4d` | 10-05 06:17 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | pennylane | ok | 7.1 | 1.8 | 5.2 | 13.7 | 906.3 |  |  | 400 |  |
| 626 | `690a0132` | 10-05 06:13 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | qiskit | ok | 8.9 | 3.4 | 5.3 | 12.8 | 819.0 |  |  | 400 |  |
| 627 | `47e1a629` | 10-05 06:16 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | qiskit | ok | 7.4 | 2.3 | 5.0 | 10.7 | 816.8 |  |  | 400 |  |
| 628 | `61dfb510` | 10-05 06:13 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | qulacs | ok | 7.1 | 1.6 | 5.3 | 10.0 | 556.0 |  |  | 400 |  |
| 629 | `c85c0ee0` | 10-05 06:16 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | qulacs | ok | 6.1 | 0.8 | 5.1 | 8.7 | 555.4 |  |  | 400 |  |
| 630 | `7ceec7a2` | 10-05 06:12 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 6.6 | 1.2 | 5.3 | 9.5 | 557.3 |  |  | 400 |  |
| 631 | `96bbc178` | 10-05 06:17 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 5.8 | 0.5 | 5.2 | 8.5 | 557.0 |  |  | 400 |  |
| 632 | `ae28f25f` | 10-05 06:14 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 7.1 | 1.6 | 5.3 | 10.0 | 556.2 |  |  | 400 |  |
| 633 | `80d916bc` | 10-05 06:16 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 6.4 | 0.9 | 5.3 | 9.2 | 556.8 |  |  | 400 |  |
| 634 | `25032f69` | 10-05 06:13 | qkrr | friedman1 | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 7.0 | 1.7 | 5.2 | 10.1 | 555.9 |  |  | 400 |  |
| 635 | `d6308751` | 10-05 06:16 | qkrr | friedman1 | angle | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 6.2 | 1.0 | 5.1 | 9.1 | 556.4 |  |  | 400 |  |
| 636 | `73010262` | 10-05 06:26 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | analytical_angle | ok | 0.1 | 0.0 | 0.1 | 2.7 | 193.9 | 0.6404 | 0.5119 | 0 |  |
| 637 | `7f5531a9` | 10-05 06:24 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | cirq | ok | 11.2 | 7.0 | 3.6 | 16.4 | 707.7 | 0.6404 | 0.5119 | 1508 |  |
| 638 | `90a80589` | 10-05 06:27 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | cirq | ok | 12.9 | 9.4 | 3.1 | 17.5 | 740.2 | 0.6316 | 0.5 | 1508 |  |
| 639 | `a40036ab` | 10-05 06:26 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | cirq (f64) | ok | 16.6 | 12.8 | 3.1 | 20.8 | 1035.2 | 0.6404 | 0.5119 | 1508 |  |
| 640 | `b88f5eb3` | 10-05 06:28 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 27.5 | 23.8 | 3.2 | 31.9 | 1105.9 | 0.6316 | 0.5 | 1508 |  |
| 641 | `994f0f5e` | 10-05 06:25 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | pennylane | ok | 10.3 | 6.6 | 3.2 | 15.9 | 650.8 | 0.6404 | 0.5119 | 1508 |  |
| 642 | `135b0a5d` | 10-05 06:28 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | pennylane | ok | 19.1 | 15.4 | 3.2 | 24.7 | 652.7 | 0.6316 | 0.5 | 1508 |  |
| 643 | `172a455e` | 10-05 06:25 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | qiskit | ok | 16.5 | 11.5 | 4.3 | 20.0 | 562.6 | 0.6404 | 0.5119 | 1508 |  |
| 644 | `694104a4` | 10-05 06:27 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | qiskit | ok | 16.4 | 12.8 | 3.2 | 19.9 | 563.9 | 0.6316 | 0.5 | 1508 |  |
| 645 | `2a45aa80` | 10-05 06:25 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | qulacs | ok | 6.9 | 3.2 | 3.2 | 9.5 | 532.5 | 0.6404 | 0.5119 | 1508 |  |
| 646 | `6e5023c8` | 10-05 06:27 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | qulacs | ok | 9.6 | 5.9 | 3.2 | 12.2 | 533.5 | 0.6316 | 0.5 | 1508 |  |
| 647 | `08123042` | 10-05 06:25 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 5.9 | 2.2 | 3.2 | 8.4 | 534.4 | 0.6404 | 0.5119 | 1508 |  |
| 648 | `eb069f28` | 10-05 06:27 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 8.7 | 5.0 | 3.2 | 11.4 | 533.8 | 0.6316 | 0.5 | 1508 |  |
| 649 | `ce1d4607` | 10-05 06:25 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 7.2 | 3.6 | 3.2 | 9.7 | 533.6 | 0.6404 | 0.5119 | 1508 |  |
| 650 | `9af49821` | 10-05 06:26 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 10.2 | 6.4 | 3.3 | 12.8 | 533.3 | 0.6316 | 0.5 | 1508 |  |
| 651 | `4fe9f83b` | 10-05 06:26 | qsvm | breast_cancer | angle | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 7.8 | 4.0 | 3.4 | 10.7 | 532.3 | 0.6404 | 0.5119 | 1508 |  |
| 652 | `807be03c` | 10-05 06:26 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 10.3 | 6.6 | 3.3 | 13.0 | 533.3 | 0.6316 | 0.5 | 1508 |  |
| 653 | `46ae6eb3` | 10-05 06:23 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 2.6 | 163.6 | 0.875 | 0.875 | 0 |  |
| 654 | `1df86753` | 10-05 06:11 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | cirq | ok | 6.5 | 2.3 | 4.1 | 11.4 | 1090.5 | 0.7778 | 0.7778 | 360 |  |
| 655 | `00c93ac2` | 10-05 06:23 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | cirq | ok | 5.1 | 1.3 | 3.6 | 9.3 | 1003.3 | 0.875 | 0.875 | 360 |  |
| 656 | `5ef897bb` | 10-05 06:12 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 10.4 | 6.5 | 3.7 | 15.3 | 1930.3 | 0.7778 | 0.7778 | 360 |  |
| 657 | `7d7dab23` | 10-05 06:23 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | cirq (f64) | ok | 6.8 | 3.3 | 3.4 | 10.9 | 1746.2 | 0.875 | 0.875 | 360 |  |
| 658 | `79944fad` | 10-05 06:12 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | pennylane | ok | 8.2 | 3.7 | 4.3 | 14.1 | 844.4 | 0.7778 | 0.7778 | 360 |  |
| 659 | `dff6f405` | 10-05 06:22 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | pennylane | ok | 5.4 | 1.5 | 3.8 | 10.9 | 841.2 | 0.875 | 0.875 | 360 |  |
| 660 | `d16d7b28` | 10-05 06:11 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | qiskit | ok | 7.6 | 3.2 | 4.3 | 11.4 | 753.7 | 0.7778 | 0.7778 | 360 |  |
| 661 | `b3305ff8` | 10-05 06:23 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | qiskit | ok | 5.7 | 1.9 | 3.7 | 8.7 | 754.1 | 0.875 | 0.875 | 360 |  |
| 662 | `3fb8c6fe` | 10-05 06:11 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | qulacs | ok | 7.2 | 1.9 | 5.0 | 10.6 | 515.9 | 0.7778 | 0.7778 | 360 |  |
| 663 | `72fda493` | 10-05 06:22 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | qulacs | ok | 4.7 | 0.7 | 3.9 | 7.2 | 515.1 | 0.875 | 0.875 | 360 |  |
| 664 | `5d1cfc84` | 10-05 06:12 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 5.7 | 1.2 | 4.4 | 8.5 | 516.5 | 0.7778 | 0.7778 | 360 |  |
| 665 | `4c03efa0` | 10-05 06:23 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 4.6 | 0.5 | 4.0 | 7.1 | 516.9 | 0.875 | 0.875 | 360 |  |
| 666 | `8447870f` | 10-05 06:11 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 6.6 | 2.0 | 4.4 | 10.0 | 515.9 | 0.7778 | 0.7778 | 360 |  |
| 667 | `ad66f7e0` | 10-05 06:22 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 4.7 | 0.9 | 3.8 | 7.2 | 515.9 | 0.875 | 0.875 | 360 |  |
| 668 | `4c4efe58` | 10-05 06:11 | qsvm | digits_01 | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 6.0 | 1.6 | 4.2 | 8.9 | 515.3 | 0.7778 | 0.7778 | 360 |  |
| 669 | `509bab84` | 10-05 06:23 | qsvm | digits_01 | angle | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 4.8 | 0.9 | 3.8 | 7.6 | 515.8 | 0.875 | 0.875 | 360 |  |
| 670 | `886861fa` | 10-05 06:18 | qsvm | iris | angle | 1 | 6 | 5 | 16 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.1 | 157.1 | 0.9667 | 0.9667 | 0 |  |
| 671 | `9829c701` | 10-05 06:18 | qsvm | iris | angle | 1 | 6 | 5 | 16 | cirq | ok | 1.4 | 0.6 | 0.8 | 6.3 | 529.9 | 0.9667 | 0.9667 | 150 |  |
| 672 | `ad7b4039` | 10-05 06:21 | qsvm | iris | zz | 1 | 6 | 5 | 16 | cirq | ok | 2.3 | 1.6 | 0.7 | 6.9 | 583.2 | 0.6 | 0.6 | 150 |  |
| 673 | `ad2708df` | 10-05 06:17 | qsvm | iris | angle | 1 | 6 | 5 | 16 | cirq (f64) | ok | 2.3 | 1.5 | 0.8 | 6.8 | 838.9 | 0.9667 | 0.9667 | 150 |  |
| 674 | `cd558ebd` | 10-05 06:22 | qsvm | iris | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 3.0 | 2.3 | 0.6 | 7.4 | 946.3 | 0.6 | 0.6 | 150 |  |
| 675 | `6d33cf50` | 10-05 06:18 | qsvm | iris | angle | 1 | 6 | 5 | 16 | pennylane | ok | 1.5 | 0.7 | 0.8 | 7.7 | 503.2 | 0.9667 | 0.9667 | 150 |  |
| 676 | `cc819f6f` | 10-05 06:22 | qsvm | iris | zz | 1 | 6 | 5 | 16 | pennylane | ok | 2.2 | 1.5 | 0.7 | 7.9 | 504.3 | 0.6 | 0.6 | 150 |  |
| 677 | `328f8bd0` | 10-05 06:18 | qsvm | iris | angle | 1 | 6 | 5 | 16 | qiskit | ok | 2.3 | 1.1 | 1.1 | 6.0 | 414.3 | 0.9667 | 0.9667 | 150 |  |
| 678 | `6807273a` | 10-05 06:22 | qsvm | iris | zz | 1 | 6 | 5 | 16 | qiskit | ok | 1.9 | 1.2 | 0.6 | 5.6 | 416.2 | 0.6 | 0.6 | 150 |  |
| 679 | `ed6fdb7f` | 10-05 06:18 | qsvm | iris | angle | 1 | 6 | 5 | 16 | qulacs | ok | 1.1 | 0.3 | 0.8 | 3.9 | 303.3 | 0.9667 | 0.9667 | 150 |  |
| 680 | `bce42a2c` | 10-05 06:22 | qsvm | iris | zz | 1 | 6 | 5 | 16 | qulacs | ok | 1.3 | 0.6 | 0.7 | 4.0 | 304.1 | 0.6 | 0.6 | 150 |  |
| 681 | `e75f3c6f` | 10-05 06:18 | qsvm | iris | angle | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 1.0 | 0.1 | 0.8 | 4.8 | 304.9 | 0.9667 | 0.9667 | 150 |  |
| 682 | `148838f0` | 10-05 06:22 | qsvm | iris | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 1.1 | 0.3 | 0.7 | 3.7 | 304.2 | 0.6 | 0.6 | 150 |  |
| 683 | `23013ae0` | 10-05 06:17 | qsvm | iris | angle | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 1.2 | 0.3 | 0.8 | 3.9 | 304.4 | 0.9667 | 0.9667 | 150 |  |
| 684 | `b2877eea` | 10-05 06:21 | qsvm | iris | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 1.2 | 0.5 | 0.7 | 3.8 | 303.7 | 0.6 | 0.6 | 150 |  |
| 685 | `6e02c365` | 10-05 06:17 | qsvm | iris | angle | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 1.1 | 0.3 | 0.8 | 3.9 | 304.4 | 0.9667 | 0.9667 | 150 |  |
| 686 | `05e32307` | 10-05 06:22 | qsvm | iris | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 1.2 | 0.5 | 0.7 | 3.8 | 303.5 | 0.6 | 0.6 | 150 |  |
| 687 | `b4004b46` | 10-05 06:01 | qsvm | moons | angle | 1 | 6 | 5 | 16 | analytical_angle | ok | 0.2 | 0.0 | 0.0 | 3.1 | 168.2 | 0.9125 | 0.9125 | 0 |  |
| 688 | `fba34c60` | 10-05 06:02 | qsvm | moons | angle | 1 | 6 | 5 | 16 | cirq | ok | 7.0 | 1.8 | 5.0 | 11.9 | 1028.0 | 0.9125 | 0.9125 | 400 |  |
| 689 | `f080b75f` | 10-05 06:29 | qsvm | moons | zz | 1 | 6 | 5 | 16 | cirq | ok | 8.9 | 4.4 | 4.3 | 14.2 | 1188.9 | 0.6625 | 0.6625 | 400 |  |
| 690 | `da83f046` | 10-05 06:02 | qsvm | moons | angle | 1 | 6 | 5 | 16 | cirq (f64) | ok | 10.1 | 4.7 | 4.9 | 15.7 | 1575.1 | 0.9125 | 0.9125 | 400 |  |
| 691 | `da33240b` | 10-05 06:30 | qsvm | moons | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 11.9 | 6.8 | 4.7 | 17.2 | 2153.9 | 0.6625 | 0.6625 | 400 |  |
| 692 | `ac5fa902` | 10-05 06:01 | qsvm | moons | angle | 1 | 6 | 5 | 16 | pennylane | ok | 7.3 | 1.9 | 5.3 | 13.5 | 905.4 | 0.9125 | 0.9125 | 400 |  |
| 693 | `3f0bfc66` | 10-05 06:31 | qsvm | moons | zz | 1 | 6 | 5 | 16 | pennylane | ok | 8.3 | 3.7 | 4.5 | 20.5 | 908.4 | 0.6625 | 0.6625 | 400 |  |
| 694 | `d0cf65a6` | 10-05 06:03 | qsvm | moons | angle | 1 | 6 | 5 | 16 | qiskit | ok | 9.6 | 3.3 | 6.1 | 17.9 | 818.1 | 0.9125 | 0.9125 | 400 |  |
| 695 | `73c5ce87` | 10-05 06:30 | qsvm | moons | zz | 1 | 6 | 5 | 16 | qiskit | ok | 9.5 | 3.8 | 5.5 | 15.8 | 818.3 | 0.6625 | 0.6625 | 400 |  |
| 696 | `3a677ec1` | 10-05 06:02 | qsvm | moons | angle | 1 | 6 | 5 | 16 | qulacs | ok | 6.4 | 0.9 | 5.3 | 9.2 | 555.5 | 0.9125 | 0.9125 | 400 |  |
| 697 | `8bddf1ec` | 10-05 06:31 | qsvm | moons | zz | 1 | 6 | 5 | 16 | qulacs | ok | 6.0 | 1.5 | 4.4 | 9.0 | 556.4 | 0.6625 | 0.6625 | 400 |  |
| 698 | `74e4b24f` | 10-05 06:03 | qsvm | moons | angle | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 6.3 | 0.3 | 5.8 | 9.9 | 556.8 | 0.9125 | 0.9125 | 400 |  |
| 699 | `6c6bdd62` | 10-05 06:31 | qsvm | moons | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 5.5 | 0.8 | 4.5 | 8.5 | 557.3 | 0.6625 | 0.6625 | 400 |  |
| 700 | `a8341382` | 10-05 06:02 | qsvm | moons | angle | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 6.3 | 0.8 | 5.3 | 9.2 | 556.3 | 0.9125 | 0.9125 | 400 |  |
| 701 | `411dc464` | 10-05 06:30 | qsvm | moons | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 7.4 | 1.7 | 5.6 | 16.4 | 556.4 | 0.6625 | 0.6625 | 400 |  |
| 702 | `b5c4c0c8` | 10-05 06:02 | qsvm | moons | angle | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 6.2 | 0.7 | 5.3 | 11.3 | 556.5 | 0.9125 | 0.9125 | 400 |  |
| 703 | `cda572c2` | 10-05 06:31 | qsvm | moons | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 6.1 | 1.3 | 4.7 | 9.2 | 555.4 | 0.6625 | 0.6625 | 400 |  |
| 704 | `a79a07dd` | 10-05 06:24 | qsvm | wine | angle | 1 | 6 | 5 | 16 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 3.3 | 157.6 | 0.5 | 0.4444 | 0 |  |
| 705 | `af8d8bbf` | 10-05 06:06 | qsvm | wine | zz | 1 | 6 | 5 | 16 | cirq | ok | 3.0 | 1.6 | 1.3 | 9.0 | 651.0 | 0.3889 | 0.3333 | 178 |  |
| 706 | `1c3d3f76` | 10-05 06:24 | qsvm | wine | angle | 1 | 6 | 5 | 16 | cirq | ok | 2.1 | 0.8 | 1.2 | 7.4 | 608.2 | 0.5 | 0.4444 | 178 |  |
| 707 | `1969cff9` | 10-05 06:06 | qsvm | wine | zz | 1 | 6 | 5 | 16 | cirq (f64) | ok | 5.3 | 4.0 | 1.2 | 11.2 | 1079.6 | 0.3889 | 0.3333 | 178 |  |
| 708 | `af2e3edd` | 10-05 06:24 | qsvm | wine | angle | 1 | 6 | 5 | 16 | cirq (f64) | ok | 3.2 | 1.9 | 1.2 | 8.1 | 1045.9 | 0.5 | 0.4444 | 178 |  |
| 709 | `9357c63a` | 10-05 06:07 | qsvm | wine | zz | 1 | 6 | 5 | 16 | pennylane | ok | 3.1 | 1.9 | 1.1 | 9.3 | 548.4 | 0.3889 | 0.3333 | 178 |  |
| 710 | `82c5cbe3` | 10-05 06:24 | qsvm | wine | angle | 1 | 6 | 5 | 16 | pennylane | ok | 2.1 | 0.9 | 1.2 | 8.9 | 547.3 | 0.5 | 0.4444 | 178 |  |
| 711 | `2405fb12` | 10-05 06:06 | qsvm | wine | zz | 1 | 6 | 5 | 16 | qiskit | ok | 3.4 | 2.0 | 1.3 | 7.8 | 461.1 | 0.3889 | 0.3333 | 178 |  |
| 712 | `7c745de5` | 10-05 06:23 | qsvm | wine | angle | 1 | 6 | 5 | 16 | qiskit | ok | 2.0 | 1.0 | 0.9 | 5.2 | 460.8 | 0.5 | 0.4444 | 178 |  |
| 713 | `91c3d2c6` | 10-05 06:07 | qsvm | wine | zz | 1 | 6 | 5 | 16 | qulacs | ok | 2.1 | 0.9 | 1.1 | 5.5 | 332.2 | 0.3889 | 0.3333 | 178 |  |
| 714 | `c8201cb8` | 10-05 06:24 | qsvm | wine | angle | 1 | 6 | 5 | 16 | qulacs | ok | 1.7 | 0.4 | 1.2 | 4.8 | 332.1 | 0.5 | 0.4444 | 178 |  |
| 715 | `98ed5e67` | 10-05 06:06 | qsvm | wine | zz | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 2.3 | 0.8 | 1.3 | 5.9 | 332.0 | 0.3889 | 0.3333 | 178 |  |
| 716 | `89aa7e9f` | 10-05 06:23 | qsvm | wine | angle | 1 | 6 | 5 | 16 | sf_optimized (patched) | ok | 1.3 | 0.2 | 1.0 | 3.8 | 332.9 | 0.5 | 0.4444 | 178 |  |
| 717 | `b7423fb7` | 10-05 06:06 | qsvm | wine | zz | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 2.3 | 0.9 | 1.3 | 5.8 | 331.9 | 0.3889 | 0.3333 | 178 |  |
| 718 | `9b4f8a40` | 10-05 06:24 | qsvm | wine | angle | 1 | 6 | 5 | 16 | sf_source_baseline | ok | 1.4 | 0.4 | 0.9 | 3.9 | 332.5 | 0.5 | 0.4444 | 178 |  |
| 719 | `b937b94e` | 10-05 06:06 | qsvm | wine | zz | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 2.6 | 1.0 | 1.5 | 6.1 | 331.9 | 0.3889 | 0.3333 | 178 |  |
| 720 | `bdaf794a` | 10-05 06:23 | qsvm | wine | angle | 1 | 6 | 5 | 16 | sf_wheel (PyPI) | ok | 1.9 | 0.6 | 1.3 | 5.2 | 332.6 | 0.5 | 0.4444 | 178 |  |
| 721 | `88e45971` | 10-05 06:31 | classical | digits_01 | angle | 1 | 6 | 5 | 20 | classical | ok | 0.2 |  |  | 2.8 | 144.1 | 1.0 | 1.0 |  |  |
| 722 | `605b9937` | 10-05 06:31 | classical | friedman1 | angle | 1 | 6 | 5 | 20 | classical | ok | 0.3 |  |  | 2.7 | 145.2 |  |  |  |  |
| 723 | `2caa6466` | 10-05 11:15 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 20 | qiskit | error |  |  |  | 1800.3 |  |  |  |  | timeout |
| 724 | `6861c27b` | 10-05 11:38 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 20 | sf_optimized (patched) | ok | 1336.6 | 1110.9 | 167.4 | 1363.6 | 917.7 | 0.6316 | 0.5 | 10005 |  |
| 725 | `64153309` | 10-05 12:06 | qkpca | breast_cancer | zz | 1 | 6 | 5 | 20 | sf_wheel (PyPI) | ok | 1603.6 | 1363.6 | 177.4 | 1629.2 | 917.3 | 0.6316 | 0.5 | 10005 |  |
| 726 | `6187160d` | 10-05 07:53 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | cirq | ok | 1060.1 | 894.7 | 117.1 | 1090.7 | 1249.8 | 0.6316 | 0.5 | 10005 |  |
| 727 | `be7b5f26` | 10-05 08:40 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | cirq (f64) | error |  |  |  | 1800.2 |  |  |  |  | timeout |
| 728 | `efd4a1d0` | 10-05 09:28 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | pennylane | error |  |  |  | 1800.0 |  |  |  |  | timeout |
| 729 | `8dd1c488` | 10-05 09:57 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | qiskit | ok | 1694.5 | 1526.9 | 120.6 | 1714.3 | 944.1 | 0.6316 | 0.5 | 10005 |  |
| 730 | `c3d07c8d` | 10-05 10:27 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | qulacs | error |  |  |  | 1800.1 |  |  |  |  | timeout |
| 731 | `0ea697fd` | 10-05 08:10 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | sf_optimized (patched) | ok | 952.8 | 785.4 | 122.5 | 968.4 | 917.5 | 0.6316 | 0.5 | 10005 |  |
| 732 | `9937519d` | 10-05 08:58 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | sf_source_baseline | ok | 1065.6 | 896.5 | 123.7 | 1081.2 | 917.3 | 0.6316 | 0.5 | 10005 |  |
| 733 | `dfffb9d9` | 10-05 10:45 | qsvm | breast_cancer | zz | 1 | 6 | 5 | 20 | sf_wheel (PyPI) | ok | 1095.6 | 925.9 | 124.3 | 1111.1 | 916.7 | 0.6316 | 0.5 | 10005 |  |
| 734 | `b805044f` | 10-05 06:52 | qsvm | moons | angle | 1 | 6 | 5 | 20 | analytical_angle | ok | 0.0 | 0.0 | 0.0 | 8.8 | 338.7 | 0.9125 | 0.9125 | 0 |  |
| 735 | `cc7632fa` | 10-05 07:21 | qsvm | moons | angle | 1 | 6 | 5 | 20 | cirq | ok | 505.6 | 426.0 | 56.3 | 514.2 | 1127.3 | 0.9125 | 0.9125 | 4960 |  |
| 736 | `58a712c5` | 10-05 07:35 | qsvm | moons | angle | 1 | 6 | 5 | 20 | cirq (f64) | ok | 840.5 | 734.3 | 70.7 | 852.7 | 1792.6 | 0.9125 | 0.9125 | 4960 |  |
| 737 | `d7d90553` | 10-05 06:44 | qsvm | moons | angle | 1 | 6 | 5 | 20 | pennylane | ok | 730.8 | 642.3 | 63.2 | 741.1 | 1046.7 | 0.9125 | 0.9125 | 4960 |  |
| 738 | `e8718b5a` | 10-05 07:12 | qsvm | moons | angle | 1 | 6 | 5 | 20 | qiskit | ok | 589.0 | 509.8 | 56.7 | 596.1 | 942.3 | 0.9125 | 0.9125 | 4960 |  |
| 739 | `f9fc6a3e` | 10-05 06:52 | qsvm | moons | angle | 1 | 6 | 5 | 20 | qulacs | ok | 511.7 | 421.7 | 65.3 | 519.1 | 930.0 | 0.9125 | 0.9125 | 4960 |  |
| 740 | `b8d1c1e8` | 10-05 06:59 | qsvm | moons | angle | 1 | 6 | 5 | 20 | sf_optimized (patched) | ok | 171.0 | 82.0 | 65.0 | 177.7 | 930.5 | 0.9125 | 0.9125 | 4960 |  |
| 741 | `6b26eea1` | 10-05 07:03 | qsvm | moons | angle | 1 | 6 | 5 | 20 | sf_source_baseline | ok | 200.4 | 120.8 | 58.0 | 206.7 | 930.4 | 0.9125 | 0.9125 | 4960 |  |
| 742 | `c25e4ed2` | 10-05 06:56 | qsvm | moons | angle | 1 | 6 | 5 | 20 | sf_wheel (PyPI) | ok | 213.2 | 131.0 | 59.7 | 219.9 | 930.4 | 0.9125 | 0.9125 | 4960 |  |

## 11. Appendix B — accounting & preservation

- raw/*.json non-config files: 798; config files: 799
- Pre-relabel snapshot: `D:\sf_runs\v8_local\backups\snap_20261005_pre_relabel` (full result+chain copy)
- Pre-timeout-change gate backup: `_pypi_v0112_check\backup_timeout_edit\`
- Ops log: `D:\sf_runs\v8_local\studies\requested_grid_split80_20_grid24_v8\_v8_ops.log`
- Watcher: `_v8_watch_c41.ps1` running; auto-relabel M1→M2 fires at 'cell 42 start'.

*Report generated 2026-10-05 12:21:16 — superseded by the final report after the notebook completes.*