# SuperFermion 24Q VQC/VQR Campaign - Outputs & Benchmarks Report

**Study**: `requested_grid_split80_20_grid24_v8` (profile `requested_grid`; 16 threads; 1200 s per-job timeout; revision `requested_grid_24q_v8_1_desktop_mt16_t20min`)  
**Status**: COMPLETE - 2156 / 2156 jobs ok, 0 failed, 0 pending (`overview.json` -> `complete: true`)  
**Generated**: 2026-10-07 17:25 by `_agent_notes/make_outputs_report.py` - every number computed from the on-disk artifacts listed below.

---

## 1. Run summary

| Section | Cells | Tasks | Jobs | Ok | Failed | Recorded compute wall |
|---|---|---|---|---|---|---|
| 1 | 41 / 43 | qsvm, qkrr, qkpca, classical | 900 | 900 | 0 | 30,169 s (first pass) + 1,158 s (resume redo) |
| 2 | 43 | vqc, vqr | 336 | 336 | 0 | 4,043 s |
| 3 | 45 | qaoa_fs, maxcut, vqe | 400 | 400 | 0 | 2,321 s |
| 4 | 47 | gradient | 80 | 80 | 0 | 3,678 s |
| 5 | 49 | circuit | 440 | 440 | 0 | 1,333 s |

Total: **2,156 jobs planned and executed, 2,156 ok, 0 failed** (final in-notebook verification re-collected everything from cache; whole notebook re-saved in 148.3 s). Wall times as recorded in the campaign logs at completion; the section-1 first pass ran 8.4 h and was finished by an automatic resume redo (19.3 min) after a mid-campaign restart.

**Environment / grid**

| Setting | Value |
|---|---|
| Threads | 16 per quantum worker (classical lanes 1; BLAS pinned to 1) |
| Per-job timeout | 1,200 s strict (5 section ceilings at 48 h; analysis 1,800 s) |
| Qubit grid | 4 / 8 / 12 / 16 / 20 (VQC/VQR: 4 / 8 / 12 with 5 updates) |
| Datasets | 7 ML (breast_cancer, iris, wine, digits_01, moons, diabetes, friedman1) + 6 special (ring, erdos_renyi, TFIM_open_chain, synthetic, batch_sweep, depth_sweep) |
| Simulator lanes | 8 lanes x 252 jobs: superfermion_optimized / _wheel / _source_baseline, qulacs, qiskit, pennylane, cirq, cirq_f64 |
| Split / seed | full 80/20 held-out split; seed 42; 1 fresh-process repetition |
| Conditions | 252 measured condition groups (all complete) |

**Completion criteria (instruction.md section 9a)**

| Criterion | Status | Evidence |
|---|---|---|
| 1. Runner prints `status 0` | PASS | full campaign saved with `status 0` (16:34:43, 12,650.2 s); verification pass saved again (16:43:03, 148.3 s) |
| 2. `nb_run_progress.log` ends with the save line | PASS | `... executed.ipynb; total 148.3s; status 0` |
| 3. `overview.json` complete | PASS | `complete: true`, expected/completed/successful = 2156/2156/2156, failed 0, pending 0 |
| 4. Results bundle zip exists | PASS | `Superfermion_requested_grid_Expanded_Results.zip` (6,005 entries, 43.7 MiB) |
| Extra: raw ledger clean | PASS | 2,156 ok rows, 0 non-ok, 0 not_started in `experiment_job_status.csv` |

---

## 2. Outputs produced

**Executed notebook & bundle**

| Artifact | Size | Location |
|---|---|---|
| Superfermion_requested_grid_Expanded_Results.zip | 43.67 MiB | `D:\sf_runs\vqc_v8\studies\requested_grid_split80_20_grid24_v8` |
| Superfermion_Full_Grid_24Q_VQC_VQR_5Steps_RAM_Time_v8.1_desktop_mt16_t20min_executed.ipynb | 22.31 MiB | `D:\sf_runs\vqc_v8\nb` |
| Superfermion_Full_Grid_24Q_VQC_VQR_5Steps_RAM_Time_v8.1_desktop_mt16_t20min.ipynb | 359.4 KiB | `D:\sf_runs\vqc_v8\nb` |
| Superfermion_Full_Grid_24Q_VQC_VQR_5Steps_RAM_Time_v8.1_desktop_mt16_t20min_executed_smoke13.ipynb | 88.0 KiB | `D:\sf_runs\vqc_v8\nb` |
| nb_run_progress.log | 44.3 KiB | `D:\sf_runs\vqc_v8\runner` |

**Study directory contents** (`D:\sf_runs\vqc_v8\studies\requested_grid_split80_20_grid24_v8`)

| File | Size | Contents |
|---|---|---|
| `all_experiment_figures.csv` | 29.6 KiB | figure index (title + png/svg paths) |
| `all_experiment_figures.html` | 56.6 KiB | HTML figure index |
| `all_experiment_figures.json` | 61.2 KiB | figure index (JSON) |
| `all_experiment_time_ram.csv` | 502.3 KiB | Time & RAM benchmark per condition x framework (q25/median/q75) |
| `all_experiment_time_ram.html` | 57.9 KiB | HTML view of the Time & RAM table |
| `all_results.csv` | 3.06 MiB | flat per-job results table (2,156 jobs, 108 columns) |
| `all_results.json` | 9.45 MiB | per-job results (JSON) |
| `analyze_study.py` | 44.7 KiB | analysis script (golden build, sha 6cd650f2) |
| `backend_preflight.json` | 23.4 KiB | backend preflight checks |
| `campaign_plan.json` | 543 B | planned job grid |
| `campaign_receipt_results_circuit.json` | 182 B | section receipt (jobs / success / failed / wall) |
| `campaign_receipt_results_gradient.json` | 181 B | section receipt (jobs / success / failed / wall) |
| `campaign_receipt_results_qaoa_fs_maxcut_vqe.json` | 182 B | section receipt (jobs / success / failed / wall) |
| `campaign_receipt_results_qsvm_qkrr_qkpca_classical.json` | 181 B | section receipt (jobs / success / failed / wall) |
| `campaign_receipt_results_vqc_vqr.json` | 181 B | section receipt (jobs / success / failed / wall) |
| `condition_leaders.csv` | 37.7 KiB | fastest lane per condition + speedup ratios |
| `condition_leaders.html` | 40.6 KiB | HTML view of condition leaders |
| `correctness.csv` | 32.5 KiB | per-condition correctness checks |
| `correctness_passed.json` | 206 B | correctness gate (validated for the golden build) |
| `data_manifest.json` | 45.2 KiB | dataset file hashes / provenance |
| `dataset_audit.csv` | 10.6 KiB | dataset audit (splits, sizes) |
| `experiment_core.py` | 18.5 KiB | experiment core (hash-locked module) |
| `experiment_job_status.csv` | 3.06 MiB | per-job status + all metrics (source for this report) |
| `experiment_job_status.html` | 317.6 KiB | HTML view of job status table |
| `figure_index.json` | 15.5 KiB | figure registry (JSON) |
| `group_coverage.csv` | 44.6 KiB | coverage of the 252 condition groups |
| `group_coverage.html` | 26.4 KiB | HTML view of coverage |
| `legacy_adapter.py` | 26.8 KiB | legacy compatibility adapter |
| `manifest.json` | 60.9 KiB | provenance manifest (script + data hashes) |
| `model_and_solver_quality.csv` | 269.1 KiB | model / solver quality metrics |
| `model_and_solver_quality.html` | 65.3 KiB | HTML view of quality table |
| `native_readout_ratios.csv` | 51.4 KiB | native-readout comparison ratios |
| `offline_checks.py` | 12.1 KiB | offline checks module |
| `outcome_agreement.csv` | 238.1 KiB | outcome agreement checks |
| `outcome_agreement.html` | 31.7 KiB | HTML view of outcome agreement |
| `overview.json` | 1.3 KiB | campaign summary: completion + headline stats |
| `paired_speedups.csv` | 168.3 KiB | paired time speedups per condition |
| `paired_speedups.html` | 27.5 KiB | HTML view of paired speedups |
| `periodic_report_config.json` | 2.9 KiB | periodic report config |
| `periodic_reports.log` | 170.2 KiB | periodic report log |
| `planned_jobs.csv` | 527 B | planned job list |
| `prepare_study_data.py` | 9.5 KiB | dataset preparation module |
| `ram_backend_checks.csv` | 351 B | RAM backend probe checks |
| `ram_backend_checks.html` | 1.1 KiB | HTML view of backend checks |
| `ram_by_condition.csv` | 963.0 KiB | RAM benchmark per condition x framework |
| `ram_by_condition.html` | 118.3 KiB | HTML view of RAM by condition |
| `ram_by_framework_task.csv` | 58.0 KiB | RAM benchmark, framework x task |
| `ram_by_framework_task.html` | 101.0 KiB | HTML view of RAM by framework x task |
| `ram_framework_summary.csv` | 5.2 KiB | RAM headline summary per framework |
| `ram_framework_summary.html` | 11.4 KiB | HTML view of RAM framework summary |
| `ram_methodology.json` | 1.6 KiB | RAM measurement methodology notes |
| `ram_paired_comparisons.csv` | 229.2 KiB | paired RAM comparisons per condition |
| `ram_paired_comparisons.html` | 40.7 KiB | HTML view of paired RAM comparisons |
| `ram_per_job.csv` | 566.2 KiB | per-job RAM table |
| `ram_per_job.html` | 56.3 KiB | HTML view of per-job RAM |
| `requirements.lock.txt` | 1.3 KiB | pinned dependency lock |
| `requirements.txt` | 1.3 KiB | requirements spec |
| `results_circuit.json` | 1.20 MiB | per-job results for one campaign section (JSON) |
| `results_gradient.json` | 241.2 KiB | per-job results for one campaign section (JSON) |
| `results_qaoa_fs_maxcut_vqe.json` | 1.38 MiB | per-job results for one campaign section (JSON) |
| `results_qsvm_qkrr_qkpca_classical.json` | 5.03 MiB | per-job results for one campaign section (JSON) |
| `results_vqc_vqr.json` | 1.60 MiB | per-job results for one campaign section (JSON) |
| `run_config.json` | 2.9 KiB | run configuration (threads / timeout / grid) |
| `statebank_budget.csv` | 215.9 KiB | state-vector bank budget vs qubits |
| `study_driver.py` | 21.4 KiB | campaign driver (hash-locked module) |
| `study_worker.py` | 30.0 KiB | per-job worker (hash-locked module) |
| `Superfermion_requested_grid_Expanded_Results.zip` | 43.67 MiB | results bundle (6,005 entries, 43.7 MiB) |
| `timing_summary.csv` | 481.7 KiB | timing summary per condition x framework |
| `timing_summary.html` | 60.0 KiB | HTML view of timing summary |
| `unsupported_feature_selection.csv` | 48 B | feature-selection coverage notes |
| `validation_results.json` | 112.9 KiB | dataset validation results |

| Subdirectory | Count | Contents |
|---|---|---|
| `raw/` | 6,568 files | per-job result JSON + sibling `.config.json` + `.log` for all 2,156 jobs |
| `figures/` | 214 files | 107 PNG figures + 107 SVG twins |
| `data/` | 35 files | prepared dataset copies used by the study |
| `logs/` | 32 files | campaign logs (kernel_and_classical, variational_qml, optimization, gradient, circuit_scaling) + per-section logs |
| `__pycache__/` | 5 files | bytecode cache |

**Results bundle zip layout** (`Superfermion_requested_grid_Expanded_Results.zip`, 6,005 entries)

| Path in zip | Entries |
|---|---|
| results/raw/ ... | 5633 |
| results/figures/ ... | 214 |
| results/ (top-level files) | 70 |
| results/data/ ... | 35 |
| results/logs/ ... | 32 |
| modifications/modified_files/ ... | 12 |
| modifications/original_files/ ... | 7 |
| modifications/superfermion_performance.patch | 1 |
| modifications/source_manifest.json | 1 |

---

## 3. Benchmarks - runtime

Metric: `primary_runtime_s` per job (the measured primary compute stage; process wall time is shown separately below). All 2,156 jobs are fresh-process runs on 16 threads.

**3a. Per task**

| Task | Jobs | Datasets | Qubits | Lanes | Extra frameworks | Median | Mean | Max |
|---|---|---|---|---|---|---|---|---|
| qsvm | 425 | 5 | 4/8/12/16/20 | 8 | analytical_angle (25) | 197.7 ms | 32.54 s | 996.03 s |
| qkrr | 170 | 2 | 4/8/12/16/20 | 8 | analytical_angle (10) | 253.4 ms | 44.44 s | 801.09 s |
| qkpca | 200 | 5 | 4/8/12/16/20 | 8 | - | 340.9 ms | 38.97 s | 1116.73 s |
| classical | 105 | 7 | 4/8/12/16/20 | 0 | classical (105) | 5.1 ms | 33.5 ms | 169.3 ms |
| vqc | 240 | 5 | 4/8/12 | 8 | - | 1.03 s | 9.99 s | 188.60 s |
| vqr | 96 | 2 | 4/8/12 | 8 | - | 932.7 ms | 8.89 s | 150.47 s |
| qaoa_fs | 160 | 2 | 4/8/12/16/20 | 8 | - | 70.2 ms | 1.97 s | 59.33 s |
| maxcut | 160 | 2 | 4/8/12/16/20 | 8 | - | 45.2 ms | 1.19 s | 37.98 s |
| vqe | 80 | 1 | 4/8/12/16/20 | 8 | - | 65.3 ms | 2.25 s | 20.92 s |
| gradient | 80 | 1 | 4/8/12/16/20 | 8 | - | 71.2 ms | 1.75 s | 29.84 s |
| circuit | 440 | 3 | 4/8/12/16/20 | 8 | - | 2.7 ms | 47.4 ms | 1.28 s |

**3b. Per framework / lane** (all jobs run under that framework)

| Framework | Jobs | Tasks | Median runtime | Median process wall | Median peak RAM | Max peak RAM |
|---|---|---|---|---|---|---|
| superfermion_optimized | 252 | 10 | 29.7 ms | 1.42 s | 150.6 MiB | 936.4 MiB |
| superfermion_wheel | 252 | 10 | 48.4 ms | 1.43 s | 150.1 MiB | 935.9 MiB |
| superfermion_source_baseline | 252 | 10 | 48.5 ms | 1.43 s | 150.2 MiB | 937.0 MiB |
| qulacs | 252 | 10 | 101.0 ms | 1.65 s | 149.6 MiB | 932.8 MiB |
| qiskit | 252 | 10 | 76.3 ms | 1.84 s | 184.7 MiB | 947.3 MiB |
| pennylane | 252 | 10 | 164.0 ms | 3.45 s | 268.9 MiB | 1.02 GiB |
| cirq | 252 | 10 | 212.8 ms | 2.69 s | 228.6 MiB | 1.26 GiB |
| cirq_f64 | 252 | 10 | 548.1 ms | 2.93 s | 229.4 MiB | 2.30 GiB |
| classical | 105 | 1 | 5.1 ms | 1.14 s | 142.9 MiB | 147.6 MiB |
| analytical_angle | 35 | 2 | 14.6 ms | 1.17 s | 157.4 MiB | 338.7 MiB |

**3c. Runtime matrix - median `primary_runtime_s` per task x lane**

| Task | superfermion_optimized | superfermion_wheel | superfermion_source_baseline | qulacs | qiskit | pennylane | cirq | cirq_f64 |
|---|---|---|---|---|---|---|---|---|
| qsvm | 114.8 ms | 129.4 ms | 133.0 ms | 347.5 ms | 148.2 ms | 213.7 ms | 392.5 ms | 720.3 ms |
| qkrr | 152.5 ms | 177.6 ms | 176.5 ms | 1.22 s | 193.1 ms | 304.9 ms | 489.1 ms | 899.7 ms |
| qkpca | 124.4 ms | 150.4 ms | 153.0 ms | 1.93 s | 156.7 ms | 304.6 ms | 527.0 ms | 1.00 s |
| vqc | 159.3 ms | 429.3 ms | 441.7 ms | 9.16 s | 373.0 ms | 2.04 s | 5.04 s | 12.60 s |
| vqr | 145.0 ms | 381.1 ms | 392.4 ms | 8.19 s | 294.9 ms | 1.77 s | 4.46 s | 10.33 s |
| qaoa_fs | 7.2 ms | 27.0 ms | 29.0 ms | 143.8 ms | 91.4 ms | 154.9 ms | 135.8 ms | 229.6 ms |
| maxcut | 4.6 ms | 10.7 ms | 12.5 ms | 69.8 ms | 43.8 ms | 80.6 ms | 66.2 ms | 120.9 ms |
| vqe | 10.1 ms | 15.6 ms | 16.1 ms | 259.3 ms | 45.4 ms | 74.5 ms | 74.4 ms | 127.6 ms |
| gradient | 4.7 ms | 15.3 ms | 15.2 ms | 139.8 ms | 7.8 ms | 39.8 ms | 82.6 ms | 189.1 ms |
| circuit | 0.3 ms | 0.6 ms | 0.6 ms | 1.0 ms | 2.0 ms | 4.4 ms | 5.4 ms | 8.7 ms |

**3d. Condition leaderboard** (fastest lane counted over 252 conditions)

| Fastest lane | Wins (all lanes, incl. f32) | Wins (f64-only) |
|---|---|---|
| superfermion_optimized | 139 | 140 |
| qulacs | 106 | 106 |
| qiskit | 5 | 6 |
| cirq | 2 | 0 |

**3e. Headline comparative stats** (`overview.json`)

| Metric | Value |
|---|---|
| Measured condition groups | 252 / 252 complete |
| superfermion_optimized fastest (all lanes, incl. qsim f32) | 139 / 252 |
| superfermion_optimized fastest (f64-only lanes) | 140 / 252 |
| source_baseline / optimized median paired ratio | 1.829x (min 0.848x, max 152.17x) |
| qulacs / optimized median paired ratio | 1.049x |
| Fresh-process repetitions / split seeds | 1 / [42] |

---

## 4. Benchmarks - memory (RAM)

Primary memory metric: **`worker_peak_rss_mib`** = peak RSS of the fresh worker process (includes interpreter + imports + preparation + statevector work; see `ram_methodology.json`). Secondary: `primary_stage_peak_rss_mib` (peak during the measured compute stage) and `worker_rss_change_mib` (exit - entry). RAM-specific output tables: `ram_by_condition.csv`, `ram_by_framework_task.csv`, `ram_framework_summary.csv`, `ram_per_job.csv`, `ram_paired_comparisons.csv`.

**4a. Per task - peak RSS**

| Task | Jobs | Median peak | P90 peak | Max peak | Median RSS growth |
|---|---|---|---|---|---|
| qsvm | 425 | 246.7 MiB | 947.3 MiB | 2.11 GiB | 22.3 MiB |
| qkrr | 170 | 267.4 MiB | 1.02 GiB | 2.30 GiB | 22.8 MiB |
| qkpca | 200 | 264.0 MiB | 1.02 GiB | 2.10 GiB | 23.3 MiB |
| classical | 105 | 142.9 MiB | 145.3 MiB | 147.6 MiB | 1.1 MiB |
| vqc | 240 | 181.9 MiB | 264.3 MiB | 387.8 MiB | 21.3 MiB |
| vqr | 96 | 186.8 MiB | 267.1 MiB | 351.1 MiB | 21.4 MiB |
| qaoa_fs | 160 | 201.0 MiB | 279.4 MiB | 399.0 MiB | 19.8 MiB |
| maxcut | 160 | 200.7 MiB | 281.9 MiB | 401.7 MiB | 18.7 MiB |
| vqe | 80 | 200.4 MiB | 270.8 MiB | 389.6 MiB | 26.2 MiB |
| gradient | 80 | 220.6 MiB | 554.1 MiB | 1.54 GiB | 27.9 MiB |
| circuit | 440 | 204.1 MiB | 316.5 MiB | 926.9 MiB | 27.2 MiB |

**4b. RAM matrix - median `worker_peak_rss_mib` per task x lane**

| Task | superfermion_optimized | superfermion_wheel | superfermion_source_baseline | qulacs | qiskit | pennylane | cirq | cirq_f64 |
|---|---|---|---|---|---|---|---|---|
| qsvm | 170.3 MiB | 169.2 MiB | 169.4 MiB | 170.1 MiB | 215.5 MiB | 300.5 MiB | 274.6 MiB | 323.1 MiB |
| qkrr | 175.1 MiB | 174.1 MiB | 174.3 MiB | 174.4 MiB | 219.7 MiB | 306.9 MiB | 286.3 MiB | 346.7 MiB |
| qkpca | 170.7 MiB | 170.3 MiB | 169.9 MiB | 171.0 MiB | 216.1 MiB | 301.9 MiB | 282.2 MiB | 334.4 MiB |
| vqc | 146.1 MiB | 145.1 MiB | 145.5 MiB | 147.0 MiB | 185.3 MiB | 264.9 MiB | 224.7 MiB | 224.1 MiB |
| vqr | 146.5 MiB | 145.2 MiB | 145.2 MiB | 146.7 MiB | 187.1 MiB | 266.3 MiB | 225.2 MiB | 224.4 MiB |
| qaoa_fs | 145.7 MiB | 145.1 MiB | 145.4 MiB | 146.2 MiB | 172.6 MiB | 261.8 MiB | 222.8 MiB | 221.6 MiB |
| maxcut | 144.8 MiB | 144.7 MiB | 144.8 MiB | 145.9 MiB | 171.8 MiB | 261.1 MiB | 221.6 MiB | 221.1 MiB |
| vqe | 144.9 MiB | 144.6 MiB | 144.7 MiB | 145.9 MiB | 171.6 MiB | 261.3 MiB | 221.8 MiB | 220.7 MiB |
| gradient | 147.7 MiB | 147.2 MiB | 147.3 MiB | 148.8 MiB | 178.1 MiB | 266.1 MiB | 226.3 MiB | 225.4 MiB |
| circuit | 144.8 MiB | 144.4 MiB | 144.5 MiB | 145.2 MiB | 172.4 MiB | 261.1 MiB | 221.8 MiB | 221.5 MiB |

**4c. Top 12 jobs by peak RSS**

| # | Task | Dataset | Qubits | Framework | Peak RSS | Runtime |
|---|---|---|---|---|---|---|
| 1 | qkrr | diabetes | 16 | cirq_f64 | 2.30 GiB | 5.58 s |
| 2 | qkrr | diabetes | 16 | cirq_f64 | 2.11 GiB | 4.19 s |
| 3 | qsvm | moons | 16 | cirq_f64 | 2.11 GiB | 4.84 s |
| 4 | qkpca | moons | 16 | cirq_f64 | 2.10 GiB | 4.83 s |
| 5 | qkrr | friedman1 | 16 | cirq_f64 | 2.10 GiB | 4.78 s |
| 6 | qkrr | diabetes | 20 | cirq_f64 | 1.97 GiB | 553.56 s |
| 7 | qsvm | moons | 20 | cirq_f64 | 1.97 GiB | 442.06 s |
| 8 | qkrr | friedman1 | 20 | cirq_f64 | 1.97 GiB | 610.63 s |
| 9 | qkpca | moons | 20 | cirq_f64 | 1.97 GiB | 444.37 s |
| 10 | qsvm | wine | 20 | cirq_f64 | 1.97 GiB | 139.19 s |
| 11 | qkpca | wine | 20 | cirq_f64 | 1.97 GiB | 95.98 s |
| 12 | qsvm | iris | 20 | cirq_f64 | 1.97 GiB | 89.79 s |

**4d. State-vector bank scaling** (median `exported_bank_peak_bytes` by qubit count)

| Qubits | Jobs | Median bank | Max bank |
|---|---|---|---|
| 4 | 152 | 0.1 MiB | 0.1 MiB |
| 8 | 152 | 1.6 MiB | 2.2 MiB |
| 12 | 152 | 25.0 MiB | 35.6 MiB |
| 16 | 152 | 360.0 MiB | 442.0 MiB |
| 20 | 152 | 512.0 MiB | 512.0 MiB |

---

## 5. Benchmarks - task quality metrics

Medians over all jobs of each task (mixed qubit sizes / datasets by design).

| Task | Metric | Jobs | Median | Min | Max |
|---|---|---|---|---|---|
| qsvm | accuracy | 425 | 0.7778 | 0.3889 | 1 |
| qsvm | ROC AUC | 255 | 0.9799 | 0.6613 | 1 |
| qkrr | R2 | 170 | 0.01056 | -0.5921 | 0.1662 |
| qkrr | RMSE | 170 | 36.25 | 4.281 | 91.84 |
| qkpca | PCA variance fraction | 200 | 0.1184 | 0.00734 | 0.4147 |
| classical | accuracy | 75 | 0.9625 | 0.9123 | 1 |
| classical | R2 | 30 | 0.4571 | -0.1237 | 0.6279 |
| vqc | accuracy | 240 | 0.4167 | 0.2778 | 0.7368 |
| vqr | R2 | 96 | 0.004448 | -0.01211 | 0.015 |
| vqr | RMSE | 96 | 38.54 | 4.653 | 72.98 |
| qaoa_fs | downstream accuracy | 160 | 0.9327 | 0.3889 | 0.9722 |
| maxcut | approximation ratio | 160 | 0.7285 | 0.4857 | 0.7758 |
| vqe | energy gap | 80 | 12.14 | 0.8658 | 21.74 |
| gradient | max gradient error | 80 | 4.996e-10 | 2.136e-10 | 1.448e-07 |
| circuit | throughput (circuits/s) | 440 | 815.7 | 0.9798 | 1.932e+05 |

---

## 6. Figures produced (107 PNG + 107 SVG)

| Figure | PNG (twin .svg alongside) |
|---|---|
| CIRCUIT · batch_sweep · statevector · angle | `figures/time_ram_circuit_f49322a0b314c884.png` |
| CIRCUIT · batch_sweep · statevector · angle | `figures/time_ram_circuit_0cc1774d8ab82408.png` |
| CIRCUIT · depth_sweep · statevector · random | `figures/time_ram_circuit_3bdca0a71cc15906.png` |
| CIRCUIT · depth_sweep · statevector · random | `figures/time_ram_circuit_b17dae95d49896eb.png` |
| CIRCUIT · synthetic · statevector · angle | `figures/time_ram_circuit_ce247560fc2fd0d2.png` |
| CIRCUIT · synthetic · statevector · ghz | `figures/time_ram_circuit_89df4ec8bb40d6bc.png` |
| CIRCUIT · synthetic · statevector · pauli | `figures/time_ram_circuit_a646abb77668ead8.png` |
| CIRCUIT · synthetic · statevector · phase | `figures/time_ram_circuit_6e80c3f0662ce30d.png` |
| CIRCUIT · synthetic · statevector · qft | `figures/time_ram_circuit_063e1a351815cf40.png` |
| CIRCUIT · synthetic · statevector · random | `figures/time_ram_circuit_bd350b3c13dc9631.png` |
| CIRCUIT · synthetic · statevector · zz | `figures/time_ram_circuit_1577419353b219ec.png` |
| CLASSICAL · breast_cancer · statevector | `figures/time_ram_classical_a442c43c81d3eea8.png` |
| CLASSICAL · breast_cancer · statevector | `figures/time_ram_classical_379ec647e993d049.png` |
| CLASSICAL · breast_cancer · statevector | `figures/time_ram_classical_f44240995ee0f68e.png` |
| CLASSICAL · diabetes · statevector | `figures/time_ram_classical_30c12cf0f85270d9.png` |
| CLASSICAL · diabetes · statevector | `figures/time_ram_classical_0647c46210c75a3e.png` |
| CLASSICAL · diabetes · statevector | `figures/time_ram_classical_d397495fe07bf6ca.png` |
| CLASSICAL · digits_01 · statevector | `figures/time_ram_classical_66567da6640c557a.png` |
| CLASSICAL · digits_01 · statevector | `figures/time_ram_classical_aba3e68623c60d70.png` |
| CLASSICAL · digits_01 · statevector | `figures/time_ram_classical_d62e25f8f07be7d1.png` |
| CLASSICAL · friedman1 · statevector | `figures/time_ram_classical_8cdf0d5a65934fdb.png` |
| CLASSICAL · friedman1 · statevector | `figures/time_ram_classical_e2aed9036c418eb0.png` |
| CLASSICAL · friedman1 · statevector | `figures/time_ram_classical_b099f3c537435556.png` |
| CLASSICAL · iris · statevector | `figures/time_ram_classical_19aff528e664a030.png` |
| CLASSICAL · iris · statevector | `figures/time_ram_classical_af736c60a070a922.png` |
| CLASSICAL · iris · statevector | `figures/time_ram_classical_e3745e27821004b0.png` |
| CLASSICAL · moons · statevector | `figures/time_ram_classical_75866a1579b9bbfe.png` |
| CLASSICAL · moons · statevector | `figures/time_ram_classical_11ac0b6c00486ce5.png` |
| CLASSICAL · moons · statevector | `figures/time_ram_classical_5ac36b9967cdf0d8.png` |
| CLASSICAL · wine · statevector | `figures/time_ram_classical_a25d7050e4b0c9a4.png` |
| CLASSICAL · wine · statevector | `figures/time_ram_classical_ffd4baf9c3a6fc1f.png` |
| CLASSICAL · wine · statevector | `figures/time_ram_classical_38db28936b089073.png` |
| GRADIENT · synthetic · native_readout | `figures/time_ram_gradient_130fce879aa9a3e4.png` |
| GRADIENT · synthetic · statevector | `figures/time_ram_gradient_9bbf1651cbee4679.png` |
| MAXCUT · erdos_renyi · native_readout | `figures/time_ram_maxcut_3a150dff18921335.png` |
| MAXCUT · erdos_renyi · statevector | `figures/time_ram_maxcut_9c4e343593b3d0cd.png` |
| MAXCUT · ring · native_readout | `figures/time_ram_maxcut_b8c34c3724e00713.png` |
| MAXCUT · ring · statevector | `figures/time_ram_maxcut_f7a3d153d6bb36d4.png` |
| QAOA_FS · breast_cancer · native_readout | `figures/time_ram_qaoa_fs_5c56b217100922c3.png` |
| QAOA_FS · breast_cancer · statevector | `figures/time_ram_qaoa_fs_35866e4c7f7b039a.png` |
| QAOA_FS · wine · native_readout | `figures/time_ram_qaoa_fs_9d2488fbbabbe407.png` |
| QAOA_FS · wine · statevector | `figures/time_ram_qaoa_fs_fa3014c768ab9b2e.png` |
| QKPCA · breast_cancer · statevector · zz map | `figures/time_ram_qkpca_683e1ae1d64eb100.png` |
| QKPCA · digits_01 · statevector · zz map | `figures/time_ram_qkpca_dd81c45f831fda93.png` |
| QKPCA · iris · statevector · zz map | `figures/time_ram_qkpca_29b3f5c95a4e2834.png` |
| QKPCA · moons · statevector · zz map | `figures/time_ram_qkpca_0c1e59afe92fe3e0.png` |
| QKPCA · wine · statevector · zz map | `figures/time_ram_qkpca_598e9ea71b29b184.png` |
| QKRR · diabetes · analytical · angle map | `figures/time_ram_qkrr_bc79b61daeaaeff0.png` |
| QKRR · diabetes · statevector · angle map | `figures/time_ram_qkrr_eb5416e27ede3460.png` |
| QKRR · diabetes · statevector · zz map | `figures/time_ram_qkrr_1db4732108fa7f08.png` |
| QKRR · friedman1 · analytical · angle map | `figures/time_ram_qkrr_413de7bd5dc34d9f.png` |
| QKRR · friedman1 · statevector · angle map | `figures/time_ram_qkrr_5d280c3b992d67d0.png` |
| QKRR · friedman1 · statevector · zz map | `figures/time_ram_qkrr_f5a542019e9b6cca.png` |
| QSVM · breast_cancer · analytical · angle map | `figures/time_ram_qsvm_6624a0817b121734.png` |
| QSVM · breast_cancer · statevector · angle map | `figures/time_ram_qsvm_176ada84c06f8510.png` |
| QSVM · breast_cancer · statevector · zz map | `figures/time_ram_qsvm_25deb623ba954693.png` |
| QSVM · digits_01 · analytical · angle map | `figures/time_ram_qsvm_9425830667c3aac6.png` |
| QSVM · digits_01 · statevector · angle map | `figures/time_ram_qsvm_6436af62f7e62207.png` |
| QSVM · digits_01 · statevector · zz map | `figures/time_ram_qsvm_5acb2f59707079d1.png` |
| QSVM · iris · analytical · angle map | `figures/time_ram_qsvm_c86e6b5f7b3d501c.png` |
| QSVM · iris · statevector · angle map | `figures/time_ram_qsvm_23f9c0cb2b8f19af.png` |
| QSVM · iris · statevector · zz map | `figures/time_ram_qsvm_c97d189a4fd77646.png` |
| QSVM · moons · analytical · angle map | `figures/time_ram_qsvm_77d03e2d1d25e0d4.png` |
| QSVM · moons · statevector · angle map | `figures/time_ram_qsvm_e8cbbdfc62b8f9e9.png` |
| QSVM · moons · statevector · zz map | `figures/time_ram_qsvm_52e30a772be3984f.png` |
| QSVM · wine · analytical · angle map | `figures/time_ram_qsvm_37db00e2c51fc1c5.png` |
| QSVM · wine · statevector · angle map | `figures/time_ram_qsvm_cc836dcae3c867f6.png` |
| QSVM · wine · statevector · zz map | `figures/time_ram_qsvm_08983ca694fdebfb.png` |
| VQC · breast_cancer · native_readout | `figures/time_ram_vqc_6bdea4644cb86682.png` |
| VQC · breast_cancer · statevector | `figures/time_ram_vqc_4f3abfdc977714da.png` |
| VQC · digits_01 · native_readout | `figures/time_ram_vqc_73fde162a96fdfc5.png` |
| VQC · digits_01 · statevector | `figures/time_ram_vqc_495e6ee89a0de152.png` |
| VQC · iris · native_readout | `figures/time_ram_vqc_6f47fa90e2dfc99c.png` |
| VQC · iris · statevector | `figures/time_ram_vqc_178eb5a0857b9dfa.png` |
| VQC · moons · native_readout | `figures/time_ram_vqc_2e8cd1da44be6e25.png` |
| VQC · moons · statevector | `figures/time_ram_vqc_23ad6cee8e55c173.png` |
| VQC · wine · native_readout | `figures/time_ram_vqc_b9c54e08fd5cbd7d.png` |
| VQC · wine · statevector | `figures/time_ram_vqc_5ff9b0d0c394f93d.png` |
| VQE · TFIM_open_chain · native_readout | `figures/time_ram_vqe_cd7656d6f4689fa9.png` |
| VQE · TFIM_open_chain · statevector | `figures/time_ram_vqe_ebde7a974a595def.png` |
| VQR · diabetes · native_readout | `figures/time_ram_vqr_1efe954c50e1cc04.png` |
| VQR · diabetes · statevector | `figures/time_ram_vqr_56a7c6e9106a991a.png` |
| VQR · friedman1 · native_readout | `figures/time_ram_vqr_9c1f39aabd3cc164.png` |
| VQR · friedman1 · statevector | `figures/time_ram_vqr_4ee4939c221fc455.png` |
| overview figure: batch_per_circuit | `figures/batch_per_circuit.png` |
| overview figure: batch_runtime | `figures/batch_runtime.png` |
| overview figure: circuit_scaling | `figures/circuit_scaling.png` |
| overview figure: classification_quality | `figures/classification_quality.png` |
| overview figure: depth_scaling | `figures/depth_scaling.png` |
| overview figure: feature_maps_latency | `figures/feature_maps_latency.png` |
| overview figure: gradient_latency | `figures/gradient_latency.png` |
| overview figure: maxcut_latency | `figures/maxcut_latency.png` |
| overview figure: optimization_traces | `figures/optimization_traces.png` |
| overview figure: paired_speedup_distribution | `figures/paired_speedup_distribution.png` |
| overview figure: process_memory | `figures/process_memory.png` |
| overview figure: qaoa_fs_latency | `figures/qaoa_fs_latency.png` |
| overview figure: qkpca_latency | `figures/qkpca_latency.png` |
| overview figure: qkrr_latency | `figures/qkrr_latency.png` |
| overview figure: qsvm_latency | `figures/qsvm_latency.png` |
| overview figure: ram_framework_overview | `figures/ram_framework_overview.png` |
| overview figure: ram_task_native_readout | `figures/ram_task_native_readout.png` |
| overview figure: ram_task_statevector | `figures/ram_task_statevector.png` |
| overview figure: readout_sensitivity | `figures/readout_sensitivity.png` |
| overview figure: regression_quality | `figures/regression_quality.png` |
| overview figure: vqc_latency | `figures/vqc_latency.png` |
| overview figure: vqe_latency | `figures/vqe_latency.png` |
| overview figure: vqr_latency | `figures/vqr_latency.png` |

Total: 84 per-condition scaling figures + 23 overview figures = 107 PNG files (plus the matching SVG twins) in `figures/`.

---

## 7. Notes & limitations

- CPU ideal statevector experiments only; no GPU, noise or hardware results
- Runtime IQR is descriptive; validation profile is not a publication-quality statistical study
- Small held-out splits and short optimizer budgets do not establish quantum ML advantage
- Process memory includes imports/preparation/warmup, not statevector-only memory
- The 20q band carries the designed strict 1200 s timeout; exactly one timeout ever occurred (qkpca/breast_cancer/pennylane/20q) and it succeeded on the automatic retry (1127 s).

_End of report. Regenerate with:_ `& D:\sf_runs\vqc_v8\venv\Scripts\python.exe "c:\Users\Pasa Moda\OneDrive\Desktop\Test Bench\_agent_notes\make_outputs_report.py"`
