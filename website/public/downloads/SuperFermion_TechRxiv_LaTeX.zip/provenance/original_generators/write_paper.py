"""Build the SuperFermion manuscript from audited saved measurements."""
from pathlib import Path
import argparse,json,csv
from copy import deepcopy

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--package-dir",type=Path,default=Path(__file__).resolve().parents[1])
p=parser.parse_args().package_dir.resolve();data=p/"data"
audit=json.loads((data/"analysis_checks.json").read_text())
figures={b["label"]:b for b in json.loads((data/"figure_manifest.json").read_text())}
tables={b["label"]:b for b in json.loads((data/"static_tables.json").read_text())}
eqs={b["label"]:b for b in json.loads((data/"equations.json").read_text())}
mt={b["label"]:b for b in json.loads((data/"mps_detailed_tables.json").read_text())}
summary=list(csv.DictReader((data/"framework_summary.csv").open()))
mrows=list(csv.DictReader((data/"mps_selected_records.csv").open()))
blocks=[]
def H(text,level=2):blocks.append(dict(type="heading",text=text,level=level))
def P(text):blocks.append(dict(type="paragraph",text=text))
def E(label):blocks.append(deepcopy(eqs[label]))
def F(label):blocks.append(deepcopy(figures[label]))
def B():blocks.append(dict(type="pagebreak"))
def T(label,title,cols,rows,note,widths=None):
 blocks.append(dict(type="table",label=label,title=title,columns=cols,rows=rows,note=note,widths=widths))
def S(label):blocks.append(deepcopy(tables[label]))
def M(label):blocks.append(deepcopy(mt[label]))

H("Introduction",1)
H("Motivation and research questions")
P("Classical simulation supports quantum algorithm development by making circuit behavior, numerical error and execution cost inspectable. Quantum kernels, variational learning and approximate optimization repeatedly evaluate related circuits, so lower execution cost can make broader experiments practical. This study evaluates SuperFermion as a quantum simulation framework across quantum machine learning, objective evaluation, circuit sweeps, matrix product states and dynamic circuits. Its contribution is an assessment of software execution efficiency under recorded conditions.")
P("Quantum feature maps represent observations as states whose overlaps define a kernel for a classical estimator. Variational methods instead adjust circuit parameters using an objective built from observable expectations. These alternatives impose different demands on simulation and readout {{cite:schuld_feature,havlicek,peruzzo,pennylane}}. Returning a complete statevector and returning a scalar observable therefore require separate analysis, even when the logical circuit is the same.")
P("The study asks how SuperFermion compares with external frameworks on matching workloads, how computation and process memory change with qubit count and output contract, and how bounded-bond simulation extends the tested circuit sizes. The six statevector configurations are SuperFermion, Qulacs, Qiskit, PennyLane, Cirq f32 and Cirq f64. The MPS suite uses SuperFermion, Qiskit Aer, PennyLane, Cirq with quimb, and Qulacs as an explicitly not-offered adapter path.")
P("The statevector analysis includes 1,512 simulator records on 252 identical conditions per configuration, plus 105 classical controls and 35 analytical controls. The replacement MPS archive contributes 182 selected unique jobs, of which 141 complete successfully. Together, the experiments describe measured behavior across exact-state outputs, native readout, truncation diagnostics and measurement-driven execution. Cases where another framework is faster, uses less recorded memory or has lower truncation error remain part of the comparison.")
H("Related work and contribution")
P("Qulacs targets efficient quantum circuit simulation, while Qiskit Aer, PennyLane, Cirq and qsim provide distinct simulation and programming interfaces {{cite:qulacs_paper,aer,pennylane,cirq,qsim}}. Kernel and variational studies motivate evaluation beyond simple gate throughput because end-to-end tasks can also depend on readout, repeated state construction and dense matrix operations. The present comparison describes the configured adapters in the supplied studies rather than every execution path available in those frameworks.")
P("Matrix product states represent a state through tensors linked by bounded auxiliary dimensions. Their favorable storage depends on the circuit's entanglement structure; increasing the maximum bond can increase both accuracy and cost {{cite:vidal2003,schollwoeck2011}}. Large-qubit results must consequently be read together with the measured circuits, bond limits, diagnostics and requested outputs.")
P("The contribution is a source-traceable evaluation of SuperFermion across a broad workload grid. Separate experiment-and-qubit tables preserve feature maps and output contracts, while matched scatter plots and all five framework heatmaps expose both advantages and counterexamples. The paper contains 104 tables and 36 figures. No simulator measurements were generated during this manuscript revision.")

H("Materials and methods",1)
H("Quantum representations and output contracts")
P("For a feature map U, a classical observation x determines a state and a fidelity kernel:")
E("kernel")
P("Kernel classification and regression use these overlaps in a classical estimator. Quantum kernel principal component analysis uses a kernel representation for dimensionality analysis. Reported primary runtimes can include more than state preparation, and the saved summaries do not isolate every matrix operation or estimator step. Variational classification, regression and objective evaluation instead use expectation values of an observable O:")
E("expectation")
P("The statevector track exports a complete state and carries out its associated readout. The native-readout track requests an observable through the framework's native interface. These routes have different materialized outputs and can use different execution primitives. Condition keys retain the track so that a scalar-output observation is not silently pooled with a state-export observation.")
H("SuperFermion execution design")
P("SuperFermion exposes circuit construction, a native intermediate representation and state or observable execution. The design considered here prepares reusable execution structure and offers statevector and native-readout routes, with batching where the study requests it {{cite:superfermion}}. Figure {{fig:execution_path}} describes that organization. The records do not provide a component-level ablation, so they cannot assign a measured improvement to a particular kernel, cache or dispatch change.")
F("execution_path")
P("A native implementation can reduce repeated dispatch, avoid unnecessary state export and retain prepared work across related evaluations. These are useful engineering mechanisms, but their individual effects must be established through controlled profiling. The recorded task costs are the evidence for this paper; the schematic is not a measurement of each mechanism.")
H("Evidence and workload selection")
P("The statevector evidence comes from a completed campaign overview and its job-by-job report {{cite:campaign,jobs}}. The included six configurations share exactly the same 252 condition keys. Every included statevector job is recorded as successful. The comparison subset contains 1,652 rows when its 140 controls are included. The earlier incomplete report is retained as source evidence but does not contribute to these estimates.")
P("The classification datasets are breast_cancer, iris, wine, digits_01 and moons; regression uses diabetes and friedman1. Feature selection uses breast_cancer and wine. MaxCut covers ring and Erdos-Renyi graph families, VQE uses an open-chain transverse-field Ising objective, and gradient and circuit tasks use synthetic inputs. The final reports specify a full 80/20 held-out split and seed 42. Complete sample cardinalities, preprocessing transformations and leakage audits are not independently available from the displayed records, so no additional dataset sizes are assumed.")
T("protocol","Selected statevector study protocol",["Item","Recorded setting or evidence boundary"],[
 ["Comparison set","Six configurations; 252 identical conditions per configuration"],
 ["Qubit grid","4, 8, 12, 16 and 20; VQC/VQR limited to 4, 8 and 12"],
 ["Learning split","Full 80/20 held-out split; seed 42"],["Training budget","VQC/VQR: five updates"],
 ["Repeated measurements","One fresh-process repetition per condition"],["Job timeout","1,200 s"],
 ["State-bank cap","512 MiB exported-bank limit; not a total process-RSS cap"],
 ["Selected coverage","1,512 simulator jobs plus 105 classical and 35 analytical controls"],
 ["Implementation metadata","Full package lock, pinned source patch and detailed adapter settings unavailable"],
 ["Learning metadata","Row-level predictive outcomes and complete preprocessing audit unavailable"]],
 "These are reported study settings. Descriptive comparisons retain the supplied output contracts and precision differences.",[1.6,4.9])
S("workloads")
P("Cirq f32 is the lower-precision configuration identified by the overview, while Cirq f64 is retained as a separate comparator. Detailed simulator flags and fusion settings are not independently exposed in the final statevector reports. The five external entries therefore describe the study's configured execution paths. Analytical-angle and classical estimators remain controls rather than general simulator competitors.")
H("Timing memory and reconstruction")
P("Statevector time is the reported primary compute stage, converted to seconds for analysis. It differs from process wall time, which also includes work outside that stage. Worker peak RSS measures the entire fresh process, including interpreter, imports, preparation and simulation. Lower process memory may therefore reflect a lighter execution environment as well as numerical allocation.")
P("Each record is keyed by framework, task, dataset, variant, map, output track, qubits, batch and depth. The reconstruction verifies uniqueness and the equality of the six 252-condition sets. Milliseconds are converted to seconds and GiB to MiB using a factor of 1,024. Original display strings and source line numbers remain in the analysis CSV. Matched time and memory comparisons use:")
E("ratios")
P("The SF subscript denotes SuperFermion. A time ratio above one favors SuperFermion, and a positive memory saving means its process peak is smaller. A median of condition-level ratios describes the typical retained pair; a ratio of compute sums describes the aggregate cost of a specified grid and gives more weight to expensive conditions. The main heatmaps use the latter definition.")
P("Displayed zero latencies are censored at report precision and are never treated as zero computational work. They are omitted from logarithmic time scatters and from positive-pair medians. Display-rounding intervals are reconstructed separately. A condition has a precision-separated leader only when one upper rounding bound is below every other configuration's lower bound. The 35 unresolved conditions are not assigned a winner. These bounds concern display rounding and are not statistical confidence intervals.")
P("Detailed tables summarize each experiment at each measured qubit count. Feature maps and output tracks stay separate. Dataset or circuit medians are cohort summaries, not repeated-run estimates. VQE and gradient tracks with one condition retain the individual observation. QKPCA and circuit tables also show maxima so that a cohort median does not conceal the expensive cases.")
H("Matrix product state and measurement protocol")
P("All MPS and mid-circuit results in this revision come from the replacement archive {{cite:mpsbundle}}. Its append-only JSONL contains 282 rows, which reduce to 264 unique jobs under the supplied reducer key. Selecting the five included configurations yields 182 unique jobs. Their final statuses, numeric values and trial medians agree with the supplied CSV. No observations from the earlier MPS archive enter the current estimates, tables or figures.")
P("The MPS state representation and bounded-bond storage are:")
E("mps_state")
P("Here chi is the maximum auxiliary bond dimension. This storage expression is useful for circuits whose required bonds remain bounded; it does not establish efficient simulation of arbitrary states. The ordinary MPS ladder and stress paths use one untimed warm call followed by three timed calls and retain their median. The saved adapter source constructs circuit or intermediate representation before those timers, but execution and observable handling remain adapter-specific.")
T("mps_protocol","MPS and dynamic circuit measurement protocol",["Item","Recorded setting or limitation"],[
 ["Included records","182 unique jobs; 141 OK, 12 budget, three error and 26 not offered"],
 ["Circuit families","GHZ, brick4, brick12, QFT, teleportation, measurement-based wire and repetition code"],
 ["Structured size grid","50 to 1,000 qubits at maximum bond 64; stress at 200, 500 and 1,000"],
 ["Accuracy anchors","GHZ/brick4 at 12 and 16; TVD at 16; bond sweeps from 2 to 128"],
 ["Ordinary timing","One warm call and three timed calls; median recorded"],
 ["Validation paths","Dense reference and TVD may use single-pass or extraction work; eight successful rows have no time"],
 ["Teleportation","12 qubits: 500 shots; 24-qubit boundary: 500 shots and a common 90 s budget"],
 ["Other dynamic cases","17-qubit wire: 200 shots; repetition code: four patterns with 200 shots per pattern"],
 ["Native MPS teleportation","100 shots at 12; 1,000 at 30, 60 and 120 qubits"],
 ["Memory metric","Process RSS snapshot/high-water value in MiB, potentially including sampling and earlier chunk work"],
 ["Sampling","Separate sample-time field; excluded from primary MPS compute time"],
 ["Failure treatment","Budget, error, not-offered and absent-job outcomes remain distinct"]],
 "MPS and statevector time totals are not pooled. Dynamic paths use a single timed replay per recorded condition.",[1.55,4.95])
T("mps_software","Recorded MPS software versions and execution paths",["Framework","Version","Recorded path"],[
 ["SuperFermion","0.1.15","Native MPS state and dynamic measurement interfaces"],["Qiskit Aer","0.17.2","matrix_product_state plus conditional execution"],
 ["PennyLane","0.45.0","default.tensor for MPS; default.qubit trajectories for MCM"],["Cirq quimb","Cirq 1.6.1 / quimb 1.13.0","MPS simulator; separate trajectory measurement path"],
 ["Qulacs","0.6.14","No offered MPS/feed-forward path in this adapter"]],
 "The probe and row identifiers remain in the source archive. The 40 completed SuperFermion rows include 38 with compiled identifier 99304153f6... and two refreshed 12-qubit teleportation/repetition-code rows with f576d0eb7a.... The timeout row lacks an identifier. The records do not establish a single-revision implementation effect.",[1.35,1.5,3.65])
P("Sampling is measured separately and may occur before the RSS snapshot. Ordinary MPS time therefore excludes sampling, while the associated process peak can include it. Chunks can contain multiple jobs, so a peak may also include earlier work in that process. The field suffix mb is misleading: the recorder divides bytes by 2 to the power 20, making both memory fields MiB. These observations do not isolate incremental tensor allocation.")
P("Dynamic correctness checks use deterministic target outputs. Teleportation starts from the specified one-bit input, the measurement-based wire checks its final target, and the repetition-code worker tests no error and one bit flip on each of three data bits. The repetition-code wall covers all four constructions and replays, with 200 shots per pattern and 800 in total. Other dynamic walls cover the single specified replay. Matching shots within a case does not make different circuit cases equivalent workloads.")
P("Accuracy is assessed using the Z0 Zlast correlation, dense-versus-MPS small-circuit anchors, and total variation distance at 16 qubits:")
E("tvd")
P("Discarded weight and the reported fidelity lower bound are engine diagnostics at larger sizes. Their definitions and aggregation policies vary across engines. A matching correlation or a favorable diagnostic does not independently certify equality of complete states or output distributions. Fixed maximum bond is not a matched-accuracy constraint.")
H("Correctness and controls")
P("The statevector overview reports a completed correctness gate, backend checks and gradient tests, including a median per-job maximum gradient error of 4.996e-10 and a largest reported value of 1.448e-7 {{cite:campaign}}. Detailed correctness files are not supplied, so those statements remain attributed summaries. Successful job status alone does not replace a numerical correctness audit.")
P("The analytical-angle control evaluates a separable RY-map kernel directly:")
E("angle")
P("Its O(n) arithmetic per data pair can avoid state simulation when the specified map has that structure, although constructing a dense Gram matrix remains quadratic in sample count. It is not applicable to every entangling map or variational circuit. Classical controls include RBF SVC, logistic regression, random-forest classification, ridge regression, RBF kernel ridge regression and random-forest regression. Their nominal qubit label only indexes a paired study setting.")

H("Results",1)
H("Overall computation and process memory")
P("SuperFermion has the lowest reconstructed successful primary-compute total among the six included configurations: 27.36 min over the common 252 conditions. Qiskit totals 34.30 min, Qulacs 70.04 min, Cirq f32 72.38 min, PennyLane 132.99 min and Cirq f64 138.52 min. The Qiskit-to-SuperFermion total ratio is approximately 1.254. These totals summarize the selected workload grid and omit startup, imports, retries and discarded attempts.")
overall=[]
for r in summary:
 ratio="-" if r["framework"]=="superfermion_optimized" else f'{float(r["median_positive_paired_time_ratio"]):.3f} ({r["positive_time_pairs"]})'
 overall.append([r["name"],f'{float(r["median_compute_ms"]):.2f}',f'{float(r["compute_sum_min"]):.2f}',ratio,f'{float(r["median_peak_rss_mib"]):.2f}',"-" if r["framework"]=="superfermion_optimized" else f'{float(r["paired_ram_saving_pct"]):.2f}'])
T("overall","Reconstructed performance on 252 matched conditions per configuration",["Framework","Compute\nmedian (ms)","Compute\ntotal (min)","Median pair\nratio (n)","RAM median\n(MiB)","Paired RAM\nsaving (%)"],overall,
 "Pair ratios compare positive displayed times with SuperFermion; n is the retained pair count. Totals weight expensive conditions more strongly than paired medians. Memory is whole-worker peak RSS; negative saving means SuperFermion's peak is higher. No repeated-run confidence intervals are available.",[1.15,.95,1.05,1.2,1.0,1.15])
F("overall_compute_ram")
P("The typical positive paired Qulacs time ratio is 1.083 across 238 retained pairs, whereas its ratio of compute totals is approximately 2.560. These quantities answer different questions. Omitting displayed-zero pairs also changes the median's population, so it is not substituted for an unrounded full-cohort statistic. The overview's 1.42 s median SuperFermion process wall is much larger than its 29.7 ms primary-compute median, indicating that the measured stage does not describe the full cost of every fresh invocation.")
P("At display precision, 217 conditions have a leader separated from all other configurations' rounding intervals. SuperFermion leads 131, Qulacs 80, Qiskit four and Cirq f32 two; 35 conditions remain unresolved. This rule is deliberately based on the available rounded records. Precision separation does not establish statistical significance or repeated-run stability.")
P("Median SuperFermion worker peak is 150.60 MiB, compared with 149.55 MiB for Qulacs, 184.70 MiB for Qiskit, 268.95 MiB for PennyLane, 228.60 MiB for Cirq f32 and 229.35 MiB for Cirq f64. Median condition-paired SuperFermion RAM savings are 16.56%, 44.15%, 34.63% and 34.68% against the latter four configurations. Against Qulacs the median saving is negative, approximately -0.37%. The small native-framework difference supplies no evidence for a universal lower-memory claim.")
H("Framework comparisons by task and qubit count")
P("All five framework heatmaps appear in this main results section. Each cell divides the comparator's compute-time sum by SuperFermion's sum over the same task and qubit cohort. Values above one favor SuperFermion; values below one favor the comparator. The common logarithmic color range is 0.5 to 512, and every planned value lies inside it. Of the 250 cells, 230 are planned and 20 remain explicitly unplanned because VQC/VQR stop at 12 qubits.")
F("heatmap_qulacs")
P("Qulacs has lower QSVM totals at 4, 8 and 16 qubits, with ratios of approximately 0.851, 0.844 and 0.937. Its 12-qubit QSVM total is about 29 times the SuperFermion total, and a marked 12-qubit increase also appears in several other configured tasks. This pattern identifies an adapter/configuration question for controlled profiling. The records alone do not identify the execution primitive responsible {{cite:qulacs_docs}}.")
F("heatmap_qiskit")
P("Qiskit is competitive in the larger kernel cohorts. At 16 qubits its QSVM, QKRR and QKPCA total ratios are approximately 0.981, 0.988 and 0.926, respectively; its gradient total ratio is about 0.862. The Qiskit heatmap nevertheless shows larger totals for many smaller objective and circuit cohorts. The outcome depends on both task and size, rather than a single framework-wide ordering.")
F("heatmap_pennylane")
P("Every planned PennyLane task/qubit compute-sum cell is above one in this selected grid, with ratios ranging approximately from 1.35 to 48.8. This describes the saved adapter and output contracts. It does not compare every differentiable execution or gradient path that PennyLane provides, and it does not imply a difference in predictive quality.")
F("heatmap_cirq")
P("The Cirq f32 heatmap is explicitly a mixed-precision comparison. SuperFermion has lower totals in most displayed cells, while the 20-qubit VQE cohort is close to parity and slightly favors Cirq f32 at a ratio of approximately 0.995. A close one-run difference is not interpreted as a stable advantage.")
F("heatmap_cirq_f64")
P("The separate Cirq f64 view preserves its higher-precision configuration. All planned compute-sum ratios are above one in the saved grid, ranging approximately from 1.71 to 109. The full matched-condition distributions remain available in Appendix D, where statevector and native-readout markers also expose differences concealed by task totals.")
H("Quantum kernels and mathematical structure")
P("Kernel costs grow sharply in several larger cohorts, making state export, retained banks and Gram-matrix work consequential. For the 20-qubit breast-cancer ZZ QSVM condition, SuperFermion takes 186.5 s, compared with 218.3 s for Qulacs and 238.5 s for Qiskit. PennyLane takes 996.0 s, Cirq f32 339.1 s and Cirq f64 911.7 s. These are matched task observations rather than a predictive-accuracy ranking.")
P("The separable angle control changes the computational problem. For breast cancer at 20 qubits it takes 64.2 ms, compared with 212.6 s for SuperFermion and 218.2 s for Qulacs. At four qubits, however, the control's 5.6 ms observation is slower than SuperFermion's 4.9 ms. Figure {{fig:analytical_angle_control}} therefore records both the larger-scale benefit of verified structure and the importance of fixed overhead at small sizes.")
F("analytical_angle_control")
P("An execution system can use such an identity only after verifying that the requested feature map is separable. General ZZ and variational circuits still require the appropriate state or observable route. The control remains outside simulator rankings because its scope is a specific closed-form kernel.")
H("Variational learning and objective evaluation")
P("VQC and VQR contain five updates at 4, 8 and 12 qubits. On breast cancer at 12 qubits, SuperFermion VQC records 588.7 ms for native readout and 804.5 ms for statevector output, with worker peaks of 148.3 and 204.8 MiB. On diabetes at the same size, VQR records 442.7 ms with 146.9 MiB for native readout and 586.3 ms with 191.1 MiB for statevector output. The limited update budget supports execution comparisons but does not establish convergence or competitive learning quality.")
P("QAOA feature selection and MaxCut retain five measured qubit sizes and both output tracks. Their objective-evaluation costs provide useful examples of avoiding unnecessary state export {{cite:farhi}}. Table {{tab:native_cases}} also retains VQE and gradient counterexamples: at 20 qubits SuperFermion VQE native readout takes 0.944 s, while Qiskit takes 0.5401 s and Cirq f32 0.2972 s. The corresponding gradient takes 0.8974 s for SuperFermion and 0.8688 s for Cirq f32.")
S("native_cases")
P("Circuit tests include angle, GHZ, Pauli, phase, QFT, random and ZZ families, together with batch and depth sweeps. The 20-qubit QFT condition at batch one and depth two takes 118.7 ms for SuperFermion, 83.7 ms for Qulacs, 77.8 ms for Qiskit and 82.3 ms for Cirq f32. This counterexample motivates circuit-specific profiling rather than treating prepared execution as a uniform gain. The qubit tables and scaling figures in Appendix A preserve each workload's relevant output contract.")
H("Memory scaling and task quality")
E("memory")
P("For complex128 storage, one dense state at 20 qubits occupies 16 MiB and one at 24 qubits would occupy 256 MiB. The latter is a storage calculation, not a completed 24-qubit learning result. Retaining B states multiplies that allocation before accounting for estimator workspaces, buffers and interpreter state. The reported exported-bank medians are 0.1, 1.6, 25.0, 360.0 and 512.0 MiB over 4 to 20 qubits.")
F("statebank_and_worker_memory")
P("The 512 MiB exported-bank cap constrains a materialized output bank; it does not constrain total process memory. SuperFermion's maximum recorded worker peak is 936.4 MiB, while Cirq f64 reaches 2,355.2 MiB on a 16-qubit diabetes QKRR condition. Process allocation can vary with execution strategy, retained objects and workload. Lower process peaks do not imply a reduction in the exponential storage complexity of arbitrary dense states.")
S("quality")
P("Task quality is separate from execution cost. The overview's heterogeneous QSVM and classical-classification summaries are not paired learning-accuracy estimates. Its low VQC accuracy and near-zero VQR R2 under five updates do not support a convergence claim. Row-level predictive outputs are unavailable for recalculation over the six included configurations, so the attributed summaries are contextual evidence rather than a revised quality leaderboard.")
H("Matrix product state coverage and scaling")
status_rows=[]
for name,x in audit["mps_lane_outcomes"].items():status_rows.append([name,str(x.get("ok",0)),str(x.get("over_budget",0)),str(x.get("error",0)),str(x.get("not_offered",0)),str(sum(x.values()))])
T("mps_status","Replacement MPS study outcomes by included configuration",["Framework","OK","Budget","Error","Not offered","Total"],status_rows,
 "Outcomes are deduplicated by recorded job key. A budget outcome has no assigned runtime. Not offered describes the recorded adapter path, not general framework impossibility.",[1.65,.65,.85,.65,1.25,1.45])
F("mps_job_status")
P("The selected MPS grid contains 141 successful observations, 12 budget outcomes, three errors and 26 not-offered entries. SuperFermion and Aer each complete 40 of 41 recorded jobs. PennyLane completes 31 of 36, while Cirq quimb completes 30 of 38 with three QFT construction errors. Qulacs has 26 not-offered rows. These differing interfaces and grids prevent success counts from functioning as a speed ranking.")
P("At maximum bond 64, SuperFermion completes the 1,000-qubit GHZ case in 0.012040 s and the four-layer brick case in 0.020053 s. Aer records 0.031483 s and 0.288328 s for those same cases. The structured circuit and requested correlation matter to interpretation: these results extend the measured low-entanglement workloads, rather than demonstrating efficient general dense-state simulation at that size.")
P("For the twelve-layer brick stress case, SuperFermion records 0.455114, 1.140850 and 2.359950 s at 200, 500 and 1,000 qubits. Aer records 0.813775, 1.705730 and 2.879600 s. At 1,000 qubits the recorded correlation differs by approximately 1.1e-12. Memory supplies a counterexample: SuperFermion's recorded process peak is 473.8 MiB, versus 296.7 MiB for Aer. This prevents interpreting the faster recorded replay as a simultaneous lower-memory result.")
H("Truncation diagnostics and QFT boundaries")
P("At 16 qubits and maximum bond two, SuperFermion TVD is approximately 0.09054 while Aer reaches 0.04076. At bond four and above their reported TVDs are approximately 8.0e-16 and 4.9e-11. SuperFermion therefore has a larger error at the tightest recorded bond. At 200 qubits, its reported discarded-weight sequence is non-monotonic: 0.2418, 0.9330 and 0.5001 at bonds 8, 16 and 32, followed by approximately 6.65e-14 at bond 64. These diagnostics warrant numerical-policy investigation and are not global fidelity certificates.")
P("At 200 qubits, the saved QFT path takes 0.586371 s for SuperFermion and 2.081645 s for Aer. PennyLane completes its 20-qubit QFT but exceeds the recorded 50-qubit budget. Cirq quimb succeeds at eight qubits and has three construction-error jobs at 20, 30 and 50 qubits. The errors concern the pinned construction and dependencies; they do not establish a general size limit for Cirq. Matching one correlation also does not validate every QFT output amplitude.")
P("The eight successful dense-reference rows without recorded time remain N/A in time tables. Cirq's largest dense-versus-MPS correlation difference is approximately 6.0e-8, while the SuperFermion, Aer and PennyLane differences are below 4.1e-12. The precision and extraction paths are not uniform. Sixteen-qubit TVD rows include dense-reference/extraction work for SuperFermion and Aer, while the other paths have different validation contracts, so their times are not ranked as equivalent outputs.")
H("Measurement feed forward and execution limits")
mainm=[]
for case,n,title in [("teleport",12,"TP 12"),("repcode",12,"Rep 12"),("mbqc",17,"Wire 17"),("teleport_mps",120,"MPS TP 120")]:
 for fw,name in [("sf_optimized","SuperFermion"),("aer","Qiskit Aer"),("pl","PennyLane"),("cirq","Cirq quimb")]:
  alias="scale_teleport" if case=="teleport_mps" and fw=="aer" else case
  hit=[r for r in mrows if r["framework"]==fw and r["mcm_case"]==alias and int(r["n_qubits"])==n]
  if not hit:continue
  r=hit[0];assert r["status"]=="ok"
  mainm.append([title,name,r["shots"]+(" x 4" if case=="repcode" else ""),f'{float(r["t_expval_total_s"]):.6f}',f'{float(r["peak_rss_mb"]):.1f}',"Yes"])
T("mps_mcm_summary","Completed dynamic circuit observations with matched case specifications",["Case","Framework","Shots","Wall (s)","RAM (MiB)","Correct"],mainm,
 "TP is ordinary teleportation; Wire is the measurement-based circuit; MPS TP is native MPS teleportation. Rep tests four error patterns at 200 shots each. Compare within a case. Correct means all tested target-bit outcomes satisfy the specified invariant, not validation for arbitrary inputs.",[.85,1.55,.85,1.05,1.2,1.0])
F("mps_mcm_time_ram")
P("The refreshed 12-qubit teleportation test uses 500 shots and records 0.067684 s for SuperFermion, 0.789876 s for Aer, 3.088467 s for Cirq and 6.304416 s for PennyLane. The four-pattern repetition-code test records 0.076387, 0.894468, 5.352905 and 6.537493 s, respectively, with all tested correction outputs passing. At the common 24-qubit ordinary-teleportation specification, all four offered paths exceed the 90 s budget. Those threshold outcomes are neither assigned zero time nor interpreted as an exclusive limitation of SuperFermion.")
F("mps_dynamic_scaling")
P("Native MPS teleportation completes at 12, 30, 60 and 120 qubits. At 120 qubits and 1,000 shots, SuperFermion takes 0.317963 s with 46.0 MiB recorded peak RSS, compared with 1.015076 s and 79.6 MiB for Aer. The time ratio is approximately 3.19 in these recorded rows, and both target-bit checks pass. At 12 qubits the matched anchor uses only 100 shots, so the connected scaling plot does not isolate qubit count from shot count.")
P("Measurement-window variation remains material. The supplied narrative reports interleaved stress medians of about 2.31 and 2.37 s at 1,000 qubits, much closer than the grid observations, and a native MPS teleportation ratio near 1.6. It also reports a reversal in the SuperFermion-versus-Cirq measurement-based-wire ordering between windows {{cite:mpsbundle}}. The supplementary call-level files referenced by that narrative are not present in the replacement archive. These report-level summaries are kept as contextual checks, not imported into the primary numeric tables or regenerated plots.")

H("Discussion",1)
H("Contribution to quantum computing software")
P("The practical contribution is lower recorded execution cost for many of the tested quantum research workloads. SuperFermion's smaller primary-compute total can shorten repeated feature-map comparisons, objective evaluation and circuit exploration under these configurations. Native observable requests can also avoid exporting a full state when the application needs only a scalar result. The qubit-specific tables identify where those routes help and where a different framework is competitive.")
P("The memory contribution is narrower. SuperFermion has lower whole-worker peaks than the configured Qiskit, PennyLane and Cirq paths across the median matched conditions, while Qulacs memory is similar and slightly lower. The MPS stress result additionally favors Aer on recorded peak RSS. A low-memory claim should therefore state the metric, workload and comparator rather than describe a universal framework property.")
P("Bounded-bond MPS and native measurement/feed-forward broaden the tested execution scope. Structured circuits reach 1,000 qubits, and native MPS teleportation reaches 120 qubits with passing target-bit checks. This supports an interface that exposes dense states, compact tensor representations and native readout with explicit diagnostics. It does not extend the learning experiments to those sizes or certify efficient simulation for arbitrary entanglement.")
P("A useful community release would pair these execution paths with documented output contracts, explicit precision settings, correctness examples and a complete pinned implementation. Publishing the native source patch and exact adapters would allow independent studies to test whether the observations persist across other workloads and repeated executions. Software efficiency is the supported research contribution; improved predictive quality or a general quantum advantage requires separate evidence.")
H("Engineering priorities")
P("The kernel data suggest controlled bank lifetimes, blocked Gram-matrix construction and reuse of prepared feature maps. The angle-control example also motivates verified analytical dispatch for separable representations. Such a route should check applicability explicitly and fall back to the requested general simulation when the identity does not apply.")
P("For variational and optimization objectives, output-aware APIs should request the smallest result that satisfies the application. Gradient evaluation should compare available analytic, adjoint, differentiation and parameter-shift methods with matched precision and output requirements. The current records show objective-evaluation costs but do not benchmark every alternative gradient implementation.")
P("For MPS execution, the low-bond truncation sequence calls for numerical-policy tests using full-distribution distances where a dense reference is possible. Validation should then distinguish engine diagnostics from independently checked state or probability errors. Dynamic correctness should expand beyond the tested deterministic inputs to superpositions and additional feed-forward histories. Repeated matched-shot comparisons would help separate stable execution behavior from measurement-window variation.")
P("Language conversion by itself is not evaluated here. Profiling should locate repeated preparation, dispatch, export, allocation and primitive costs before an implementation change is chosen. The saved counterexamples identify concrete targets for such investigation, while the missing component ablation prevents assigning causality to a particular optimization mechanism.")
H("Limitations and validity")
P("The main statistical limitation is repetition. The statevector grid has one fresh-process measurement per condition, and most MPS trials are warm calls within a process rather than independent fresh repetitions. Workload medians and display-rounding intervals do not quantify repeated-run variation. Close ratios and precision-separated leaders remain descriptive observations.")
P("The MPS grid combines saved measurement windows and compiled SuperFermion revisions. The narrative's interleaved checks indicate that some large nominal margins narrow and the measurement-based-wire direction can reverse. Their call-level supplements are absent from the replacement archive. Primary tables retain the exact grid values and provenance rather than treating those report summaries as another independently reconstructible dataset.")
P("Output fairness is also limited. Dense-state export, native observables, tensor diagnostics, exact-reference extraction and shot replay materialize different results. Cirq f32 uses mixed precision, and fixed MPS bond does not match approximation error across engines. A comparison of configured adapters consequently does not rank the complete capability of each framework.")
P("Measurement scope restricts memory interpretation. Fresh-worker RSS includes imports and setup. MPS peaks can include sampling or earlier work in a shared chunk. Those metrics are useful operational observations but cannot identify incremental tensor allocation. Reported compute totals also exclude some costs present in process or notebook walls.")
P("Implementation reproducibility remains incomplete. The final statevector overview lists correctness artifacts and an implementation patch without providing their complete contents. The replacement MPS notebook exposes adapter code, records and probes, but the native source patch and supplementary interleaved calls are not supplied. Independent reruns with a full environment and source manifest remain necessary before a general performance conclusion.")
P("The tested scope is finite. No completed 24-qubit learning results or VQC/VQR training above 12 qubits are supplied. The 24-qubit dynamic test is a shared budget boundary. Five training updates and aggregate task-quality summaries do not establish convergence, clinical efficacy or a predictive advantage. Those questions require their own experiments and row-level outcomes.")

H("Conclusion",1)
P("SuperFermion records the lowest reconstructed primary-compute total among six included statevector configurations on 252 matched conditions. The analysis preserves separate output contracts, all five main-paper framework heatmaps, and detailed comparisons at each measured qubit count. SuperFermion is the precision-separated leader in 131 conditions; 35 conditions remain unresolved at display precision. Qulacs, Qiskit and Cirq retain specific advantages, and Qulacs process memory is similar to and slightly lower than SuperFermion's.")
P("The replacement MPS results extend the evaluation to bounded-bond structured circuits and dynamic measurement. They include 141 successful observations among 182 selected jobs, 1,000-qubit ladder and stress cases, and correct native MPS teleportation through 120 qubits. Low-bond accuracy counterexamples, a higher SuperFermion stress peak than Aer, symmetric ordinary-teleportation budget limits and measurement-window variation remain explicit. The evidence supports practical software execution benefits under recorded workloads, with broader claims contingent on complete provenance and repeated controlled comparisons.")
H("Data and code availability",1)
P("The accompanying source archive contains the supplied statevector reports, the replacement MPS ZIP and its executed notebook, JSONL/CSV records, capability probe, narrative and original plots. Analysis scripts select the included configurations, verify unique matching conditions, reconcile the latest MPS jobs with the supplied CSV, regenerate every figure and reconstruct all tables. Every selected MPS job appears once in the detailed condition tables. Source hashes, unit conversions, omitted time-pair counts and build checks remain inspectable.")
P("The archive builds the paper and its editable Word equations without rerunning a quantum simulator. The raw source material is preserved for traceability, while the manuscript's comparison set is restricted to the stated configurations. The native implementation patch and supplementary interleaved call files remain separate reproducibility requirements.")
blocks.append(dict(type="bibliography"));B();blocks.append(dict(type="appendix"))
H("Quantum experiment comparisons by qubit count",1)
P("Each table is an individual experiment-and-qubit comparison. Six simulator configurations share the same condition keys; QSVM and QKRR also retain the analytical-angle control. Time is the primary compute stage and RAM is whole-worker peak RSS. Cohort medians do not represent repeated-run uncertainty. Source display strings and complete condition records are retained in the analysis data.")
P("Feature maps remain separate for QSVM/QKRR, and output tracks remain separate for variational and objective tasks. QKPCA and circuit tables show median and maximum values. N/A denotes an absent evaluation; a reported latency rounded to zero remains a censored value. No 24-qubit learning tables are constructed because completed observations are not supplied.")
taskdefs=[("qsvm","Quantum support vector machine"),("qkrr","Quantum kernel ridge regression"),("qkpca","Quantum kernel principal component analysis"),
 ("vqc","Variational quantum classification"),("vqr","Variational quantum regression"),("qaoa_fs","QAOA feature selection"),("maxcut","QAOA MaxCut"),("vqe","Variational quantum eigensolver"),("gradient","Gradient evaluation"),("circuit","Circuit simulation and sweeps")]
for task,title in taskdefs:
 B();H(title);qs=[4,8,12] if task in ["vqc","vqr"] else [4,8,12,16,20]
 P("The measured qubit grid is "+", ".join(str(q) for q in qs)+". The scaling view retains the output or feature-map distinctions used in the following tables.")
 F("scaling_"+task);B()
 for q in qs:S(task+"_"+str(q))
B();H("Classical controls by nominal qubit setting",1)
P("Classical controls use no quantum state allocation. The nominal qubit label indexes the paired experiment configuration. Results summarize the specified estimator cohort rather than an accuracy-controlled predictive comparison.")
F("classical_controls");B()
for q in [4,8,12,16,20]:S("classical_"+str(q))
B();H("Matrix product state and dynamic circuit comparisons",1)
P("Every time value and status in this appendix is reconstructed from the replacement MPS archive. Time is seconds and recorded process memory is MiB. Missing values and unoffered cases remain explicit. Eight successful dense-reference rows lack recorded timing. A single Z0 Zlast value is a correlation check, while TVD and discarded weight have distinct definitions. Each of the 182 selected jobs occurs in exactly one table.")
B();H("Small circuit correctness anchors");F("mps_validation_time_ram");B()
for circ in ["ghz","brick4"]:
 for n in [12,16]:
  for method in ["dense","mps"]:M(f"mps_validate_{circ}_{n}_{method}")
for circ,title in [("ghz","GHZ matrix product state ladder"),("brick4","Four layer brick circuit ladder")]:
 B();H(title);F("mps_ghz_time_ram" if circ=="ghz" else "mps_brick4_time_ram");B()
 for n in [50,100,200,500,1000]:M(f"mps_ladder_{circ}_{n}")
B();H("Twelve layer brick circuit stress");F("mps_stress_time_ram");B()
for n in [200,500,1000]:M(f"mps_stress_brick12_{n}")
B();H("Quantum Fourier transform conditions");F("mps_qft_time_ram");B()
for n in [8,20,30,50,100,200]:M(f"mps_qft_{n}")
for n,grid in [(16,[2,4,8,64]),(200,[8,16,32,64,128])]:
 B();H("Bond sweep at "+str(n)+" qubits");F("mps_bonds16_time_ram" if n==16 else "mps_bonds200_time_ram");B()
 for bond in grid:M(f"mps_bonds_{n}_{bond}")
B();H("Truncation diagnostics")
P("TVD at 16 qubits uses an exact probability reference. The 200-qubit discarded-weight sequence is an engine diagnostic rather than an independently measured full-state error. Missing fields are not assigned zero, and the non-monotonic sequence is preserved as recorded.")
F("mps_truncation_quality")
B();H("Dynamic measurement conditions")
P("Figures {{fig:mps_mcm_time_ram}} and {{fig:mps_dynamic_scaling}} appear in the main results. The following tables preserve each case, qubit count, shot specification, target-bit check and outcome. Repetition-code shots are per error pattern; its wall covers all four patterns. Budget and not-offered entries receive no invented runtime.")
for case,n in [("teleport",12),("teleport",24),("mbqc",17),("repcode",12),("mps_teleport",12),("mps_teleport",30),("mps_teleport",60),("mps_teleport",120)]:M(f"mps_mcm_{case}_{n}")
B();H("Matched condition time and memory distributions",1)
P("All task/qubit heatmaps are in the main paper. This appendix gives the complementary condition-level time/RSS scatter view for each external configuration against SuperFermion. Markers distinguish statevector and native readout. The horizontal reference is SuperFermion on both panels, and the equality line indicates which recorded value is lower. Time panels omit pairs censored by a displayed zero; memory panels retain all 252 pairs.")
for fw,title in [("qulacs","Qulacs"),("qiskit","Qiskit"),("pennylane","PennyLane"),("cirq","Cirq f32"),("cirq_f64","Cirq f64")]:
 B();H(title);F("matched_"+fw)
 if fw=="cirq":P("Cirq f32 is a mixed-precision comparison. These plots preserve the study's configured outputs rather than asserting precision-matched framework capability.")

refs=json.loads((data/"reference_definitions.json").read_text())
import re
cited=[]
for b in blocks:
 for field in ["text","caption","note"]:
  for token in re.findall(r"\{\{cite:([^}]+)\}\}",b.get(field,"")):
   for k in token.split(","):
    if k not in cited:cited.append(k)
refs=[r for k in cited for r in refs if r["key"]==k]
content=dict(title="SuperFermion for Efficient Quantum Circuit Simulation",
 subtitle="Quantum learning objective evaluation matrix product states and dynamic circuits",
 abstract="Efficient quantum simulation supports repeated circuit evaluation in quantum algorithm research. This study evaluates SuperFermion against external frameworks using saved statevector and matrix product state (MPS) measurements. Six statevector configurations share 252 matched conditions, covering 4 to 20 qubits and five-update variational learning at 4 to 12 qubits. The analysis includes 1,512 simulator jobs and 140 controls. SuperFermion has the lowest reconstructed primary-compute total, 27.36 min, compared with 34.30 min for Qiskit, the next lowest total. Median condition-paired process-memory savings are approximately 16.6% against Qiskit, 44.1% against PennyLane and 34.6-34.7% against Cirq. Qulacs memory is similar and slightly lower. All five framework heatmaps appear in the main results, preserving task and qubit variation. The replacement MPS archive contributes 182 selected unique jobs, including 141 successful observations. Structured circuits reach 1,000 qubits at bounded bond, and native MPS teleportation reaches 120 qubits with passing target-bit checks. At 120 qubits and 1,000 shots, SuperFermion records 0.318 s versus 1.015 s for Aer; the narrative's interleaved checks report a narrower ratio near 1.6. Low-bond truncation errors, a higher SuperFermion stress peak than Aer, shared 24-qubit budget limits and measurement-window variation constrain generalization. The results support workload-specific software execution benefits, with repeated measurements and complete implementation provenance still required for broad performance claims.",
 keywords="quantum circuit simulation; SuperFermion; quantum machine learning; native readout; process memory; matrix product states; mid circuit measurement; truncation diagnostics",
 source_note="Analysis of recorded benchmark reports and the replacement MPS archive; simulator measurements were not rerun.",authors=None,references=refs,blocks=blocks)
assert sum(b["type"]=="table" for b in blocks)==104
assert sum(b["type"]=="figure" for b in blocks)==36
assert sum(b["type"]=="equation" for b in blocks)==7
assert len({b["label"] for b in blocks if b["type"] in ["table","figure"]})==140
appendix=next(i for i,b in enumerate(blocks) if b["type"]=="appendix")
heatmaps=[b["label"] for b in blocks[:appendix] if b["type"]=="figure" and b["label"].startswith("heatmap_")]
assert len(heatmaps)==5 and all(not (b["type"]=="figure" and b["label"].startswith("heatmap_")) for b in blocks[appendix:])
rendered=json.dumps(content)
assert not re.search(r"SF optimized|SF published|SF source|Optimized SuperFermion|desktop|laptop|AMD64|logical CPUs",rendered,re.I)
assert not re.search(r"\bWindows\b",rendered)
(data/"manuscript.json").write_text(json.dumps(content,indent=2)+"\n")
print(json.dumps(dict(tables=104,figures=36,editable_equations=7,references=len(refs),main_results_heatmaps=heatmaps),indent=2))
