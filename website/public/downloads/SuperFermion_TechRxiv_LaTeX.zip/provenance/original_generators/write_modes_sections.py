"""Write the manuscript additions from reconciled supplied results."""
from pathlib import Path
import argparse,json

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--package-dir',type=Path,default=Path(__file__).resolve().parents[1])
p=parser.parse_args().package_dir.resolve();d=p/'data'
analysis=json.loads((d/'mode_analysis_checks.json').read_text())
summary=json.loads((d/'mode_summary.json').read_text())
figures={x['label']:x for x in json.loads((d/'figure_manifest.json').read_text())}
details=json.loads((d/'mode_detailed_tables.json').read_text())
blocks=[];groups={};active='introduction'
def add(x):
 x=dict(x);x['insert_group']=active;blocks.append(x);return x
def h(text,level=1):return add(dict(type='heading',level=level,text=text))
def para(text):return add(dict(type='paragraph',text=text))
def eq(label,tex):return add(dict(type='equation',label='modes_'+label,tex=tex))
def fig(label):return add(figures[label])
def table(label,title,columns,rows,note,widths):return add(dict(type='table',label=label,title=title,columns=columns,rows=rows,note=note,widths=widths))
def n(value):return f'{value:.6g}'

references=[
 dict(key='modes_methods',kind='misc',author='SuperFermion methods report',bibauthor='{SuperFermion methods report}',title='SF optimization methods at the math level MPS engine versus cat Clifford engine',venue='User-supplied code-oriented mathematical methods report',year='2026'),
 dict(key='modes_suite',kind='misc',author='SuperFermion execution modes benchmark suite',bibauthor='{SuperFermion execution modes benchmark suite}',title='Stabilizer adjoint density matrix and Clifford benchmark results',venue='User-supplied executed notebook and CSV/JSONL records, 12 October 2026',year='2026'),
 dict(key='modes_ag',kind='article',author='Scott Aaronson and Daniel Gottesman',bibauthor='Scott Aaronson and Daniel Gottesman',title='Improved simulation of stabilizer circuits',venue='Physical Review A 70, 052328',journal='Physical Review A',volume='70',pages='052328',year='2004',doi='10.1103/PhysRevA.70.052328'),
 dict(key='modes_stim',kind='article',author='Craig Gidney',bibauthor='Craig Gidney',title='Stim: a fast stabilizer circuit simulator',venue='Quantum 5, 497',journal='Quantum',volume='5',pages='497',year='2021',doi='10.22331/q-2021-07-06-497'),
 dict(key='modes_mps',kind='article',author='Ulrich Schollwoeck',bibauthor='Ulrich Schollwoeck',title='The density-matrix renormalization group in the age of matrix product states',venue='Annals of Physics 326, 96-192',journal='Annals of Physics',volume='326',pages='96--192',year='2011',doi='10.1016/j.aop.2010.09.012'),
 dict(key='modes_adj',kind='misc',author='Tyson Jones and Julien Gacon',bibauthor='Tyson Jones and Julien Gacon',title='Efficient calculation of gradients in classical simulations of variational quantum algorithms',venue='arXiv preprint 2009.02823',year='2020',url='https://arxiv.org/abs/2009.02823'),
]

h('Introduction')
para('Quantum simulation benefits from matching the requested circuit and output to a suitable representation. A dense statevector supports general pure-state evolution, but its storage grows exponentially with qubit count. A stabilizer tableau exploits the Clifford gate class without requiring low entanglement. An MPS instead exploits bounded bond dimension and can support general rotations with controlled local truncation. These computational regimes motivate separate execution paths within SuperFermion, rather than a single performance claim for every circuit. {{cite:modes_ag,modes_mps}}')
para('The mathematical mechanisms are described by the accompanying code-oriented methods report. The execution-mode suite adds 24 recorded conditions: six stabilizer sampling conditions, five large-Clifford conditions, ten gradient conditions and three density-matrix conditions. The stabilizer and Clifford labels exercise the same Pauli-frame engine in different size regimes. Gradient evaluation uses a compiled statevector handle, and density-matrix evaluation uses a separate native-core path. {{cite:modes_methods,modes_suite}}')
para('The observations favor SuperFermion for repeated prepared sampling and for the recorded compiled-handle gradients, while preserving slower cold cases and a density-matrix counterexample. The comparison therefore separates representation, preparation, repeated execution and numerical checks. It does not pool these mode timings with statevector or MPS campaigns that use different output and execution contracts.')
fig('modes_regimes')

active='math_methods';h('Mathematical methods')
h('MPS representation and canonical structure',2)
para('For an open chain, each site tensor has a left bond, a right bond and a binary physical index. Both boundary bond dimensions equal one, and internal bond dimensions are bounded by chi. The wavefunction amplitude and the leading storage order are')
eq('mps_state',r'\psi_{s_1\cdots s_n}=A_1^{s_1}\cdots A_n^{s_n},\qquad D_i\leq\chi,\qquad N_{\mathrm{MPS}}=O(n\chi^2).')
para('The storage order counts complex entries and is not a measured process-memory result. The methods report describes a default bond cap of 64 and each site as two physical blocks stacked in a matrix. Left QR sweeps absorb the triangular factor into the next site; right LQ sweeps establish an isometric suffix. The corresponding canonical conditions are')
eq('canonical',r'\sum_s (A_i^s)^\dagger A_i^s=I,\qquad \sum_s B_i^s(B_i^s)^\dagger=I.')
para('The report describes a dirty-window frontier for right canonicality and a cached left measurement environment. Rewriting a local tensor invalidates the affected frontier, so subsequent measurement repairs the needed interval instead of sweeping the entire chain unconditionally. These mechanisms reduce repeated preparation work when their invariants hold; the mode suite does not contain a component ablation measuring their individual contribution. {{cite:modes_methods,modes_mps}}')
h('Two site gates and truncation',2)
para('A two-qubit gate first contracts the shared bond and acts on the physical indices. With l and r denoting the outer bonds and a the shared bond, the merged matrix can be written as')
eq('merge',r'M_{(l,o_1),(o_2,r)}=\sum_{a,i_1,i_2}g_{o_1o_2,i_1i_2}(A_i^{i_1})_{la}(A_{i+1}^{i_2})_{ar}.')
para('The methods report describes an exact structured split when a block-diagonal gate admits a factorization whose rank fits the bond cap. That path avoids a full singular-value decomposition for the qualifying merge. The general default uses a thin SVD and a relative pruning threshold of 1e-12 times the merged Frobenius norm. An exact retained singular subspace gives the rank-k approximation; an orthonormal retained basis also permits the projected-mass formulation')
eq('projection',r'M_k=M V_kV_k^\dagger,\qquad \varepsilon=\frac{\|M\|_F^2-\|M V_k\|_F^2}{\|M\|_F^2},\qquad V_k^\dagger V_k=I.')
para('The report describes selecting retained columns using measured norms of M v when reported singular values and vectors are inconsistent. This is a numerical safeguard described by that source, not an independently reproduced native-code finding. It also distinguishes the default SVD route from a legacy positional QR cut. The internal values summarized below are source-comment observations, kept separate from the recorded execution-mode benchmark. {{cite:modes_methods}}')
table('modes_internal_mps','Report attributed internal MPS observations',['Condition','Reported legacy','Reported default','Evidence scope'],[
 ['Brick12, 200 qubits','2.18 s; reported discard metric about 5.2e-4','1.04 s; accumulated discarded mass about 6.7e-14','Source-comment timing; telemetry labels differ'],
 ['Brick12, 26 qubits; cap 64','Reported error 4.2e-6','Reported error 3.6e-14','The report does not define the error metric here'],
 ['Same 26-qubit condition','Accumulated discarded mass 6.7e-2','Accumulated discarded mass 1.1e-16','Telemetry is not certified global fidelity'],
 ],'Values are attributed to internal measurements in native source comments summarized by the supplied methods report. The 200-qubit legacy discard metric has an unspecified aggregation, while the default is stated as an accumulated sum. No call-level record, complete recipe or native source revision is included. These observations do not enter framework rankings, measured RAM comparisons or the 24-condition suite statistics. {{cite:modes_methods}}',[1.25,1.6,1.6,2.05])
para('Truncation telemetry records per-step discarded mass, event counts and its accumulated sum. The field named fidelity_lower_bound is described in the methods report as a diagnostic rather than a certified global fidelity bound. Repeated truncation, renormalization and circuit structure can change the relationship between local discarded mass and final-state error. Quantitative accuracy claims consequently require independent state or probability comparisons.')
h('MPS routing observables and sampling',2)
para('Lazy routing tracks a logical-to-site permutation. Bringing distant sites together still requires adjacent tensor operations, but leaving the resulting permutation in place can avoid unconditional swap-back work. The bookkeeping update is constant time; that statement does not make a tensor SWAP itself constant time.')
para('Sequential sampling uses the probability chain rule. In a gauge with a right-isometric tail, a prefix vector v can be propagated through the chosen physical block. Normalized local branch probabilities and the complete sample distribution are')
eq('sampling',r'p(s_i\mid s_{<i})=\frac{\|v_{i-1}A_i^{s_i}\|^2}{\sum_{b=0}^1\|v_{i-1}A_i^b\|^2},\qquad p(s)=\prod_{i=1}^n p(s_i\mid s_{<i}).')
para('Under the stated canonical structure and fixed physical dimension, per-sample contraction work is linear in chain length and quadratic in bond dimension, without constructing a dense statevector. Measurement projects and renormalizes the chosen branch; reset can then apply X when the observed bit is one. A Pauli-product expectation can likewise be evaluated with a sequence of transfer matrices,')
eq('observable',r'E_i=\sum_{s,t}(P_i)_{st}(A_i^s)^\dagger E_{i-1}A_i^t,\qquad E_0=1,\qquad \psi^\dagger(P_1\otimes\cdots\otimes P_n)\psi=E_n.')
para('Bounded-bond storage is useful only when the retained bond dimensions describe the state accurately. A Clifford circuit can create extensive entanglement and remain tractable for a stabilizer tableau, while a fixed-bond MPS can require truncation. Conversely, the Clifford class by itself does not guarantee that a particular tableau implementation wins every timing comparison. The new mode suite contains no shared-workload head-to-head MPS-versus-tableau measurement. {{cite:modes_ag,modes_mps,modes_suite}}')
h('Pauli frame tableau and symbolic measurements',2)
para('A pure stabilizer state can be represented with stabilizer and destabilizer rows containing binary X and Z indicators and phase bits. The described implementation packs row data into 64-bit words. Tableau storage is quadratic in qubit count; elementary H, S and controlled-X updates touch selected bit positions in each row. This storage order should not be confused with a universal measured gate-time complexity or an automatic 64-fold speedup. {{cite:modes_methods,modes_ag}}')
para('For H on qubit q, the X and Z bits exchange and the phase toggles when both were set. For S, the Z bit is XORed with X and the same phase correction applies. The controlled-X update combines the two target bit positions with a Boolean phase term. The report describes fusing the operation stream row by row and using word-level phase products to avoid repeated per-bit traversal.')
para('The sampling preparation performs the symbolic stabilizer measurement procedure once. Independent random branches introduce unbiased binary variables; determined outcomes become affine parity functions of those variables. In vector notation,')
eq('affine',r'\mathbf{y}=A\mathbf{r}\oplus\mathbf{c},\qquad \mathbf{r}\sim\mathrm{Uniform}(\mathbb{F}_2^k).')
para('The described sampler evaluates these parity expressions across 64 independent shot lanes packed into a word, then transposes them into output keys. Sparse dependency lists reduce parity work when the measurement structure permits it. A column index accelerates finding active tableau rows, and repeated strings are materialized once per distinct count key. GHZ conditions have two reported keys, whereas the tested brickwork and random-Clifford conditions record 2,000 distinct keys; output structure is therefore part of the measured work. {{cite:modes_methods}}')
para('The tableau path applies to Clifford circuits. Non-Clifford gates require another execution path; a general variational rotation is not represented by this Pauli-frame sampler. Stim is a specialized stabilizer comparator, and its recorded sample-array contract differs from the SuperFermion counts-map contract. {{cite:modes_stim,modes_suite}}')
h('Compiled adjoint gradients',2)
para('The gradient experiment uses RY and RZ on every qubit in each layer, followed by a controlled-X ladder. It has P = 2 n L parameters and the full Z-product observable. A compiled handle separates circuit construction from repeated gradient evaluation. For a parameterized gate in a circuit with G gates, a reverse sweep uses the forward state and the backward observable state,')
eq('adjoint',r'\frac{\partial f}{\partial\theta_j}=2\operatorname{Re}\left(\lambda_j^\dagger\frac{\partial U_j}{\partial\theta_j}\psi_{j-1}\right),\qquad \lambda_j=U_{j+1}^\dagger\cdots U_G^\dagger O\psi_G.')
para('This form avoids independent full-circuit replay for every parameter and can reuse a constant number of dense statevectors. Its memory still grows exponentially with qubit count. The compiled-handle experiment measures this dense-state gradient route, not the Clifford tableau engine. {{cite:modes_adj,modes_suite}}')
h('Dense density matrix checks',2)
para('For the noiseless unitary circuits in this suite, the expected density matrix is a pure-state outer product. Its diagonal agrees with statevector probabilities, and its trace and purity are one:')
eq('density',r'\rho=\psi\psi^\dagger,\qquad \rho_{jj}=\psi_j\overline{\psi_j},\qquad \operatorname{Tr}\rho=1,\qquad \operatorname{Tr}(\rho^2)=1.')
para('These checks are useful but do not identify a complete density matrix. For example, the two states below have the same diagonal, trace and purity but different coherences,')
eq('density_counterexample',r'\rho_+=\tfrac12\begin{pmatrix}1&1\\1&1\end{pmatrix},\qquad \rho_-=\tfrac12\begin{pmatrix}1&-1\\-1&1\end{pmatrix}.')
para('A complete density-matrix validation would compare off-diagonal entries or suitable informationally complete observables, with explicit tolerance. No noisy-channel workload is measured by these three pure-state conditions. Dense density-matrix storage grows as four to the power of the qubit count in complex entries; this is a representation count, not a measured RAM estimate.')

active='protocol';h('Experimental protocol')
para('The executed notebook contains no saved error outputs. The analysis reconciles all 24 unique JSONL condition keys with the four supplied CSVs and confirms that the nested results ZIP is a duplicate copy of the same recorded data. The selected comparison has 81 framework observations after retaining the primary SuperFermion execution path and external comparators. The archive provides aggregate window statistics rather than complete timed-call arrays, so repeated-run uncertainty cannot be reconstructed. {{cite:modes_suite}}')
table('modes_protocol','Recorded execution mode protocol',['Experiment','Recorded grid','Timing and output contract'],[
 ['Stabilizer','6 conditions; 64 to 1,024 qubits','GHZ, depth-eight brickwork and random Clifford; 2,000 shots'],
 ['Large Clifford','5 conditions; 1,024 and 4,096 qubits','Same Pauli-frame path in the larger regime; 2,000 shots'],
 ['Gradient','10 conditions; 6 to 20 qubits','One layer at every measured size; two and four layers at 8 qubits; P = 2 n L'],
 ['Density matrix','3 conditions; 8, 10 and 12 qubits','Noiseless depth-eight brickwork; separate native dense-core path'],
 ['Concurrency','SuperFermion: Rayon limit 4','Competitors use package defaults; equal-concurrency comparison was not recorded'],
 ['Random seeds','Brickwork 11; random Clifford 7','Gradient parameters use seed 7 with draws between 0.1 and 1.2'],
 ['Sampling repetitions','Two reversed comparison windows','SF and Stim: 7 timed calls/window; Aer and PennyLane: 2 cold and 3 warm; Cirq: 1'],
 ['Gradient repetitions','Two forward comparison cycles','7 timed gradient calls/window; SF handle compile cost reported separately'],
 ['Density repetitions','Two SF windows, then two Aer windows','SF: 7 calls/window; Aer: 5 after an excluded warm call'],
 ['Timing boundaries','Native process startup excluded','Recorded cold contracts differ; SF warm counts versus Stim sample array'],
 ['Resource guards','40 s first-call criterion','Cirq capped above 64 qubits; stabilizer Aer above 256; budget checked after the call'],
 ['RAM','No RSS or allocation measurements','No measured memory ranking is inferred from this suite'],
 ],'Timings are means of two window medians. Adjoint and density-matrix order are not the reversed tableau order. Quoted repeat counts describe the saved adapter; per-call values are absent.',[1.25,2.05,3.2])
para('Tableau windows run SuperFermion, Stim, Aer, PennyLane and Cirq in forward and then reverse order. Gradient windows instead use two forward comparison cycles. Density-matrix windows are grouped as two SuperFermion calls followed by two Aer calls in the notebook code. This distinction matters because a general description of all sections as ABBA-interleaved would be inaccurate.')
para('SuperFermion cold sampling includes native tableau construction, measurement-plan preparation and first execution inside its timed region. Stim full timing includes sampler compilation and sampling, with Python circuit assembly already outside that region. Aer, PennyLane and Cirq have their own fresh-construction boundaries. SuperFermion warm timing produces a count map; Stim warm timing produces a sample array. The additional Aer reuse measurement is retained in each detailed sampling table but is separate from the archive\'s warm headline.')
para('The saved software versions are Stim 1.16.0, Qiskit 2.1.2 with Aer 0.17.2, PennyLane 0.45.0, Cirq 1.6.1 and Qulacs 0.6.14. The native example has the recorded short binary identifier c0c9679b215e and configuration identifier 3b88281923. These identify the measured implementation but do not replace a full source manifest. The Rust execution paths in the suite are engine-level measurements through a release example; the supplied README states that those paths are not yet exposed by the shipped Python package.')
para('The Qulacs gradient adapter compensates for its rotation convention by setting negative angles and negating the returned backpropagation derivative. Gradient parity refers to those compensated derivatives. Construction of the SuperFermion handle remains separate from its timed evaluations; the recorded Qulacs function includes parameter updates, state allocation, circuit application and backpropagation.')
para('The density-matrix observations call the native core\'s QuantumDAG.simulate_dm implementation through the example. The separate density-matrix planner mode is held out and is not claimed as implemented by these timings. The supplied methods report traces implementation mechanisms to native source files, while the ZIP ships the benchmark adapter and executed outputs rather than those complete native implementations. Mechanism descriptions are consequently attributed to the report; no component ablation is inferred.')

active='results';h('Execution mode results')
h('Stabilizer and large Clifford sampling',2)
table('modes_outcomes','Sampling outcomes and available comparator standings',['Regime','Conditions','Faster cold','Faster warm','Complete field'],[
 ['Stabilizer','6','2 / 6','5 / 6','1 / 6'],['Large Clifford','5','2 / 5','5 / 5','0 / 5'],['Combined','11','4 / 11','10 / 11','1 / 11']],
 'Faster means below every external comparator with a recorded timing in that condition. Complete field requires all four external sampling comparators to have timings. Missing capped or budget jobs do not count as wins or losses. The selected sampling observations comprise 39 OK, 15 capped and one budget outcome.',[1.5,1.0,1.25,1.25,1.5])
para('SuperFermion is faster than every available external sampling comparator in ten of eleven prepared warm conditions. The exception is 64-qubit brickwork: SuperFermion takes 0.522775 ms while Stim takes 0.23665 ms, a comparator-to-SuperFermion ratio of about 0.453. Cold standings are narrower, with four wins across the eleven recorded conditions. Only the 64-qubit GHZ condition has a complete four-comparator field, so the large-regime observations do not establish a win against every framework at every size.')
fig('modes_tableau_heatmaps')
para('At 1,024 and 4,096 qubits, GHZ prepared counting takes 0.8224 and 2.652575 ms for SuperFermion, versus Stim\'s 10.75125 and 76.52965 ms. The corresponding recorded ratios are 13.07 and 28.85. Large brickwork has ratios 3.07 and 5.40, and 4,096-qubit random Clifford has ratio 6.68. These values concern the saved prepared-output contracts and concurrency configuration, not a universal simulator or public-API speedup.')
fig('modes_tableau_times')
para('Cold large-Clifford costs retain the preparation counterexamples. At 4,096 qubits, SuperFermion brickwork takes 2,106.4573 ms compared with Stim\'s 231.2324 ms. For random Clifford, the cold values are 9,396.8310 and 4,413.2164 ms. SuperFermion\'s reported random-Clifford measurement-plan cost is 8,021.0467 ms, much larger than its 14.0754 ms prepared counting cost. This identifies preparation reuse as a practical distinction without assigning causality to a particular kernel.')
h('Prepared gradient evaluation',2)
para('All ten saved SuperFermion prepared-gradient timings are below the corresponding Qulacs timings. The maximum reported component-wise gradient discrepancy is 2.8172e-15. The independent central finite-difference anchor occurs only at eight qubits and one layer, with maximum error 3.9037e-11; it is not a finite-difference validation of the entire size grid.')
fig('modes_adjoint_scaling')
para('At 20 qubits and one layer, SuperFermion records 923.79665 ms for the gradient, Qulacs records 1,264.0098 ms, and the separate SuperFermion compilation cost is 363.89395 ms. The prepared gradient ratio is about 1.368. The largest ratio occurs at 12 qubits, where the reported Qulacs timing rises to 181.6728 ms while SuperFermion records 0.6909 ms. The resulting ratio is about 262.95; the irregular comparator trend needs targeted profiling before a general scaling interpretation is justified.')
para('Repeated-use cost can be examined with a transparent arithmetic estimate. Let C be the saved SuperFermion compile time, g its prepared gradient time, q the Qulacs per-call time, and K the number of repeated evaluations:')
eq('amortization',r'C+K g<K q\quad\Longleftrightarrow\quad K>\frac{C}{q-g},\qquad q>g.')
para('Using that estimate, four calls amortize the recorded compile cost at ten qubits, five at sixteen qubits, and two at twenty qubits. The calculation excludes a separate Qulacs setup cost because that quantity was not recorded; it is not a measured cold end-to-end comparison. The archive\'s cold_ms field is not substituted for C + g, since the saved timing windows and boundaries differ.')
fig('modes_adjoint_ratios')
h('Density matrix evaluation and numerical checks',2)
para('At eight qubits, the native SuperFermion density-matrix engine takes 28.424 ms and Aer takes 49.21935 ms, giving an Aer-to-SuperFermion ratio of about 1.732. At twelve qubits, SuperFermion takes 14,239.7466 ms while Aer takes 9,192.7935 ms; SuperFermion is approximately 1.549 times slower. Both saved diagonal flags pass at those sizes, but the limited checks do not certify complete matrix equality.')
para('The same native worker records statevector anchors of 0.5535, 1.45895 and 2.7277 ms at eight, ten and twelve qubits. Those anchors return a different object and remain contextual observations, not framework speed comparisons. They illustrate why a pure-state application should request a dense density matrix only when that output is required.')
fig('modes_density_matrix')
para('The ten-qubit row records 815.93745 ms for SuperFermion and 659.0791 ms for Aer. Aer\'s diagonal flag is false, even though its trace and purity are near one. The adapter rounds the diagonal and reference probabilities to eight decimal places and then uses exact array equality. The archive does not save Aer\'s unrounded diagonal discrepancy or density matrix, so this flag cannot be diagnosed as a particular implementation error or dismissed as harmless rounding. The time remains visible as a recorded observation, with validated relative-performance interpretation withheld.')
table('modes_accuracy','Scope of the recorded numerical checks',['Check','Saved observation','Interpretation'],[
 ['Gradient parity','10 / 10 conditions; maximum 2.8172e-15','Component-wise SF/Qulacs agreement in the saved windows'],
 ['Finite differences','8 qubits, 1 layer; 3.9037e-11','One independent gradient anchor, not all sizes'],
 ['GHZ sample support','All recorded GHZ checks pass','Samples lie in the two GHZ branches; frequencies and all output states are not certified'],
 ['SF density diagonal','Flags pass at 8, 10 and 12 qubits','Native worker probability check; thresholds differ from the Aer recipe'],
 ['Aer density diagonal','Pass at 8 and 12; false at 10','Eight-decimal array comparison; missing unrounded error prevents diagnosis'],
 ['Density trace and purity','All saved deviations below 4.4e-14','Reported scalar checks; complete coherences and Hermiticity are not independently verified'],
 ],'These values are audit scopes, not repeated-run confidence bounds. Full brickwork/random sampling distributions and complete density matrices are not supplied for independent reconstruction.',[1.55,2.15,2.8])

active='discussion';h('Contribution and limitations')
para('The new evidence supports a representation-aware execution interface: use a tableau sampling plan for Clifford work, MPS contractions for suitable bounded-entanglement workloads, a reusable adjoint handle for repeated dense-state gradients, and an explicitly separate density-matrix path. Prepared sampling and gradient observations show where retaining a plan or compiled handle can shorten repeated research computations. The colder brickwork and density-matrix cases show why representation selection and preparation cost must remain visible.')
para('The methods report supplies a mathematical explanation for locality, canonical repair, affine measurements and packed-shot evaluation. The mode archive adds measured execution observations for the tableau, adjoint and dense-core paths; it does not add an MPS performance study or establish the effect size of each reported optimization. No measured RAM field is present, so the new suite does not support an additional low-memory framework claim. Algorithmic storage orders should remain separate from process RSS measurements.')
para('Material comparison limits include unequal concurrency, different output contracts, different construction boundaries and nonidentical window orders. The saved summaries lack complete per-call arrays, preventing a defensible uncertainty estimate. Numerical checks cover gradient parity, one finite-difference condition, GHZ support and selected density diagnostics; they do not establish complete output equivalence for every family. Broader community claims need equivalent public interfaces, complete native source provenance, balanced repeated measurements and stronger distribution or matrix validation.')

active='availability';h('Data and reproducibility')
para('The accompanying source package contains the unchanged methods report, the supplied execution-mode ZIP, its executed notebook, adapter source, raw JSONL, four CSVs and original figure exports. Analysis files retain the selected framework observations, condition-specific tables, source hashes, comparison outcomes and arithmetic gradient-amortization estimates. Figures are exported as vector PDF and SVG and high-resolution PNG. The manuscript and editable Word equations share one content source. No simulator benchmark was rerun for this analysis.')
add(dict(type='pagebreak'));add(dict(type='bibliography'));add(dict(type='pagebreak'));add(dict(type='appendix'))
active='details';h('Execution mode comparisons by condition')
para('Each table preserves one experiment, qubit count and circuit or depth setting. Framework rows are the selected SuperFermion path and the external comparators actually measured or guarded by that section. Capped and budget results remain distinct from measured times. The density-matrix flag remains explicit, and compilation stays separate from prepared gradient timing. No RAM measurements are present for these conditions.')
for section,title in [('stab','Stabilizer sampling'),('cliff','Large Clifford sampling'),('adj','Adjoint gradients'),('dm','Density matrix evaluation')]:
 h(title,2)
 subset=[x for x in details if x['label'].startswith('modes_'+section+'_')]
 for item in subset:
  if section=='dm':
   item=dict(item)
   r=next(r for r in summary['dm'] if item['label']=='modes_'+r['ykey'].replace(':','_'))
   item['note']+=' The separately recorded SuperFermion statevector anchor is '+n(r['rust']['sv_ms'])+' ms and has a different output contract.'
  add(item)

abstract=('SuperFermion uses distinct representations for Clifford sampling, bounded-entanglement simulation and general variational circuits. We describe the MPS and Pauli-frame mechanisms from the code-oriented methods report and analyze 24 supplied execution-mode conditions. The stabilizer and large-Clifford labels share a tableau engine with a prepared affine measurement plan. SuperFermion is below every available external comparator in ten of eleven prepared sampling conditions, while cold construction wins only four. Its ten compiled-handle gradient observations are faster than Qulacs, with maximum recorded component-wise discrepancy 2.8172e-15; finite differences provide one independent eight-qubit anchor. The separate dense-core density-matrix route is faster than Aer at eight qubits and slower at twelve. Aer\'s ten-qubit diagonal-check flag remains explicit and that comparison is unranked. The suite records unequal concurrency, adapter-specific output and construction boundaries, and no RAM measurements. These observations support reusable preparation and representation-aware execution under the recorded contracts; they do not establish universal speed, memory or public-interface superiority.')
content=dict(title='SuperFermion execution modes and mathematical methods',subtitle='MPS algorithms stabilizer sampling adjoint gradients and density matrix evaluation',abstract=abstract,keywords='SuperFermion; MPS; stabilizer simulation; Clifford circuits; adjoint differentiation; density matrices; reproducible benchmarking',references=references,blocks=blocks)
(d/'manuscript.json').write_text(json.dumps(content,indent=2)+'\n')
for group in sorted({b['insert_group'] for b in blocks}):groups[group]=[b for b in blocks if b['insert_group']==group and b['type'] not in ['bibliography','pagebreak','appendix']]
(d/'insert_blocks.json').write_text(json.dumps(dict(references=references,groups=groups),indent=2)+'\n')
assert len([b for b in blocks if b['type']=='table'])==28
assert len([b for b in blocks if b['type']=='figure'])==6
assert len([b for b in blocks if b['type']=='equation'])==11
print(json.dumps(dict(tables=28,figures=6,editable_equations=11,condition_tables=24),indent=2))
