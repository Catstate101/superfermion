"""Export LaTeX additions after building main.tex from the shared content."""
from pathlib import Path
import argparse,shutil
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--package-dir',type=Path,default=Path(__file__).resolve().parents[1])
p=parser.parse_args().package_dir.resolve();text=(p/'main.tex').read_text();out=p/'insert';out.mkdir(exist_ok=True)
cuts=[('math_methods','Mathematical methods','Experimental protocol'),('benchmark_protocol','Experimental protocol','Execution mode results'),('execution_mode_results','Execution mode results','Contribution and limitations'),('discussion_addition','Contribution and limitations','Data and reproducibility')]
for name,start,end in cuts:
 fragment=text.split('\\section{'+start+'}',1)[1].split('\\section{'+end+'}',1)[0].strip()
 if name=='benchmark_protocol':fragment='\\subsection{Execution mode benchmark protocol}\n\n'+fragment
 (out/(name+'.tex')).write_text(fragment+'\n')
fragment=text.split('\\section{Data and reproducibility}',1)[1].split('\\bibliographystyle',1)[0].strip()
(out/'data_availability_addition.tex').write_text(fragment+'\n')
fragment=text.split('\\section{Execution mode comparisons by condition}',1)[1].split('\\end{document}',1)[0].strip()
(out/'mode_detail_appendix.tex').write_text('\\section{Execution mode comparisons by condition}\n\n'+fragment+'\n')
shutil.copy2(p/'references.bib',out/'references_modes.bib')
print('Exported six LaTeX content fragments and the references.')
