"""Integrate the current manuscript and supplied later study without simulator runs."""
from pathlib import Path
from copy import deepcopy
from collections import Counter
import json, re, shutil, hashlib

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'base'
ADD = ROOT / 'insert'
OUT = ROOT / 'merged'
if OUT.exists():
    raise SystemExit('The output folder already exists; preserve the existing build.')
paper = json.loads((BASE/'data/manuscript.json').read_text())
addition = json.loads((ADD/'data/insert_blocks.json').read_text())
original = deepcopy(paper)
blocks = paper['blocks']
aliases = {}
for ref in addition['references']:
    same = next((r for r in paper['references'] if
        (ref.get('doi') and r.get('doi') == ref['doi']) or
        (ref.get('url') and r.get('url') == ref['url'])), None)
    if same:
        aliases[ref['key']] = same['key']
    else:
        assert not any(r['key']==ref['key'] for r in paper['references'])
        paper['references'].append(deepcopy(ref))

def rewrite(b):
    b = deepcopy(b)
    for field in ('text','caption','note'):
        if field in b:
            b[field] = re.sub(r'\{\{cite:([^}]+)\}\}',lambda m:
                '{{cite:'+','.join(aliases.get(k,k) for k in m[1].split(','))+'}}',b[field])
    b.pop('insert_group', None)
    return b

def group(name):
    g = [rewrite(b) for b in addition['groups'][name]]
    if g and g[0]['type']=='heading' and g[0]['level']==1:
        g=g[1:]
    return g

def para(text): return {'type':'paragraph','text':text}
def heading(text): return {'type':'heading','level':2,'text':text}
def first_para(prefix):
    return next(b for b in blocks if b['type']=='paragraph' and b['text'].startswith(prefix))
def insert_before_section(title, items):
    i = next(i for i,b in enumerate(blocks) if b['type']=='heading' and b['level']==1 and b['text']==title)
    blocks[i:i] = items
def insert_after(target, items):
    i = next(i for i,b in enumerate(blocks) if b is target)
    blocks[i+1:i+1] = items

paper['subtitle'] = 'Statevector learning matrix product states dynamic circuits and specialized execution modes'
paper['abstract'] = (
 'Efficient quantum simulation requires execution paths that match circuit structure and requested outputs. '
 'This study evaluates SuperFermion using three recorded benchmark suites covering statevectors, matrix product states (MPS), dynamic circuits and specialized execution modes. '
 'Six statevector configurations share 252 conditions from 4 to 20 qubits, including five-update variational learning from 4 to 12 qubits. '
 'The selected corpus contains 1,512 simulator jobs and 140 controls. SuperFermion has the lowest reconstructed primary-compute total, 27.36 min, compared with 34.30 min for Qiskit. '
 'Median paired process-memory savings are approximately 16.6% against Qiskit, 44.1% against PennyLane and 34.6-34.7% against Cirq; Qulacs memory is similar and slightly lower. '
 'The MPS suite contributes 182 selected unique jobs, including 141 successful observations. Structured circuits reach 1,000 qubits, and native MPS teleportation reaches 120 qubits with passing target-bit checks. '
 'At 120 qubits and 1,000 shots, SuperFermion records 0.318 s versus 1.015 s for Aer, while attributed interleaved checks report a narrower ratio near 1.6. '
 'The later suite adds 24 conditions across tableau sampling, compiled adjoint gradients and dense-core density matrices. Stabilizer and Clifford labels share one engine. '
 'SuperFermion is faster than every available external comparator in 10 of 11 prepared sampling conditions but only four cold conditions. '
 'All ten prepared gradients are faster than Qulacs, with maximum saved component-wise discrepancy 2.8172e-15 and one independent eight-qubit finite-difference anchor. '
 'The dense-core density-matrix route is faster than Aer at eight qubits and slower at twelve; the ten-qubit Aer diagonal-check flag leaves that comparison unranked. '
 'MPS truncation counterexamples, process-memory exceptions, preparation costs, unequal concurrency, different output contracts and incomplete repeated-run records constrain generalization. '
 'The evidence supports workload-specific execution benefits and preparation reuse; the three suites retain separate timing definitions and correctness scopes.'
)
paper['keywords'] = ('quantum circuit simulation; SuperFermion; quantum machine learning; matrix product states; '
 'dynamic circuits; stabilizer sampling; Clifford circuits; adjoint gradients; density matrices')
paper['source_note'] = 'Integrated analysis of recorded statevector, MPS and execution-mode studies; no simulator measurements were rerun.'

p = first_para('Classical simulation supports')
p['text'] = p['text'].replace('matrix product states and dynamic circuits.',
 'matrix product states, dynamic circuits, Clifford sampling, adjoint gradients and density-matrix evaluation.')
p = first_para('The statevector analysis includes')
p['text'] = p['text'].replace('Together, the experiments',
 'The later execution-mode suite adds 24 conditions and 81 selected framework observations. Together, the experiments')
insert_after(p, [para('The specialized paths address different computational regimes. A stabilizer tableau exploits the Clifford gate class without requiring low entanglement, whereas an MPS exploits a bounded auxiliary dimension and can support general rotations with local truncation. Reusable dense-state adjoint handles target repeated variational gradients. We therefore assess representation, preparation and requested output separately, rather than pooling incompatible timing contracts. {{cite:modes_ag,schollwoeck2011,modes_adj,modes_suite}}')])
p = first_para('The contribution is a source-traceable')
p['text'] = p['text'].replace('The paper contains 104 tables and 36 figures.',
 'The integrated paper contains 132 tables and 42 figures. The later methods report adds mathematical descriptions of canonical MPS repair, two-site splitting, symbolic tableau measurements and prepared gradients, while the execution-mode suite adds measured sampling, gradient and density-matrix results. {{cite:modes_methods,modes_suite}}')

p = first_para('A native implementation can reduce')
regime = next(b for b in group('introduction') if b['type']=='figure')
insert_after(p, [para('Figure {{fig:modes_regimes}} distinguishes the representations used by the recorded paths. The stabilizer and Clifford labels share the same Pauli-frame engine; the gradient handle and density-matrix core are separate dense-state paths. The later report describes MPS mechanisms but does not establish which native source revision produced every earlier campaign record. {{cite:modes_methods,modes_suite}}'), regime])
p = first_para('The statevector evidence comes')
insert_after(p, [para('The three suites remain separate evidence strata. The statevector campaign supplies matched task records and controls, the MPS archive supplies bounded-bond and dynamic-circuit observations, and the later executed notebook supplies 24 specialized conditions. Duplicate copies within the execution-mode archive are reconciled as the same dataset. No combined compute total or global framework ranking is formed across these different workloads. {{cite:campaign,mpsbundle,modes_suite}}')])

math = group('math_methods')
math = [b for b in math if b.get('label')!='modes_mps_state']
math[0]['text'] = 'MPS canonical structure and local repair'
next(b for b in math if b['type']=='paragraph')['text'] = (
 'In the open-chain MPS representation above, each site tensor has a left bond, a right bond and a binary physical index. '
 'Both boundary bond dimensions equal one, and internal dimensions are bounded by chi. The O(n chi squared) storage order counts complex entries and is not a measured process-memory result.'
)
p = next(b for b in math if b['type']=='paragraph' and b['text'].startswith('The storage order counts'))
p['text'] = p['text'].replace('The storage order counts complex entries and is not a measured process-memory result. ', '')
insert_before_section('Results', math + [heading('Execution mode benchmark protocol')] + group('protocol'))
insert_before_section('Discussion', group('results'))

p = first_para('Bounded-bond MPS and native')
insert_after(p, [para('The later observations extend this contribution to preparation reuse. The same tableau path supplies 2,000-shot Clifford samples through 4,096 qubits, while a separately compiled handle evaluates ten dense-state gradient conditions. SuperFermion leads the available external field in 10 of 11 prepared sampling conditions and all ten recorded Qulacs gradient comparisons. Cold construction and the density-matrix counterexample show why these observations require explicit output and preparation contracts. {{cite:modes_suite}}')])
p = first_para('For variational and optimization')
p['text'] = ('For variational and optimization objectives, output-aware APIs should request the smallest result that satisfies the application. '
 'The later compiled-handle gradient experiment demonstrates a recorded benefit from separating construction and repeated evaluation, but it does not compare every analytic, adjoint, automatic-differentiation or parameter-shift route. '
 'The arithmetic compile-amortization analysis can guide repeated-use profiling, provided its estimate remains distinct from a measured cold end-to-end comparison.')
insert_after(p, [para('For Clifford sampling, preparation and output conversion need separate profiling. The random-Clifford measurement plan can dominate cold cost even when subsequent packed-shot counting is short. Equivalent count or sample-array outputs and balanced concurrency are needed to assess the effect of the affine plan independently. For density matrices, a follow-up should retain unrounded diagonal differences and complete off-diagonal checks before investigating performance, then extend validation to noisy channels.')])
p = first_para('The main statistical limitation')
p['text'] += ' The later mode suite reports means of two window medians, with different ordering in the sampling, gradient and density-matrix sections. It does not save complete per-call timing arrays, so those aggregates cannot supply a reconstructed uncertainty interval.'
p = first_para('Output fairness is also limited')
p['text'] += ' The mode suite additionally contrasts SuperFermion counts maps with Stim sample arrays, uses adapter-specific cold boundaries and fixes a four-thread Rayon limit for native paths while competitors use their defaults. These engine-level release-example paths are not identified as equivalent shipped Python interfaces.'
p = first_para('Measurement scope restricts memory')
p['text'] += ' The later execution-mode suite records no RAM field; its representation storage orders do not extend the process-RSS comparison.'
p = first_para('Implementation reproducibility remains')
p['text'] += ' The later adapter and executed notebook are available, while the complete native MPS, tableau, adjoint and density-matrix implementations cited by the methods report are not included. Source-comment MPS timings remain attributed context, with no component ablation or mapping to all earlier compiled revisions.'
insert_after(p, [para('Correctness coverage also differs across regimes. The later gradient parity is computed from the retained second-window vectors, and independent finite differences cover only eight qubits and one layer. GHZ support checks do not validate full brickwork or random-Clifford distributions. Trace, purity and diagonal checks cannot identify complete density matrices; the ten-qubit Aer diagonal flag therefore remains explicit and its performance comparison is unranked. {{cite:modes_suite}}')])

p = first_para('The replacement MPS results extend')
p['text'] = p['text'].replace(' The evidence supports practical software execution benefits under recorded workloads, with broader claims contingent on complete provenance and repeated controlled comparisons.', '')
insert_after(p, [para('The later 24-condition suite adds mathematical methods and specialized execution evidence. The shared stabilizer/Clifford engine is faster than every available external comparator in 10 of 11 prepared sampling conditions, with only four corresponding cold wins. All ten prepared adjoint gradients are below Qulacs, while the density-matrix path is faster at eight qubits and slower at twelve. The flagged ten-qubit comparison remains unranked. These results extend the observed scope without replacing or pooling the earlier statevector and MPS measurements.'),
 para('Across the three suites, the supported conclusion is practical execution efficiency for stated workloads and output contracts. Preparation reuse and representation selection are promising engineering mechanisms; their individual effects, public-interface parity and broad performance stability require complete native provenance, balanced repeated measurements and stronger distribution or matrix validation.')])

p = first_para('The accompanying source archive contains')
p['text'] = ('The accompanying source archive contains the supplied statevector reports, the MPS ZIP and its executed notebook, JSONL/CSV records, capability probe, narrative and original plots. '
 'It also contains the unchanged later methods report and execution-mode ZIP, together with its executed notebook, benchmark adapter, raw JSONL, four CSVs and original figure exports. '
 'Analysis scripts verify matching statevector conditions, reconcile MPS jobs and mode records with the supplied CSVs, regenerate figures and reconstruct tables. '
 'Each of the 182 selected MPS jobs occurs once in its detailed condition tables; all 24 specialized conditions have separate comparison tables. '
 'Source hashes, unit conversions, missing-data outcomes, numerical flags and arithmetic gradient-amortization estimates remain inspectable.')
p = first_para('The archive builds the paper')
p['text'] = ('One shared manuscript source builds the integrated LaTeX, PDF and Word text, table values, captions and editable Word equations without rerunning a quantum simulator. '
 'Raw source material is preserved for traceability and the nested mode results copy is not counted as an additional study. '
 'The manuscript retains the stated comparison sets and separates source-comment mechanisms from benchmark observations. '
 'Complete native implementation sources, the original statevector correctness artifacts and MPS supplementary interleaved calls remain requirements for independent reproduction.')

blocks.extend([{'type':'pagebreak'}, {'type':'heading','level':1,'text':'Execution mode comparisons by condition'}] + group('details'))
for b in blocks:
    if b['type']=='table' and b.get('label','').startswith('modes_adj_'):
        b['note'] = b['note'].replace('maximum over the two comparison windows',
                                     'maximum from the retained second comparison window')

counts = Counter(b['type'] for b in blocks)
assert (counts['table'],counts['figure'],counts['equation']) == (132,42,17), counts
assert len(paper['references']) == 21
labels = [b['label'] for b in blocks if 'label' in b]
assert len(labels)==len(set(labels))
for typ in ('table','figure','equation'):
    old = {b['label']:b for b in original['blocks'] if b['type']==typ}
    now = {b['label']:b for b in blocks if b['type']==typ}
    assert all(now[k]==v for k,v in old.items()), ('Changed original asset',typ)

shutil.copytree(BASE,OUT)
if (OUT/'data/build_validation.json').exists():
    (OUT/'data/build_validation.json').rename(OUT/'data/base_build_validation.json')
shutil.copytree(ADD/'source_modes',OUT/'source_modes',dirs_exist_ok=True)
for folder in ('figures','data'):
    for f in (ADD/folder).iterdir():
        if f.is_file() and (folder=='figures' or f.name not in ('manuscript.json','document_index.json','build_validation.json')):
            name='modes_'+f.name if folder=='data' and (OUT/folder/f.name).exists() else f.name
            shutil.copy2(f,OUT/folder/name)
for name in ('prepare_modes.py','write_modes_sections.py','export_fragments.py'):
    shutil.copy2(ADD/'scripts'/name,OUT/'scripts'/name)
(OUT/'scripts/prepare_modes.py').write_text((OUT/'scripts/prepare_modes.py').read_text().replace(
    'maximum over the two comparison windows','maximum from the retained second comparison window'))
detail = json.loads((OUT/'data/mode_detailed_tables.json').read_text())
for b in detail:
    if b['label'].startswith('modes_adj_'):
        b['note']=b['note'].replace('maximum over the two comparison windows','maximum from the retained second comparison window')
(OUT/'data/mode_detailed_tables.json').write_text(json.dumps(detail,indent=2)+'\n')
(OUT/'data/manuscript.json').write_text(json.dumps(paper,indent=2)+'\n')
(OUT/'data/equations.json').write_text(json.dumps([b for b in blocks if b['type']=='equation'],indent=2)+'\n')
shutil.copy2(Path(__file__),OUT/'scripts/integrate_manuscript.py')
receipt = {'base_tables_preserved':104,'base_figures_preserved':36,'base_equations_preserved':7,
    'added_tables':28,'added_figures':6,'added_nonduplicate_equations':10,'total_tables':132,
    'total_figures':42,'total_equations':17,'references':21,'later_conditions':24,
    'later_selected_framework_observations':81,'benchmarks_rerun':False,
    'changes':['Expanded abstract introduction discussion conclusion and availability',
               'Integrated mathematical methods and specialized benchmark protocol',
               'Integrated later results and condition appendix E',
               'Removed one duplicate MPS representation equation',
               'Corrected gradient parity provenance to the retained second window',
               'Preserved the failed 10-qubit Aer diagonal flag as unranked']}
(OUT/'data/merge_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
