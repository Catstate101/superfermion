# SuperFermion: A Leap Forward in Quantum Circuit Simulation Efficiency

Authors, in order: Md. Hasibul Hassan Himal; Muhebbullah Tamim. Both authors are affiliated with Catstate. Their email addresses and linked ORCID identifiers are included on the title page and in `data/manuscript.json`.

This preprint uses the requested SuperFermion 0.1.15 release label. Archived benchmark data and original input documents retain their original provenance and are not edited or rerun.

This package contains the current full paper with the later mathematical methods and execution-mode experiments integrated into its abstract, introduction, methods, results, discussion, conclusion and availability statement. Original statevector and MPS numerical tables, figures and equations are preserved. The specialized conditions are added in Appendix E.

The complete manuscript has 132 tables, 42 figures, 17 equations and 21 deduplicated references. The PDF has 107 pages; the verified Word rendering has 105 pages. Both versions share the same text, table values, captions and equation content. Word display equations are native editable OMML objects.

## Evidence

- Statevector study: six configurations on 252 matching conditions each, comprising 1,512 simulator records and 140 controls.
- MPS and dynamic-circuit study: 182 selected unique jobs, including 141 successful observations.
- Later execution-mode study: 24 conditions, comprising six stabilizer, five large-Clifford, ten adjoint-gradient and three density-matrix conditions; 81 selected primary-path and external-framework observations.

The three studies retain their own timing, output, precision and correctness contracts. No cross-study compute total is introduced, no new simulator measurements were run, and the duplicate nested mode-results bundle is not counted as an independent experiment.

Stabilizer and Clifford labels share the same Pauli-frame path. Density-matrix measurements use the separate native core, while the planner density mode is held out. The 10-qubit Aer diagonal-check flag remains visible and its validated timing ranking is withheld. MPS values from source comments are separately attributed context. The mode suite has no measured RAM field.

The merge corrects the gradient-table note: SF/Qulacs component-wise parity is calculated from retained second-window vectors, while timing summaries are means of two window medians. One duplicate MPS representation equation has been removed without dropping its mathematical content.

## Package contents

- `main.tex`, `main.bbl`, `references.bib`: complete integrated manuscript and bibliography.
- `tables/`: all 132 numbered table sources.
- `figures/`: all 42 figures in vector PDF/SVG and high-resolution PNG.
- `data/manuscript.json`: canonical shared manuscript for rebuilding LaTeX and Word.
- `data/document_index.json`: regenerated table, figure and citation numbers.
- `data/equations.json`: 17 nonduplicate display equations.
- `data/build_validation.json`, `data/merge_receipt.json`: final validation and integration records.
- `data/base_manuscript.json`, `data/modes_standalone_manuscript.json`: unchanged input manuscript content for provenance.
- `data/`: original statevector/MPS analysis and later selected observations, numerical audit, condition tables and gradient-amortization calculations.
- `source_reports/`, `source_mps/`: unchanged earlier benchmark evidence.
- `source_modes/`: unchanged later methods report, benchmark ZIP and complete extracted notebook, code, data and original plots.
- `scripts/`: saved-data analysis, document builders and integrated-content validation.
- `provenance/original_generators/`: original standalone authoring and one-time integration scripts, retained as history rather than rebuild entry points.

## Compile with Overleaf or a TeX installation

Upload this ZIP to Overleaf, choose `main.tex`, and select pdfLaTeX. Figures, table sources and the compiled bibliography are included. A standard TeX Live or MiKTeX installation can compile the source with:

```sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The equivalent wrapper is:

```sh
python scripts/build_pdf.py --package-dir . --output-file build/SuperFermion_TechRxiv_Paper.pdf
```

Compilation requires only standard LaTeX packages: geometry, amsmath, amssymb, graphicx, booktabs, tabularx, array, caption, xurl, hyperref and needspace. Quantum simulator dependencies are not required to compile the paper.

## Rebuild the Word file and shared LaTeX

Install `requirements-analysis.txt` and Pandoc, then run:

```sh
python scripts/build_documents.py --package-dir . --output-dir build
python scripts/build_pdf.py --package-dir . --output-file build/SuperFermion_TechRxiv_Paper.pdf
```

The Word output is `build/SuperFermion_TechRxiv_Paper.docx`. The builder regenerates table sources, citations and references from the canonical manuscript. Equation conversion uses Pandoc to create native editable Word math.

## Saved-data analysis and verification

Analysis scripts operate on saved measurements:

```sh
python scripts/prepare_study.py --package-dir .
python scripts/prepare_modes.py --package-dir .
```

They regenerate numerical analysis and figures without executing a simulator. The canonical manuscript remains the editorial source; these analysis commands do not overwrite it. If benchmark records change, review and update embedded manuscript claims and table values before rebuilding the documents.

Validate a rebuilt integrated document with:

```sh
python scripts/validate_merged.py --package-dir . --pdf build/SuperFermion_TechRxiv_Paper.pdf --docx build/SuperFermion_TechRxiv_Paper.docx
```

Add `--word-pdf /path/to/rendered-word.pdf` to check a Word PDF export. Validation verifies table cells, image/equation counts, captions, source hashes, original numerical content, correctness flags and text bounds. Visual inspection is still required after layout changes.

Independent simulator reproduction requires missing native implementation sources and the build environment. Recorded source identifiers, package versions, guards, output contracts and limitations are retained in the manuscript and raw evidence.
