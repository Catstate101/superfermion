"""Build _sfcat_bench.ipynb -- self-contained sf-cat Clifford benchmark notebook.

The notebook is the primary artifact and is fully self-contained:
  * competitor lanes (stim / aer / pl / cirq) run IN-PROCESS in the kernel,
  * the cat_pf + sf-ir lanes run via the l1_bench example subprocess
    (Rust-native, RAYON_NUM_THREADS=4, process startup excluded by design),
  * the LAST CELL writes sfcat_bench_results_<host>.zip containing the csv,
    jsonl, summary json, report.md and figures -- run it in Colab/Jupyter and
    the zip (with a download link) is produced there.

Op streams (LAYER_SEED=11, CLIFF_SEED=7, depth 8), lane recipes, caps and
fairness notes are copied VERBATIM from the shipped sim4 scripts
(sim4_bench_suite/_sf_cat_l1_ab.py, _sf_cat_vs_all.py) -- this notebook
re-produces that comparison in a fresh window.

Usage: python _sfcat_bench_build.py    (writes _sfcat_bench.ipynb next to it)
"""
from __future__ import annotations

import pathlib

HERE = pathlib.Path(__file__).resolve().parent
NB = HERE / "_sfcat_bench.ipynb"
CELLS = []


def md(src):
    CELLS.append({"cell_type": "markdown", "metadata": {}, "source": src})


def code(src):
    CELLS.append({"cell_type": "code", "metadata": {}, "execution_count": None,
                  "outputs": [], "source": src})


md(r'''# sf-cat benchmark suite — Clifford/stabilizer sampling round

**Lane under test:** `cat_pf` — the SuperFermion Rust-native Pauli-frame ("cat")
sampler from the `sf-cat` release example `l1_bench` (subprocess, 4-thread
RAYON; in-process timing, process startup excluded).

**Competitors (this class only):** `stim` (reference tableau sampler),
`aer` (`AerSimulator(method='stabilizer')`), `pl` (`default.clifford`,
stim-backed), `cirq` (`CliffordSimulator`). The operator streams
(`ghz`, seeded `brick` depth-8) are **bit-identical on every engine**
(LAYER_SEED=11, CLIFF_SEED=7 — same streams as the shipped sim4 campaign).

**Workload:** n = 64 / 256 / 1024 / 4096, 2000 shots per sample, ABBA window
order per rung (cat, stim, aer, pl, cirq | cirq, pl, aer, stim, cat), two
windows per lane, headline = window mean.

**Headline questions:**
- cold (build + first sample): when does the Rust tableau pipeline beat the
  Python engines' setup + first sample?
- warm (prepared sampler, counts-map output class): who samples fastest?
- where do the caps/probes (cirq n<=64, aer n<=256) and budget guard bite?

**Outputs:** this notebook embeds every table, figure and verdict as executed;
the **last cell** writes `sfcat_bench_results_<host>.zip` (csv + jsonl +
summary json + report.md + figures).''')

md(r'''## Method, fairness & disclosures

| item | definition |
|---|---|
| `cat_pf` cold | tableau build + plan + first sample in ONE timed region (strict end-to-end) |
| `cat_pf` warm | sample-only repeats from the prepared sampler; `pack` = raw (shots,n) array class, `counts` = counts-map class (what the product path returns) |
| `stim` cold / warm | compile_sampler + sample (one region) / sampler reuse (`sample(shots)`) |
| `aer` cold / warm | circuit build + measure_all + fresh `AerSimulator` per rep / fixed circuit, fresh simulator per rep (worker recipe) |
| `pl` cold / warm | fresh device + QNode + first call / QNode re-run (tape re-emitted per call) |
| `cirq` cold / warm | build + fresh `CliffordSimulator` + first run / fresh simulator per rep |
| `sf-ir` | the sf-ir StabilizerTableau lane from the SAME l1_bench process (same-window reference for where the cat_pf win comes from) |

**Fairness / honesty notes**
- `cat_pf` runs 4-thread RAYON (sim4 convention, SF_THREADS=4); competitors run
  their shipped defaults (single-threaded tableau backends).
- `cat_pf` is Rust-native and NOT yet reachable from the Python package — this
  compares engines, not shipped APIs. Product-path numbers are a different lane.
- Per-lane first call is guarded by a **40 s budget**: a lane that exceeds it is
  recorded `over_budget` (it cannot be ranked — no claim is made).
- `cirq` is capped at n<=64 (cost probes 2026-10-12: ghz n=64 = 33.7 s/call at
  shots=2000; ghz n=256 = 375.4 s) and `aer` at n<=256 (brick n=1024 = 102.4 s);
  above the cap the lane is `not_run_capped` — never fabricated.
- GHZ support check: every lane that samples GHZ at n<=256 must produce only
  the all-0/all-1 branches (validated live; see `ghz_ok`).
- qulacs / qiskit-family are **not offered** in this class (no stabilizer
  sampling engine) — no lane is fabricated for them.

**Re-run behavior:** rows are appended to `sfcat_bench_out/sfcat_bench.jsonl`
with a config hash; re-running the notebook skips (rung x config) cells already
measured and lands new rows in a fresh window.''')

code(r'''# ==== Setup / config ====
import hashlib
import json
import os
import pathlib
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import zipfile

HOST = socket.gethostname().split(".")[0].lower()
HERE = pathlib.Path.cwd()
OUT = HERE / "sfcat_bench_out"
(OUT / "figs").mkdir(parents=True, exist_ok=True)

# the sf-cat release example binary (Windows dev box default; env-overridable,
# plus a relative fallback so a Linux/macOS build works unmodified)
EXE = pathlib.Path(os.environ.get("L1_BENCH_EXE",
                                  r"D:\sf_cat_target\release\examples\l1_bench.exe"))
if not EXE.exists():
    for cand in ("l1_bench", "_bin/l1_bench", "bin/l1_bench"):
        p = HERE / cand
        if p.exists():
            EXE = p
            break
CAT_OK = EXE.exists() and EXE.is_file()

_win_d = pathlib.Path("D:/")
_default_tmp = (r"D:\sf_cat_bench\tmp" if platform.system() == "Windows" and _win_d.exists()
                else tempfile.gettempdir())
TMP = pathlib.Path(os.environ.get("L1_BENCH_TMP", _default_tmp))
TMP.mkdir(parents=True, exist_ok=True)

GRID = dict(ns=[64, 256, 1024, 4096], circuits=["ghz", "brick"], depth=8,
            shots=2000, reps=7, comp_reps=3, comp_cold_reps=2, cirq_reps=1,
            budget=40.0, cirq_max_n=64, aer_max_n=256)
LAYER_SEED = 11   # seeded brick H/CX/S flags shared by every engine
CLIFF_SEED = 7    # sampling seed
COMPETITORS = ["stim", "aer", "pl", "cirq"]
PROBE_EVIDENCE = {
    "cirq": "cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; "
            "ghz n=256 = 375.4 s -- warm reps=1, no reuse row",
    "aer": "single-call cost probe 2026-10-12: brick n=1024 = 102.4 s",
}
BOUNDARY_PROBE = {
    "what": "repeated ghz@64 rung re-runs (identical ABBA recipes) probing the 40 s cirq guard",
    "when": "2026-10-12 23:51-00:07", "rungs": 5, "windows": 10,
    "cirq_first_call_min_s": 28.0, "cirq_first_call_max_s": 33.3,
    "cirq_first_calls_over_budget": "0/10", "cirq_calls_over_budget": "0/30",
    "cirq_call_max_s": 37.2,
    "cross_window": "the same rung/build/recipes measured 67.2 s (over_budget) in the "
                    "2026-10-12 16:25 gen-A window -- the guard outcome flips with window state",
    "strict_cold_flicker": "1/5 probe rungs: cat cold 0.414 ms vs stim full 0.399 ms "
                           "(~15 us cross at the sub-ms resolution floor) -> cold flag False",
    "evidence": "sfcat_bench_out/boundary_probe_ghz64.json (raw rows) + "
                "_sfcat_boundary_probe_ghz64.log (suite folder)",
}
EXE_MD5 = hashlib.md5(EXE.read_bytes()).hexdigest()[:12] if CAT_OK else None
CFG_HASH = hashlib.md5(json.dumps(
    [GRID, LAYER_SEED, CLIFF_SEED, EXE_MD5, str(EXE)], sort_keys=True).encode()
).hexdigest()[:10]

print(f"host: {HOST} | python {sys.version.split()[0]} on {platform.system()}")
print(f"cat lane: {'ACTIVE  ' + str(EXE) + '  md5:' + str(EXE_MD5) if CAT_OK else 'NOT AVAILABLE (l1_bench binary not found on this host) -> cat rows recorded not_available'}")
print(f"scratch : {TMP}")
print(f"grid    : ns={GRID['ns']} circuits={GRID['circuits']} shots={GRID['shots']} "
      f"reps={GRID['reps']} depth={GRID['depth']} cfg_hash={CFG_HASH}")
print(f"caps    : cirq<={GRID['cirq_max_n']} (probe {PROBE_EVIDENCE['cirq'].split(';')[0]})")
print(f"          aer <={GRID['aer_max_n']} (probe {PROBE_EVIDENCE['aer']})")''')

code(r'''# ==== Dependencies (Colab-safe: installs only what is missing) ====
import importlib

INSTALL_IF_MISSING = True
_PIP = {"stim": "stim", "qiskit": "qiskit", "qiskit_aer": "qiskit-aer",
        "pennylane": "pennylane", "cirq": "cirq-core"}
missing = [pkg for mod, pkg in _PIP.items() if importlib.util.find_spec(mod) is None]
if missing and INSTALL_IF_MISSING:
    print("installing lane dependencies:", missing)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", *missing],
                   check=False, capture_output=True)
missing = [mod for mod in _PIP if importlib.util.find_spec(mod) is None]
print("missing lane deps after setup:", missing if missing else "none")

VERSIONS = {}
for mod in ("numpy", "pandas", "matplotlib", "stim", "qiskit", "qiskit_aer",
            "pennylane", "cirq"):
    if importlib.util.find_spec(mod) is not None:
        m = importlib.import_module(mod)
        VERSIONS[mod] = getattr(m, "__version__", "?")
print("versions:", json.dumps(VERSIONS))''')

code(r'''# ==== Engine lanes (op streams + recipes copied VERBATIM from the shipped campaign) ====
# ---- op streams (bit-identical on every engine: LAYER_SEED / CLIFF_SEED) ----
def ghz_ops(n):
    return [("h", 0)] + [("cx", 0, i) for i in range(1, n)]

def brick_ops(n, depth, seed=LAYER_SEED):
    import numpy as np
    rng = np.random.default_rng(seed)
    ops = []
    for _ in range(depth):
        ops += [("h", q) for q in range(n)]
        ops += [("cx", q, q + 1) for q in range(0, n - 1, 2)]
        fl = rng.integers(0, 2, size=n)
        ops += [("s", q) for q in range(n) if fl[q]]
        ops += [("cx", q, q + 1) for q in range(1, n - 1, 2)]
    return ops

def brick_gate_count(n, depth, seed=LAYER_SEED):
    import numpy as np
    rng = np.random.default_rng(seed)
    s_tot = 0
    for _ in range(depth):
        s_tot += int(rng.integers(0, 2, size=n).sum())
    return depth * (n + n // 2 + (n - 1) // 2) + s_tot

# ---- timing helpers ----
def median(values):
    xs = sorted(values)
    m = len(xs) // 2
    return xs[m] if len(xs) % 2 else 0.5 * (xs[m - 1] + xs[m])

def mean_of(a, b):
    return 0.5 * (a + b)

def timed_reps(fn, reps):
    fn()  # warm pass, excluded
    times = []
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t0)
    return times

class OverBudget(Exception):
    pass

def _probe(fn, budget):
    t0 = time.perf_counter()
    out = fn()
    dt = time.perf_counter() - t0
    if dt > budget:
        raise OverBudget(f"first call {dt:.1f}s > budget {budget:.0f}s")
    return out, dt

def _branch_ok(arr, n):
    import numpy as np
    uniq = np.unique(np.asarray(arr), axis=0)
    ok = all(bool((row == 0).all() or (row == 1).all()) for row in uniq)
    return ok, int(uniq.shape[0])

# ---- cat_pf / sf-ir lane: the Rust example binary (in-process timing inside;
#      process startup is EXCLUDED by design; two window calls per rung) ----
def rust_lane(ops, n, shots, reps):
    job = {"n": n, "ops": [[o[0], *o[1:]] for o in ops], "shots": shots,
           "reps": reps, "seed": CLIFF_SEED}
    job_path = TMP / f"sfcat_job_n{n}.json"
    job_path.write_text(json.dumps(job), encoding="utf-8")
    env = dict(os.environ)
    env["RAYON_NUM_THREADS"] = "4"  # sim4 convention: SF_THREADS=4
    p = subprocess.run([str(EXE), str(job_path)], capture_output=True,
                       text=True, env=env, timeout=1800)
    if p.returncode != 0:
        raise RuntimeError(f"l1_bench failed rc={p.returncode}: {p.stderr[-300:]}")
    line = [l for l in p.stdout.splitlines() if l.strip().startswith("{")][-1]
    return json.loads(line)

# ---- stim lane (worker recipe: compile + sample inside the timed region) ----
def stim_lane(ops, n, shots, reps):
    import stim
    c = stim.Circuit()
    for op in ops:
        name = op[0].lower()
        if name == "h":
            c.append("H", [op[1]])
        elif name == "cx":
            c.append("CX", [op[1], op[2]])
        elif name == "s":
            c.append("S", [op[1]])
        else:
            raise ValueError(name)
    c.append("M", list(range(n)))
    full = timed_reps(lambda: c.compile_sampler().sample(shots=shots), reps)
    samp = c.compile_sampler()
    warm = timed_reps(lambda: samp.sample(shots=shots), reps)
    return {"full_ms": median(full) * 1e3, "sample_ms": median(warm) * 1e3,
            "version": getattr(stim, "__version__", "?")}

# ---- competitor lanes (recipes copied VERBATIM from the shipped worker) ----
def aer_lane(ops, n, shots, reps, cold_reps, budget, circ):
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    out = {"status": "ok", "api": "AerSimulator(method='stabilizer')"}

    def build():
        qc = QuantumCircuit(n)
        for op in ops:
            if op[0] == "h":
                qc.h(op[1])
            elif op[0] == "s":
                qc.s(op[1])
            elif op[0] == "cx":
                qc.cx(op[1], op[2])
            else:
                raise ValueError(str(op))
        qcm = qc.copy()
        qcm.measure_all()
        return qcm

    def fresh_run(qcm):
        return AerSimulator(method="stabilizer").run(
            qcm, shots=shots, seed=CLIFF_SEED).result()

    qcm = build()
    last, _ = _probe(lambda: fresh_run(qcm), budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        fresh_run(build())
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = fresh_run(qcm)
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    sim = AerSimulator(method="stabilizer")
    last = sim.run(qcm, shots=shots, seed=CLIFF_SEED).result()
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = sim.run(qcm, shots=shots, seed=CLIFF_SEED).result()
        ts.append(time.perf_counter() - t0)
    out["reuse_ms"] = median(ts) * 1e3
    cnt = dict(last.get_counts())
    out["keys"] = len(cnt)
    if circ == "ghz":
        out["ghz_ok"] = bool(set(cnt) <= {"0" * n, "1" * n})
    return out

def pl_lane(ops, n, shots, reps, cold_reps, budget, circ):
    import numpy as np
    import pennylane as qml
    out = {"status": "ok", "api": "default.clifford"}

    def emit():
        for op in ops:
            if op[0] == "h":
                qml.Hadamard(op[1])
            elif op[0] == "s":
                qml.S(op[1])
            elif op[0] == "cx":
                qml.CNOT(wires=[op[1], op[2]])
            else:
                raise ValueError(str(op))

    def make():
        dev = qml.device("default.clifford", wires=n, shots=shots)

        @qml.qnode(dev)
        def samp():
            emit()
            return qml.sample(wires=list(range(n)))

        return samp

    samp = make()
    last, _ = _probe(samp, budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        make()()
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = samp()
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    arr = np.asarray(last)
    if circ == "ghz":
        ok, kb = _branch_ok(arr, n)
        out["ghz_ok"] = bool(ok)
        out["ghz_branches"] = kb
    else:
        out["keys"] = int(np.unique(arr, axis=0).shape[0])
    return out

def cirq_lane(ops, n, shots, reps, cold_reps, budget, circ):
    import cirq
    import numpy as np
    out = {"status": "ok", "api": "CliffordSimulator"}
    q = cirq.LineQubit.range(n)

    def build():
        items = []
        for op in ops:
            if op[0] == "h":
                items.append(cirq.H(q[op[1]]))
            elif op[0] == "s":
                items.append(cirq.S(q[op[1]]))
            elif op[0] == "cx":
                items.append(cirq.CNOT(q[op[1]], q[op[2]]))
            else:
                raise ValueError(str(op))
        items.append(cirq.measure(*q, key="m"))
        return cirq.Circuit(items)

    def fresh_run(c):
        return cirq.CliffordSimulator(seed=CLIFF_SEED).run(
            c, repetitions=shots).measurements["m"]

    c = build()
    last, _ = _probe(lambda: fresh_run(c), budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        fresh_run(build())
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = fresh_run(c)
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    out["reuse_ms"] = None  # cirq re-compiles per run; reuse == warm, not measured
    arr = np.asarray(last)
    if circ == "ghz":
        ok, kb = _branch_ok(arr, n)
        out["ghz_ok"] = bool(ok)
        out["ghz_branches"] = kb
    else:
        out["keys"] = int(np.unique(arr, axis=0).shape[0])
    return out

LANE_FN = {"aer": aer_lane, "pl": pl_lane, "cirq": cirq_lane}

def comp_lane(lane, ops, n, shots, reps, cold_reps, budget, circ):
    try:
        return LANE_FN[lane](ops, n, shots, reps, cold_reps, budget, circ)
    except OverBudget as e:
        return {"status": "over_budget", "note": str(e)}
    except Exception as e:  # fail-soft, honest
        return {"status": f"error: {type(e).__name__}: {e}"}

def stim_branch_check(ops, n, shots):
    import stim
    c = stim.Circuit()
    for op in ops:
        if op[0] == "h":
            c.append("H", [op[1]])
        elif op[0] == "cx":
            c.append("CX", [op[1], op[2]])
        elif op[0] == "s":
            c.append("S", [op[1]])
    c.append("M", list(range(n)))
    arr = c.compile_sampler().sample(shots=shots)
    ok, kb = _branch_ok(arr, n)
    return {"ghz_ok": bool(ok), "ghz_branches": kb}

def combine(win_a, win_b, fields):
    out = {}
    for f in fields:
        va, vb = win_a.get(f), win_b.get(f)
        out[f] = (mean_of(va, vb) if isinstance(va, (int, float))
                  and isinstance(vb, (int, float)) else None)
    return out

print("lanes ready | cat lane:", "ACTIVE" if CAT_OK else "not available on this host")''')

code(r'''# ==== RUN — ABBA windows per rung; resumable via config hash ====
ROWS_JSONL = OUT / "sfcat_bench.jsonl"
rows = []
if ROWS_JSONL.exists():
    for line in ROWS_JSONL.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            if r.get("cfg_hash") == CFG_HASH:
                rows.append(r)
done = {(r["circuit"], int(r["n"])) for r in rows}
n_cached = len(done)
print(f"rungs cached for cfg {CFG_HASH}: {n_cached}")

def _cat_dict(c1, c2):
    if isinstance(c1, dict) and isinstance(c2, dict) and "cat_pf" in c1 and "cat_pf" in c2:
        a, b = c1["cat_pf"], c2["cat_pf"]
        return {
            "cold_ms": mean_of(a["cold_ms"], b["cold_ms"]),
            "build_ms": mean_of(a["build_ms"], b["build_ms"]),
            "plan_ms": mean_of(a["plan_ms"], b["plan_ms"]),
            "pack_ms": mean_of(a["sample_pack_ms"], b["sample_pack_ms"]),
            "counts_ms": mean_of(a["sample_counts_ms"], b["sample_counts_ms"]),
            "keys": b["keys"],
        }
    return None

def _assemble(circ, n, gates, wins):
    row = {"circuit": circ, "n": n, "shots": GRID["shots"], "gates": gates,
           "cfg_hash": CFG_HASH}
    c1, c2 = wins["cat"]
    cat = _cat_dict(c1, c2)
    if cat is None:
        bad = c1 if not (isinstance(c1, dict) and "cat_pf" in c1) else c2
        row["cat_status"] = (bad.get("status") if isinstance(bad, dict) else "not_available")
    s1, s2 = wins["stim"]
    if all(isinstance(x, dict) and "full_ms" in x for x in (s1, s2)):
        stim = combine(s1, s2, ["full_ms", "sample_ms"])
        stim["version"] = s2.get("version")
    else:
        bad = s1 if not (isinstance(s1, dict) and "full_ms" in s1) else s2
        stim = {"status": (bad.get("status") if isinstance(bad, dict) else "error"),
                "note": str(bad)[:200]}
    comp = {}
    for lane in ("aer", "pl", "cirq"):
        a, b = wins[lane]
        if all(isinstance(x, dict) and x.get("status") == "ok" for x in (a, b)):
            d = combine(a, b, ["cold_ms", "warm_ms", "reuse_ms"])
            d["status"] = "ok"
            d["api"] = b.get("api")
            for k in ("ghz_ok", "ghz_branches", "keys"):
                if k in b:
                    d[k] = b[k]
            comp[lane] = d
        else:
            bad = a if not (isinstance(a, dict) and a.get("status") == "ok") else b
            comp[lane] = {"status": (bad.get("status") if isinstance(bad, dict) else "error"),
                          "note": (bad.get("note") if isinstance(bad, dict) else str(bad)[:200])}
    if circ == "ghz" and "full_ms" in stim:
        try:
            stim.update(stim_branch_check(ghz_ops(n), n, GRID["shots"]))
        except Exception as e:
            stim["ghz_check_error"] = str(e)[:160]
    if cat and circ == "ghz":
        cat["ghz_ok"] = cat["keys"] == 2
    cold_ref = {"stim": stim.get("full_ms")}
    warm_ref = {"stim": stim.get("sample_ms")}
    for lane in ("aer", "pl", "cirq"):
        cold_ref[lane] = comp[lane].get("cold_ms")
        warm_ref[lane] = comp[lane].get("warm_ms")
    avail_cold = [l for l in COMPETITORS if cold_ref.get(l)]
    avail_warm = [l for l in COMPETITORS if warm_ref.get(l)]
    if cat:
        rank_cold = {l: cat["cold_ms"] < cold_ref[l] for l in avail_cold}
        rank_warm = {l: cat["counts_ms"] < warm_ref[l] for l in avail_warm}
        row["win_cold"] = rank_cold
        row["win_warm"] = rank_warm
        row["beats_all_cold"] = all(rank_cold.values()) if len(avail_cold) == len(COMPETITORS) else None
        row["beats_all_warm"] = all(rank_warm.values()) if len(avail_warm) == len(COMPETITORS) else None
        row["beats_available_cold"] = bool(rank_cold) and all(rank_cold.values())
        row["beats_available_warm"] = bool(rank_warm) and all(rank_warm.values())
    else:
        row["win_cold"] = row["win_warm"] = None
        row["beats_all_cold"] = row["beats_all_warm"] = None
        row["beats_available_cold"] = row["beats_available_warm"] = None
    row["unranked"] = [l for l in COMPETITORS if not cold_ref.get(l) or not warm_ref.get(l)]
    row["cat"] = cat
    row["sf_ir"] = c2.get("sf_ir") if isinstance(c2, dict) else None
    row["stim"] = stim
    row["comp"] = comp
    return row

def _win_status(lane, w):
    if lane == "cat":
        return "ok" if isinstance(w, dict) and "cat_pf" in w else str(w.get("status") if isinstance(w, dict) else w)
    if lane == "stim":
        return "ok" if isinstance(w, dict) and "full_ms" in w else str(w.get("status") if isinstance(w, dict) else w)
    return str(w.get("status") if isinstance(w, dict) else w)

for circ in GRID["circuits"]:
    for n in GRID["ns"]:
        if (circ, n) in done:
            print(f"{circ:5s} n={n:5d} | cached (cfg {CFG_HASH})", flush=True)
            continue
        ops = ghz_ops(n) if circ == "ghz" else brick_ops(n, GRID["depth"])
        gates = None if circ == "ghz" else brick_gate_count(n, GRID["depth"])
        wins = {"cat": [], "stim": [], "aer": [], "pl": [], "cirq": []}
        order = ["cat", "stim", "aer", "pl", "cirq", "cirq", "pl", "aer", "stim", "cat"]
        print(f"{circ:5s} n={n:5d} | windows: " + " ".join(order), flush=True)
        for lane in order:
            if lane == "cat":
                if CAT_OK:
                    try:
                        wins["cat"].append(rust_lane(ops, n, GRID["shots"], GRID["reps"]))
                    except Exception as e:
                        wins["cat"].append({"status": f"error: {type(e).__name__}: {e}"})
                else:
                    wins["cat"].append({"status": "not_available",
                                        "note": "l1_bench example binary not present on this host"})
            elif lane == "stim":
                try:
                    wins["stim"].append(stim_lane(ops, n, GRID["shots"], GRID["reps"]))
                except Exception as e:
                    wins["stim"].append({"status": f"error: {type(e).__name__}: {e}"})
            else:
                cap = (GRID["cirq_max_n"] if lane == "cirq"
                       else GRID["aer_max_n"] if lane == "aer" else None)
                if cap is not None and n > cap:
                    wins[lane].append({
                        "status": "not_run_capped",
                        "note": f"n>{cap}: not attempted in the ladder; {PROBE_EVIDENCE[lane]}"})
                    print(f"   [{lane:5s}] {len(wins[lane])}/2 not_run_capped (n>{cap})", flush=True)
                    continue
                if lane == "cirq":
                    creps, cold = GRID["cirq_reps"], 1
                else:
                    creps, cold = GRID["comp_reps"], GRID["comp_cold_reps"]
                wins[lane].append(comp_lane(lane, ops, n, GRID["shots"], creps, cold,
                                            GRID["budget"], circ))
            print(f"   [{lane:5s}] {len(wins[lane])}/2 {_win_status(lane, wins[lane][-1])}", flush=True)
        row = _assemble(circ, n, gates, wins)
        rows.append(row)
        with ROWS_JSONL.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row) + "\n")
        fmt = lambda v: f"{v:9.3f}" if isinstance(v, (int, float)) else "      n/a"
        ca = row.get("cat") or {}
        cp = row["comp"]
        cr = row.get("win_cold") or {}
        wr = row.get("win_warm") or {}
        print(f"{circ:5s} n={n:5d} | cold ms: cat {fmt(ca.get('cold_ms'))} "
              f"stim {fmt(row['stim'].get('full_ms'))} aer {fmt(cp['aer'].get('cold_ms'))} "
              f"pl {fmt(cp['pl'].get('cold_ms'))} cirq {fmt(cp['cirq'].get('cold_ms'))} | "
              f"warm ms: cat {fmt(ca.get('counts_ms'))} stim {fmt(row['stim'].get('sample_ms'))} "
              f"aer {fmt(cp['aer'].get('warm_ms'))} pl {fmt(cp['pl'].get('warm_ms'))} "
              f"cirq {fmt(cp['cirq'].get('warm_ms'))} | "
              f"cold {sum(cr.values())}/{len(cr)} warm {sum(wr.values())}/{len(wr)}", flush=True)
print(f"\nRUN complete: {len(rows)} rung rows ({n_cached} cached) -> {ROWS_JSONL.name}")''')

code(r'''# ==== Tables + CSV + summary JSON ====
import pandas as pd

def _cat_ms(r, field):
    return (r.get("cat") or {}).get(field)

def _fir_ms(r, field):
    return (r.get("sf_ir") or {}).get(field)

def _stim_ms(r, field):
    return (r.get("stim") or {}).get(field)

def _comp_ms(r, lane, field):
    return ((r.get("comp") or {}).get(lane) or {}).get(field)

recs = []
for r in rows:
    recs.append({
        "circuit": r["circuit"], "n": r["n"], "shots": r["shots"], "gates": r.get("gates"),
        "cat_cold_ms": _cat_ms(r, "cold_ms"), "cat_build_ms": _cat_ms(r, "build_ms"),
        "cat_plan_ms": _cat_ms(r, "plan_ms"), "cat_pack_ms": _cat_ms(r, "pack_ms"),
        "cat_counts_ms": _cat_ms(r, "counts_ms"), "cat_keys": _cat_ms(r, "keys"),
        "sfir_cold_ms": _fir_ms(r, "cold_ms"), "sfir_sample_ms": _fir_ms(r, "sample_ms"),
        "stim_full_ms": _stim_ms(r, "full_ms"), "stim_sample_ms": _stim_ms(r, "sample_ms"),
        "aer_cold_ms": _comp_ms(r, "aer", "cold_ms"), "aer_warm_ms": _comp_ms(r, "aer", "warm_ms"),
        "pl_cold_ms": _comp_ms(r, "pl", "cold_ms"), "pl_warm_ms": _comp_ms(r, "pl", "warm_ms"),
        "cirq_cold_ms": _comp_ms(r, "cirq", "cold_ms"), "cirq_warm_ms": _comp_ms(r, "cirq", "warm_ms"),
        "cirq_status": _comp_ms(r, "cirq", "status"), "cirq_note": _comp_ms(r, "cirq", "note"),
        "beats_available_cold": r.get("beats_available_cold"),
        "beats_available_warm": r.get("beats_available_warm"),
        "cat_status": ("ok" if r.get("cat") else (r.get("cat_status") or "not_available")),
    })
df = pd.DataFrame(recs)
df.to_csv(OUT / "sfcat_bench_rows.csv", index=False)

cold_cols = ["circuit", "n", "cat_cold_ms", "sfir_cold_ms", "stim_full_ms", "aer_cold_ms", "pl_cold_ms", "cirq_cold_ms"]
warm_cols = ["circuit", "n", "cat_counts_ms", "sfir_sample_ms", "stim_sample_ms", "aer_warm_ms", "pl_warm_ms", "cirq_warm_ms"]
print("== cold (ms) ==")
print(df[cold_cols].to_string(index=False, float_format=lambda v: f"{v:.4g}"))
print()
print("== warm (ms) ==")
print(df[warm_cols].to_string(index=False, float_format=lambda v: f"{v:.4g}"))
print()
print("== statuses / available-lane verdicts ==")
print(df[["circuit", "n", "cat_status", "cirq_status", "beats_available_cold", "beats_available_warm"]].to_string(index=False))

def _strict_boundary_notes(rows_in, budget_s=GRID["budget"]):
    """Strict-win rungs that sit on the 40 s guard: disclose, do not claim a stable win."""
    notes = []
    for r in rows_in:
        if not (r.get("beats_all_cold") or r.get("beats_all_warm")):
            continue
        cirq = ((r.get("comp") or {}).get("cirq") or {})
        times = {k: cirq.get(k) for k in ("cold_ms", "warm_ms")}
        if not any(isinstance(v, (int, float)) for v in times.values()):
            continue
        seg = ", ".join(f"{k.replace('_ms', '')} {v / 1e3:.1f} s" for k, v in times.items()
                        if isinstance(v, (int, float)))
        margin_s = min(budget_s - v / 1e3 for v in times.values()
                       if isinstance(v, (int, float)))
        notes.append(
            f"{r['circuit']}@n={r['n']} strict win is BUDGET-BOUNDARY data, not a stable "
            f"strict win: the strict comb only computes when cirq ranks, and cirq's time "
            f"straddles the {budget_s:.0f} s first-call guard (this window: {seg}, tightest "
            f"margin {margin_s:.1f} s; cross-window: {BOUNDARY_PROBE['cross_window']}).")
    return notes

boundary_notes = _strict_boundary_notes(rows)
print()
for n_ in boundary_notes:
    print("boundary:", n_)

SUMMARY = {
    "generated": time.strftime("%Y-%m-%dT%H:%M:%S"), "host": HOST,
    "exe": str(EXE) if CAT_OK else None, "exe_md5": EXE_MD5, "cfg_hash": CFG_HASH,
    "grid": {k: GRID[k] for k in ("ns", "circuits", "shots", "reps", "depth")},
    "seeds": {"layer": LAYER_SEED, "cliff": CLIFF_SEED},
    "caps": {"cirq_max_n": GRID["cirq_max_n"], "aer_max_n": GRID["aer_max_n"]},
    "probe_evidence": PROBE_EVIDENCE, "versions": VERSIONS,
    "class_note": ("stabilizer/Clifford sampling class only; qulacs and qiskit-family "
                   "are not offered here (no stabilizer sampling engine) -- no lane fabricated"),
    "threads_note": "cat_pf = 4-thread RAYON; competitors at shipped defaults.",
    "verdict": {
        "strict_beats_all_cold": f"{sum(1 for r in rows if r.get('beats_all_cold'))}/{len(rows)}",
        "strict_beats_all_warm": f"{sum(1 for r in rows if r.get('beats_all_warm'))}/{len(rows)}",
        "beats_available_cold": f"{sum(1 for r in rows if r.get('beats_available_cold'))}/{len(rows)}",
        "beats_available_warm": f"{sum(1 for r in rows if r.get('beats_available_warm'))}/{len(rows)}",
        "boundary_note": (" ".join(boundary_notes) if boundary_notes else None),
    },
}
(OUT / "sfcat_bench_summary.json").write_text(json.dumps(SUMMARY, indent=2), encoding="utf-8")
print()
print("verdict:", json.dumps(SUMMARY["verdict"]))
print("wrote:", (OUT / "sfcat_bench_rows.csv").name, "+", (OUT / "sfcat_bench_summary.json").name)''')

code(r'''# ==== Figures (png files + inline display) ====
try:
    import warnings
    warnings.filterwarnings("ignore")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from IPython.display import Image, display

    labels = [f"{r['circuit']} {r['n']}" for r in rows]
    lanes = ["cat_pf", "stim", "aer", "pl", "cirq"]

    def _v(r, lane, kind):
        if lane == "cat_pf":
            return (r.get("cat") or {}).get("cold_ms" if kind == "cold" else "counts_ms")
        if lane == "stim":
            return (r.get("stim") or {}).get("full_ms" if kind == "cold" else "sample_ms")
        return _comp_ms(r, lane, "cold_ms" if kind == "cold" else "warm_ms")

    def _groups(kind, fname, title, note):
        x = np.arange(len(labels))
        w = 0.16
        fig, ax = plt.subplots(figsize=(12, 5))
        for i, lane in enumerate(lanes):
            vals = [(_v(r, lane, kind) if isinstance(_v(r, lane, kind), (int, float))
                     else float("nan")) for r in rows]
            ax.bar(x + (i - 2) * w, vals, w, label=lane)
        ax.set_yscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=15)
        ax.set_ylabel(f"{kind} time (ms, log)")
        ax.set_title(title + "  —  " + note, fontsize=10)
        ax.legend(ncol=5, fontsize=9)
        ax.grid(axis="y", alpha=0.3)
        fig.tight_layout()
        path = OUT / "figs" / fname
        fig.savefig(path, dpi=140)
        display(Image(str(path)))
        plt.close(fig)
        return path

    p1 = _groups("cold", "fig_cold_ms.png", "Cold (build + first sample, ms)",
                 "missing bar = capped / not offered / not available")
    p2 = _groups("warm", "fig_warm_ms.png", "Warm (prepared sampler, ms)",
                 "cat = counts-map class; stim = sample; aer/pl/cirq = warm rep")

    ratios = []
    for r in rows:
        c = (r.get("cat") or {}).get("counts_ms")
        s = (r.get("stim") or {}).get("sample_ms")
        ratios.append((s / c) if (c and s) else float("nan"))
    fig, ax = plt.subplots(figsize=(12, 4))
    ax.bar(np.arange(len(labels)), ratios, 0.5)
    ax.axhline(1.0, color="k", lw=0.8)
    ax.set_xticks(np.arange(len(labels)))
    ax.set_xticklabels(labels, rotation=15)
    ax.set_ylabel("stim / cat_pf speed-up (warm; >1 = cat faster)")
    ax.set_title("Warm sampling ratio vs stim")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    p3 = OUT / "figs" / "fig_warm_ratio_vs_stim.png"
    fig.savefig(p3, dpi=140)
    display(Image(str(p3)))
    plt.close(fig)
    print("figures saved:", p1.name, p2.name, p3.name)
except Exception as e:
    print("figures skipped:", type(e).__name__, e)''')

code(r'''# ==== Report (report.md) ====
def _md_table(cols, headers, recs_, float_fmt=".4g"):
    lines = ["| " + " | ".join(headers) + " |", "|" + "---|" * len(headers)]
    for r in recs_:
        cells = []
        for c in cols:
            v = r.get(c)
            if isinstance(v, bool):
                cells.append("yes" if v else "no")
            elif isinstance(v, float):
                cells.append(f"{v:{float_fmt}}")
            elif v is None:
                cells.append("—")
            else:
                cells.append(str(v))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)

cold_tbl = _md_table(
    ["circuit", "n", "cat_cold_ms", "sfir_cold_ms", "stim_full_ms", "aer_cold_ms", "pl_cold_ms", "cirq_cold_ms"],
    ["circuit", "n", "cat_pf cold", "sf-ir cold", "stim full", "aer cold", "pl cold", "cirq cold"], recs)
warm_tbl = _md_table(
    ["circuit", "n", "cat_counts_ms", "sfir_sample_ms", "stim_sample_ms", "aer_warm_ms", "pl_warm_ms", "cirq_warm_ms"],
    ["circuit", "n", "cat_pf counts", "sf-ir sample", "stim sample", "aer warm", "pl warm", "cirq warm"], recs)

over = [r for r in recs if r.get("cirq_status") not in (None, "ok")]
rep = []
rep.append("# sf-cat benchmark — Clifford/stabilizer sampling round (cat_pf vs stim/aer/pl/cirq)\n")
rep.append(f"Generated {SUMMARY['generated']} on host **{HOST}** — cfg `{CFG_HASH}`, "
           f"shots={GRID['shots']}, depth={GRID['depth']}, seeds L{LAYER_SEED}/C{CLIFF_SEED}.\n")
rep.append("## Headline verdict\n")
rep.append(f"- strict beats ALL lanes (incl. capped/over-budget ones): cold "
           f"**{SUMMARY['verdict']['strict_beats_all_cold']}**, warm **{SUMMARY['verdict']['strict_beats_all_warm']}**\n")
rep.append(f"- beats every lane that actually produced data: cold "
           f"**{SUMMARY['verdict']['beats_available_cold']}**, warm **{SUMMARY['verdict']['beats_available_warm']}**\n")
rep.append("- cold = build + first sample in one region per lane; warm = prepared sampler "
           "(cat_pf counts-map class vs each lane's warm recipe).\n")
if SUMMARY["verdict"].get("boundary_note"):
    bp = BOUNDARY_PROBE
    rep.append("\n## Boundary sensitivity (strict verdict)\n")
    rep.append(f"- {SUMMARY['verdict']['boundary_note']}\n")
    rep.append(f"- Probe evidence: {bp['rungs']}x ghz@64 rung re-runs ({bp['when']}): cirq "
               f"first calls {bp['cirq_first_call_min_s']}-{bp['cirq_first_call_max_s']} s "
               f"({bp['cirq_first_calls_over_budget']} over budget, {bp['cirq_calls_over_budget']} "
               f"calls over); all-call max {bp['cirq_call_max_s']} s; cold-side flicker: "
               f"{bp['strict_cold_flicker']}.\n")
    rep.append(f"- Raw probe data: {bp['evidence']}.\n")
rep.append("\n## Cold times (ms), window-mean of 2 windows per lane\n\n" + cold_tbl + "\n")
rep.append("\n## Warm times (ms)\n\n" + warm_tbl + "\n")
rep.append("\n## Non-ok rows on the cirq lane (guard results, not failures)\n\n")
if over:
    for r in over:
        rep.append(f"- {r['circuit']} n={r['n']}: `{r['cirq_status']}` — {r.get('cirq_note') or ''}".rstrip())
        rep.append("")
else:
    rep.append("(none)\n")
rep.append("\n## Disclosures\n")
rep.append(f"- cat_pf is the Rust-native l1_bench example (md5 {EXE_MD5}), 4-thread RAYON; not yet reachable from the Python package — engines are compared, not shipped APIs.\n")
rep.append("- cat cold = tableau build + plan + first sample (ONE region); cat warm counts = counts-map class; pack = raw (shots,n) array class.\n")
rep.append("- stim: compile+sample timed region / sampler-reuse; aer: fresh stabilizer simulator per rep (worker recipe); pl: QNode re-run (tape re-emitted); cirq: fresh CliffordSimulator per rep.\n")
rep.append(f"- caps: cirq n<={GRID['cirq_max_n']} ({PROBE_EVIDENCE['cirq']}); aer n<={GRID['aer_max_n']} ({PROBE_EVIDENCE['aer']}); per-lane first-call budget {GRID['budget']:.0f} s (over it = over_budget, unranked).\n")
rep.append("- GHZ branch checks: every GHZ rung must sample only the all-0/all-1 branches (see summary json + ghz_ok fields in the jsonl).\n")
rep.append("- sf-ir = the sf-ir StabilizerTableau lane from the SAME l1_bench process (same-window reference column).\n")
rep.append(f"- versions: {json.dumps(VERSIONS)}\n")
rep.append("\n## Artifacts\n")
rep.append("- `sfcat_bench.jsonl` raw rows (both windows per lane) · `sfcat_bench_rows.csv` flattened table · "
           "`sfcat_bench_summary.json` config+verdict · `figs/*.png` figures · this report.\n")
if SUMMARY["verdict"].get("boundary_note"):
    rep.append("- `boundary_probe_ghz64.json` repeated ghz@64 rung re-runs "
               "(boundary-sensitivity evidence) · raw log `_sfcat_boundary_probe_ghz64.log` "
               "in the suite folder.\n")
(OUT / "report.md").write_text("\n".join(rep), encoding="utf-8")
print("report.md written:", len("\n".join(rep)), "bytes")
print("\n".join(rep)[:1200])''')

code(r'''# ==== Package results zip (the deliverable this notebook produces) ====
from IPython.display import FileLink, display

ZIP = HERE / f"sfcat_bench_results_{HOST}.zip"
summary = json.loads((OUT / "sfcat_bench_summary.json").read_text(encoding="utf-8"))
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(OUT.rglob("*")):
        if f.is_file():
            z.write(f, str(f.relative_to(HERE)))
    z.writestr("README_RESULTS.txt", (
        "sf-cat benchmark results bundle\n"
        "===============================\n"
        "sfcat_bench_out/sfcat_bench.jsonl          raw rows (one full JSON per rung, both windows)\n"
        "sfcat_bench_out/sfcat_bench_rows.csv       flattened table (all lanes, cold+warm)\n"
        "sfcat_bench_out/sfcat_bench_summary.json   verdict + config + versions + probe evidence\n"
        "sfcat_bench_out/report.md                  full report\n"
        "sfcat_bench_out/figs/*.png                 figures\n"
        "Regenerate: open _sfcat_bench.ipynb (Colab/Jupyter) and Run All; the last cell re-creates this zip.\n"))
    z.writestr("run_summary.json", json.dumps(summary, indent=2))
print(f"results zip: {ZIP.name}  {ZIP.stat().st_size // 1024} KB")
print("bundled:", ", ".join(sorted(p.relative_to(HERE).as_posix() for p in OUT.rglob("*") if p.is_file())))
_dist = HERE.parent / "_dist"
if _dist.is_dir():
    shutil.copy2(ZIP, _dist / ZIP.name)
    print("mirrored to:", _dist / ZIP.name)
display(FileLink(ZIP.name))
print("DONE — open _sfcat_bench.ipynb in Colab to view all outputs as executed, or re-run to reproduce.")''')


def main():
    import nbformat
    nb = nbformat.v4.new_notebook()
    for c in CELLS:
        if c["cell_type"] == "markdown":
            nb.cells.append(nbformat.v4.new_markdown_cell(c["source"]))
        else:
            nb.cells.append(nbformat.v4.new_code_cell(c["source"]))
    nb.metadata["kernelspec"] = {"display_name": "sfdev", "language": "python",
                                "name": "sfdev"}
    nb.metadata["language_info"] = {"name": "python"}
    nbformat.write(nb, str(NB))
    print(f"wrote {NB.name}: {len(nb.cells)} cells")


if __name__ == "__main__":
    main()


