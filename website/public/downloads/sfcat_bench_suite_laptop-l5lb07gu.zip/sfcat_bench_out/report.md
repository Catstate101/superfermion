# sf-cat benchmark — Clifford/stabilizer sampling round (cat_pf vs stim/aer/pl/cirq)

Generated 2026-10-13T00:13:44 on host **laptop-l5lb07gu** — cfg `d65e0d0530`, shots=2000, depth=8, seeds L11/C7.

## Headline verdict

- strict beats ALL lanes (incl. capped/over-budget ones): cold **1/8**, warm **1/8**

- beats every lane that actually produced data: cold **4/8**, warm **7/8**

- cold = build + first sample in one region per lane; warm = prepared sampler (cat_pf counts-map class vs each lane's warm recipe).


## Boundary sensitivity (strict verdict)

- ghz@n=64 strict win is BUDGET-BOUNDARY data, not a stable strict win: the strict comb only computes when cirq ranks, and cirq's time straddles the 40 s first-call guard (this window: cold 37.6 s, warm 38.9 s, tightest margin 1.1 s; cross-window: the same rung/build/recipes measured 67.2 s (over_budget) in the 2026-10-12 16:25 gen-A window -- the guard outcome flips with window state).

- Probe evidence: 5x ghz@64 rung re-runs (2026-10-12 23:51-00:07): cirq first calls 28.0-33.3 s (0/10 over budget, 0/30 calls over); all-call max 37.2 s; cold-side flicker: 1/5 probe rungs: cat cold 0.414 ms vs stim full 0.399 ms (~15 us cross at the sub-ms resolution floor) -> cold flag False.

- Raw probe data: sfcat_bench_out/boundary_probe_ghz64.json (raw rows) + _sfcat_boundary_probe_ghz64.log (suite folder).


## Cold times (ms), window-mean of 2 windows per lane

| circuit | n | cat_pf cold | sf-ir cold | stim full | aer cold | pl cold | cirq cold |
|---|---|---|---|---|---|---|---|
| ghz | 64 | 0.2422 | 0.5326 | 0.5551 | 279 | 17.24 | 3.758e+04 |
| ghz | 256 | 2.358 | 2.841 | 3.187 | 7032 | 69.88 | — |
| ghz | 1024 | 14.37 | 18.15 | 15.75 | — | 415.3 | — |
| ghz | 4096 | 158.6 | 303.4 | 172.3 | — | 4342 | — |
| brick | 64 | 3.163 | 2.777 | 0.3259 | 352.7 | 70.86 | — |
| brick | 256 | 20.86 | 19.1 | 3.928 | 4333 | 261.8 | — |
| brick | 1024 | 192.6 | 165 | 24.32 | — | 1616 | — |
| brick | 4096 | 2354 | 2353 | 206 | — | 7642 | — |


## Warm times (ms)

| circuit | n | cat_pf counts | sf-ir sample | stim sample | aer warm | pl warm | cirq warm |
|---|---|---|---|---|---|---|---|
| ghz | 64 | 0.06077 | 0.1587 | 0.3109 | 282.3 | 15.45 | 3.887e+04 |
| ghz | 256 | 0.3244 | 0.6326 | 3.073 | 7083 | 64.95 | — |
| ghz | 1024 | 1.216 | 1.946 | 12.93 | — | 413.5 | — |
| ghz | 4096 | 3.417 | 7.496 | 85.23 | — | 4792 | — |
| brick | 64 | 0.6072 | 1.178 | 0.2439 | 335.9 | 67.69 | — |
| brick | 256 | 3.105 | 3.241 | 3.489 | 4313 | 254.1 | — |
| brick | 1024 | 6.996 | 6.601 | 17.1 | — | 1604 | — |
| brick | 4096 | 18.18 | 23.03 | 93.83 | — | 7636 | — |


## Non-ok rows on the cirq lane (guard results, not failures)


- ghz n=256: `not_run_capped` — n>64: not attempted in the ladder; cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; ghz n=256 = 375.4 s -- warm reps=1, no reuse row

- ghz n=1024: `not_run_capped` — n>64: not attempted in the ladder; cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; ghz n=256 = 375.4 s -- warm reps=1, no reuse row

- ghz n=4096: `not_run_capped` — n>64: not attempted in the ladder; cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; ghz n=256 = 375.4 s -- warm reps=1, no reuse row

- brick n=64: `over_budget` — first call 74.8s > budget 40s

- brick n=256: `not_run_capped` — n>64: not attempted in the ladder; cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; ghz n=256 = 375.4 s -- warm reps=1, no reuse row

- brick n=1024: `not_run_capped` — n>64: not attempted in the ladder; cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; ghz n=256 = 375.4 s -- warm reps=1, no reuse row

- brick n=4096: `not_run_capped` — n>64: not attempted in the ladder; cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; ghz n=256 = 375.4 s -- warm reps=1, no reuse row


## Disclosures

- cat_pf is the Rust-native l1_bench example (md5 c0c9679b215e), 4-thread RAYON; not yet reachable from the Python package — engines are compared, not shipped APIs.

- cat cold = tableau build + plan + first sample (ONE region); cat warm counts = counts-map class; pack = raw (shots,n) array class.

- stim: compile+sample timed region / sampler-reuse; aer: fresh stabilizer simulator per rep (worker recipe); pl: QNode re-run (tape re-emitted); cirq: fresh CliffordSimulator per rep.

- caps: cirq n<=64 (cost probes 2026-10-12: ghz n=64 = 33.7 s/call at shots=2000; ghz n=256 = 375.4 s -- warm reps=1, no reuse row); aer n<=256 (single-call cost probe 2026-10-12: brick n=1024 = 102.4 s); per-lane first-call budget 40 s (over it = over_budget, unranked).

- GHZ branch checks: every GHZ rung must sample only the all-0/all-1 branches (see summary json + ghz_ok fields in the jsonl).

- sf-ir = the sf-ir StabilizerTableau lane from the SAME l1_bench process (same-window reference column).

- versions: {"numpy": "2.5.3", "pandas": "2.3.2", "matplotlib": "3.10.6", "stim": "1.16.0", "qiskit": "2.1.2", "qiskit_aer": "0.17.2", "pennylane": "0.45.0", "cirq": "1.6.1"}


## Artifacts

- `sfcat_bench.jsonl` raw rows (both windows per lane) · `sfcat_bench_rows.csv` flattened table · `sfcat_bench_summary.json` config+verdict · `figs/*.png` figures · this report.

- `boundary_probe_ghz64.json` repeated ghz@64 rung re-runs (boundary-sensitivity evidence) · raw log `_sfcat_boundary_probe_ghz64.log` in the suite folder.
