@echo off
rem sf-cat benchmark suite: headless execute + pack (one command)
cd /d %~dp0
python _sfcat_bench_exec.py _sfcat_bench.ipynb
if errorlevel 1 (
    echo EXEC FAILED - inspect the notebook outputs before packing
    exit /b 1
)
python _sfcat_bench_pack.py
if errorlevel 1 (
    echo PACK FAILED
    exit /b 1
)
echo DONE - see _dist\ for the zips
