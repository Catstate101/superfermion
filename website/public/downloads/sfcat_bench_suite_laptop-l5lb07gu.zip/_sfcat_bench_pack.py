"""Package sf-cat bench: results zip (Colab view) + portable suite folder.

Run AFTER the notebook execution finishes:
    python _sfcat_bench_pack.py

Two auto-detected modes:
  * workspace (this repo): refreshes the nested sf_cat_bench_suite/ folder, then zips it
  * suite    (inside a copied sf_cat_bench_suite/ folder): packs itself

Creates:
  _dist/sfcat_bench_results_<host>.zip   executed notebook + report + figs + csv/jsonl
                                         (upload the ipynb to Colab: outputs visible)
  _dist/sfcat_bench_suite[_<host>].zip   the copyable suite folder (scripts + results +
                                         executed notebook)
"""
import json
import pathlib
import shutil
import socket
import zipfile
from collections import Counter
from datetime import datetime

HERE = pathlib.Path(__file__).resolve().parent
HOST = socket.gethostname().split(".")[0].lower()
NB = HERE / "_sfcat_bench.ipynb"
OUT = HERE / "sfcat_bench_out"
JSONL = OUT / "sfcat_bench.jsonl"
DIST = HERE / "_dist"
NESTED = HERE / "sf_cat_bench_suite"
WORKSPACE = NESTED.exists()
SUITE = NESTED if WORKSPACE else HERE
if not WORKSPACE and not ((HERE / "run_notebook.bat").exists()
                          and (HERE / "requirements.txt").exists()):
    raise SystemExit("not a workspace (no sf_cat_bench_suite/) nor a suite folder "
                     "(no run_notebook.bat) - aborting")

# ---- 0) freshness checks -------------------------------------------------
import nbformat

if not NB.exists():
    raise SystemExit(f"missing {NB.name} - build it first (python _sfcat_bench_build.py)")
nb = nbformat.read(str(NB), as_version=4)
n_out = sum(len(c.get("outputs", [])) for c in nb.cells)
err_cells = sum(1 for c in nb.cells
                if any(o.get("output_type") == "error" for o in c.get("outputs", [])))
rows = [json.loads(l) for l in JSONL.read_text(encoding="utf-8").splitlines()
        if l.strip()] if JSONL.exists() else []
status_counts = dict(Counter(r.get("cat_status", "ok") for r in rows))
verdict = {}
sm_path = OUT / "sfcat_bench_summary.json"
if sm_path.exists():
    verdict = json.loads(sm_path.read_text(encoding="utf-8")).get("verdict", {})
print(f"pack mode: {'workspace' if WORKSPACE else 'suite'} | host: {HOST}")
print(f"notebook: {len(nb.cells)} cells | {n_out} outputs | {err_cells} error cells")
print(f"rows: {len(rows)} | verdict: {verdict}")
if n_out == 0:
    print("WARNING: notebook has no outputs -- run _sfcat_bench_exec.py first")
if err_cells:
    print("WARNING: executed notebook has error cells -- inspect before shipping")

summary = {
    "host": HOST,
    "packed_at": datetime.now().isoformat(timespec="seconds"),
    "cells": len(nb.cells), "outputs": n_out, "error_cells": err_cells,
    "rows": len(rows), "cat_status_counts": status_counts, "verdict": verdict,
}

# ---- 1) results zip (what you open in Colab) -----------------------------
DIST.mkdir(exist_ok=True)
rzip = DIST / f"sfcat_bench_results_{HOST}.zip"
with zipfile.ZipFile(rzip, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(NB, "SF_CAT_Benchmark.ipynb")
    rp = OUT / "report.md"
    if rp.exists():
        z.write(rp, "report.md")
    for f in sorted(OUT.glob("*.jsonl")) + sorted(OUT.glob("*.csv")) + sorted(OUT.glob("*.json")):
        z.write(f, f"sfcat_bench_out/{f.name}")
    figs = OUT / "figs"
    if figs.exists():
        for f in sorted(figs.iterdir()):
            if f.is_file():
                z.write(f, f"sfcat_bench_out/figs/{f.name}")
    z.writestr("run_summary.json", json.dumps(summary, indent=2))
    z.writestr("README_RESULTS.txt", (
        "Open SF_CAT_Benchmark.ipynb in Colab (or Jupyter):\n"
        "all tables, stdout and inline plots are stored in the notebook.\n"
        "sfcat_bench_out/figs/*.png are the same figures as image files.\n"
        "sfcat_bench_out/sfcat_bench.jsonl is the raw row stream (one JSON per rung, both ABBA windows).\n"
        "sfcat_bench_out/sfcat_bench_rows.csv is the flattened table.\n"
        "sfcat_bench_out/sfcat_bench_summary.json carries config + verdict + probe evidence.\n"
        "report.md is the full report.\n"
        "Summary: run_summary.json\n"
        "Full reproducible folder: _dist/sfcat_bench_suite[_<host>].zip.\n"))
print("results zip:", rzip.name, f"{rzip.stat().st_size // 1024} KB")

# ---- 2) suite folder (portable to another desktop) -----------------------
SUITE.mkdir(exist_ok=True)
SUITE_OUT = SUITE / "sfcat_bench_out"


def portable_copy(src, dst_name=None):
    shutil.copy2(src, SUITE / (dst_name or src.name))


if WORKSPACE:
    shutil.copy2(NB, SUITE / "_sfcat_bench.ipynb")
    for _tool in ("_sfcat_bench_build.py", "_sfcat_bench_exec.py", "_sfcat_bench_pack.py",
                  "README.md", "requirements.txt", "run_notebook.bat"):
        if (HERE / _tool).exists():
            portable_copy(HERE / _tool)
    if SUITE_OUT.exists():
        shutil.rmtree(SUITE_OUT)
    shutil.copytree(OUT, SUITE_OUT)
else:
    print("suite mode: running inside the suite folder -- files already in place")
(SUITE / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

szip = (DIST / "sfcat_bench_suite.zip") if WORKSPACE else (DIST / f"sfcat_bench_suite_{HOST}.zip")
with zipfile.ZipFile(szip, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(SUITE.rglob("*")):
        if not f.is_file():
            continue
        if f.relative_to(SUITE).parts[0] in ("_dist", "_run1_archive", "_run2_archive"):
            continue
        z.write(f, f.relative_to(HERE))
print("suite zip:", szip.name, f"{szip.stat().st_size // 1024} KB")
print("suite folder:", SUITE)
print("PACK_OK")
