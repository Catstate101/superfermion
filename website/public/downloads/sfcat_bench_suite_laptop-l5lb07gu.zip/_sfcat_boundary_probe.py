"""Boundary probe: re-run the ghz@64 rung of the sf-cat bench suite N times.

Purpose: check whether cirq's first-call time reproducibly stays under the
40 s budget guard. gen-A window: 67.2 s (over_budget, packed 16:25);
gen-B window: 37.6 s cold / 38.9 s warm (ok, packed 21:23).

Fidelity: lane recipes, op stream (ghz n=64, LAYER_SEED=11), sampling seed
(CLIFF_SEED=7), shots (2000), reps (cat/stim=7, aer=3/2, pl=3/2, cirq=1/1),
ABBA order (cat,stim,aer,pl,cirq | cirq,pl,aer,stim,cat), budget guard and
CFG_HASH inputs are copied VERBATIM from _sfcat_bench_build.py. Additive
recording only: cirq first-call dt (the suite discards it on success) and
per-phase call durations.

Usage: python _sfcat_boundary_probe.py [n_iterations]     (default 5)
Writes: sfcat_bench_out/boundary_probe_ghz64.json + _sfcat_boundary_probe_ghz64.log
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import platform
import re
import socket
import subprocess
import sys
import tempfile
import time
from datetime import datetime

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE / "sfcat_bench_out"
OUT.mkdir(parents=True, exist_ok=True)
LOG = HERE / "_sfcat_boundary_probe_ghz64.log"
PROBE_JSON = OUT / "boundary_probe_ghz64.json"
N_ITERS = int(sys.argv[1]) if len(sys.argv) > 1 else 5


def log(msg):
    line = f"{datetime.now().strftime('%H:%M:%S')} {msg}"
    print(line, flush=True)
    with LOG.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


LOG.write_text(f"== sfcat boundary probe (ghz@64 x{N_ITERS}) "
               f"started {datetime.now().isoformat(timespec='seconds')} ==\n",
               encoding="utf-8")

# ==== config — VERBATIM from _sfcat_bench_build.py (do not alter) ====
EXE = pathlib.Path(os.environ.get("L1_BENCH_EXE",
                                  r"D:\sf_cat_target\release\examples\l1_bench.exe"))
CAT_OK = EXE.exists() and EXE.is_file()
_win_d = pathlib.Path("D:/")
TMP = pathlib.Path(os.environ.get("L1_BENCH_TMP",
                                  r"D:\sf_cat_bench\tmp" if platform.system() == "Windows" and _win_d.exists()
                                  else tempfile.gettempdir()))
TMP.mkdir(parents=True, exist_ok=True)

GRID = dict(ns=[64, 256, 1024, 4096], circuits=["ghz", "brick"], depth=8,
            shots=2000, reps=7, comp_reps=3, comp_cold_reps=2, cirq_reps=1,
            budget=40.0, cirq_max_n=64, aer_max_n=256)
LAYER_SEED = 11
CLIFF_SEED = 7
COMPETITORS = ["stim", "aer", "pl", "cirq"]
EXE_MD5 = hashlib.md5(EXE.read_bytes()).hexdigest()[:12] if CAT_OK else None
CFG_HASH = hashlib.md5(json.dumps(
    [GRID, LAYER_SEED, CLIFF_SEED, EXE_MD5, str(EXE)], sort_keys=True).encode()
).hexdigest()[:10]

VERSIONS = {}
for mod in ("numpy", "pandas", "matplotlib", "stim", "qiskit", "qiskit_aer",
            "pennylane", "cirq"):
    try:
        m = __import__(mod)
        VERSIONS[mod] = getattr(m, "__version__", "?")
    except Exception:
        pass

log(f"host {socket.gethostname().split('.')[0].lower()} | exe_md5 {EXE_MD5} "
    f"| cfg_hash {CFG_HASH} (must equal the packed suite cfg)")
log(f"versions {json.dumps(VERSIONS)}")

# ==== op streams + timing helpers — VERBATIM ====
def ghz_ops(n):
    return [("h", 0)] + [("cx", 0, i) for i in range(1, n)]


def median(values):
    xs = sorted(values)
    m = len(xs) // 2
    return xs[m] if len(xs) % 2 else 0.5 * (xs[m - 1] + xs[m])


def mean_of(a, b):
    return 0.5 * (a + b)


def timed_reps(fn, reps):
    fn()  # warm pass, excluded
    times = []
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t0)
    return times


class OverBudget(Exception):
    pass


def _probe(fn, budget):
    t0 = time.perf_counter()
    out = fn()
    dt = time.perf_counter() - t0
    if dt > budget:
        raise OverBudget(f"first call {dt:.1f}s > budget {budget:.0f}s")
    return out, dt


def _branch_ok(arr, n):
    import numpy as np
    uniq = np.unique(np.asarray(arr), axis=0)
    ok = all(bool((row == 0).all() or (row == 1).all()) for row in uniq)
    return ok, int(uniq.shape[0])


def rust_lane(ops, n, shots, reps):
    job = {"n": n, "ops": [[o[0], *o[1:]] for o in ops], "shots": shots,
           "reps": reps, "seed": CLIFF_SEED}
    job_path = TMP / f"sfcat_job_n{n}.json"
    job_path.write_text(json.dumps(job), encoding="utf-8")
    env = dict(os.environ)
    env["RAYON_NUM_THREADS"] = "4"
    p = subprocess.run([str(EXE), str(job_path)], capture_output=True,
                       text=True, env=env, timeout=1800)
    if p.returncode != 0:
        raise RuntimeError(f"l1_bench failed rc={p.returncode}: {p.stderr[-300:]}")
    line = [l for l in p.stdout.splitlines() if l.strip().startswith("{")][-1]
    return json.loads(line)


def stim_lane(ops, n, shots, reps):
    import stim
    c = stim.Circuit()
    for op in ops:
        name = op[0].lower()
        if name == "h":
            c.append("H", [op[1]])
        elif name == "cx":
            c.append("CX", [op[1], op[2]])
        elif name == "s":
            c.append("S", [op[1]])
        else:
            raise ValueError(name)
    c.append("M", list(range(n)))
    full = timed_reps(lambda: c.compile_sampler().sample(shots=shots), reps)
    samp = c.compile_sampler()
    warm = timed_reps(lambda: samp.sample(shots=shots), reps)
    return {"full_ms": median(full) * 1e3, "sample_ms": median(warm) * 1e3,
            "version": getattr(stim, "__version__", "?")}


def aer_lane(ops, n, shots, reps, cold_reps, budget, circ):
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    out = {"status": "ok", "api": "AerSimulator(method='stabilizer')"}

    def build():
        qc = QuantumCircuit(n)
        for op in ops:
            if op[0] == "h":
                qc.h(op[1])
            elif op[0] == "s":
                qc.s(op[1])
            elif op[0] == "cx":
                qc.cx(op[1], op[2])
            else:
                raise ValueError(str(op))
        qcm = qc.copy()
        qcm.measure_all()
        return qcm

    def fresh_run(qcm):
        return AerSimulator(method="stabilizer").run(
            qcm, shots=shots, seed=CLIFF_SEED).result()

    qcm = build()
    last, _ = _probe(lambda: fresh_run(qcm), budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        fresh_run(build())
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = fresh_run(qcm)
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    sim = AerSimulator(method="stabilizer")
    last = sim.run(qcm, shots=shots, seed=CLIFF_SEED).result()
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = sim.run(qcm, shots=shots, seed=CLIFF_SEED).result()
        ts.append(time.perf_counter() - t0)
    out["reuse_ms"] = median(ts) * 1e3
    cnt = dict(last.get_counts())
    out["keys"] = len(cnt)
    if circ == "ghz":
        out["ghz_ok"] = bool(set(cnt) <= {"0" * n, "1" * n})
    return out


def pl_lane(ops, n, shots, reps, cold_reps, budget, circ):
    import numpy as np
    import pennylane as qml
    out = {"status": "ok", "api": "default.clifford"}

    def emit():
        for op in ops:
            if op[0] == "h":
                qml.Hadamard(op[1])
            elif op[0] == "s":
                qml.S(op[1])
            elif op[0] == "cx":
                qml.CNOT(wires=[op[1], op[2]])
            else:
                raise ValueError(str(op))

    def make():
        dev = qml.device("default.clifford", wires=n, shots=shots)

        @qml.qnode(dev)
        def samp():
            emit()
            return qml.sample(wires=list(range(n)))

        return samp

    samp = make()
    last, _ = _probe(samp, budget)
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        make()()
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = samp()
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    arr = np.asarray(last)
    if circ == "ghz":
        ok, kb = _branch_ok(arr, n)
        out["ghz_ok"] = bool(ok)
        out["ghz_branches"] = kb
    else:
        out["keys"] = int(np.unique(arr, axis=0).shape[0])
    return out


def cirq_lane(ops, n, shots, reps, cold_reps, budget, circ):
    import cirq
    import numpy as np
    out = {"status": "ok", "api": "CliffordSimulator"}
    q = cirq.LineQubit.range(n)
    calls = []  # probe-additive: per-phase durations (suite discards them)

    def build():
        items = []
        for op in ops:
            if op[0] == "h":
                items.append(cirq.H(q[op[1]]))
            elif op[0] == "s":
                items.append(cirq.S(q[op[1]]))
            elif op[0] == "cx":
                items.append(cirq.CNOT(q[op[1]], q[op[2]]))
            else:
                raise ValueError(str(op))
        items.append(cirq.measure(*q, key="m"))
        return cirq.Circuit(items)

    def fresh_run(c):
        return cirq.CliffordSimulator(seed=CLIFF_SEED).run(
            c, repetitions=shots).measurements["m"]

    c = build()
    last, dt = _probe(lambda: fresh_run(c), budget)
    out["first_call_ms"] = dt * 1e3          # probe-additive (suite discards dt)
    calls.append({"phase": "probe", "s": dt})
    ts = []
    for _ in range(cold_reps):
        t0 = time.perf_counter()
        fresh_run(build())
        ts.append(time.perf_counter() - t0)
    out["cold_ms"] = median(ts) * 1e3
    calls.append({"phase": "cold", "s": ts[0]})
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        last = fresh_run(c)
        ts.append(time.perf_counter() - t0)
    out["warm_ms"] = median(ts) * 1e3
    calls.append({"phase": "warm", "s": ts[0]})
    out["calls"] = calls                   # probe-additive
    out["reuse_ms"] = None
    arr = np.asarray(last)
    if circ == "ghz":
        ok, kb = _branch_ok(arr, n)
        out["ghz_ok"] = bool(ok)
        out["ghz_branches"] = kb
    else:
        out["keys"] = int(np.unique(arr, axis=0).shape[0])
    return out


LANE_FN = {"aer": aer_lane, "pl": pl_lane, "cirq": cirq_lane}


def comp_lane(lane, ops, n, shots, reps, cold_reps, budget, circ):
    try:
        return LANE_FN[lane](ops, n, shots, reps, cold_reps, budget, circ)
    except OverBudget as e:
        return {"status": "over_budget", "note": str(e)}
    except Exception as e:
        return {"status": f"error: {type(e).__name__}: {e}"}


def stim_branch_check(ops, n, shots):
    import stim
    c = stim.Circuit()
    for op in ops:
        if op[0] == "h":
            c.append("H", [op[1]])
        elif op[0] == "cx":
            c.append("CX", [op[1], op[2]])
        elif op[0] == "s":
            c.append("S", [op[1]])
    c.append("M", list(range(n)))
    arr = c.compile_sampler().sample(shots=shots)
    ok, kb = _branch_ok(arr, n)
    return {"ghz_ok": bool(ok), "ghz_branches": kb}


def combine(win_a, win_b, fields):
    out = {}
    for f in fields:
        va, vb = win_a.get(f), win_b.get(f)
        out[f] = (mean_of(va, vb) if isinstance(va, (int, float))
                  and isinstance(vb, (int, float)) else None)
    return out


def _cat_dict(c1, c2):
    if isinstance(c1, dict) and isinstance(c2, dict) and "cat_pf" in c1 and "cat_pf" in c2:
        a, b = c1["cat_pf"], c2["cat_pf"]
        return {
            "cold_ms": mean_of(a["cold_ms"], b["cold_ms"]),
            "build_ms": mean_of(a["build_ms"], b["build_ms"]),
            "plan_ms": mean_of(a["plan_ms"], b["plan_ms"]),
            "pack_ms": mean_of(a["sample_pack_ms"], b["sample_pack_ms"]),
            "counts_ms": mean_of(a["sample_counts_ms"], b["sample_counts_ms"]),
            "keys": b["keys"],
        }
    return None


def _win_status(lane, w):
    if lane == "cat":
        return "ok" if isinstance(w, dict) and "cat_pf" in w else str(w.get("status") if isinstance(w, dict) else w)
    if lane == "stim":
        return "ok" if isinstance(w, dict) and "full_ms" in w else str(w.get("status") if isinstance(w, dict) else w)
    return str(w.get("status") if isinstance(w, dict) else w)


def assemble(circ, n, gates, wins):
    """Trimmed _assemble (same verdict logic; no stim-branch re-check needed)."""
    row = {"circuit": circ, "n": n, "shots": GRID["shots"], "gates": gates,
           "cfg_hash": CFG_HASH}
    c1, c2 = wins["cat"]
    cat = _cat_dict(c1, c2)
    s1, s2 = wins["stim"]
    if all(isinstance(x, dict) and "full_ms" in x for x in (s1, s2)):
        stim = combine(s1, s2, ["full_ms", "sample_ms"])
        stim["version"] = s2.get("version")
    else:
        stim = {"status": "error"}
    comp = {}
    for lane in ("aer", "pl", "cirq"):
        a, b = wins[lane]
        if all(isinstance(x, dict) and x.get("status") == "ok" for x in (a, b)):
            d = combine(a, b, ["cold_ms", "warm_ms", "reuse_ms"])
            d["status"] = "ok"
            d["api"] = b.get("api")
            for k in ("ghz_ok", "ghz_branches", "keys"):
                if k in b:
                    d[k] = b[k]
            comp[lane] = d
        else:
            bad = a if not (isinstance(a, dict) and a.get("status") == "ok") else b
            comp[lane] = {"status": (bad.get("status") if isinstance(bad, dict) else "error"),
                          "note": (bad.get("note") if isinstance(bad, dict) else str(bad)[:200])}
    cold_ref = {"stim": stim.get("full_ms")}
    warm_ref = {"stim": stim.get("sample_ms")}
    for lane in ("aer", "pl", "cirq"):
        cold_ref[lane] = comp[lane].get("cold_ms")
        warm_ref[lane] = comp[lane].get("warm_ms")
    avail_cold = [l for l in COMPETITORS if cold_ref.get(l)]
    avail_warm = [l for l in COMPETITORS if warm_ref.get(l)]
    if cat:
        rank_cold = {l: cat["cold_ms"] < cold_ref[l] for l in avail_cold}
        rank_warm = {l: cat["counts_ms"] < warm_ref[l] for l in avail_warm}
        row["win_cold"] = rank_cold
        row["win_warm"] = rank_warm
        row["beats_all_cold"] = all(rank_cold.values()) if len(avail_cold) == len(COMPETITORS) else None
        row["beats_all_warm"] = all(rank_warm.values()) if len(avail_warm) == len(COMPETITORS) else None
        row["beats_available_cold"] = bool(rank_cold) and all(rank_cold.values())
        row["beats_available_warm"] = bool(rank_warm) and all(rank_warm.values())
    row["unranked"] = [l for l in COMPETITORS if not cold_ref.get(l) or not warm_ref.get(l)]
    row["cat"] = cat
    row["stim"] = stim
    row["comp"] = comp
    return row


# ==== rung loop — ABBA order, VERBATIM dispatch from the RUN cell ====
order = ["cat", "stim", "aer", "pl", "cirq", "cirq", "pl", "aer", "stim", "cat"]
n = 64
ops = ghz_ops(n)

results = {
    "probe": f"ghz@64 rung re-run x{N_ITERS} (ABBA, suite recipes verbatim)",
    "started": datetime.now().isoformat(timespec="seconds"),
    "host": socket.gethostname().split(".")[0].lower(),
    "exe": str(EXE) if CAT_OK else None, "exe_md5": EXE_MD5, "cfg_hash": CFG_HASH,
    "grid": {"n": n, "circuit": "ghz", "shots": GRID["shots"], "reps": GRID["reps"],
             "comp_reps": GRID["comp_reps"], "comp_cold_reps": GRID["comp_cold_reps"],
             "cirq_reps": GRID["cirq_reps"], "budget_s": GRID["budget"]},
    "seeds": {"layer": LAYER_SEED, "cliff": CLIFF_SEED},
    "versions": VERSIONS,
    "iterations": [],
}


def cirq_window_summary(w, started):
    """Normalize one cirq window dict into probe evidence."""
    if isinstance(w, dict) and w.get("status") == "ok":
        return {"status": "ok", "started": started,
                "first_call_s": round(w.get("first_call_ms", float("nan")) / 1e3, 3),
                "calls_s": [round(c["s"], 3) for c in w.get("calls", [])],
                "cold_s": round(w["cold_ms"] / 1e3, 3),
                "warm_s": round(w["warm_ms"] / 1e3, 3)}
    note = w.get("note") if isinstance(w, dict) else str(w)
    m = re.search(r"first call ([\d.]+)s", note or "")
    return {"status": w.get("status") if isinstance(w, dict) else "error",
            "started": started,
            "first_call_s": float(m.group(1)) if m else None,
            "calls_s": [], "note": note}


for it in range(1, N_ITERS + 1):
    log(f"-- iteration {it}/{N_ITERS} --")
    wins = {"cat": [], "stim": [], "aer": [], "pl": [], "cirq": []}
    stamps = {k: [] for k in wins}
    for lane in order:
        stamps[lane].append(datetime.now().isoformat(timespec="seconds"))
        if lane == "cat":
            try:
                wins["cat"].append(rust_lane(ops, n, GRID["shots"], GRID["reps"]))
            except Exception as e:
                wins["cat"].append({"status": f"error: {type(e).__name__}: {e}"})
        elif lane == "stim":
            try:
                wins["stim"].append(stim_lane(ops, n, GRID["shots"], GRID["reps"]))
            except Exception as e:
                wins["stim"].append({"status": f"error: {type(e).__name__}: {e}"})
        else:
            cap = (GRID["cirq_max_n"] if lane == "cirq"
                   else GRID["aer_max_n"] if lane == "aer" else None)
            if cap is not None and n > cap:
                wins[lane].append({"status": "not_run_capped"})
                continue
            if lane == "cirq":
                creps, cold = GRID["cirq_reps"], 1
            else:
                creps, cold = GRID["comp_reps"], GRID["comp_cold_reps"]
            wins[lane].append(comp_lane(lane, ops, n, GRID["shots"], creps, cold,
                                        GRID["budget"], "ghz"))
        w = wins[lane][-1]
        st = _win_status(lane, w)
        extra = ""
        if lane == "cirq" and isinstance(w, dict) and st == "ok":
            extra = (f" first-call {w['first_call_ms']/1e3:.1f}s"
                     f" ({'UNDER' if w['first_call_ms']/1e3 <= GRID['budget'] else 'OVER'})")
        if lane == "cirq" and isinstance(w, dict) and st != "ok":
            extra = f" {w.get('note', '')}"
        log(f"   [{lane:5s}] {len(wins[lane])}/2 {st}{extra}")

    row = assemble("ghz", n, None, wins)

    iter_rec = {"iter": it, "cirq_windows": [], "row": {
        "cat": row.get("cat"), "stim": {k: v for k, v in (row.get("stim") or {}).items() if k != "version"},
        "comp": row.get("comp"), "win_cold": row.get("win_cold"), "win_warm": row.get("win_warm"),
        "beats_all_cold": row.get("beats_all_cold"), "beats_all_warm": row.get("beats_all_warm"),
        "beats_available_cold": row.get("beats_available_cold"),
        "beats_available_warm": row.get("beats_available_warm")}}
    # per-window cirq detail incl. the recorded first-call dt
    for i, w in enumerate(wins["cirq"]):
        iter_rec["cirq_windows"].append(cirq_window_summary(w, stamps["cirq"][i]))
    results["iterations"].append(iter_rec)

    for wj in iter_rec["cirq_windows"]:
        log(f"   cirq w{iter_rec['cirq_windows'].index(wj)+1}: "
            f"{wj['status']} first-call {wj.get('first_call_s')}s calls {wj.get('calls_s')}")
    log(f"   iter {it} verdicts: beats_all cold/warm {iter_rec['row']['beats_all_cold']}/"
        f"{iter_rec['row']['beats_all_warm']} beats_avail "
        f"{iter_rec['row']['beats_available_cold']}/{iter_rec['row']['beats_available_warm']}")

    results["finished"] = datetime.now().isoformat(timespec="seconds")
    PROBE_JSON.write_text(json.dumps(results, indent=2), encoding="utf-8")

# ==== stats + verdict ====
first_calls = [w["first_call_s"] for it_rec in results["iterations"]
               for w in it_rec["cirq_windows"] if w["first_call_s"] is not None]
all_calls = [c for it_rec in results["iterations"] for w in it_rec["cirq_windows"]
             for c in w.get("calls_s", [])]
budget = GRID["budget"]
n_over_windows = sum(1 for it_rec in results["iterations"] for w in it_rec["cirq_windows"]
                     if w["status"] == "over_budget")
n_windows = len(first_calls)
n_over_calls = sum(1 for c in all_calls if c > budget)
if n_over_windows == 0:
    verdict = "reproducibly_under"
elif n_over_windows == n_windows:
    verdict = "reproducibly_over"
else:
    verdict = "straddles"
stats = {
    "n_windows": n_windows, "n_windows_over_budget": n_over_windows,
    "n_calls": len(all_calls), "n_calls_over_budget": n_over_calls,
    "first_call_s": sorted(first_calls),
    "min_s": min(first_calls) if first_calls else None,
    "median_s": median(first_calls) if first_calls else None,
    "max_s": max(first_calls) if first_calls else None,
    "margin_to_budget_s": (budget - max(first_calls)) if first_calls else None,
    "verdict_vs_budget": verdict,
}
results["stats"] = stats
results["finished"] = datetime.now().isoformat(timespec="seconds")
PROBE_JSON.write_text(json.dumps(results, indent=2), encoding="utf-8")
log(f"== stats: {json.dumps(stats)} ==")
log(f"== PROBE DONE -> {PROBE_JSON} ==")
