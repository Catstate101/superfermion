# sf-cat benchmark suite — Clifford/stabilizer sampling round

Self-contained, notebook-based benchmark of the **`cat_pf`** lane (the
SuperFermion Rust-native Pauli-frame sampler, run via the `sf-cat` release
example `l1_bench`) against **stim / aer / pl / cirq** on bit-identical
stabilizer circuits (`ghz`, seeded `brick` depth-8; LAYER_SEED=11,
CLIFF_SEED=7 — same streams as the shipped sim4 campaign).

## Quick start (Windows / any desktop with the binary)

    python _sfcat_bench_exec.py _sfcat_bench.ipynb     # headless execute (~5-15 min)
    python _sfcat_bench_pack.py                        # results zip + suite zip

or double-click / run:

    run_notebook.bat

## Colab / Jupyter

Open `_sfcat_bench.ipynb` — all outputs (tables, figures, verdicts) are already
embedded from the executed run. **Run All** to reproduce on your own host:

* the competitor lanes run in-process (the notebook pip-installs any missing
  lane dependency itself),
* the `cat_pf` lane needs the `l1_bench` release binary — set `L1_BENCH_EXE`
  (default `D:\sf_cat_target\release\examples\l1_bench.exe`); without it the
  cat rows are recorded as `not_available` and everything else still runs,
* the **last cell** writes `sfcat_bench_results_<host>.zip` (csv + jsonl +
  summary json + report.md + figures) with a download link — on Colab this
  downloads straight to your machine.

## What it measures

| lane | cold | warm |
|---|---|---|
| `cat_pf` | tableau build + plan + first sample (one region) | sample-only from prepared sampler (`counts` = counts-map class, `pack` = raw array class) |
| `stim` | compile_sampler + sample | sampler reuse |
| `aer` | build + measure_all + fresh `AerSimulator(method='stabilizer')` | fresh simulator per rep |
| `pl` | fresh device + QNode + first call (`default.clifford`) | QNode re-run |
| `cirq` | build + fresh `CliffordSimulator` + first run | fresh simulator per rep |
| `sf-ir` | same-window reference lane from the SAME `l1_bench` process | — |

ABBA window order per rung (cat, stim, aer, pl, cirq | cirq, pl, aer, stim,
cat); headline = window mean. n = 64/256/1024/4096, 2000 shots.

**Guards (honest, not fabricated):** per-lane first-call budget 40 s
(`over_budget` = unranked), `cirq` capped at n≤64 and `aer` at n≤256 with the
measured probe evidence recorded in the summary json.

## Artifacts

* `_sfcat_bench.ipynb` — executed notebook (the primary artifact)
* `sfcat_bench_out/` — `sfcat_bench.jsonl` (raw rows), `sfcat_bench_rows.csv`,
  `sfcat_bench_summary.json`, `report.md`, `figs/*.png`
* `sfcat_bench_results_<host>.zip` — the results bundle (written by the
  notebook's last cell)
* `_dist/` — pack output: `sfcat_bench_results_<host>.zip` (executed notebook +
  data) and `sfcat_bench_suite_<host>.zip` (this whole folder, copyable)

## Files

    _sfcat_bench_build.py    regenerates the notebook
    _sfcat_bench_exec.py     headless execution (no per-cell timeout)
    _sfcat_bench_pack.py     results zip + suite folder zip
    requirements.txt         lane dependencies
    run_notebook.bat         one-command execute + pack

## Disclosures

* `cat_pf` runs 4-thread RAYON; competitors run shipped defaults
  (single-threaded tableau backends).
* `cat_pf` is Rust-native and not yet reachable from the Python package — this
  compares engines, not shipped APIs.
* qulacs / qiskit-family do not offer this class (no stabilizer sampling
  engine) — no lane is fabricated for them.
