Open SF_CAT_Benchmark.ipynb in Colab (or Jupyter):
all tables, stdout and inline plots are stored in the notebook.
sfcat_bench_out/figs/*.png are the same figures as image files.
sfcat_bench_out/sfcat_bench.jsonl is the raw row stream (one JSON per rung, both ABBA windows).
sfcat_bench_out/sfcat_bench_rows.csv is the flattened table.
sfcat_bench_out/sfcat_bench_summary.json carries config + verdict + probe evidence.
report.md is the full report.
Summary: run_summary.json
Full reproducible folder: _dist/sfcat_bench_suite[_<host>].zip.
