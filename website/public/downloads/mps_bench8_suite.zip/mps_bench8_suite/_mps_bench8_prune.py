"""Delete pass-1 collateral `over_budget` rows so the resume pass re-runs them.

Why: chunk packing put the sf m=8 teleport wall job (500 shots, ~minutes) in the
same child as sub-second jobs (qft n=50: ~0.2s, teleport m=4: ~1s). When the wall
job burned the whole chunk cap, its chunkmates were killed too and the runner
synthesized over_budget rows for them -- starvation artifacts, not real results.
After the chunk_jobs solo fix, re-running the notebook resumes exactly the rows
removed here: the fast jobs land in normal chunks (-> ok rows) and the wall job
gets its own chunk (-> a genuine over_budget row at its own cap).

Genuine over_budget rows (slow jobs: pl qft n=50, sf wall m=8, aer scale m=40,
if slow) are KEPT unless they match the starvation patterns below.

Usage: python _mps_bench8_prune.py <jsonl> [--apply]     (default: dry-run)
"""
import json
import pathlib
import sys

f = pathlib.Path(sys.argv[1])
apply_ = "--apply" in sys.argv
rows = [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()]


def is_starvation(r):
    """Fast jobs that can only be over_budget because a chunkmate starved them."""
    fw, mode, case = r.get("framework") or "", r.get("mode") or "", r.get("mcm_case") or ""
    if r.get("status") != "over_budget":
        return False
    if fw.startswith("sf") and mode == "qft":
        return True                      # sf qft is sub-second up to n=200 (measured)
    if fw.startswith("sf") and case == "teleport":
        return True                      # m=4 instant; m=8 wall re-runs solo (own cap)
    return False


drop = [r for r in rows if is_starvation(r)]
keep = [r for r in rows if not is_starvation(r)]
print(f"rows total {len(rows)} | starvation rows to drop {len(drop)} | keep {len(keep)}")
for r in drop:
    print("  DROP", r.get("framework"), r.get("mode"), r.get("circuit"),
          "n=", r.get("n_qubits"), r.get("mcm_case") or "", "|", str(r.get("error"))[:80])
other = [r for r in keep if r.get("status") == "over_budget"]
if other:
    print("kept over_budget rows (genuine or to review):")
    for r in other:
        print("  KEEP", r.get("framework"), r.get("mode"), r.get("circuit"),
              "n=", r.get("n_qubits"), r.get("mcm_case") or "", "|", str(r.get("error"))[:80])
if apply_ and drop:
    f.with_suffix(".jsonl.bak").write_text(
        "\n".join(json.dumps(r, default=float) for r in rows) + "\n", encoding="utf-8")
    f.write_text("\n".join(json.dumps(r, default=float) for r in keep) + "\n",
                 encoding="utf-8")
    print(f"APPLIED: {len(drop)} rows removed, backup -> {f.with_suffix('.jsonl.bak').name}")
else:
    print("dry-run only; re-run with --apply to write")
