"""teleport_mps at the exact wall rung (m=8, n=24, 500 shots): the same circuit
that needs ~29 min on the statevector trajectory path, measured on the native
MPS-MCM path, via the official worker + pinned optimized site."""
import json
import os
import pathlib
import subprocess
import time

HERE = pathlib.Path(__file__).resolve().parent
PY = r"c:\Users\ASUS\OneDrive\Desktop\sfdeploy\superfermion\scratch\colab_sim\Scripts\python.exe"
WORKER = HERE / "_mps_bench8_worker.py"
SITE = r"D:\sf_runs\v8_local\sites\superfermion_optimized"
TMP = HERE / "mps_bench8_out" / "batches"

env = os.environ.copy()
for k in ["PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONWARNINGS",
          "SF_MPS_SVD_DEBUG", "SF_MPS_SVD_FULL", "SF_MPS_SKIP_CANON", "SF_MPS_FORCE_CANON",
          "SF_MPS_TRUNCATION"]:
    env.pop(k, None)
env["SF_SITE"] = SITE
env["SF_THREADS"] = "4"
j = {"framework": "sf_optimized", "circuit": "mcm", "layers": 0, "n": 24,
     "bond": None, "method": "mcm", "mode": "mcm", "mcm_case": "teleport_mps",
     "mcm_param": 8, "shots": 500, "reps": 1, "sample_reps": 0, "budget_s": 300}
bf = TMP / "_m8_probe_teleport_mps_s500.json"
bf.write_text(json.dumps([j]), encoding="utf-8")
t0 = time.perf_counter()
p = subprocess.run([PY, "-X", "utf8", str(WORKER), "--batch-file", str(bf)],
                   capture_output=True, text=True, encoding="utf-8",
                   errors="replace", env=env, cwd=str(HERE), timeout=600)
wall = time.perf_counter() - t0
for ln in p.stdout.splitlines():
    if ln.startswith("JOBJSON "):
        r = json.loads(ln[8:])
        t = r.get("t_expval_total_s")
        print(f"teleport_mps m=8 n=24 shots=500 threads=4 status={r['status']} t={t}s "
              f"per_shot={(t / 500 * 1e3):.2f}ms all_correct={r.get('all_correct')} "
              f"proc_wall={wall:.1f}s")
        break
else:
    print(f"NO JOBJSON rc={p.returncode} wall={wall:.1f}s")
    print((p.stdout or "")[-400:])
    print((p.stderr or "")[-400:])
