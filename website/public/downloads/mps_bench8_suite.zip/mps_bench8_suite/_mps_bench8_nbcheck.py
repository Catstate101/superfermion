"""Inspect an executed bench8 notebook: error cells, jsonl row counts, figures, key outputs."""
import json
import pathlib
import sys
from collections import Counter

import nbformat

HERE = pathlib.Path(__file__).resolve().parent
p = HERE / (sys.argv[1] if len(sys.argv) > 1 else "_mps_bench8_quick.ipynb")
nb = nbformat.read(str(p), as_version=4)
bad = 0
for i, c in enumerate(nb.cells):
    errs = [o for o in c.get("outputs", []) if o.get("output_type") == "error"]
    if errs:
        bad += 1
        print(f"cell {i} ERROR: {errs[0].get('ename')}: {str(errs[0].get('evalue'))[:200]}")
print("cells:", len(nb.cells), "| error cells:", bad)

d = HERE / "mps_bench8_out"
for f in sorted(d.glob("*.jsonl")):
    rows = [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()]
    print(f"\n{f.name}: {len(rows)} rows")
    print("  statuses:", dict(Counter(r.get("status") for r in rows)))
    print("  lanes   :", dict(Counter(r.get("framework") for r in rows)))
figs = sorted((d / "figs").glob("*.png")) if (d / "figs").exists() else []
print("\nfigs:", [f.name for f in figs])

want = ("summary tables", "coverage + honest", "RUN:")
for c in nb.cells:
    if c.cell_type != "code":
        continue
    src = c.source
    if any(w in src for w in want[:2]):
        print(f"\n===== output of cell starting: {src.splitlines()[0][:70]} =====")
        for o in c.get("outputs", []):
            if o.get("output_type") == "stream":
                print(o.get("text", "")[:6000])
