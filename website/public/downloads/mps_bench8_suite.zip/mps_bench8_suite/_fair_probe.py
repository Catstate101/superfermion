"""Fair-comparison audit (same host, same window, official worker + pinned site).

A) thread honoring: stress brick12 n=500, sf_optimized + aer at SF_THREADS=1/4/8
   (i7-8565U: 4 physical / 8 logical cores; campaign cap is 4)
B) same-window ABBA re-measure of the headline claims (SF_THREADS=4):
   stress brick12 n=200/500/1000, sf_optimized vs aer; official j_std spec
C) MCM controlled rows (SF_THREADS=4):
   teleport_mps m=40 1000 shots (sf) vs scale_teleport m=40 (aer), ABBA;
   teleport m=4 at EQUAL 500 shots, all four lanes, ABBA-symmetric;
   mbqc N=17 at 200 shots, sf vs cirq, ABBA

sample_reps=0 (isolate the expval timing = the headline metric; the official
t_expval rows are unaffected by the separate sampling block)."""
import json
import os
import pathlib
import subprocess
import time

HERE = pathlib.Path(__file__).resolve().parent
PY = r"C:\Python313\python.exe"
WORKER = HERE / "_mps_bench8_worker.py"
SITE = r"D:\sf_runs\v8_local\sites\superfermion_optimized"
TMP = HERE / "mps_bench8_out" / "batches"
ALL_ROWS = []


def j_std(lane, circ, n, method="mps", mode="stress", reps=3):
    return {"framework": lane, "circuit": circ,
            "layers": 0 if circ in ("ghz", "qft") else int(circ[5:]),
            "n": n, "bond": 64, "method": method, "mode": mode,
            "reps": reps, "sample_reps": 0, "budget_s": 600}


def j_mcm(lane, case, n, param, shots):
    return {"framework": lane, "circuit": "mcm", "layers": 0, "n": n, "bond": None,
            "method": "mcm", "mode": "mcm", "mcm_case": case, "mcm_param": param,
            "shots": shots, "reps": 1, "sample_reps": 0, "budget_s": 600}


def child(threads, jobs, tag):
    env = os.environ.copy()
    for k in ["PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONWARNINGS",
              "SF_MPS_SVD_DEBUG", "SF_MPS_SVD_FULL", "SF_MPS_SKIP_CANON",
              "SF_MPS_FORCE_CANON", "SF_MPS_TRUNCATION"]:
        env.pop(k, None)
    env["SF_SITE"] = SITE
    env["SF_THREADS"] = str(threads)
    bf = TMP / f"_fair_{tag}.json"
    bf.write_text(json.dumps(jobs), encoding="utf-8")
    t0 = time.perf_counter()
    p = subprocess.run([PY, "-X", "utf8", str(WORKER), "--batch-file", str(bf)],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", env=env, cwd=str(HERE), timeout=1800)
    wall = time.perf_counter() - t0
    out = []
    for ln in p.stdout.splitlines():
        if ln.startswith("JOBJSON "):
            out.append(json.loads(ln[8:]))
    ALL_ROWS.extend(out)
    if not out:
        print(f"[{tag}] NO JOBJSON rc={p.returncode} wall={wall:.1f}s")
        print((p.stdout or "")[-500:])
        print((p.stderr or "")[-500:])
    return out


def lane_tag(r):
    case = r.get("mcm_case") or "-"
    s = f"{r['framework']} {r['circuit']} n={r['n_qubits']} {case}"
    if r.get("mcm_case"):
        s += f" m={r.get('mcm_param')}"
    return s


print("=== A) thread honoring: stress brick12 n=500 @ SF_THREADS=1/4/8 ===", flush=True)
for th in (1, 4, 8):
    rs = child(th, [j_std("sf_optimized", "brick12", 500),
                    j_std("aer", "brick12", 500)], f"th{th}")
    for r in rs:
        print(f"  th={th} {lane_tag(r)} status={r['status']} t={r.get('t_expval_total_s')} "
              f"trials={r.get('trials')}", flush=True)

print("=== B) ABBA same-window: stress brick12, sf vs aer (SF_THREADS=4) ===", flush=True)
for n in (1000, 500, 200):
    rs = child(4, [j_std("sf_optimized", "brick12", n), j_std("aer", "brick12", n),
                   j_std("aer", "brick12", n), j_std("sf_optimized", "brick12", n)],
               f"abba{n}")
    for r in rs:
        print(f"  n={n} {lane_tag(r)} t={r.get('t_expval_total_s')} "
              f"trials={r.get('trials')} expval={r.get('expval_z0zlast')}", flush=True)

print("=== C1) teleport_mps m=40 (1000 shots) ABBA sf vs aer ===", flush=True)
rs = child(4, [j_mcm("sf_optimized", "teleport_mps", 120, 40, 1000),
               j_mcm("aer", "scale_teleport", 120, 40, 1000),
               j_mcm("aer", "scale_teleport", 120, 40, 1000),
               j_mcm("sf_optimized", "teleport_mps", 120, 40, 1000)], "mps40")
for r in rs:
    print(f"  {lane_tag(r)} shots={r.get('shots')} t={r.get('t_expval_total_s')} "
          f"ok={r.get('all_correct')}", flush=True)

print("=== C2) teleport m=4 at EQUAL 500 shots, all lanes, ABBA-symmetric ===", flush=True)
rs = child(4, [j_mcm("sf_optimized", "teleport", 12, 4, 500),
               j_mcm("aer", "teleport", 12, 4, 500),
               j_mcm("pl", "teleport", 12, 4, 500),
               j_mcm("cirq", "teleport", 12, 4, 500),
               j_mcm("cirq", "teleport", 12, 4, 500),
               j_mcm("pl", "teleport", 12, 4, 500),
               j_mcm("aer", "teleport", 12, 4, 500),
               j_mcm("sf_optimized", "teleport", 12, 4, 500)], "tp4")
for r in rs:
    print(f"  {lane_tag(r)} shots={r.get('shots')} t={r.get('t_expval_total_s')} "
          f"ok={r.get('all_correct')}", flush=True)

print("=== C3) mbqc N=17 (200 shots) ABBA sf vs cirq ===", flush=True)
rs = child(4, [j_mcm("sf_optimized", "mbqc", 17, 17, 200),
               j_mcm("cirq", "mbqc", 17, 17, 200),
               j_mcm("cirq", "mbqc", 17, 17, 200),
               j_mcm("sf_optimized", "mbqc", 17, 17, 200)], "mbqc")
for r in rs:
    print(f"  {lane_tag(r)} shots={r.get('shots')} t={r.get('t_expval_total_s')} "
          f"ok={r.get('all_correct')}", flush=True)

(HERE / "_fair_probe_rows.json").write_text(json.dumps(ALL_ROWS, indent=1),
                                            encoding="utf-8")
print("FAIR_PROBE_DONE", flush=True)
