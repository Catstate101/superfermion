@echo off
rem Headless run of the MPS+MCM benchmark notebook (in-place, resume-safe),
rem then pack the results (executed notebook + figures + data) into _dist\*.zip.
cd /d "%~dp0"
python -X utf8 _mps_bench8_exec.py _mps_bench8.ipynb
if errorlevel 1 (
  echo.
  echo Notebook execution reported a failure - the pack step still archives what ran.
)
python -X utf8 _mps_bench8_pack.py
pause
