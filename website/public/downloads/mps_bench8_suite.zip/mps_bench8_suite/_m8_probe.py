"""m=8 statevector wall investigation: per-shot cost scaling for the sf.run
statevector MCM trajectory replay (teleport chain, default method), across
m = 4/6/8 and thread counts, via the official worker + pinned optimized site."""
import json
import os
import pathlib
import subprocess
import time

HERE = pathlib.Path(__file__).resolve().parent
PY = r"c:\Users\ASUS\OneDrive\Desktop\sfdeploy\superfermion\scratch\colab_sim\Scripts\python.exe"
WORKER = HERE / "_mps_bench8_worker.py"
SITE = r"D:\sf_runs\v8_local\sites\superfermion_optimized"
TMP = HERE / "mps_bench8_out" / "batches"


def run(m, shots, threads):
    env = os.environ.copy()
    for k in ["PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONWARNINGS",
              "SF_MPS_SVD_DEBUG", "SF_MPS_SVD_FULL", "SF_MPS_SKIP_CANON", "SF_MPS_FORCE_CANON",
              "SF_MPS_TRUNCATION"]:
        env.pop(k, None)
    env["SF_SITE"] = SITE
    env["SF_THREADS"] = str(threads)
    j = {"framework": "sf_optimized", "circuit": "mcm", "layers": 0, "n": 3 * m,
         "bond": None, "method": "mcm", "mode": "mcm", "mcm_case": "teleport",
         "mcm_param": m, "shots": shots, "reps": 1, "sample_reps": 0, "budget_s": 300}
    bf = TMP / f"_m8_probe_m{m}_s{shots}_t{threads}.json"
    bf.write_text(json.dumps([j]), encoding="utf-8")
    t0 = time.perf_counter()
    p = subprocess.run([PY, "-X", "utf8", str(WORKER), "--batch-file", str(bf)],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", env=env, cwd=str(HERE), timeout=900)
    wall = time.perf_counter() - t0
    for ln in p.stdout.splitlines():
        if ln.startswith("JOBJSON "):
            r = json.loads(ln[8:])
            t = r.get("t_expval_total_s")
            print(f"m={m} n={3*m} shots={shots} threads={threads} status={r['status']} "
                  f"t={t}s per_shot={(t / shots * 1e3):.2f}ms all_correct={r.get('all_correct')} "
                  f"proc_wall={wall:.1f}s")
            return
    print(f"m={m} shots={shots} t={threads} NO JOBJSON rc={p.returncode} wall={wall:.1f}s")
    print((p.stdout or "")[-400:])
    print((p.stderr or "")[-400:])


run(4, 500, 4)   # baseline rung (official m=4 row is 0.0506 s)
run(6, 96, 4)    # 2^18
run(8, 48, 4)    # the wall rung, small shot count -> extrapolate 500
run(8, 48, 1)    # thread scaling at the wall rung
