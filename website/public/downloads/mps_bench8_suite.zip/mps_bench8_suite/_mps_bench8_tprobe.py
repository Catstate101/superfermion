"""Hard-timeout wrapper for the bench8 probes.

Usage:
  python _mps_bench8_tprobe.py <probe> <cap_s> [case [args...]]

Spawns `_mps_bench8_<probe>.py` with the same interpreter and environment,
streams its output live, and kills it after <cap_s> seconds. Prints a
verdict line: either `[TW] finished rc=0 in Xs` or `[TW] TIMEOUT after cap=Xs`.
"""
import pathlib
import queue
import subprocess
import sys
import threading
import time

HERE = r"c:\Users\ASUS\OneDrive\Desktop\sfdocs"


def main():
    probe, cap = sys.argv[1], float(sys.argv[2])
    args = sys.argv[3:]
    script = rf"{HERE}\_mps_bench8_{probe}.py"
    logdir = pathlib.Path(HERE) / "_mps_bench8_logs"
    logdir.mkdir(exist_ok=True)
    logf = (logdir / (f"{probe}_" + "_".join(args or ["all"]) + ".log")).open(
        "w", encoding="utf-8")
    t0 = time.perf_counter()
    p = subprocess.Popen([sys.executable, "-X", "utf8", script] + args,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, encoding="utf-8", errors="replace")
    # Reader thread + deadline loop: the cap fires even when the child is silent,
    # so a hung case can never outlive cap seconds (the earlier blocking
    # `for line in p.stdout` loop could wait forever on a quiet child).
    q = queue.Queue()

    def reader():
        for line in p.stdout:
            q.put(line)
        q.put(None)

    threading.Thread(target=reader, daemon=True).start()
    timed_out = False
    while True:
        remaining = cap - (time.perf_counter() - t0)
        if remaining <= 0:
            timed_out = True
            break
        try:
            line = q.get(timeout=min(1.0, remaining))
        except queue.Empty:
            continue
        if line is None:
            break
        print(line, end="", flush=True)
        logf.write(line)
        logf.flush()
    if p.poll() is None:
        p.kill()
        p.wait()
    dt = time.perf_counter() - t0
    if timed_out or p.returncode not in (0, None):
        verdict = f"[TW] TIMEOUT/FAIL {args} -> rc={p.returncode} elapsed={dt:.1f}s cap={cap}s"
    else:
        verdict = f"[TW] finished {args} rc=0 in {dt:.1f}s"
    print(verdict, flush=True)
    logf.write(verdict + "\n")
    logf.close()


main()
