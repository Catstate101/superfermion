"""_mps_bench8_worker.py -- MPS-to-1000-qubits + mid-circuit-measurement benchmark worker.

Lanes (same as bench7):
  sf_optimized | sf_wheel | sf_source : superfermion builds (site root via env SF_SITE)
  aer  : Qiskit AerSimulator('matrix_product_state')
  pl   : PennyLane default.tensor(method='mps')   (quimb; analytic expval only)
  cirq : cirq.contrib.quimb.MPSSimulator          (quimb; no dense extraction)
  qulacs : not_offered (no MPS engine, no classical feed-forward)

Suites (job["mode"]):
  validate : n in {12, 16}, ghz + brick4, mps + dense rows (cross-engine anchors)
  ladder   : n in {50,100,200,500,1000}, ghz + brick4 (headline MPS scale grid)
  stress   : brick12 at n in {200,500,1000} (entanglement pressure, real truncation)
  qft      : QFT at 50/100/200 where the lane can (pl 20 live; cirq<=30 live, crash >=40)
  bonds    : bond sweep n=16 brick4 with TVD-versus-exact (sf/aer) plus
             n=200 brick12 bond sweep with discarded weight / fidelity estimate
  mcm      : teleport chain m=4 (all lanes, 500 shots) + the n=24 wall rung m=8
             (all lanes, 500 shots), MBQC wire N=17 (all lanes, 200 shots),
             rep-code d=3 AND-ancilla lookup (all feed-forward lanes: sf/aer/pl/cirq;
             qulacs not_offered), MPS+MCM scale teleport m=4/10/20/40 on aer AND all
             three sf builds (sf collapses the MPS itself per shot; old pip builds
             record unsupported)

Protocol pins (established by probes 2-5; logs in _mps_bench8_logs/):
  - same gate sequences on every engine (no native templates in timed rows);
    QFT = H + controlled-phase grid + reversal swaps everywhere
  - brick parameter stream: seed 7, layers of RY + ZZ brick (bench7 replica)
  - SF bricks <= 4 layers never exceed bond 4; brick12 is the truncation probe
  - endianness: sf/aer counts = little-endian int(key, 2), bit i = qubit i;
    pl dense = big-endian; cirq dense = little-endian (validate rows carry it)
  - sf counts report the POST-MEASUREMENT QUBIT STATES (the classical register is
    not echoed): sf MCM correctness checks read the target/data qubits themselves;
    aer counts are the classical register (clbit positions); pl/cirq sample wires
  - sf dynamic MCM cost ~2^n on the statevector method: n=12 0.4s, n>=24 over
    any sane budget -> cap n<=18 for method='statevector'; method='mps'
    (bond_dim-capped, no 2^n expansion) runs the scale teleport rows n=30..120
  - Aer MCM works in BOTH statevector and MPS (scale rows m=4/10/20/40)
  - pl/cirq MCM run on their trajectory simulators (default.qubit / cirq.Simulator)
  - cirq partial-trace sampling is reps-bounded: only used for n<=200 in the builder
  - MCM correctness checks: every measured target/output bit must be 1 in every
    sampled shot (deterministic circuits; wrong corrections would flip bits)

The worker prints one `JOBSTART {..}` line before each job and one
`JOBJSON {row}` line per finished job (streamed, flush=True). Chunk-level hard
timeouts live in the notebook RUN cell; jobs that do not finish inside their
budget become `status="over_budget"` rows there.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
BOND_DEFAULT = 64
SHOTS = 4000
CIRQ_REPS = 100
LAYER_SEED = 7
SAMPLE_SEED = 5
LANES = ["sf_optimized", "sf_wheel", "sf_source", "aer", "pl", "cirq", "qulacs"]

FIELDS = ["framework", "fw_version", "engine_md5", "site", "circuit", "layers",
          "n_qubits", "bond", "method", "mode", "mcm_case", "mcm_param", "shots",
          "status", "expval_z0zlast", "t_expval_total_s", "trials", "t_sample_s",
          "sample_reps", "sample_distinct", "all_correct", "quality",
          "rss_mb", "peak_rss_mb", "budget_s", "notes", "error"]


def bootstrap_env() -> int:
    threads = os.environ.get("SF_THREADS", "4")
    for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "RAYON_NUM_THREADS", "NUMBA_NUM_THREADS"):
        os.environ[var] = threads
    return int(threads) if threads.isdigit() else 1


def enter_site(site: str) -> None:
    if site:
        p = str(pathlib.Path(site))
        if p in sys.path:
            sys.path.remove(p)
        sys.path.insert(0, p)


def md5_file(path: pathlib.Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def engine_md5(sf_module) -> str:
    # Prefer the extension module that actually got imported (_sf_core.__file__);
    # globbing the package dir is only a fallback (never matches *.pyd.bak-* files).
    try:
        core = getattr(sf_module, "_sf_core", None)
        core_file = getattr(core, "__file__", "") if core is not None else ""
        p = pathlib.Path(core_file).resolve() if core_file else None
        if p is not None and p.suffix.lower() in (".pyd", ".so") and p.exists():
            return md5_file(p)
    except Exception:
        pass
    try:
        pkg = pathlib.Path(sf_module.__file__).resolve().parent
        cands = sorted(pkg.glob("_sf_core*.pyd")) + sorted(pkg.glob("_sf_core*.so"))
        if cands:
            return md5_file(cands[0])
    except Exception:
        pass
    return ""


def verify_site_load(sf_module, lane: str) -> None:
    """Fail-loud guard: a pinned lane must import superfermion from its own site.

    Observed failure mode: the site dir momentarily flaps (AV scan / lock) ->
    `import superfermion` silently falls back to the user-site build -> the lane
    times a different engine. Rows carrying that would be poisoned, so instead
    raise here: the job becomes an `error` row (non-terminal -> re-queued by the
    resume scan), never a silent wrong number.
    """
    site = os.environ.get("SF_SITE", "")
    if not site:
        return  # unpinned lane (e.g. Colab): environment fallback is the contract
    want = (pathlib.Path(site) / "superfermion").resolve()
    got = pathlib.Path(getattr(sf_module, "__file__", "") or "").resolve()
    if got.parent != want:
        raise RuntimeError(
            f"site-fallback guard [{lane}]: superfermion imported from {got} "
            f"but SF_SITE pins {want}; refusing to run the wrong build")
    core = getattr(sf_module, "_sf_core", None)
    core_file = getattr(core, "__file__", "") if core is not None else ""
    if core_file:
        cf = pathlib.Path(core_file).resolve()
        if want not in cf.parents:
            raise RuntimeError(
                f"site-fallback guard [{lane}]: _sf_core loaded from {cf}, "
                f"outside pinned site {want}")


def build_params(n: int, layers: int, seed: int = LAYER_SEED):
    """Exact replica of the standing brick parameter stream (seed 7)."""
    import numpy as np
    rng = np.random.default_rng(seed)
    out = []
    for layer in range(layers):
        rys = [float(rng.uniform(-np.pi, np.pi)) for _ in range(n)]
        rzzs = [(i, float(rng.uniform(-np.pi, np.pi))) for i in range(layer % 2, n - 1, 2)]
        out.append((rys, rzzs))
    return out


def rss_info() -> dict:
    out = {"rss_mb": None, "peak_rss_mb": None}
    try:
        import psutil
        mi = psutil.Process(os.getpid()).memory_info()
        out["rss_mb"] = round(mi.rss / 2 ** 20, 1)
        pw = getattr(mi, "peak_wset", None)
        if pw:
            out["peak_rss_mb"] = round(pw / 2 ** 20, 1)
        return out
    except Exception:
        pass
    try:
        import ctypes
        from ctypes import wintypes

        class PMC(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
        pmc = PMC()
        pmc.cb = ctypes.sizeof(PMC)
        ctypes.windll.psapi.GetProcessMemoryInfo(
            ctypes.windll.kernel32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb)
        out["rss_mb"] = round(pmc.WorkingSetSize / 2 ** 20, 1)
        out["peak_rss_mb"] = round(pmc.PeakWorkingSetSize / 2 ** 20, 1)
    except Exception:
        pass
    return out


def base_res(J: dict) -> dict:
    return {"framework": J["framework"], "fw_version": "", "engine_md5": "",
            "site": os.environ.get("SF_SITE", ""), "circuit": J["circuit"],
            "layers": J.get("layers"), "n_qubits": J["n"], "bond": J.get("bond"),
            "method": J.get("method", "mps"), "mode": J.get("mode", ""),
            "mcm_case": J.get("mcm_case", ""), "mcm_param": J.get("mcm_param"),
            "shots": J.get("shots") or 0, "status": "ok", "expval_z0zlast": None,
            "t_expval_total_s": None, "trials": [], "t_sample_s": None,
            "sample_reps": 0, "sample_distinct": None, "all_correct": None,
            "quality": "", "rss_mb": None, "peak_rss_mb": None,
            "budget_s": J.get("budget_s"), "notes": "", "error": ""}


def median(xs):
    s = sorted(xs)
    return s[len(s) // 2]


def check_bits_lsb(counts, positions):
    """True when every key kk has bit i == 1 for all i in positions.

    Counts keys are bit strings; bit i of int(key, 2) is qubit i for the
    little-endian engines (sf, aer -> pinned in probe 3)."""
    for kk in counts:
        v = int(kk, 2)
        for i in positions:
            if ((v >> i) & 1) != 1:
                return False
    return True


# --------------------------------------------------------------------------
# circuit builders (identical gate sequences on every engine)
# --------------------------------------------------------------------------

def _sf_circuit(sf, J: dict):
    n = J["n"]
    if J["circuit"] == "ghz":
        c = sf.Circuit(n).h(0)
        for i in range(n - 1):
            c = c.cnot(i, i + 1)
        return c
    if J["circuit"] == "qft":
        c = sf.Circuit(n)
        import math
        for j in range(n):
            c = c.h(j)
            for k in range(j + 1, n):
                c = c.cp(2 * math.pi / (2 ** (k - j + 1)), k, j)
        for i in range(n // 2):
            c = c.swap(i, n - 1 - i)
        return c
    params = build_params(n, J.get("layers") or int(J["circuit"][5:]))
    c = sf.Circuit(n)
    for rys, rzzs in params:
        for i in range(n):
            c = c.ry(rys[i], i)
        for i, v in rzzs:
            c = c.rzz(v, i, i + 1)
    return c


def _aer_qc(J: dict, measure: bool, save_expval: bool):
    from qiskit import QuantumCircuit
    from qiskit.quantum_info import Pauli
    n = J["n"]
    qc = QuantumCircuit(n)
    if J["circuit"] == "ghz":
        qc.h(0)
        for i in range(n - 1):
            qc.cx(i, i + 1)
    elif J["circuit"] == "qft":
        import math
        for j in range(n):
            qc.h(j)
            for k in range(j + 1, n):
                qc.cp(2 * math.pi / (2 ** (k - j + 1)), k, j)
        for i in range(n // 2):
            qc.swap(i, n - 1 - i)
    else:
        for rys, rzzs in build_params(n, J.get("layers") or int(J["circuit"][5:])):
            for i in range(n):
                qc.ry(rys[i], i)
            for i, v in rzzs:
                qc.rzz(v, i, i + 1)
    if save_expval:
        qc.save_expectation_value(Pauli("Z" + "I" * (n - 2) + "Z"), list(range(n)))
    if measure:
        qc.measure_all()
    return qc


def _pl_circuit_body(qml, J: dict, n: int):
    if J["circuit"] == "ghz":
        qml.Hadamard(0)
        for i in range(n - 1):
            qml.CNOT(wires=[i, i + 1])
    elif J["circuit"] == "qft":
        import math
        for j in range(n):
            qml.Hadamard(j)
            for k in range(j + 1, n):
                qml.ctrl(qml.PhaseShift, control=k)(2 * math.pi / (2 ** (k - j + 1)), wires=j)
        for i in range(n // 2):
            qml.SWAP(wires=[i, n - 1 - i])
    else:
        for rys, rzzs in build_params(n, J.get("layers") or int(J["circuit"][5:])):
            for i in range(n):
                qml.RY(rys[i], wires=i)
            for i, v in rzzs:
                qml.IsingZZ(v, wires=[i, i + 1])


def _cirq_circuit(J: dict):
    import cirq
    import numpy as np
    n = J["n"]
    q = cirq.LineQubit.range(n)
    if J["circuit"] == "ghz":
        return q, cirq.Circuit([cirq.H(q[0])] + [cirq.CNOT(q[i], q[i + 1]) for i in range(n - 1)])
    if J["circuit"] == "qft":
        ops = []
        for j in range(n):
            ops.append(cirq.H(q[j]))
            for k in range(j + 1, n):
                ops.append(cirq.CZ(q[k], q[j]) ** (1 / (2 ** (k - j))))
        for i in range(n // 2):
            ops.append(cirq.SWAP(q[i], q[n - 1 - i]))
        return q, cirq.Circuit(ops)
    moments = []
    for rys, rzzs in build_params(n, J.get("layers") or int(J["circuit"][5:])):
        moments.append([cirq.ry(rys[i]).on(q[i]) for i in range(n)])
        if rzzs:
            moments.append([cirq.ZZPowGate(exponent=v / np.pi).on(q[i], q[i + 1])
                            for i, v in rzzs])
    return q, cirq.Circuit(moments)


# --------------------------------------------------------------------------
# MCM circuit builders (teleport chain / MBQC wire), per engine
# --------------------------------------------------------------------------

def sf_teleport(sf, m):
    n = 3 * m
    c = sf.Circuit(n, 3 * m)
    for k in range(m):
        a, b, t_ = 3 * k, 3 * k + 1, 3 * k + 2
        c = c.x(a)
        c = c.h(b)
        c = c.cx(b, t_)
        c = c.cx(a, b)
        c = c.h(a)
        c = c.measure(a, 3 * k)
        c = c.measure(b, 3 * k + 1)
        c = c.c_if(3 * k, 1).z(t_)
        c = c.c_if(3 * k + 1, 1).x(t_)
        c = c.measure(t_, 3 * k + 2)
    return c


def sf_mbqc(sf, N):
    """One-way wire, input |1>; M = N-1 measurements. For even M the fitted rule
    is: k even -> Z(out) if s_k; k odd -> X(out) if s_k (probe 4/5, all 2^M
    histories verified for both parity classes)."""
    c = sf.Circuit(N, N)
    c = c.x(0)
    for k in range(1, N):
        c = c.h(k)
    for k in range(N - 1):
        c = c.cz(k, k + 1)
    for k in range(N - 1):
        c = c.h(k)
        c = c.measure(k, k)
        if (k % 2 == 0) if (N - 1) % 2 == 0 else (k % 2 == 1):
            c = c.c_if(k, 1).z(N - 1)
        else:
            c = c.c_if(k, 1).x(N - 1)
    c = c.measure(N - 1, N - 1)
    return c


def sf_repcode(sf, err):
    """Rep-code d=3 round with AND-ancilla syndrome lookup (aer construction
    ported to sf, probe-validated on the pinned builds for all four patterns;
    data |111> -> corrected |111>)."""
    c = sf.Circuit(12, 12)
    d0, d1, d2 = 0, 1, 2
    a0, a1 = 3, 4
    u0, u1, v0, v1, t1, t2, t3 = 5, 6, 7, 8, 9, 10, 11
    c = c.x(d0)
    c = c.x(d1)
    c = c.x(d2)
    if err is not None:
        c = c.x(err)
    c = c.cx(d0, a0)
    c = c.cx(d1, a0)
    c = c.cx(d1, a1)
    c = c.cx(d2, a1)
    c = c.measure(a0, 0)
    c = c.measure(a1, 1)
    c = c.c_if(0, 1).x(u0)
    c = c.c_if(1, 1).x(u1)
    c = c.c_if(0, 1).x(v0)
    c = c.x(v0)
    c = c.c_if(1, 1).x(v1)
    c = c.x(v1)
    c = c.ccx(u0, v1, t1)
    c = c.ccx(v0, u1, t2)
    c = c.ccx(u0, u1, t3)
    c = c.measure(t1, 2)
    c = c.measure(t2, 3)
    c = c.measure(t3, 4)
    c = c.c_if(2, 1).x(d0)
    c = c.c_if(3, 1).x(d2)
    c = c.c_if(4, 1).x(d1)
    c = c.measure(d0, 5)
    c = c.measure(d1, 6)
    c = c.measure(d2, 7)
    return c


def aer_mcm_qc(m, n_cbits=None, out_positions=None):
    from qiskit import QuantumCircuit, ClassicalRegister
    n = 3 * m
    creg = ClassicalRegister(3 * m)
    qc = QuantumCircuit(n)
    qc.add_register(creg)
    for k in range(m):
        a, b, t_ = 3 * k, 3 * k + 1, 3 * k + 2
        qc.x(a)
        qc.h(b)
        qc.cx(b, t_)
        qc.cx(a, b)
        qc.h(a)
        qc.measure(a, 3 * k)
        qc.measure(b, 3 * k + 1)
        with qc.if_test((creg[3 * k], 1)):
            qc.z(t_)
        with qc.if_test((creg[3 * k + 1], 1)):
            qc.x(t_)
        qc.measure(t_, 3 * k + 2)
    return qc


def aer_mbqc_qc(N):
    from qiskit import QuantumCircuit, ClassicalRegister
    creg = ClassicalRegister(N)
    qc = QuantumCircuit(N)
    qc.add_register(creg)
    qc.x(0)
    for k in range(1, N):
        qc.h(k)
    for k in range(N - 1):
        qc.cz(k, k + 1)
    for k in range(N - 1):
        qc.h(k)
        qc.measure(k, k)
        if (k % 2 == 0) if (N - 1) % 2 == 0 else (k % 2 == 1):
            with qc.if_test((creg[k], 1)):
                qc.z(N - 1)
        else:
            with qc.if_test((creg[k], 1)):
                qc.x(N - 1)
    qc.measure(N - 1, N - 1)
    return qc


def aer_repcode_qc(err):
    """Rep-code d=3 round with AND-ancilla syndrome lookup (validated on aer sv,
    all four error patterns deterministic). Data |111> -> corrected |111>."""
    from qiskit import QuantumCircuit, ClassicalRegister
    creg = ClassicalRegister(12)
    qc = QuantumCircuit(12)
    qc.add_register(creg)
    d0, d1, d2 = 0, 1, 2
    a0, a1 = 3, 4
    u0, u1, v0, v1, t1, t2, t3 = 5, 6, 7, 8, 9, 10, 11
    qc.x(d0)
    qc.x(d1)
    qc.x(d2)
    if err is not None:
        qc.x(err)
    qc.cx(d0, a0)
    qc.cx(d1, a0)
    qc.cx(d1, a1)
    qc.cx(d2, a1)
    qc.measure(a0, 0)
    qc.measure(a1, 1)
    with qc.if_test((creg[0], 1)):
        qc.x(u0)
    with qc.if_test((creg[1], 1)):
        qc.x(u1)
    with qc.if_test((creg[0], 1)):
        qc.x(v0)
    qc.x(v0)
    with qc.if_test((creg[1], 1)):
        qc.x(v1)
    qc.x(v1)
    qc.ccx(u0, v1, t1)
    qc.ccx(v0, u1, t2)
    qc.ccx(u0, u1, t3)
    qc.measure(t1, 2)
    qc.measure(t2, 3)
    qc.measure(t3, 4)
    with qc.if_test((creg[2], 1)):
        qc.x(d0)
    with qc.if_test((creg[3], 1)):
        qc.x(d2)
    with qc.if_test((creg[4], 1)):
        qc.x(d1)
    qc.measure(d0, 5)
    qc.measure(d1, 6)
    qc.measure(d2, 7)
    return qc


def pl_teleport_qnode(qml, m, shots):
    n = 3 * m
    dev = qml.device("default.qubit", wires=n, shots=shots)

    @qml.qnode(dev)
    def circ():
        for k in range(m):
            a, b, t_ = 3 * k, 3 * k + 1, 3 * k + 2
            qml.PauliX(a)
            qml.Hadamard(b)
            qml.CNOT([b, t_])
            qml.CNOT([a, b])
            qml.Hadamard(a)
            ma = qml.measure(a)
            mb = qml.measure(b)
            qml.cond(mb, qml.PauliX)(t_)
            qml.cond(ma, qml.PauliZ)(t_)
        return qml.sample(wires=list(range(n)))

    return circ


def pl_mbqc_qnode(qml, N, shots):
    dev = qml.device("default.qubit", wires=N, shots=shots)

    @qml.qnode(dev)
    def circ():
        qml.PauliX(0)
        for k in range(1, N):
            qml.Hadamard(k)
        for k in range(N - 1):
            qml.CZ(wires=[k, k + 1])
        meas = []
        for k in range(N - 1):
            qml.Hadamard(k)
            meas.append(qml.measure(k))
        for k in range(N - 1):
            if (k % 2 == 0) if (N - 1) % 2 == 0 else (k % 2 == 1):
                qml.cond(meas[k], qml.PauliZ)(N - 1)
            else:
                qml.cond(meas[k], qml.PauliX)(N - 1)
        return qml.sample(wires=list(range(N)))

    return circ


def pl_repcode_qnode(qml, err, shots):
    """Rep-code d=3 with AND-ancilla syndrome lookup on default.qubit trajectories
    (aer construction ported to pl; all four patterns pre-verified)."""
    dev = qml.device("default.qubit", wires=12, shots=shots)

    @qml.qnode(dev)
    def circ():
        d0, d1, d2 = 0, 1, 2
        a0, a1 = 3, 4
        u0, u1, v0, v1, t1, t2, t3 = 5, 6, 7, 8, 9, 10, 11
        qml.PauliX(d0)
        qml.PauliX(d1)
        qml.PauliX(d2)
        if err is not None:
            qml.PauliX(err)
        qml.CNOT([d0, a0])
        qml.CNOT([d1, a0])
        qml.CNOT([d1, a1])
        qml.CNOT([d2, a1])
        ma = qml.measure(a0)
        mb = qml.measure(a1)
        qml.cond(ma, qml.PauliX)(u0)
        qml.cond(mb, qml.PauliX)(u1)
        qml.cond(ma, qml.PauliX)(v0)
        qml.PauliX(v0)
        qml.cond(mb, qml.PauliX)(v1)
        qml.PauliX(v1)
        qml.Toffoli([u0, v1, t1])
        qml.Toffoli([v0, u1, t2])
        qml.Toffoli([u0, u1, t3])
        mt1 = qml.measure(t1)
        mt2 = qml.measure(t2)
        mt3 = qml.measure(t3)
        qml.cond(mt1, qml.PauliX)(d0)
        qml.cond(mt2, qml.PauliX)(d2)
        qml.cond(mt3, qml.PauliX)(d1)
        return qml.sample(wires=[d0, d1, d2])

    return circ


def cirq_teleport_circuit(N_or_m, is_mbqc, N_mbqc=None):
    import cirq
    if is_mbqc:
        N = N_mbqc
        q = cirq.LineQubit.range(N)
        ops = [cirq.X(q[0])]
        ops += [cirq.H(q[k]) for k in range(1, N)]
        ops += [cirq.CZ(q[k], q[k + 1]) for k in range(N - 1)]
        for k in range(N - 1):
            ops.append(cirq.H(q[k]))
            ops.append(cirq.measure(q[k], key=f"m{k}"))
            if (k % 2 == 0) if (N - 1) % 2 == 0 else (k % 2 == 1):
                ops.append(cirq.Z(q[N - 1]).with_classical_controls(f"m{k}"))
            else:
                ops.append(cirq.X(q[N - 1]).with_classical_controls(f"m{k}"))
        ops.append(cirq.measure(q[N - 1], key="out"))
        return q, cirq.Circuit(ops)
    m = N_or_m
    n = 3 * m
    q = cirq.LineQubit.range(n)
    ops = []
    for k in range(m):
        a, b, t_ = q[3 * k], q[3 * k + 1], q[3 * k + 2]
        ops += [cirq.X(a), cirq.H(b), cirq.CNOT(b, t_), cirq.CNOT(a, b), cirq.H(a)]
        ops.append(cirq.measure(a, key=f"a{k}"))
        ops.append(cirq.measure(b, key=f"b{k}"))
        ops.append(cirq.X(t_).with_classical_controls(f"b{k}"))
        ops.append(cirq.Z(t_).with_classical_controls(f"a{k}"))
    ops.append(cirq.measure(*q, key="out"))
    return q, cirq.Circuit(ops)


def cirq_repcode_circuit(err):
    """Rep-code d=3 with AND-ancilla syndrome lookup on cirq.Simulator (ported
    from the aer construction; all four patterns pre-verified)."""
    import cirq
    q = cirq.LineQubit.range(12)
    d0, d1, d2 = q[0], q[1], q[2]
    a0, a1 = q[3], q[4]
    u0, u1, v0, v1, t1, t2, t3 = q[5], q[6], q[7], q[8], q[9], q[10], q[11]
    ops = [cirq.X(d0), cirq.X(d1), cirq.X(d2)]
    if err is not None:
        ops.append(cirq.X(q[err]))
    ops += [cirq.CNOT(d0, a0), cirq.CNOT(d1, a0), cirq.CNOT(d1, a1), cirq.CNOT(d2, a1)]
    ops.append(cirq.measure(a0, key="sa"))
    ops.append(cirq.measure(a1, key="sb"))
    ops.append(cirq.X(u0).with_classical_controls("sa"))
    ops.append(cirq.X(u1).with_classical_controls("sb"))
    ops.append(cirq.X(v0).with_classical_controls("sa"))
    ops.append(cirq.X(v0))
    ops.append(cirq.X(v1).with_classical_controls("sb"))
    ops.append(cirq.X(v1))
    ops.append(cirq.CCX(u0, v1, t1))
    ops.append(cirq.CCX(v0, u1, t2))
    ops.append(cirq.CCX(u0, u1, t3))
    ops.append(cirq.measure(t1, key="st1"))
    ops.append(cirq.measure(t2, key="st2"))
    ops.append(cirq.measure(t3, key="st3"))
    ops.append(cirq.X(d0).with_classical_controls("st1"))
    ops.append(cirq.X(d2).with_classical_controls("st2"))
    ops.append(cirq.X(d1).with_classical_controls("st3"))
    ops.append(cirq.measure(d0, key="d0"))
    ops.append(cirq.measure(d1, key="d1"))
    ops.append(cirq.measure(d2, key="d2"))
    return cirq.Circuit(ops)


# --------------------------------------------------------------------------
# lane bodies
# --------------------------------------------------------------------------

def body_sf(J: dict) -> dict:
    import numpy as np
    import superfermion as sf
    verify_site_load(sf, J["framework"])
    res = base_res(J)
    res["fw_version"] = getattr(sf, "__version__", "?")
    res["engine_md5"] = engine_md5(sf)
    n, bond = J["n"], J.get("bond") or BOND_DEFAULT
    reps, sample_reps = J.get("reps", 3), J.get("sample_reps", 0)

    if J.get("method") == "mcm":
        case = J["mcm_case"]
        shots = J.get("shots") or 1000
        if case == "teleport":
            m = J["mcm_param"]
            n = 3 * m
            res["n_qubits"] = n
            c = sf_teleport(sf, m)
            t0 = time.perf_counter()
            r = sf.run(c, shots=shots, seed=SAMPLE_SEED)
            dt = time.perf_counter() - t0
            ok = check_bits_lsb(r.counts, [3 * k + 2 for k in range(m)])
            res["all_correct"] = bool(ok)
            res["expval_z0zlast"] = None
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = (f"teleport chain m={m}: every one of the {shots} shots has all "
                            f"target bits 1 in {len(r.counts)} distinct keys; "
                            "sf dynamic MCM = statevector trajectory replay per shot")
        elif case == "mbqc":
            N = J["mcm_param"]
            res["n_qubits"] = N
            c = sf_mbqc(sf, N)
            t0 = time.perf_counter()
            r = sf.run(c, shots=shots, seed=SAMPLE_SEED)
            dt = time.perf_counter() - t0
            ok = check_bits_lsb(r.counts, [N - 1])
            res["all_correct"] = bool(ok)
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = (f"MBQC wire N={N} (M={N - 1} measurements): output qubit is 1 "
                            f"in every shot across {len(r.counts)} histories; corrections "
                            "via c_if per measurement outcome")
        elif case == "repcode":
            res["n_qubits"] = 12
            t0 = time.perf_counter()
            pat_ok = {}
            for err in (None, 0, 1, 2):
                c = sf_repcode(sf, err)
                r = sf.run(c, shots=shots, seed=SAMPLE_SEED)
                # sf counts carry the post-measurement qubit states: the data qubits
                # 0..2 are measured at the end, so their readback must be 1 per shot
                pat_ok[str(err)] = bool(check_bits_lsb(r.counts, [0, 1, 2]))
            dt = time.perf_counter() - t0
            res["all_correct"] = all(pat_ok.values())
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["quality"] = json.dumps(pat_ok)
            res["notes"] = ("rep-code d=3 with AND-ancilla syndrome lookup, 4 error "
                            "patterns (none/X0/X1/X2): data qubits 0..2 read back 111 "
                            "in all shots (statevector trajectory replay)")
        elif case == "teleport_mps":
            m = J["mcm_param"]
            res["n_qubits"] = 3 * m
            c = sf_teleport(sf, m)
            try:
                t0 = time.perf_counter()
                r = sf.run(c, device="cpu", method="mps", bond_dim=BOND_DEFAULT,
                           shots=shots, seed=SAMPLE_SEED)
                dt = time.perf_counter() - t0
            except Exception as e:
                # Older builds without native MPS-MCM degrade gracefully.
                res["status"] = "unsupported"
                res["error"] = f"{type(e).__name__}: {e}"[:300]
                res["notes"] = ("MPS + mid-circuit measurement not available in this "
                                "build (pip fallback); pinned desktop builds run it "
                                "natively with per-shot collapse on the MPS")
            else:
                res["all_correct"] = bool(check_bits_lsb(
                    r.counts, [3 * k + 2 for k in range(m)]))
                res["t_expval_total_s"] = round(dt, 6)
                res["trials"] = [round(dt, 6)]
                res["notes"] = (
                    f"teleport chain m={m} on SF MPS (bond<={BOND_DEFAULT}): every "
                    f"one of the {shots} shots has all target bits 1 in "
                    f"{len(r.counts)} distinct keys; MCM inside the MPS engine "
                    "(no 2^n statevector expansion)")
        res.update(rss_info())
        return res

    c = _sf_circuit(sf, J)
    ir = c.to_ir()
    obs = [([3] + [0] * (n - 2) + [3], 1.0, 0.0)]

    if J.get("method") == "dense":
        st = ir.simulate_to_state("statevector", "cpu")
        res["expval_z0zlast"] = float(st.expectation(obs))
        res["notes"] = "dense statevector reference row"
        res.update(rss_info())
        return res

    if J.get("tvd"):
        # bond sweep at n=16: exact-vs-truncated total variation distance
        t0 = time.perf_counter()
        st_exact = ir.simulate_to_state("statevector", "cpu")
        exact = np.asarray(st_exact.numpy())
        pex = np.abs(exact) ** 2
        st = ir.simulate_to_state("mps", "cpu", bond)
        sv = np.asarray(st.numpy())
        nrm = float(np.linalg.norm(sv))
        p = np.abs(sv / nrm) ** 2
        tvd = 0.5 * float(np.sum(np.abs(p - pex)))
        dt = time.perf_counter() - t0
        res["expval_z0zlast"] = float(st.expectation(obs))
        res["t_expval_total_s"] = round(dt, 6)
        res["trials"] = [round(dt, 6)]
        rep = st.truncation_report()
        res["quality"] = json.dumps({**rep, "tvd_vs_exact": tvd, "mps_norm": nrm}, default=float)
        res["notes"] = "TVD between truncated-MPS probabilities and exact statevector probs"
        res.update(rss_info())
        return res

    simfn = lambda: ir.simulate_to_state("mps", "cpu", bond)
    simfn()  # warm pass (untimed)
    trials = []
    for _ in range(max(1, reps)):
        t0 = time.perf_counter()
        st = simfn()
        v = float(st.expectation(obs))
        trials.append(time.perf_counter() - t0)
    res["expval_z0zlast"] = v
    res["t_expval_total_s"] = round(median(trials), 6)
    res["trials"] = [round(t, 6) for t in trials]
    try:
        rep = st.truncation_report()
        res["quality"] = json.dumps(rep, default=float)
    except Exception as e:
        res["quality"] = json.dumps({"truncation_report_error": f"{type(e).__name__}: {e}"[:120]})
    if sample_reps:
        t0 = time.perf_counter()
        rr = sf.run(c, device="cpu", method="mps", bond_dim=bond, shots=sample_reps, seed=SAMPLE_SEED)
        res["t_sample_s"] = round(time.perf_counter() - t0, 6)
        res["sample_reps"] = sample_reps
        res["sample_distinct"] = len(set(rr.counts))
    res.update(rss_info())
    return res


def body_aer(J: dict) -> dict:
    import numpy as np
    import qiskit_aer
    from qiskit_aer import AerSimulator
    res = base_res(J)
    res["fw_version"] = qiskit_aer.__version__
    n, bond = J["n"], J.get("bond") or BOND_DEFAULT
    reps, sample_reps = J.get("reps", 3), J.get("sample_reps", 0)
    method = J.get("method", "mps")

    if method == "mcm":
        case = J["mcm_case"]
        shots = J.get("shots") or 1000
        if case == "teleport":
            m = J["mcm_param"]
            res["n_qubits"] = 3 * m
            qc = aer_mcm_qc(m)
            sim = AerSimulator(method="statevector")
            t0 = time.perf_counter()
            r = sim.run(qc, shots=shots, seed_simulator=SAMPLE_SEED).result()
            dt = time.perf_counter() - t0
            counts = r.get_counts()
            res["all_correct"] = check_bits_lsb(counts, [3 * k + 2 for k in range(m)])
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = (f"teleport m={m} statevector: all target bits 1 across "
                            f"{len(counts)} keys")
        elif case == "mbqc":
            N = J["mcm_param"]
            res["n_qubits"] = N
            qc = aer_mbqc_qc(N)
            sim = AerSimulator(method="statevector")
            t0 = time.perf_counter()
            r = sim.run(qc, shots=shots, seed_simulator=SAMPLE_SEED).result()
            dt = time.perf_counter() - t0
            counts = r.get_counts()
            res["all_correct"] = check_bits_lsb(counts, [N - 1])
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = f"MBQC wire N={N} statevector: output 1 in every shot"
        elif case == "repcode":
            sim = AerSimulator(method="statevector")
            t0 = time.perf_counter()
            pat_ok = {}
            for err in (None, 0, 1, 2):
                qc = aer_repcode_qc(err)
                r = sim.run(qc, shots=shots, seed_simulator=SAMPLE_SEED).result()
                pat_ok[str(err)] = check_bits_lsb(r.get_counts(), [5, 6, 7])
            dt = time.perf_counter() - t0
            res["n_qubits"] = 12
            res["all_correct"] = all(pat_ok.values())
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["quality"] = json.dumps(pat_ok)
            res["notes"] = ("rep-code d=3 with AND-ancilla syndrome lookup, 4 error "
                            "patterns (none/X0/X1/X2): data read back 111 in all shots "
                            "(construction validated on all four feed-forward engines)")
        elif case == "scale_teleport":
            m = J["mcm_param"]
            res["n_qubits"] = 3 * m
            qc = aer_mcm_qc(m)
            sim = AerSimulator(method="matrix_product_state",
                               matrix_product_state_max_bond_dimension=64)
            t0 = time.perf_counter()
            r = sim.run(qc, shots=shots, seed_simulator=SAMPLE_SEED).result()
            dt = time.perf_counter() - t0
            counts = r.get_counts()
            res["all_correct"] = check_bits_lsb(counts, [3 * k + 2 for k in range(m)])
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = (f"teleport m={m} on Aer MPS (bond<=64): MCM inside the MPS "
                            "engine -- the combined MPS+MCM scale lane")
        res.update(rss_info())
        return res

    dense = method == "dense"
    sim_method = "statevector" if dense else "matrix_product_state"

    if J.get("tvd"):
        sim = AerSimulator(method="matrix_product_state",
                           matrix_product_state_max_bond_dimension=bond)
        qc_e = _aer_qc(J, measure=False, save_expval=False)
        qc_e.save_statevector()
        t0 = time.perf_counter()
        r_exact = AerSimulator(method="statevector").run(qc_e, seed_simulator=SAMPLE_SEED).result()
        exact = np.asarray(r_exact.data(0)["statevector"])
        r = sim.run(qc_e, seed_simulator=SAMPLE_SEED).result()
        sv = np.asarray(r.data(0)["statevector"])
        dt = time.perf_counter() - t0
        pex = np.abs(exact) ** 2
        p = np.abs(sv / np.linalg.norm(sv)) ** 2
        tvd = 0.5 * float(np.sum(np.abs(p - pex)))
        res["t_expval_total_s"] = round(dt, 6)
        res["trials"] = [round(dt, 6)]
        res["quality"] = json.dumps({"tvd_vs_exact": tvd})
        res["notes"] = "TVD between MPS save_statevector and exact statevector (both densified)"
        res.update(rss_info())
        return res

    qc = _aer_qc(J, measure=False, save_expval=True)
    sim = AerSimulator(method=sim_method,
                       matrix_product_state_max_bond_dimension=bond)
    sim.run(qc, seed_simulator=SAMPLE_SEED).result()  # warm
    trials = []
    for _ in range(max(1, reps)):
        t0 = time.perf_counter()
        r = sim.run(qc, seed_simulator=SAMPLE_SEED).result()
        res["expval_z0zlast"] = float(r.data(0)["expectation_value"])
        trials.append(time.perf_counter() - t0)
    res["t_expval_total_s"] = round(median(trials), 6)
    res["trials"] = [round(t, 6) for t in trials]
    if not dense:
        res["notes"] = "aer expval as one-shot run (prep+expval inseparable); trunc_threshold=1e-16 default"
        if sample_reps:
            qcm = _aer_qc(J, measure=True, save_expval=False)
            t0 = time.perf_counter()
            r2 = sim.run(qcm, shots=sample_reps, seed_simulator=SAMPLE_SEED).result()
            res["t_sample_s"] = round(time.perf_counter() - t0, 6)
            res["sample_reps"] = sample_reps
            res["sample_distinct"] = len(r2.get_counts())
    else:
        res["notes"] = "dense statevector reference row"
    res.update(rss_info())
    return res


def body_pl(J: dict) -> dict:
    import importlib.util
    import numpy as np
    import pennylane as qml
    res = base_res(J)
    res["fw_version"] = qml.__version__
    if importlib.util.find_spec("quimb") is None:
        res["status"] = "unavailable"
        res["notes"] = "pennyLane MPS (default.tensor) requires quimb; install with: pip install quimb"
        return res
    n, bond = J["n"], J.get("bond") or BOND_DEFAULT
    reps = J.get("reps", 3)

    if J.get("method") == "mcm":
        case = J["mcm_case"]
        shots = J.get("shots") or 1000
        if case == "teleport":
            m = J["mcm_param"]
            res["n_qubits"] = 3 * m
            circ = pl_teleport_qnode(qml, m, shots)
            t0 = time.perf_counter()
            s = np.asarray(circ())
            dt = time.perf_counter() - t0
            ok = bool(np.all(s[:, [3 * k + 2 for k in range(m)]] == 1))
            res["all_correct"] = ok
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = (f"teleport m={m}: qml.measure + qml.cond on default.qubit; "
                            f"{shots} shots, targets 1 in every shot")
        elif case == "mbqc":
            N = J["mcm_param"]
            res["n_qubits"] = N
            circ = pl_mbqc_qnode(qml, N, shots)
            t0 = time.perf_counter()
            s = np.asarray(circ())
            dt = time.perf_counter() - t0
            ok = bool(np.all(s[:, N - 1] == 1))
            res["all_correct"] = ok
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = f"MBQC wire N={N}: {N - 1} conditional corrections via qml.cond"
        elif case == "repcode":
            res["n_qubits"] = 12
            t0 = time.perf_counter()
            pat_ok = {}
            for err in (None, 0, 1, 2):
                circ = pl_repcode_qnode(qml, err, shots)
                s = np.asarray(circ())
                pat_ok[str(err)] = bool(np.all(s == 1))
            dt = time.perf_counter() - t0
            res["all_correct"] = all(pat_ok.values())
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["quality"] = json.dumps(pat_ok)
            res["notes"] = ("rep-code d=3 with AND-ancilla syndrome lookup, 4 error "
                            "patterns (none/X0/X1/X2): data qubits 0..2 read back 111 "
                            "in all shots (default.qubit trajectories)")
        res.update(rss_info())
        return res

    dense = J.get("method") == "dense"
    dev = (qml.device("default.qubit", wires=n) if dense
           else qml.device("default.tensor", wires=n, method="mps", max_bond_dim=bond))

    @qml.qnode(dev)
    def circ():
        _pl_circuit_body(qml, J, n)
        return qml.expval(qml.PauliZ(0) @ qml.PauliZ(n - 1))

    circ()  # warm
    trials = []
    for _ in range(max(1, reps)):
        t0 = time.perf_counter()
        res["expval_z0zlast"] = float(circ())
        trials.append(time.perf_counter() - t0)
    res["t_expval_total_s"] = round(median(trials), 6)
    res["trials"] = [round(t, 6) for t in trials]
    res["notes"] = ("pl default.tensor mps analytic-only: no shots/counts" if not dense
                    else "dense default.qubit reference row")
    res.update(rss_info())
    return res


def body_cirq(J: dict) -> dict:
    import importlib.util
    import numpy as np
    import cirq
    res = base_res(J)
    res["fw_version"] = f"cirq-core {cirq.__version__}"
    if importlib.util.find_spec("quimb") is None:
        res["status"] = "unavailable"
        res["notes"] = "Cirq MPS (cirq.contrib.quimb) requires quimb; install with: pip install quimb"
        return res
    n, bond = J["n"], J.get("bond") or BOND_DEFAULT
    reps, sample_reps = J.get("reps", 3), J.get("sample_reps", 0)

    if J.get("method") == "mcm":
        case = J["mcm_case"]
        shots = J.get("shots") or 1000
        if case == "teleport":
            m = J["mcm_param"]
            res["n_qubits"] = 3 * m
            q, cm = cirq_teleport_circuit(m, False)
            sim = cirq.Simulator(seed=SAMPLE_SEED)
            t0 = time.perf_counter()
            rr = sim.run(cm, repetitions=shots)
            dt = time.perf_counter() - t0
            out = np.asarray(rr.measurements["out"])
            ok = bool(np.all(out[:, [3 * k + 2 for k in range(m)]] == 1))
            res["all_correct"] = ok
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = (f"teleport m={m}: with_classical_controls on cirq.Simulator; "
                            f"{shots} reps, targets 1 in every rep")
        elif case == "mbqc":
            N = J["mcm_param"]
            res["n_qubits"] = N
            q, cm = cirq_teleport_circuit(0, True, N_mbqc=N)
            sim = cirq.Simulator(seed=SAMPLE_SEED)
            t0 = time.perf_counter()
            rr = sim.run(cm, repetitions=shots)
            dt = time.perf_counter() - t0
            out = np.asarray(rr.measurements["out"])
            ok = bool(np.all(out[:, 0] == 1))
            res["all_correct"] = ok
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["notes"] = f"MBQC wire N={N}: {N - 1} classical-control corrections"
        elif case == "repcode":
            res["n_qubits"] = 12
            sim = cirq.Simulator(seed=SAMPLE_SEED)
            t0 = time.perf_counter()
            pat_ok = {}
            for err in (None, 0, 1, 2):
                cm = cirq_repcode_circuit(err)
                rr = sim.run(cm, repetitions=shots)
                pat_ok[str(err)] = all(
                    bool(np.all(np.asarray(rr.measurements[k]) == 1))
                    for k in ("d0", "d1", "d2"))
            dt = time.perf_counter() - t0
            res["all_correct"] = all(pat_ok.values())
            res["t_expval_total_s"] = round(dt, 6)
            res["trials"] = [round(dt, 6)]
            res["quality"] = json.dumps(pat_ok)
            res["notes"] = ("rep-code d=3 with AND-ancilla syndrome lookup, 4 error "
                            "patterns (none/X0/X1/X2): data qubits 0..2 read back 111 "
                            "in all reps (cirq.Simulator classical controls)")
        res.update(rss_info())
        return res

    dense = J.get("method") == "dense"
    q, circ = _cirq_circuit(J)
    zz = np.diag([1, -1, -1, 1])
    if dense:
        sim = cirq.Simulator(seed=SAMPLE_SEED)
        vals = sim.simulate_expectation_values(circ, [cirq.Z(q[0]) * cirq.Z(q[n - 1])])
        res["expval_z0zlast"] = float(np.real(vals[0]))
        res["notes"] = "dense cirq Simulator reference row"
        res.update(rss_info())
        return res
    from cirq.contrib.quimb import MPSOptions, MPSSimulator
    import quimb
    res["fw_version"] = f"cirq-core {cirq.__version__} / quimb {quimb.__version__}"
    sim = MPSSimulator(seed=SAMPLE_SEED,
                       simulation_options=MPSOptions(max_bond=bond, cutoff=1e-16,
                                                     cutoff_mode="rsum2"))
    trials, fs = [], None
    for rep_i in range(max(1, reps) + 1):  # first pass = warm (untimed)
        t0 = time.perf_counter()
        fs = sim.simulate(circ).final_state
        rho = fs.partial_trace({q[0], q[n - 1]})
        v = float(np.real(np.trace(rho @ zz)))
        dt = time.perf_counter() - t0
        if rep_i:
            trials.append(dt)
    res["expval_z0zlast"] = v
    res["t_expval_total_s"] = round(median(trials), 6)
    res["trials"] = [round(t, 6) for t in trials]
    try:
        res["quality"] = json.dumps({k: (float(vv) if hasattr(vv, "item") else vv)
                                     for k, vv in fs.estimation_stats().items()})
    except Exception as e:
        res["quality"] = json.dumps({"estimation_stats_error": f"{type(e).__name__}: {e}"[:120]})
    if sample_reps:
        cm = circ + cirq.measure(*q, key="m")
        t0 = time.perf_counter()
        rr = sim.run(cm, repetitions=sample_reps)
        res["t_sample_s"] = round(time.perf_counter() - t0, 6)
        res["sample_reps"] = sample_reps
        try:
            res["sample_distinct"] = int(rr.data.drop_duplicates().shape[0])
        except Exception:
            res["sample_distinct"] = None
        res["notes"] = "cirq run() samples per-repetition via partial traces"
    res.update(rss_info())
    return res


def body_qulacs(J: dict) -> dict:
    import qulacs
    res = base_res(J)
    res["fw_version"] = getattr(qulacs, "__version__", "?")
    res["status"] = "not_offered"
    if J.get("method") == "mcm":
        res["notes"] = ("qulacs exposes no classical feed-forward (no conditional gate "
                        "execution): MCM lanes not offered upstream")
    else:
        res["notes"] = ("qulacs exposes no MPS engine (no qulacs.MPS; no MPS symbols in "
                        "qulacs_core binding); lane documented as not offered upstream")
    return res


BODIES = {"sf_optimized": body_sf, "sf_wheel": body_sf, "sf_source": body_sf,
          "aer": body_aer, "pl": body_pl, "cirq": body_cirq, "qulacs": body_qulacs}


# --------------------------------------------------------------------------
# probes
# --------------------------------------------------------------------------

def probe_one(lane: str) -> dict:
    out = {"lane": lane, "status": "ok", "version": "", "engine_md5": "",
           "site": os.environ.get("SF_SITE", ""), "mps_api": "", "mcm_api": "", "notes": ""}
    try:
        if lane.startswith("sf_"):
            import superfermion as sf
            verify_site_load(sf, lane)
            out["version"] = getattr(sf, "__version__", "?")
            out["engine_md5"] = engine_md5(sf)
            c = sf.Circuit(3).h(0)
            c = c.cnot(0, 1)
            st = c.to_ir().simulate_to_state("mps", "cpu", 16)
            ok = abs(abs(complex(st.expectation([([3, 0, 0], 1.0, 0.0)]))) - 0.0) < 1.0
            out["mps_api"] = "ir.simulate_to_state('mps', ...) smoked" if ok else "smoke oddity"
            c2 = sf.Circuit(3, 1)
            c2 = c2.x(0)
            c2 = c2.measure(0, 0)
            c2 = c2.c_if(0, 1).x(1)
            r = sf.run(c2, shots=50, seed=1)
            good = all((int(kk, 2) >> 1) & 1 == 1 for kk in r.counts)
            out["mcm_api"] = ("dynamic statevector trajectory + c_if feed-forward ok"
                              if good else "mcm smoke oddity")
        elif lane == "aer":
            import qiskit_aer
            from qiskit_aer import AerSimulator
            out["version"] = qiskit_aer.__version__
            AerSimulator(method="matrix_product_state", matrix_product_state_max_bond_dimension=16)
            out["mps_api"] = "AerSimulator(method='matrix_product_state')"
            out["mcm_api"] = "if_test works in statevector AND mps methods"
        elif lane == "pl":
            import importlib.util
            import pennylane as qml
            out["version"] = qml.__version__
            if importlib.util.find_spec("quimb") is None:
                out["status"] = "unavailable"
                out["notes"] = "needs quimb: pip install quimb  (provides default.tensor method='mps')"
            else:
                dev = qml.device("default.tensor", wires=3, method="mps", max_bond_dim=16)

                @qml.qnode(dev)
                def circ():
                    qml.Hadamard(0)
                    return qml.expval(qml.PauliZ(0))
                circ()
                out["mps_api"] = "default.tensor(method='mps', max_bond_dim=..)"
                out["mcm_api"] = "qml.measure + qml.cond on default.qubit (trajectories)"
        elif lane == "cirq":
            import importlib.util
            import cirq
            out["version"] = cirq.__version__
            if importlib.util.find_spec("quimb") is None:
                out["status"] = "unavailable"
                out["notes"] = "needs quimb: pip install quimb  (provides cirq.contrib.quimb.MPSSimulator)"
            else:
                from cirq.contrib.quimb import MPSOptions, MPSSimulator
                import quimb
                out["version"] = f"cirq-core {cirq.__version__} / quimb {quimb.__version__}"
                MPSSimulator(seed=1, simulation_options=MPSOptions(max_bond=16, cutoff=1e-16))
                out["mps_api"] = "cirq.contrib.quimb.MPSSimulator"
                out["mcm_api"] = "with_classical_controls on cirq.Simulator (trajectories)"
        elif lane == "qulacs":
            import qulacs
            import qulacs_core
            out["version"] = getattr(qulacs, "__version__", "?")
            syms = [a for a in dir(qulacs_core) if "MPS" in a.upper() or "MATRIXPROD" in a.upper()]
            out["status"] = "not_offered"
            out["mps_api"] = "none"
            out["mcm_api"] = "none"
            out["notes"] = ("no qulacs.MPS and no MPS symbols in qulacs_core "
                            f"(checked: {syms or '0 symbols'}); no classical feed-forward; "
                            "lane documented as not offered upstream")
        else:
            out["status"] = "error"
            out["notes"] = "unknown lane"
    except Exception as e:
        out["status"] = "error"
        out["notes"] = f"{type(e).__name__}: {e}"[:200]
    return out


# --------------------------------------------------------------------------

def job_key(J: dict) -> dict:
    return {"framework": J["framework"], "circuit": J["circuit"], "n": J["n"],
            "bond": J.get("bond"), "method": J.get("method", "mps"),
            "mcm_case": J.get("mcm_case", ""), "mcm_param": J.get("mcm_param")}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--probe", metavar="LANE", default=None)
    ap.add_argument("--batch-file", default=None)
    args = ap.parse_args()
    bootstrap_env()
    if args.probe is not None:
        enter_site(os.environ.get("SF_SITE", ""))
        print(json.dumps(probe_one(args.probe)), flush=True)
        return
    if args.batch_file:
        enter_site(os.environ.get("SF_SITE", ""))
        jobs = json.loads(pathlib.Path(args.batch_file).read_text(encoding="utf-8"))
        for J in jobs:
            print("JOBSTART " + json.dumps(job_key(J)), flush=True)
            try:
                res = BODIES[J["framework"]](J)
            except Exception as e:
                res = base_res(J)
                res["status"] = "error"
                res["error"] = f"{type(e).__name__}: {e}"[:400]
            print("JOBJSON " + json.dumps(res, default=float), flush=True)
        return
    ap.error("nothing to do: pass --probe LANE or --batch-file PATH")


if __name__ == "__main__":
    main()
