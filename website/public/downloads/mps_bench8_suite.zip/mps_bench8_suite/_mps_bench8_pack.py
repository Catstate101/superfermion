"""Package bench8: self-contained suite folder (other desktops) + results zip (Colab view).

Run AFTER the notebook execution (and any resume pass) finishes:
    python _mps_bench8_pack.py

Two auto-detected modes:
  * workspace (this repo): refreshes the nested mps_bench8_suite/ folder, then zips it
  * suite    (inside a copied mps_bench8_suite/ folder): packs itself -- so a plain
    desktop run (run_notebook.bat) produces the results zip + the folder zip

Creates:
  mps_bench8_suite/                              copy to another desktop and run
      _mps_bench8.ipynb                          executed notebook (outputs + plots embedded)
      _mps_bench8_worker.py                      standalone 7-lane worker
      _mps_bench8_{exec,pack,nbcheck,status,prune,build,struct}.py
      run_notebook.bat / run_notebook.ps1        one-command headless execution + pack
      requirements.txt / README.md
      mps_bench8_out/                            results from this run (jsonl/csv/probe/figs)
  _dist/mps_mcm_bench8_results_<host>.zip        executed notebook + report + figs + data
                                                 (upload the ipynb to Colab: outputs visible)
  _dist/mps_bench8_suite.zip (workspace)         the suite folder zipped
  _dist/mps_bench8_suite_<host>.zip (suite mode) the copyable folder zipped
"""
import json
import pathlib
import shutil
import socket
import zipfile
from collections import Counter
from datetime import datetime

HERE = pathlib.Path(__file__).resolve().parent
HOST = socket.gethostname().split(".")[0].lower()
NB = HERE / "_mps_bench8.ipynb"
OUT = HERE / "mps_bench8_out"
JSONL = OUT / f"{HOST}_mps8.jsonl"
DIST = HERE / "_dist"
# dual mode: run from the workspace (refreshes + zips the nested suite folder) or
# from inside a copied suite folder itself (it IS the suite)
NESTED = HERE / "mps_bench8_suite"
WORKSPACE = NESTED.exists()
SUITE = NESTED if WORKSPACE else HERE
if not WORKSPACE and not ((HERE / "run_notebook.bat").exists() and (HERE / "requirements.txt").exists()):
    raise SystemExit("not a workspace (no mps_bench8_suite/) nor a suite folder (no run_notebook.bat) - aborting")

# ---- 0) freshness checks -------------------------------------------------
import nbformat

nb = nbformat.read(str(NB), as_version=4)
n_out = sum(len(c.get("outputs", [])) for c in nb.cells)
err_cells = sum(1 for c in nb.cells
                if any(o.get("output_type") == "error" for o in c.get("outputs", [])))
rows = [json.loads(l) for l in JSONL.read_text(encoding="utf-8").splitlines()
        if l.strip()] if JSONL.exists() else []
status_counts = dict(Counter(r.get("status") for r in rows))
lane_counts = dict(Counter(r.get("framework") for r in rows))
print(f"pack mode: {'workspace' if WORKSPACE else 'suite'} | host: {HOST}")
print(f"notebook: {len(nb.cells)} cells | {n_out} outputs | {err_cells} error cells")
print(f"rows: {len(rows)} | statuses: {status_counts}")
print(f"lanes: {lane_counts}")
if n_out == 0:
    print("WARNING: notebook has no outputs -- run _mps_bench8_exec.py first")
if err_cells:
    print("WARNING: executed notebook has error cells -- inspect before shipping")

summary = {
    "host": HOST,
    "packed_at": datetime.now().isoformat(timespec="seconds"),
    "cells": len(nb.cells), "outputs": n_out, "error_cells": err_cells,
    "rows": len(rows), "status_counts": status_counts, "lane_counts": lane_counts,
}

# ---- 1) results zip (what you open in Colab) -----------------------------
DIST.mkdir(exist_ok=True)
rzip = DIST / f"mps_mcm_bench8_results_{HOST}.zip"
with zipfile.ZipFile(rzip, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(NB, "MPS_MCM_Benchmark_7Framework.ipynb")
    rp = HERE / "report.md"
    if rp.exists():
        z.write(rp, "report.md")
    rp2 = HERE / "report_mcm_fair_v2.md"
    if rp2.exists():
        z.write(rp2, "report_mcm_fair_v2.md")
    for pat in ("*.jsonl", "*.csv", "*_probe.json"):
        for f in sorted(OUT.glob(pat)):
            if "quick" in f.name:
                continue  # quick-mode calibration artifacts stay local
            z.write(f, f"mps_bench8_out/{f.name}")
    figs = OUT / "figs"
    if figs.exists():
        for f in sorted(figs.iterdir()):
            if f.is_file():
                z.write(f, f"mps_bench8_out/figs/{f.name}")
    z.writestr("run_summary.json", json.dumps(summary, indent=2))
    z.writestr("README_RESULTS.txt", (
        "Open MPS_MCM_Benchmark_7Framework.ipynb in Colab (or Jupyter): all tables,\n"
        "stdout and inline plots are stored in the notebook.\n"
        "mps_bench8_out/figs/*.png are the same figures as image files.\n"
        "mps_bench8_out/*.jsonl|*.csv are the raw result rows (one job per line).\n"
        "Summary: run_summary.json\n"
        "Full reproducible folder: _dist/mps_bench8_suite_<host>.zip (or mps_bench8_suite.zip).\n"))
print("results zip:", rzip.name, f"{rzip.stat().st_size // 1024} KB")

# ---- 2) suite folder (portable to another desktop) -----------------------
SUITE.mkdir(exist_ok=True)
SUITE_OUT = SUITE / "mps_bench8_out"


def portable_copy(src, dst_name=None):
    """Copy a tool, rewriting the hardcoded workspace path to __file__-relative."""
    txt = src.read_text(encoding="utf-8")
    txt = txt.replace(r'HERE = pathlib.Path(__file__).resolve().parent',
                      "HERE = pathlib.Path(__file__).resolve().parent")
    (SUITE / (dst_name or src.name)).write_text(txt, encoding="utf-8")


if WORKSPACE:
    shutil.copy2(NB, SUITE / "_mps_bench8.ipynb")
    shutil.copy2(HERE / "report.md", SUITE / "report.md")
    if (HERE / "report_mcm_fair_v2.md").exists():
        shutil.copy2(HERE / "report_mcm_fair_v2.md", SUITE / "report_mcm_fair_v2.md")
    shutil.copy2(HERE / "_mps_bench8_worker.py", SUITE / "_mps_bench8_worker.py")
    portable_copy(HERE / "_mps_bench8_exec.py")
    portable_copy(HERE / "_mps_bench8_nbcheck.py")
    portable_copy(HERE / "_mps_bench8_status.py")
    portable_copy(HERE / "_mps_bench8_prune.py")
    portable_copy(HERE / "_mps_bench8_dedupe.py")
    portable_copy(HERE / "_mps_bench8_build.py")
    portable_copy(HERE / "_mps_bench8_pack.py")
    portable_copy(HERE / "_m8_probe.py")
    portable_copy(HERE / "_m8_probe_mps.py")
    portable_copy(HERE / "_chi2_probe.py")
    portable_copy(HERE / "_fair_probe.py")
    portable_copy(HERE / "_fair_probe2.py")
    portable_copy(HERE / "_fair_verdict.py")
    for _rows_json in ("_fair_probe_rows.json", "_fair_probe2_rows.json"):
        if (HERE / _rows_json).exists():
            shutil.copy2(HERE / _rows_json, SUITE / _rows_json)
    shutil.copy2(HERE / "_mps_bench8_struct.py", SUITE / "_mps_bench8_struct.py")
    shutil.copy2(HERE / "_mps_bench8_suite_README.md", SUITE / "README.md")
    shutil.copy2(HERE / "_mps_bench8_suite_requirements.txt", SUITE / "requirements.txt")
    shutil.copy2(HERE / "_mps_bench8_suite_run_notebook.bat", SUITE / "run_notebook.bat")
    shutil.copy2(HERE / "_mps_bench8_suite_run_notebook.ps1", SUITE / "run_notebook.ps1")

    if SUITE_OUT.exists():
        shutil.rmtree(SUITE_OUT)
    shutil.copytree(OUT, SUITE_OUT)
    # keep the shipped results focused: drop quick-mode calibration + local backups
    for f in list(SUITE_OUT.rglob("*quick*")) + list(SUITE_OUT.rglob("*.bak")):
        if f.is_file():
            f.unlink()
else:
    print("suite mode: running inside the suite folder -- files already in place")
(SUITE / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

szip = (DIST / "mps_bench8_suite.zip") if WORKSPACE else (DIST / f"mps_bench8_suite_{HOST}.zip")
with zipfile.ZipFile(szip, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(SUITE.rglob("*")):
        if not f.is_file():
            continue
        if f.relative_to(SUITE).parts[0] == "_dist":
            continue  # never embed our own zips
        z.write(f, f.relative_to(HERE))
print("suite zip:", szip.name, f"{szip.stat().st_size // 1024} KB")
print("suite folder:", SUITE)
print("PACK_OK")
