"""Execute a bench8 notebook in place with NO per-cell timeout (chunk caps bound the run).

Usage: python _mps_bench8_exec.py <notebook> [kernel]

Portable across desktops: if the requested kernelspec is missing, a user kernelspec
is installed with the CURRENT interpreter (needs ipykernel) and execution retries.
JUPYTER_PATH points at _nbrun_kernels/ when present (this repo's local `sfdev` spec).
"""
import os
import pathlib
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
_kern = HERE / "_nbrun_kernels"
if _kern.exists():
    os.environ.setdefault("JUPYTER_PATH", str(_kern))

import nbformat
from jupyter_client.kernelspec import KernelSpecManager
from nbclient import NotebookClient

name = sys.argv[1] if len(sys.argv) > 1 else "_mps_bench8.ipynb"
kernel = sys.argv[2] if len(sys.argv) > 2 else "sfdev"
p = pathlib.Path(name)
if not p.is_absolute():
    p = (HERE / name).resolve()

ksm = KernelSpecManager()
if kernel not in ksm.find_kernel_specs():
    print(f"kernelspec '{kernel}' not found -- installing with {sys.executable}", flush=True)
    subprocess.run([sys.executable, "-m", "ipykernel", "install", "--user",
                    "--name", kernel, "--display-name", kernel], check=False)
    ksm = KernelSpecManager()
avail = ksm.find_kernel_specs()
if kernel not in avail:
    kernel = "python3" if "python3" in avail else next(iter(avail))
    print(f"falling back to kernelspec '{kernel}'", flush=True)

nb = nbformat.read(str(p), as_version=4)
client = NotebookClient(nb, timeout=None, kernel_name=kernel,
                        resources={"metadata": {"path": str(p.parent)}})
try:
    client.execute()
    status = "EXEC_OK"
except Exception as e:
    status = f"EXEC_FAIL {type(e).__name__}: {str(e)[:220]}"
nbformat.write(nb, str(p))
print(status, p.name, flush=True)
sys.exit(0 if status == "EXEC_OK" else 1)
