"""Deduplicate the bench8 jsonl: keep only the NEWEST row per job key.

History: pass-2 wrote retryable `skipped_wall` rows for jobs the wall cut; pass-3
re-ran exactly those jobs and appended terminal rows. The jsonl is append-only, so
both generations co-exist and double-count jobs. This keeps the last (terminal)
row per (framework, circuit, n_qubits, bond, method, mcm_case, mcm_param, mode)
and drops superseded rows. A backup is written before any change.

Usage: python _mps_bench8_dedupe.py <jsonl> [--apply]     (default: dry-run)
"""
import json
import pathlib
import sys
from collections import Counter

f = pathlib.Path(sys.argv[1])
apply_ = "--apply" in sys.argv
rows = [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()]


def jkey(r):
    # `mode` matters: validate brick4@16 b64 and the bonds sweep @16 b64 share
    # framework/circuit/n/bond/method and must not collapse into one job
    return (r.get("framework"), r.get("circuit"), r.get("n_qubits", r.get("n")),
            r.get("bond"), r.get("method", "mps"), r.get("mcm_case") or "",
            r.get("mcm_param"), r.get("mode") or "")


latest = {}
for r in rows:  # later rows override earlier ones (append-only history)
    latest[jkey(r)] = r
out = list(latest.values())
print(f"rows in {len(rows)} | unique jobs {len(out)} | superseded {len(rows) - len(out)}")
print("status before:", dict(Counter(r.get("status") for r in rows)))
print("status after :", dict(Counter(r.get("status") for r in out)))
if apply_ and len(out) < len(rows):
    f.with_suffix(f.suffix + ".prededupe.bak").write_text(
        "\n".join(json.dumps(r, default=float) for r in rows) + "\n", encoding="utf-8")
    f.write_text("\n".join(json.dumps(r, default=float) for r in out) + "\n",
                 encoding="utf-8")
    print(f"APPLIED -> {f.name} | backup -> {f.with_suffix(f.suffix + '.prededupe.bak').name}")
else:
    print("dry-run only; re-run with --apply to write")
