"""chi=2 TVD investigation: rerun the exact official bonds row (brick4@16)
under the default (svd) and legacy (qr) truncation policies, plus b=3 as a
reference, using the official worker + pinned optimized site."""
import json
import os
import pathlib
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
PY = r"c:\Users\ASUS\OneDrive\Desktop\sfdeploy\superfermion\scratch\colab_sim\Scripts\python.exe"
WORKER = HERE / "_mps_bench8_worker.py"
SITE = r"D:\sf_runs\v8_local\sites\superfermion_optimized"
TMP = HERE / "mps_bench8_out" / "batches"

JOB = {"framework": "sf_optimized", "circuit": "brick4", "layers": 4, "n": 16,
       "bond": None, "method": "mps", "mode": "bonds", "reps": 1, "sample_reps": 0,
       "budget_s": 90, "tvd": True}


def run(variant, bond):
    env = os.environ.copy()
    for k in ["PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONWARNINGS",
              "SF_MPS_SVD_DEBUG", "SF_MPS_SVD_FULL", "SF_MPS_SKIP_CANON", "SF_MPS_FORCE_CANON",
              "SF_MPS_TRUNCATION"]:
        env.pop(k, None)
    env["SF_SITE"] = SITE
    env["SF_THREADS"] = "4"
    if variant:
        env["SF_MPS_TRUNCATION"] = variant
    j = dict(JOB)
    j["bond"] = bond
    bf = TMP / f"_chi2_probe_{(variant or 'svd')}_b{bond}.json"
    bf.write_text(json.dumps([j]), encoding="utf-8")
    p = subprocess.run([PY, "-X", "utf8", str(WORKER), "--batch-file", str(bf)],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", env=env, cwd=str(HERE), timeout=600)
    for ln in p.stdout.splitlines():
        if ln.startswith("JOBJSON "):
            r = json.loads(ln[8:])
            q = json.loads(r.get("quality") or "{}")
            print(f"variant={variant or 'svd(default)':<13} bond={bond} status={r['status']} "
                  f"t={r.get('t_expval_total_s')} expval={r.get('expval_z0zlast')}\n"
                  f"    tvd={q.get('tvd_vs_exact')} disc={q.get('discarded_weight')} "
                  f"maxdisc={q.get('max_discarded_weight')} events={q.get('truncation_events')} "
                  f"norm={q.get('mps_norm')} md5={(r.get('engine_md5') or '')[:8]}")
            return
    print(f"variant={variant} bond={bond} NO JOBJSON rc={p.returncode}")
    print((p.stdout or "")[-500:])
    print((p.stderr or "")[-500:])


for bond in (2, 3):
    run(None, bond)    # current default: tau-pruned SVD
    run("qr", bond)    # legacy position cut
