# Headless run of the MPS+MCM benchmark notebook (in-place, resume-safe),
# then pack the results (executed notebook + figures + data) into _dist/*.zip.
Set-Location $PSScriptRoot
python -X utf8 _mps_bench8_exec.py _mps_bench8.ipynb
python -X utf8 _mps_bench8_pack.py
