"""Structural check of the built bench8 notebook before a long execution."""
import sys

import nbformat

p = sys.argv[1] if len(sys.argv) > 1 else "_mps_bench8.ipynb"
nb = nbformat.read(p, as_version=4)
print("cells:", len(nb.cells))
g = next((c.source for c in nb.cells if "GRID = {" in c.source), "")
all_src = "\n".join(c.source for c in nb.cells)
checks = {
    'quick_false': '"quick": False' in g,
    'wall_cap_2700': '"wall_cap_s": 2700' in g,
    'mbqc_cap_min200': ('min(shots, 200)' in g) or ('"mbqc", N, N, 200, 120' in g),
    'lanes7': '"sf_optimized", "sf_wheel", "sf_source", "aer", "pl", "cirq", "qulacs"' in all_src,
    'suites6': '["validate", "ladder", "stress", "qft", "bonds", "mcm"]' in g,
    'hard_timeout_margin': 'CHUNK_MARGIN_S = 30' in "".join(
        c.source for c in nb.cells if "CHUNK_MARGIN_S" in c.source),
    'worker_embed': any(c.source.startswith("%%writefile _mps_bench8_worker.py") for c in nb.cells),
}
for k, v in checks.items():
    print(f"  {k:22s} {v}")
bad = [k for k, v in checks.items() if not v]
print("STRUCT_OK" if not bad else f"STRUCT_BAD {bad}")
