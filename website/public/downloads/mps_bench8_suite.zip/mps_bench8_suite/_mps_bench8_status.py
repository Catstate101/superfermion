"""One-glance status of the live bench8 jsonl: counts by status/lane/mode + last rows."""
import json
import pathlib
import sys
from collections import Counter

HERE = pathlib.Path(__file__).resolve().parent
f = HERE / sys.argv[1]
rows = [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()]
print("total rows:", len(rows))
print("status:", dict(Counter(r.get("status") for r in rows)))
print("lane  :", dict(Counter(r.get("framework") for r in rows)))
print("mode  :", dict(Counter(r.get("mode") for r in rows)))
ok = [r for r in rows if r.get("status") == "ok"]
t = sum(r.get("t_expval_total_s") or 0 for r in ok)
print(f"sum t_expval (ok rows): {t:.1f}s")
bad = [r for r in rows if r.get("status") not in ("ok", "not_offered")]
if bad:
    print("non-ok rows:")
    for r in bad:
        print("  ", r.get("framework"), r.get("mode"), r.get("circuit"),
              "n=", r.get("n_qubits"), r.get("mcm_case") or "", "->", r.get("status"),
              "|", str(r.get("error"))[:90])
mcmbad = [r for r in rows if r.get("mode") == "mcm" and r.get("status") == "ok"
          and r.get("all_correct") is False]
if mcmbad:
    print("MCM all_correct=False rows:")
    for r in mcmbad:
        print("  ", r.get("framework"), r.get("mcm_case"), r.get("mcm_param"))
print("last 3:")
for r in rows[-3:]:
    print("  ", r.get("ts"), r.get("framework"), r.get("mode"), r.get("circuit"),
          "n=", r.get("n_qubits"), r.get("mcm_case") or "-", "->", r.get("status"),
          "t=", r.get("t_expval_total_s"))
