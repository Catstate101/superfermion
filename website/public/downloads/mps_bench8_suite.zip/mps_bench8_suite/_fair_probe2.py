"""Extended same-window interleaved (drift-robust) re-measure of the headline
claims, official worker specs, SF_THREADS=4, single child process:
  stress n=1000/500/200: 3 x ABBA [sf, aer, aer, sf]
  teleport_mps m=40 (sf) vs scale_teleport m=40 (aer): 3 x ABBA
  teleport m=4 @ EQUAL 500 shots sf/aer/pl/cirq: 2 x ABBA-symmetric
  mbqc N=17 @200 shots sf vs cirq: 3 x ABBA
Prints per-lane min/median; persists _fair_probe2_rows.json."""
import json
import os
import pathlib
import statistics
import subprocess
import time

HERE = pathlib.Path(__file__).resolve().parent
PY = r"C:\Python313\python.exe"
WORKER = HERE / "_mps_bench8_worker.py"
SITE = r"D:\sf_runs\v8_local\sites\superfermion_optimized"
TMP = HERE / "mps_bench8_out" / "batches"


def j_std(lane, circ, n):
    return {"framework": lane, "circuit": circ, "layers": int(circ[5:]), "n": n,
            "bond": 64, "method": "mps", "mode": "stress", "reps": 3,
            "sample_reps": 0, "budget_s": 600}


def j_mcm(lane, case, n, param, shots):
    return {"framework": lane, "circuit": "mcm", "layers": 0, "n": n, "bond": None,
            "method": "mcm", "mode": "mcm", "mcm_case": case, "mcm_param": param,
            "shots": shots, "reps": 1, "sample_reps": 0, "budget_s": 600}


jobs = []
for n in (1000, 500, 200):
    for _ in range(3):
        jobs += [j_std("sf_optimized", "brick12", n), j_std("aer", "brick12", n),
                 j_std("aer", "brick12", n), j_std("sf_optimized", "brick12", n)]
for _ in range(3):
    jobs += [j_mcm("sf_optimized", "teleport_mps", 120, 40, 1000),
             j_mcm("aer", "scale_teleport", 120, 40, 1000),
             j_mcm("aer", "scale_teleport", 120, 40, 1000),
             j_mcm("sf_optimized", "teleport_mps", 120, 40, 1000)]
for _ in range(2):
    jobs += [j_mcm("sf_optimized", "teleport", 12, 4, 500), j_mcm("aer", "teleport", 12, 4, 500),
             j_mcm("pl", "teleport", 12, 4, 500), j_mcm("cirq", "teleport", 12, 4, 500),
             j_mcm("cirq", "teleport", 12, 4, 500), j_mcm("pl", "teleport", 12, 4, 500),
             j_mcm("aer", "teleport", 12, 4, 500), j_mcm("sf_optimized", "teleport", 12, 4, 500)]
for _ in range(3):
    jobs += [j_mcm("sf_optimized", "mbqc", 17, 17, 200), j_mcm("cirq", "mbqc", 17, 17, 200),
             j_mcm("cirq", "mbqc", 17, 17, 200), j_mcm("sf_optimized", "mbqc", 17, 17, 200)]

env = os.environ.copy()
for k in ["PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONWARNINGS",
          "SF_MPS_SVD_DEBUG", "SF_MPS_SVD_FULL", "SF_MPS_SKIP_CANON",
          "SF_MPS_FORCE_CANON", "SF_MPS_TRUNCATION"]:
    env.pop(k, None)
env["SF_SITE"] = SITE
env["SF_THREADS"] = "4"
bf = TMP / "_fair2_all.json"
bf.write_text(json.dumps(jobs), encoding="utf-8")
t0 = time.perf_counter()
p = subprocess.run([PY, "-X", "utf8", str(WORKER), "--batch-file", str(bf)],
                   capture_output=True, text=True, encoding="utf-8",
                   errors="replace", env=env, cwd=str(HERE), timeout=1800)
wall = time.perf_counter() - t0
rows = [json.loads(ln[8:]) for ln in p.stdout.splitlines() if ln.startswith("JOBJSON ")]
if len(rows) != len(jobs):
    print(f"WARNING jobs={len(jobs)} rows={len(rows)} rc={p.returncode}")
    print((p.stdout or "")[-500:])
    print((p.stderr or "")[-500:])
(HERE / "_fair_probe2_rows.json").write_text(json.dumps(rows, indent=1), encoding="utf-8")


def sec(r):
    if r.get("mode") == "stress":
        return f"stress n={r['n_qubits']}"
    return f"{r.get('mcm_case')} m={r.get('mcm_param')}"


print(f"window wall={wall:.0f}s  jobs={len(rows)}")
groups = {}
for r in rows:
    groups.setdefault((sec(r), r["framework"]), []).append(
        round(r.get("t_expval_total_s") or -1, 4))
order = [f"stress n={n}" for n in (1000, 500, 200)] + \
        ["teleport_mps m=40", "teleport m=4", "mbqc m=17"]
for s in order:
    parts = []
    for (ss, fw), ts in sorted(groups.items()):
        if ss == s:
            parts.append(f"{fw}: min={min(ts)} med={statistics.median(ts)} n={len(ts)} {ts}")
    print(f"[{s}] " + " | ".join(parts))
print("FAIR2_DONE")
