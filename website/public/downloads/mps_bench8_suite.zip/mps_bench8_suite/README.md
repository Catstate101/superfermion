# MPS + mid-circuit measurement benchmark — 7 frameworks

Benchmark notebook for **MPS simulation from 50 up to 1000 qubits** and **mid-circuit
measurement (MCM)**, across:

| lane | engine |
|---|---|
| sf_optimized / sf_wheel / sf_source | SuperFermion pinned local builds (optimized / wheel / baseline-git) |
| aer | Qiskit Aer (`matrix_product_state`) |
| pl | PennyLane (`default.tensor` = quimb MPS; MCM on `default.qubit`) |
| cirq | Cirq (`cirq.contrib.quimb.MPSSimulator`) |
| qulacs | Qulacs (documented `not_offered` — no MPS, no feed-forward) |

Circuits follow MQTBench-style selection (GHZ, 1D brick TFIM Trotter, QFT); truncation
is reported Quantinuum-style (discarded weight / estimated fidelity / TVD vs exact at
n=16); execution-time thresholds are first-class (per-job `budget_s`, hard chunk caps,
`over_budget` rows as data).

## Run it

**Colab (view):** the shipped notebook is **already executed** — open/upload it and every table, stdout line and plot of the reference run is shown *without running anything*.

**Colab (re-run):** *Runtime → Run all*. The setup cell pip-installs the dependencies. Note: the pinned SuperFermion builds only exist on the benchmark desktops — in Colab all three `sf_*` lanes fall back to the pip `superfermion` package and are the same engine (the probe table shows identical md5s).

**Desktop (Windows / Linux / macOS):**

```bash
python -m pip install -r requirements.txt
python -X utf8 _mps_bench8_exec.py _mps_bench8.ipynb     # headless, in-place
```

or double-click `run_notebook.bat` (PowerShell: `run_notebook.ps1`) — these also pack
the zips afterwards (see Packing) — or open the notebook in Jupyter and Run All. If
the `sfdev` kernelspec is missing, the runner auto-installs a kernelspec with the
current interpreter and falls back to it.

Results are written **per machine**: `<host>` in every filename is the *running*
host's name, so a new desktop measures fresh into its own jsonl, and the shipped
`mps_bench8_out/laptop-l5lb07gu_mps8.jsonl` stays as the reference record. To compare
desktops, compare the per-host jsonl files.

## Outputs

- `mps_bench8_out/<host>_mps8.jsonl` — every result row, streamed live
  (`ok` / `not_offered` / `over_budget` / `unsupported` / `error`; `error` =
  reproducible engine crash, e.g. cirq QFT at n≥12 in this pinned construction)
- `mps_bench8_out/<host>_mps8.csv` — same rows as CSV (written by the summary cell)
- `mps_bench8_out/<host>_probe.json` — capability probe per lane (version, md5, APIs)
- `mps_bench8_out/figs/*.png|svg` — all figures

## Packing (zips of the run)

`run_notebook.bat` / `run_notebook.ps1` pack automatically after the run; to pack
later (e.g. after a manual Jupyter run):

```bash
python -X utf8 _mps_bench8_pack.py
```

Produces in `_dist/`:

- `mps_mcm_bench8_results_<host>.zip` — executed notebook (all tables, stdout and
  inline plots embedded), `report.md`, raw jsonl/csv + probe json, every figure as
  `.png` and `.svg`, `run_summary.json`
- `mps_bench8_suite_<host>.zip` — this whole folder (runner, worker, build, probes,
  data), ready to hand to another desktop

The results zip is the one to upload to Colab: open the `.ipynb` inside it and all
stored outputs render without executing anything.

The notebook itself ends with a **bundle cell**: on desktop it prints a pointer to the
runner's zips (a cell cannot embed its own outputs -- the packer runs after execution
ends instead); in Colab it builds the same bundle live -- the Colab `get_ipynb` API
embeds the executed notebook (all outputs so far) next to the csv/jsonl/probe, figures
and a bundle summary -- and offers `mps_mcm_bench8_results_<host>.zip` for download.

## Timeouts and resume semantics

Every job carries `budget_s`. The runner packs jobs into per-lane chunks (≤240 s of
cumulative budget; risky jobs get a solo chunk) and **hard-kills each chunk at
chunk-budget + 30 s** — even mid-computation and silent. Unfinished jobs become
`over_budget` rows ("did not finish inside its budget": data, not a failure, matching
the execution-time-threshold methodology). The notebook-wide wall is 2700 s; the
remainder becomes retryable `skipped_wall` rows. **Re-running the notebook resumes:**
terminal statuses (`ok` / `not_offered` / `over_budget` / `unsupported`) are skipped;
`error` rows are re-queued (retried) on every run — deterministic engine failures
re-fail and append an identical row; delete a row to force re-execution.

## Files

| file | role |
|---|---|
| `report.md` | written summary of the reference run (tables, honesty notes, same-window audit) |
| `_mps_bench8.ipynb` | the benchmark notebook (self-contained; embeds the worker) |
| `_mps_bench8_worker.py` | 7-lane worker (also usable directly: `--probe <lane>`, `--batch-file <json>`) |
| `_mps_bench8_exec.py` | headless notebook runner (portable kernelspec handling) |
| `_mps_bench8_pack.py` | packs `_dist/`: results zip (notebook + report + figs + data) + whole-folder zip |
| `_mps_bench8_nbcheck.py` | executed-notebook inspector (error cells, rows, figs) |
| `_mps_bench8_status.py` | live jsonl summarizer |
| `_mps_bench8_prune.py` | removes starvation-artifact `over_budget` rows so a resume pass re-runs them |
| `_mps_bench8_dedupe.py` | append-only jsonl housekeeping: keep the newest row per job |
| `_mps_bench8_build.py` | regenerates the notebook from sources |
| `_mps_bench8_struct.py` | pre-run structural check of the notebook |
| `_fair_probe.py`, `_fair_probe2.py`, `_fair_verdict.py` | same-window interleaved ABBA re-measure + verdict reducer for the disputed rows |
| `_fair_probe_rows.json`, `_fair_probe2_rows.json` | raw rows of those re-measures |
| `requirements.txt` | pip dependencies |
| `run_summary.json` | pack summary (cells, outputs, rows, status/lane counts) |
| `mps_bench8_out/` | reference results: host-named jsonl/csv, probe json, figures, chunk archives (delete for a fresh run) |
