# MPS to 1000 qubits and mid-circuit measurement — 7-framework benchmark report

Run of `_mps_bench8.ipynb` on host **laptop-l5lb07gu**, results window 2026-10-07T23:03:46 → 2026-10-12T06:54:51.
Executed in resume passes (append-only jsonl; this report keeps the newest row per job):
**264 unique jobs** — 221 ok / 26 not_offered / 14 over_budget / 3 error.

- python : 3.13.3 | Windows AMD64
- cpus   : 8 | colab: False | host: laptop-l5lb07gu
- nb dir : C:\Users\ASUS\OneDrive\Desktop\sfdocs

## 1. What was measured

| suite | circuits | sizes | measures |
|---|---|---|---|
| validate | GHZ, brick4 | n = 12, 16 | correctness anchors: MPS vs dense statevector `<Z0·Zlast>` per engine |
| ladder | GHZ, brick4 | n = 50, 100, 200, 500, 1000 | prep + `<Z0·Zlast>` time vs qubit count, bond 64 |
| stress | brick12 | n = 200, 500, 1000 | entanglement pressure at bond 64 (12 brick layers) |
| qft | QFT | n = 8…200 (lane-dependent) | quadratic-depth entangler; execution-time threshold |
| bonds | brick4 @ 16 / brick12 @ 200 | χ = 2…128 | truncation error vs cost (TVD vs exact @16; discarded weight @200) |
| mcm | teleport chain, MBQC wire, rep-code | n = 12…120 | mid-circuit measurement + feed-forward: correctness, cost, walls |

- **Time metric**: prep + `<Z0·Zlast>` per row; one warm pass, then 3 timed passes, median kept
  (dense validation rows: 1 pass). MCM rows report the full shot-replay wall.
- **Fairness protocol**: identical gate sequences per engine (shared seed-7 builder), one thread
  cap for every lane (`SF_THREADS=4` sets all six thread env vars before any engine import), the
  same timing policy on every engine path, and MCM rows are a single timed shot-replay on every
  lane (the first run is the timed run) — §9 re-measures the headline claims interleaved same-window.
- **v2 fairness grid** (after the fairness review): one shot count and one budget per MCM job
  class on every lane — teleport m=4 500 shots/120 s, the n=24 wall (m=8) 500 shots/90 s solo on
  all seven lanes, MBQC N=17 200 shots/120 s, rep-code 200 shots/60 s on every feed-forward lane,
  MPS+MCM scale m=4/10/20/40 on all three pinned sf builds + aer. What changed and why: §12.
- **Quality**: SF rows carry `discarded_weight` + `fidelity_lower_bound`; Aer carries discarded
  weight; Cirq reports `estimation_stats` (no dense extraction); at n=16 the swept rows compare
  truncated-MPS probabilities against the exact statevector (**TVD**).
- **Correctness gates**: every MCM circuit is deterministic (teleport input |1>, MBQC wire |1>,
  rep-code |111>) so *every sampled shot must show 1 on every target bit* (`all_correct`).
- **Timeouts are data**: each job carries `budget_s`; chunks are hard-killed at chunk-budget + 30 s
  and unfinished jobs are recorded as **`over_budget`** rows (execution-time threshold), the
  notebook wall (2700 s) as retryable `skipped_wall` rows — none remain in this file.

## 2. Lanes and provenance

| lane | engine | probe | version | engine md5 | MPS API | MCM API |
|---|---|---|---|---|---|---|
| sf_optimized | SuperFermion (pinned local build) | ok | 0.1.14 | f576d0eb7a | ir.simulate_to_state('mps', ...) smoked | dynamic statevector trajectory + c_if feed-for |
| sf_wheel | SuperFermion (pinned local build) | ok | 0.1.14 | 6c63fc917e | ir.simulate_to_state('mps', ...) smoked | dynamic statevector trajectory + c_if feed-for |
| sf_source | SuperFermion (pinned local build) | ok | 0.1.14 | 6c63fc917e | ir.simulate_to_state('mps', ...) smoked | dynamic statevector trajectory + c_if feed-for |
| aer | Qiskit Aer | ok | 0.17.2 | — | AerSimulator(method='matrix_product_state') | if_test works in statevector AND mps methods |
| pl | PennyLane (default.tensor / default.qubit) | ok | 0.45.0 | — | default.tensor(method='mps', max_bond_dim=..) | qml.measure + qml.cond on default.qubit (traje |
| cirq | Cirq + quimb | ok | cirq-core 1.6.1 / quimb 1.13.0 | — | cirq.contrib.quimb.MPSSimulator | with_classical_controls on cirq.Simulator (tra |
| qulacs | Qulacs | not_offered | 0.6.14 | — | none | none |

Status matrix:

| lane | ok | over_budget | error | not_offered | total |
|---|---|---|---|---|---|
| sf_optimized | 40 | 1 | 0 | 0 | 41 |
| sf_wheel | 40 | 1 | 0 | 0 | 41 |
| sf_source | 40 | 1 | 0 | 0 | 41 |
| aer | 40 | 1 | 0 | 0 | 41 |
| pl | 31 | 5 | 0 | 0 | 36 |
| cirq | 30 | 5 | 3 | 0 | 38 |
| qulacs | 0 | 0 | 0 | 26 | 26 |

Caveats that constrain every comparison below:

- The three **sf** lanes are *pinned local builds* (optimized / wheel / baseline-source); md5s in the
  table above. On Colab they collapse to the pip `superfermion` build — three lanes, one engine.
- **qulacs** is documented `not_offered` (no MPS engine in the binding; no classical feed-forward) —
  its rows record that state, not a failure.
- **PennyLane** `default.tensor` (quimb) is analytic-only: no shots/counts/TVD; its MCM rows run on
  `default.qubit` trajectories.
- **Cirq** uses `cirq.contrib.quimb.MPSSimulator` (no long-range routing — see §6; no dense
  extraction — quality via estimation stats only).
- **SuperFermion MPS + dynamic MCM** runs on the pinned builds: `method='mps'`
  collapses the MPS itself per shot (bond<=64, no 2^n expansion) — the
  `teleport_mps` rows, now measured on all three pinned builds at m=4/10/20/40;
  `method='statevector'` trajectories (cost ~2^n) remain for small n and stay as
  measured walls (the m=8 wall now runs on every lane, §7).

## 3. MPS ladder — 50 → 1000 qubits

### GHZ (bond 64)
| qubits | sf_optimized | sf_wheel | sf_source | aer | pl | cirq |
|---|---|---|---|---|---|---|
| 50 | 0.000513 | 0.000567 | 0.000979 | 0.003371 | 0.091111 | 0.33106 |
| 100 | 0.00088 | 0.001196 | 0.002225 | 0.005211 | 0.13952 | 0.69507 |
| 200 | 0.001788 | 0.002362 | 0.002421 | 0.005984 | 0.45368 | — |
| 500 | 0.005105 | 0.006151 | 0.005902 | 0.01704 | 1.1569 | 2.4152 |
| 1000 | 0.01204 | 0.012739 | 0.01327 | 0.031483 | 3.7331 | 5.4405 |

![ladder GHZ](mps_bench8_out/figs/ladder_ghz_time.png)

### brick4 (bond 64)
| qubits | sf_optimized | sf_wheel | sf_source | aer | pl | cirq |
|---|---|---|---|---|---|---|
| 50 | 0.001412 | 0.001462 | 0.001541 | 0.01736 | 0.21929 | 0.42886 |
| 100 | 0.001773 | 0.002589 | 0.003037 | 0.053491 | 0.47877 | 0.86347 |
| 200 | 0.003783 | 0.004382 | 0.004637 | 0.046151 | 0.97276 | — |
| 500 | 0.008581 | 0.014555 | 0.012947 | 0.10024 | 3.4381 | 3.2368 |
| 1000 | 0.020053 | 0.019485 | 0.022291 | 0.28833 | 9.0052 | 6.8641 |

![ladder brick4](mps_bench8_out/figs/ladder_brick4_time.png)

GHZ ladder only — ratio vs sf_optimized (x = lane / sf_optimized):

| qubits | sf_wheel | sf_source | aer | pl | cirq |
|---|---|---|---|---|---|
| 50 | x1.105 | x1.908 | x6.571 | x177.604 | x645.351 |
| 100 | x1.359 | x2.528 | x5.922 | x158.548 | x789.857 |
| 200 | x1.321 | x1.354 | x3.347 | x253.736 | — |
| 500 | x1.205 | x1.156 | x3.338 | x226.617 | x473.102 |
| 1000 | x1.058 | x1.102 | x2.615 | x310.061 | x451.867 |

![slowest circuit per lane at n=1000](mps_bench8_out/figs/ratio_n_top.png)

Reading notes (all from the tables above):

- `<Z0·Zlast>` agrees across engines for GHZ (1.0, spread 0) and validate rows (spread ≤ 1e-11);
  ladder rows agree to ≤ 2e-12 (GHZ ≤ 4.8e-13; brick4 n=50 spread 2.0e-12).
- Sampling is timed in a separate column (`t_sample_s` in the notebook summary): 4000 shots for
  sf/aer; cirq adds a 100-rep sampling pass at n≤200; pl/qulacs do not sample.
- The qulacs column is omitted from numeric tables (documented `not_offered`; see the status matrix).
- Missing cells: cirq n=200 ladder rows are `over_budget` (§8).
- The n=1000 ratio **chart** answers a different question than the GHZ ratio **table** above it:
  the table is same-circuit (GHZ); the chart divides each lane's *slowest* ladder/stress circuit
  at n=1000 by sf_optimized's slowest there (stress brick12, 2.36 s) — an at-its-worst view, with
  the compared circuit annotated on each bar (pl/cirq have no stress row at n=1000, so their brick4
  ladder rows stand in).

## 4. Stress — brick12 at bond 64

| qubits | sf_optimized | sf_wheel | sf_source | aer | pl | cirq |
|---|---|---|---|---|---|---|
| 200 | 0.45511 | 1.7498 | 1.8152 | 0.81378 | 71.816 | — |
| 500 | 1.1408 | 4.1781 | 4.6128 | 1.7057 | — | 35.877 |
| 1000 | 2.3599 | 8.4652 | 9.2652 | 2.8796 | — | — |

![stress brick12](mps_bench8_out/figs/stress_brick12_time.png)

At n=1000 the sf lanes and aer agree on `<Z0·Zlast>` to ≤ 1e-6: sf_optimized (-0.2358585, discarded
weight 2.8e-13 → fidelity bound 1.0) matches aer (-0.2358585) to 1.1e-12; the older wheel/source
builds carry 1.1e-6 discarded weight and land 9.5e-7 away. The current build completes the rungs in
0.46 / 1.14 / 2.36 s (n = 200/500/1000) — at n=1000 that is faster than aer's 2.88 s; the wheel/source
builds need 8.5 / 9.3 s there. pl n=200 completes in 71.8 s, but pl n=500/1000 and cirq n=200/1000
were killed at their 270 s chunk caps (`over_budget`); cirq n=500 completed in 35.9 s.

Same-window fair check (§9): with sf_optimized and aer interleaved 6x each in one child
(3x ABBA, `_fair_probe2.py`), the gap at n=1000 is 2.31 vs 2.37 s (median; ranges overlap)
and at n=500 1.11 vs 1.24 s (ranges disjoint); n=200 is a tie (0.431 vs 0.437 s). The
columns above are cross-window rows — the sf_optimized lane was re-measured on the final
build ~19 h after aer — so direction is stable, but the 18/33/44% magnitudes are not.

## 5. Truncation quality

### Bond sweep, brick4 @ n=16 — TVD vs exact statevector
| bond χ | sf_optimized | sf_wheel | sf_source | aer | pl | cirq |
|---|---|---|---|---|---|---|
| 2 | 0.09054 | 0.09054 | 0.09054 | 0.04076 | — | — |
| 4 | 7.998e-16 | 9.007e-16 | 9.007e-16 | 4.864e-11 | — | — |
| 8 | 7.998e-16 | 9.007e-16 | 9.007e-16 | 4.864e-11 | — | — |
| 64 | 7.998e-16 | 9.007e-16 | 9.007e-16 | 4.864e-11 | — | — |

![bond sweep n16 TVD](mps_bench8_out/figs/bonds_n16_tvd.png)

(pl/cirq have no dense extraction/TVD; sf/aer TVD rows are the hard truncation numbers.)

The χ=2 cell is the one genuine aer edge here: both engines are coarse at that cut (TVD 9.1% vs
4.1%) and the gap is a truncation-policy difference, not a regression — all three pinned sf builds
agree to 5 digits (0.09054). sf's current SVD policy is its better one (legacy position-cut QR
measures 0.334 on the same row); sf crosses below aer's χ=2 number at χ=3 (0.0391) and at χ≥4 sits
≈5 orders lower (8.0e-16 vs 4.9e-11). χ=3/QR numbers: supplementary `_chi2_probe.py` probe (official
worker + pinned site).

### Bond sweep, brick12 @ n=200 — discarded weight
| bond χ | sf_optimized | sf_wheel | sf_source | aer | pl | cirq |
|---|---|---|---|---|---|---|
| 8 | 0.2418 | 0.2418 | 0.2418 | — | — | — |
| 16 | 0.933 | 0.01071 | 0.01071 | — | — | — |
| 32 | 0.5001 | 8.527e-05 | 8.527e-05 | — | — | — |
| 64 | 6.65e-14 | 4.451e-07 | 4.451e-07 | — | — | — |
| 128 | 6.65e-14 | 1.876e-13 | 1.876e-13 | — | — | — |

![bond sweep n200 time](mps_bench8_out/figs/bonds_n200_time.png)

At χ=8 the n=200 row shows the engine split: aer 0.13338 / pl 0.13284 / cirq 0.13266 vs sf 0.11196
(spread 2.1e-2) — the same circuit truncates differently per engine at tight bond (sf carries
discarded weight 0.24 there).

### Ladder @ n=1000 — quality at the top rung
| bond χ | sf_optimized | sf_wheel | sf_source | aer | pl | cirq |
|---|---|---|---|---|---|---|
| 64 | 0 | 0 | 0 | — | — | — |

(sf fidelity_lower_bound at ghz@1000: 1.0; brick12@1000: sf_optimized discarded weight 2.8e-13 → bound 1.0,
wheel/source 1.1e-6.)

## 6. QFT

| qubits | sf_optimized | sf_wheel | sf_source | aer | pl | cirq | qulacs |
|---|---|---|---|---|---|---|---|
| 8 | — | — | — | — | — | 0.041238 | — |
| 20 | — | — | — | — | 35.457 | [error] | — |
| 30 | — | — | — | — | — | [error] | — |
| 50 | 0.049639 | 0.042113 | 0.039813 | 0.1245 | [over_budget] | [error] | [not_offered] |
| 100 | 0.15242 | 0.16664 | 0.17042 | 0.45545 | — | — | — |
| 200 | 0.58637 | 0.65274 | 0.84417 | 2.0816 | — | — | — |

![qft time](mps_bench8_out/figs/qft_time.png)

- sf/aer run the shared QFT gate sequence at every n (sf sub-second at n=200).
- pl: n=20 completes (analytic, 35.5 s); n=50 exceeds its 180 s budget → `over_budget`.
- cirq quimb: **the pinned QFT construction works only at n=8 (0.04 s)**. n=12 (probe) and n=30
  (grid) fail with a UnicodeEncodeError cascading from quimb's non-ASCII error message; n=20 and
  n=50 fail at numpy's 64-dim ndarray cap (`found 72` / `found 65`). Reproduced deterministically
  across passes (probe + grid + retry runs, identical error on every attempt), recorded as `error` rows.

## 7. Mid-circuit measurement

| case | param m/N | lane | n | shots | wall s | all_correct |
|---|---|---|---|---|---|---|
| teleport | 4 | sf_optimized | 12 | 500 | 0.067684 | True |
| teleport | 4 | sf_wheel | 12 | 500 | 0.17425 | True |
| teleport | 4 | sf_source | 12 | 500 | 1.3278 | True |
| teleport | 4 | aer | 12 | 500 | 0.78988 | True |
| teleport | 4 | pl | 12 | 500 | 6.3044 | True |
| teleport | 4 | cirq | 12 | 500 | 3.0885 | True |
| mbqc | 17 | sf_optimized | 17 | 200 | 2.0147 | True |
| mbqc | 17 | sf_wheel | 17 | 200 | 3.5898 | True |
| mbqc | 17 | sf_source | 17 | 200 | 3.1204 | True |
| mbqc | 17 | aer | 17 | 200 | 12.33 | True |
| mbqc | 17 | pl | 17 | 200 | 69.025 | True |
| mbqc | 17 | cirq | 17 | 200 | 4.1046 | True |
| scale_teleport | 10 | aer | 30 | 1000 | 0.22577 | True |
| scale_teleport | 20 | aer | 60 | 1000 | 0.36882 | True |
| scale_teleport | 40 | aer | 120 | 1000 | 1.0151 | True |
| teleport_mps | 4 | sf_optimized | 12 | 100 | 0.00698 | True |
| teleport_mps | 4 | sf_wheel | 12 | 100 | 0.028926 | True |
| teleport_mps | 4 | sf_source | 12 | 100 | 0.030511 | True |
| teleport_mps | 10 | sf_optimized | 30 | 1000 | 0.09374 | True |
| teleport_mps | 10 | sf_wheel | 30 | 1000 | 1.9324 | True |
| teleport_mps | 10 | sf_source | 30 | 1000 | 2.1998 | True |
| teleport_mps | 20 | sf_optimized | 60 | 1000 | 0.23667 | True |
| teleport_mps | 20 | sf_wheel | 60 | 1000 | 7.1298 | True |
| teleport_mps | 20 | sf_source | 60 | 1000 | 11.382 | True |
| teleport_mps | 40 | sf_optimized | 120 | 1000 | 0.31796 | True |
| teleport_mps | 40 | sf_wheel | 120 | 1000 | 26.58 | True |
| teleport_mps | 40 | sf_source | 120 | 1000 | 57.25 | True |
| repcode | — | sf_optimized | 12 | 200 | 0.076387 | True |
| repcode | — | sf_wheel | 12 | 200 | 0.21227 | True |
| repcode | — | sf_source | 12 | 200 | 0.22016 | True |
| repcode | — | aer | 12 | 200 | 0.89447 | True |
| repcode | — | pl | 12 | 200 | 6.5375 | True |
| repcode | — | cirq | 12 | 200 | 5.3529 | True |

![mcm times](mps_bench8_out/figs/mcm_times.png)

![aer teleport inside MPS](mps_bench8_out/figs/mcm_aer_mps_scale.png)

- All `all_correct` gates pass on every lane that offers them: teleport (m=4, all lanes), MBQC
  wire (N=17), rep-code (all four error patterns), and the MPS+MCM scale rows — 1 on every
  target bit in every shot (qulacs documents `not_offered`).
- **Teleport m=4 — equal shots on all lanes (v2 official row)**: 500 shots / 120 s everywhere,
  measured this session: sf_optimized 0.068 / sf_wheel 0.174 / sf_source 1.328 / aer 0.790 /
  pl 6.304 / cirq 3.088 s — sf_optimized is x11.7 per shot vs aer, ~x45 vs cirq, ~x93 vs pl on
  identical specs. The same-window interleaved probe (`_fair_probe.py`, §9) re-measured four
  lanes at 500 shots inside one process: sf_optimized 0.049 vs aer 0.462 / cirq 2.15 / pl 3.83 s
  — same direction, warm window.
- **Aer runs the teleport chain inside the MPS engine** (m = 10, 20, 40 → n = 30, 60, 120) — the
  "MCM to shortcut MPS limits" lane (m=4 anchor row at 100 shots).
- **SuperFermion runs the same chain inside its own MPS engine** (`teleport_mps`, m=4/10/20/40 on
  all three pinned builds now; per-shot collapse at bond<=64, no 2^n expansion). The v2 scale rows
  expose the build spread at 1000 shots — sf_optimized 0.007/0.094/0.237/0.318 s vs sf_wheel
  0.029/1.93/7.13/26.6 s vs sf_source 0.031/2.20/11.4/57.3 s (m=4/10/20/40): same engine, three
  builds, ~x180 apart at m=40.
- On the one MPS+MCM rung controlled for n and shots (m=40, n=120, 1000 shots each): sf_optimized
  0.318 s vs aer 1.015 s — both `all_correct`; same-window ABBA re-measure (§9): 0.36 vs 0.57 s
  median, n=6 each, ranges disjoint → ≈1.6x fair margin.
- **The n=24 statevector-trajectory wall is engine-generic — v2 runs it on every lane** (teleport
  m=8, 500 shots, 90 s budget, solo so nothing joins the chunk; hard-killed at the 120 s cap):
  sf_optimized / sf_wheel / sf_source / aer / pl / cirq all land `over_budget`; qulacs
  `not_offered`. v1 offered this rung on the sf lanes only, which read as an sf-specific budget —
  the v2 grid shows every trajectory-replay engine hits the same wall at n=24. Supplementary
  probe (`_m8_probe.py`): trajectory cost 3.53 s/shot at n=24 (48-shot rung: 169.6 s,
  `all_correct`; ≈29 min for 500 shots extrapolated) vs the same rung on the native MPS path
  (`teleport_mps` m=8, 500 shots, `_m8_probe_mps.py`) in 0.107 s — the wall is the statevector
  path, not any one engine.
- MBQC N=17 — equal shots on all lanes (v2): 200 shots / 120 s: sf_optimized 2.01 / sf_wheel 3.59 /
  sf_source 3.12 / aer 12.3 / cirq 4.10 / pl 69.0 s; qulacs `not_offered`.
- **MBQC sf-vs-cirq direction is window-sensitive** (§9): official sf_optimized 2.01 vs cirq
  4.10 s this session; same-window v1 re-measures flipped once — one window cirq 2.24 vs sf 3.4 s
  (sf's first-in-process mbqc costs 2.0–3.4 s cold vs 1.28 s warm; cirq's path is far less
  warm-up-sensitive), the cleanest window sf 1.28 vs cirq 1.81 s in 3/3 interleaved cycles. The
  aer (~x6) and pl (~x34) MBQC margins vs sf are large and held in every window measured.
- Rep-code — equal shots on all lanes (v2, 200 shots / 60 s, four error patterns each): sf 0.076 /
  0.212 / 0.220, aer 0.894, pl 6.54, cirq 5.35 s; every pattern `all_correct` on every lane
  (construction port probe-validated on sf/pl/cirq before the grid ran; sf reads back
  post-measurement qubit states).

### MCM boundaries (non-ok MCM rows)

| lane | case | n | param | status | note |
|---|---|---|---|---|---|
| qulacs | mbqc | 17 | 17 | not_offered |  |
| qulacs | repcode | 12 | 0 | not_offered |  |
| aer | teleport | 24 | 8 | over_budget | chunk hard-killed at cap 120s (job budget_s=90s) |
| cirq | teleport | 24 | 8 | over_budget | chunk hard-killed at cap 120s (job budget_s=90s) |
| pl | teleport | 24 | 8 | over_budget | chunk hard-killed at cap 120s (job budget_s=90s) |
| qulacs | teleport | 12 | 4 | not_offered |  |
| qulacs | teleport | 24 | 8 | not_offered |  |
| sf_optimized | teleport | 24 | 8 | over_budget | chunk hard-killed at cap 120s (job budget_s=90s) |
| sf_source | teleport | 24 | 8 | over_budget | chunk hard-killed at cap 120s (job budget_s=90s) |
| sf_wheel | teleport | 24 | 8 | over_budget | chunk hard-killed at cap 120s (job budget_s=90s) |

## 8. Non-ok rows outside MCM (boundaries as data)

| lane | mode | circuit | n | budget s | status | note |
|---|---|---|---|---|---|---|
| cirq | ladder | ghz | 200 | 180 | over_budget | chunk hard-killed at cap 210s (job budget_s=180s) |
| cirq | ladder | brick4 | 200 | 180 | over_budget | chunk hard-killed at cap 210s (job budget_s=180s) |
| cirq | qft | qft | 20 | 90 | error | ValueError: maximum supported dimension for an ndarray is currently 64, found 72 |
| cirq | qft | qft | 30 | 90 | error | UnicodeEncodeError: 'ascii' codec can't encode characters in position 22-27: ordinal not in ran… |
| cirq | qft | qft | 50 | 60 | error | ValueError: maximum supported dimension for an ndarray is currently 64, found 65 |
| cirq | stress | brick12 | 200 | 240 | over_budget | chunk hard-killed at cap 270s (job budget_s=240s) |
| cirq | stress | brick12 | 1000 | 240 | over_budget | chunk hard-killed at cap 270s (job budget_s=240s) |
| pl | bonds | brick12 | 200 | 180 | over_budget | chunk hard-killed at cap 210s (job budget_s=180s) |
| pl | qft | qft | 50 | 180 | over_budget | chunk hard-killed at cap 210s (job budget_s=180s) |
| pl | stress | brick12 | 500 | 240 | over_budget | chunk hard-killed at cap 270s (job budget_s=240s) |
| pl | stress | brick12 | 1000 | 240 | over_budget | chunk hard-killed at cap 270s (job budget_s=240s) |

All `over_budget` rows are execution-time-threshold results: the job did not finish inside its own
budget on this host; the competing engines that did finish show their measured times in §3–§6.

## 9. Same-window interleaved audit (fair comparisons)

The grid above is a **cross-window composition**: each lane's rows sit inside one tight pass
(aer 10-07 23:03–23:08, pl 23:12–23:43, cirq 10-07 23:47+, wheel/source 10-08 03:33–03:45,
sf_optimized re-measured on the final build 10-08 18:32–18:45; 28 of the 44 MCM rows were
re-measured (or newly added) in one session 10-12 06:38–06:55, with the other 16 kept from the
v1 windows at identical specs — all three sf wall rows, the sf/aer MBQC rows, sf_optimized
teleport_mps m=4/10/20/40, sf_wheel/sf_source teleport_mps m=4, aer scale m=10/20/40), so
lane-vs-lane gaps can carry host-state drift — the MPS lanes on this laptop
swing 10–60% between windows (aer's own n=1000: 2.88 s official vs 2.35–2.41 s later; sf's
mbqc: 2.01 s official vs 1.19–1.34 s warm). Engine provenance was identical across the windows
involved (probe md5s; `_fair_verdict.py`), and the shared thread cap is not a handicap:
SF_THREADS=1/4/8 moves sf only 1.63→1.33 s and aer 1.51→1.44 s (n=500; no lane gains beyond
4 threads).

Every headline claim was therefore re-measured **interleaved ABBA inside a single child process**
(supplementary `_fair_probe.py` + `_fair_probe2.py`: official job specs, SF_THREADS=4, equal
shots where comparable; the 76-job `_fair_probe2.py` window re-runs the whole set interleaved):

| claim | official (cross-window) | same-window interleaved | verdict |
|---|---|---|---|
| stress n=1000 | 2.36 vs 2.88 s (−18%) | 2.31 vs 2.37 s med, n=6 each | sf ≈2.5% ahead; ranges overlap |
| stress n=500 | 1.14 vs 1.71 s (−33%) | 1.11 vs 1.24 s med, n=6 each | sf ≈10% ahead; ranges disjoint |
| stress n=200 | 0.46 vs 0.81 s (−44%) | 0.43 vs 0.44 s med, n=6 each | tie (±3% both ways across windows) |
| teleport m=4 @ equal 500 shots (now the v2 official row) | 0.068 vs aer 0.790 / cirq 3.088 / pl 6.304 s | sf 0.049 / aer 0.462 / cirq 2.15 / pl 3.83 s | sf ≥9x per shot vs aer, ~44–93x vs cirq/pl — robust |
| teleport_mps m=40 vs scale_teleport m=40 | 0.318 vs 1.015 s (x3.2) | 0.36 vs 0.57 s med, n=6 each | sf ≈x1.6 ahead — robust |
| mbqc N=17 | 2.01 vs cirq 4.10 s (v2 window) | window A: cirq 2.24 vs sf 3.4 s; window B: sf 1.28 vs cirq 1.81 s (3/3 cycles) | sf-vs-cirq direction host-state-dependent; sf-vs-aer/pl margins large in every window |

Consequences applied in this report: §4/§7 margins were restated at their same-window values;
the sf-vs-cirq MBQC row is flagged host-state-dependent; all other directions held in every
window measured, and every correctness invariant held too (cross-window expval parity ≤ 1.1e-11,
`all_correct` True on all MCM rows in all windows). Scope: ladder/QFT rows carry the same
cross-window caveat but were not re-measured same-window; the v2 MCM grid shrank the MCM
composition problem to the 16 kept rows at identical specs (listed above).

## 10. What this run did NOT measure

1. **No noise, no hardware** — pure statevector/MPS simulation on one Windows ultrabook; no
   density-matrix noise models, no real QPU lanes, no cloud latency.
2. **Not a framework-quality ranking** — it measures wall time and truncation behavior for five
   specific circuit families at bond 64 on this host in this session. Ecosystem strengths
   (Aer's noise/backend tooling, PennyLane's differentiable-programming stack, Cirq's hardware
   integrations) are outside the grid.
3. **sf lanes are local pinned builds** — not the pip package; compare md5s before comparing rows
   with any other machine.
4. **MCM rows are shot-uniform per rung (v2)** — teleport m=4 is 500 shots on every lane, the
   wall 500, MBQC 200, rep-code 200; v1's per-lane shot counts (sf 500 / aer 1000 / pl, cirq 200)
   were removed (§12). Wall rows are engine-generic threshold results, not rankings.
5. **TVD is only where a dense reference exists** (sf/aer at n=16); elsewhere quality is
   engine-reported (discarded weight / estimated fidelity) and definitions differ per engine.
6. **Rows are single-window; comparisons are cross-window** — each lane's rows were measured in
   one tight pass (sf_optimized 10-08 18:32–18:45 vs aer 10-07 23:03–23:08 for the official
   gaps; the v2 MCM rows 10-12 06:38–06:55) and this host drifts 10–60% between passes; §9
   quantifies the drift and re-measures the headline claims same-window (direction-stable;
   stress magnitudes shrink; sf-vs-cirq MBQC unstable).
7. **Cirq QFT boundary is construction-specific** — it is the pinned shared gate sequence that
   crashes at n≥12, not necessarily cirq/quimb in general.
8. **Sampling columns** — pl/qulacs do not offer sampling here; cirq sampled only n≤200.

## 11. Reproduce / artifacts

| artifact | path |
|---|---|
| executed notebook (tables + plots embedded) | `_mps_bench8.ipynb` |
| portable suite (run on another desktop) | `mps_bench8_suite/` + `_dist/mps_bench8_suite.zip` |
| results zip for Colab | `_dist/mps_mcm_bench8_results_laptop-l5lb07gu.zip` |
| raw rows | `mps_bench8_out/laptop-l5lb07gu_mps8.jsonl` (+ `.csv`) |
| figures (PNG + SVG) | `mps_bench8_out/figs/` |
| supplementary probes (wall + TVD + fair-comparison) | `_m8_probe.py`, `_m8_probe_mps.py`, `_chi2_probe.py`, `_fair_probe.py`, `_fair_probe2.py`, `_fair_verdict.py` (shipped in the suite) |

```text
Colab      : upload _mps_bench8.ipynb, Runtime -> Run all (pip deps install in the setup cell)
Desktop    : pip install -r requirements.txt  ->  python -X utf8 _mps_bench8_exec.py _mps_bench8.ipynb
Re-run     : resumes from the jsonl (terminal rows are skipped; delete a row to force re-execution)
```

## 12. v2 fairness changelog (what changed after the fairness review)

- **One shot count and one budget per MCM job class on every lane.** v1: teleport m=4 shots were
  sf 500 / aer 1000 / pl 200 / cirq 200 (budgets 60/60/120/120 s), MBQC budgets were 240 s (pl)
  and 150 s (cirq), and the n=24 wall rung (teleport m=8, 500 shots, 90 s) ran on the sf lanes
  only. v2: teleport m=4 = 500 shots / 120 s on all seven lanes; MBQC N=17 = 200 shots / 120 s on
  all lanes; the wall rung runs on all seven lanes at the same 500 shots / 90 s solo budget.
- **The wall result is now symmetric**: sf_optimized / sf_wheel / sf_source / aer / pl / cirq all
  `over_budget` at the identical spec (§7) — the v1 impression that sf alone "got budgeted" was
  an artifact of the wall being offered on the sf lanes only.
- **Rep-code now runs on every feed-forward lane** (v1: aer only) — the construction was ported
  to sf/pl/cirq and probe-validated on all four error patterns before queueing; qulacs gains
  `not_offered` rows for MBQC and rep-code so every lane has the same grid shape.
- **MPS+MCM scale covers all three sf builds** (v1: sf_optimized only) plus the aer m=4 anchor —
  the build spread at m=40 (0.318 vs 26.6 vs 57.3 s at 1000 shots) is measured, not implied.
- **Spec-changed v1 rows were pruned and re-measured** on this host in the v2 window
  (10-12 06:38–06:55); all other rows are the v1 measurements. Every row carries its own `ts`,
  `shots` and `budget_s`, so this changelog is auditable against the raw jsonl.

