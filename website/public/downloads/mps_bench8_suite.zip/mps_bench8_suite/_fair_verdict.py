"""Fair-comparison verdict reduction: official (OFF, latest ts per job key)
vs first probe window (W1) vs extended probe window (W2).
Prints per-panel rows with shots and per-shot ms; writes nothing."""
import json
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
_cands = [p for p in sorted((HERE / "mps_bench8_out").glob("*_mps8.jsonl"))
          if "quick" not in p.name]
if not _cands:
    raise SystemExit("no *_mps8.jsonl under mps_bench8_out/")
OFF = _cands[-1]


def jkey(r):
    return (r.get("framework"), r.get("circuit"), r.get("n_qubits"),
            r.get("bond"), r.get("method", "mps"), r.get("mcm_case") or "",
            r.get("mcm_param"), r.get("mode") or "")


off_all = [json.loads(l) for l in open(OFF, encoding="utf-8") if l.strip()]
off = {}
for r in off_all:
    k = jkey(r)
    if k not in off or (r.get("ts") or "") >= (off[k].get("ts") or ""):
        off[k] = r
w1 = json.load(open(HERE / "_fair_probe_rows.json", encoding="utf-8"))
w2 = json.load(open(HERE / "_fair_probe2_rows.json", encoding="utf-8"))


def row(r):
    t = r.get("t_expval_total_s")
    sh = r.get("shots") or 0
    per = f"{t / sh * 1e3:8.3f}" if (t and sh) else "       -"
    return (f"t={t if t is None else round(t, 4)!s:>8s}s shots={sh:>5d} "
            f"per={per}ms ok={str(r.get('all_correct')):>5s} st={r.get('status')}"
            + (f" {r.get('ts', '')}" if r.get("ts") else ""))


def off_rows(fw, case=None, param=None, n=None, mode="stress", circ="brick12"):
    out = []
    for k, r in off.items():
        if k[0] != fw:
            continue
        if mode == "stress" and not (r.get("method") == "mps"
                                     and r.get("mode") == "stress"
                                     and r.get("circuit") == "brick12"):
            continue
        if case is not None and r.get("mcm_case") != case:
            continue
        if case is None and r.get("mcm_case"):
            continue
        if param is not None and str(r.get("mcm_param")) != str(param):
            continue
        if n is not None and r.get("n_qubits") != n:
            continue
        out.append(r)
    return out


def panel(title, fw_list, case=None, param=None, n=None, mode="stress"):
    print(f"--- {title} ---")
    for fw in fw_list:
        for r in off_rows(fw, case, param, n, mode):
            print(f"  OFF {fw:12s} {row(r)}")
        for wname, rows in (("W1", w1), ("W2", w2)):
            for r in rows:
                if r.get("framework") != fw:
                    continue
                if mode == "stress":
                    if not (r.get("mode") == "stress" and r.get("circuit") == "brick12"
                            and (n is None or r.get("n_qubits") == n)):
                        continue
                else:
                    if case is not None and r.get("mcm_case") != case:
                        continue
                    if case is None and r.get("mcm_case"):
                        continue
                    if param is not None and str(r.get("mcm_param")) != str(param):
                        continue
                    if n is not None and r.get("n_qubits") != n:
                        continue
                t = r.get("t_expval_total_s")
                sh = r.get("shots") or 0
                per = f"{t / sh * 1e3:8.3f}" if (t and sh) else "       -"
                print(f"  {wname} {fw:12s} t={round(t, 4)}s shots={sh} per={per}ms "
                      f"ok={r.get('all_correct')}")
    print()


LANES4 = ["sf_optimized", "aer", "pl", "cirq"]
for n in (1000, 500, 200):
    panel(f"stress brick12 n={n} (reps=3, median)", ["sf_optimized", "aer"], n=n)
panel("teleport m=4 (all lanes)", LANES4, case="teleport", param=4, mode="mcm")
panel("teleport_mps m=40 (sf) vs scale_teleport m=40 (aer)",
      ["sf_optimized", "aer"], case="teleport_mps", param=40, mode="mcm")
# aer uses mcm_case=scale_teleport
print("--- scale_teleport m=40 (aer) ---")
for r in off_rows("aer", "scale_teleport", 40):
    print(f"  OFF aer          {row(r)}")
for wname, rows in (("W1", w1), ("W2", w2)):
    for r in rows:
        if (r.get("framework") == "aer" and r.get("mcm_case") == "scale_teleport"
                and str(r.get("mcm_param")) == "40"):
            t = r.get("t_expval_total_s")
            sh = r.get("shots") or 0
            per = f"{t / sh * 1e3:8.3f}" if (t and sh) else "       -"
            print(f"  {wname} aer          t={round(t, 4)}s shots={sh} per={per}ms "
                  f"ok={r.get('all_correct')}")
print()
panel("mbqc N=17 (sf vs cirq)", ["sf_optimized", "cirq"], case="mbqc", param=17, mode="mcm")
print("DONE_VERDICT")
