"""Build _mps_bench8.ipynb (full grid) or _mps_bench8_quick.ipynb (`quick` arg).

The notebook is self-contained for Colab: it embeds _mps_bench8_worker.py via a
%%writefile cell, defines pinned lane sites with graceful fallback, probes all
lanes, queues the MPS+MCM job grid, and runs one child process per per-lane
CHUNK with hard timeouts (user directive: every long step is time-bounded).
"""
import pathlib
import sys

import nbformat as nbf

HERE = pathlib.Path(__file__).resolve().parent
QUICK = "quick" in sys.argv

nb = nbf.v4.new_notebook()
cells = []


def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))


def code(text):
    cells.append(nbf.v4.new_code_cell(text))


md(r'''# MPS to 1000 qubits + mid-circuit measurement -- 7-framework industry benchmark

Custom benchmark notebook (MQTBench-style circuit selection, Quantinuum-style truncation reporting, KTH-style execution-time thresholds). Everything after execution is stored in the notebook, so it opens in Colab with outputs and plots present; re-running it there installs the pip packages, re-writes the worker, and re-runs the grid.

| suite | circuits | sizes | what it measures |
|---|---|---|---|
| **validate** | ghz, brick4 | n = 12, 16 | cross-engine anchors: MPS vs dense statevector expval (endianness + correctness gates) |
| **ladder** | ghz, brick4 | n = 50, 100, 200, 500, 1000 | the headline MPS scale grid: prep + `<Z0 Zlast>` cost vs qubit count, per engine |
| **stress** | brick12 | n = 200, 500, 1000 | entanglement pressure: 12 brick layers force real bond truncation at bond 64 |
| **qft** | QFT | n = 50, 100, 200 (lane-dependent) | quadratic-depth entangling circuit; the execution-time-threshold poster child |
| **bonds** | brick4 @16 / brick12 @200 | bond = 2..128 | truncation error vs cost: TVD against the exact statevector (n=16) and discarded weight / estimated fidelity (n=200) |
| **mcm** | teleport chain, MBQC wire, rep-code | n = 12..120 | mid-circuit measurement + feed-forward: correctness of conditional corrections, cost, and the MPS+MCM combination |

**Methodology pins**

- Metric for MPS rows: `<Z0 * Z_{n-1}>` after preparation; timed quantity = prep + expval (warm pass, then `reps` timed passes, median kept).
- Circuits are generated from one shared parameter stream (seed 7), and **identical gate sequences run on every engine** (QFT = H + controlled-phase grid + reversal swaps everywhere; no engine-native templates in timed rows).
- Truncation is where the MPS story lives: SF reports `discarded_weight` + `fidelity_lower_bound` per row; Cirq reports `estimation_stats` (num_coefs_used, memory, estimated_fidelity); at n=16 the swept rows put a hard number on the error: TVD between truncated-MPS probabilities and the exact statevector probabilities.
- Execution-time thresholds are first-class: every job carries a `budget_s`; the runner hard-kills any chunk that exceeds its budget and records an **`over_budget` row** for the unfinished jobs. `over_budget` = "did not finish inside its budget" -- data, not a failure. A `skipped_wall` row means the global notebook wall stopped the run (re-running picks those up).
- MCM correctness gates: every MCM circuit is deterministic (teleport input |1>, MBQC wire input |1>, rep-code prepared |111>) so **every sampled shot must show 1 on every target bit**; the `all_correct` column carries that verdict.
- Mid-circuit measurement inside the MPS engine: both Aer (`matrix_product_state`) and SuperFermion (`method='mps'`, bond_dim=64, all three pinned builds) run the teleport chain with per-shot collapse at m = 4/10/20/40 -> n = 12/30/60/120 (`scale_teleport` / `teleport_mps` rows). SuperFermion's statevector-trajectory MCM path stays for the small-n rows and its cost still grows like 2^n -- the n=24 wall rung (now run on every lane at equal shots and budget) measures that live against the bond-capped MPS path.
''')


md(r'''**Fairness and honesty notes (read before comparing numbers)**

- The three SuperFermion lanes are *pinned local builds* (optimized / wheel / baseline-source sites; md5 in the probe table). In Colab the sites do not exist, so all three lanes fall back to the pip `superfermion` package and become the same build -- the probe table then shows identical md5s and the three lanes are one engine.
- qulacs: **not_offered** for both suites (no MPS symbols in the binding; no classical feed-forward for MCM). Rows exist to document that state, not to compete.
- PennyLane `default.tensor` (quimb) is **analytic-only**: no shots, no counts, no TVD; its MCM rows run on `default.qubit` trajectories instead.
- Cirq `cirq.contrib.quimb` has **no long-range routing**: the pinned QFT construction works only at n=8 (0.04 s); n=12 and n=30 fail with a UnicodeEncodeError cascading from quimb's non-ASCII error message (ascii codec, characters at positions 22-27); n=20 and n=50 fail at numpy's 64-dim ndarray cap (ValueError "maximum supported dimension ... is currently 64, found 72" / "found 65") -- all recorded as error rows and reproduced across passes (probe + grid + retry). Its `MPSState` has no dense extraction, so quality comes from `estimation_stats()` only.
- SuperFermion MPS + dynamic mid-circuit measurement is **supported natively** on the pinned builds: `method='mps'` + `bond_dim` replays the trajectories with every Measure/Reset collapsing the MPS in place (no 2^n statevector). Builds without this support (older pip wheels) degrade to an `unsupported` row.
- The rep-code construction (AND-ancilla syndrome lookup) runs on every feed-forward lane (sf x3, aer, pl, cirq); it was ported to sf/pl/cirq and verified on all four error patterns (none/X0/X1/X2) on each engine before queueing (qulacs documents not_offered).
- Budgets (per job): validate 90 s; ladder 120-180 s; stress 90-240 s; QFT 30-180 s; bonds 90-240 s; MCM 60-150 s -- and inside the MCM suite one budget per job class on every lane: teleport m=4 120 s, wall m=8 90 s, MBQC 120 s, rep-code 60 s, MPS+MCM scale 60/90/150 s. Chunks pack jobs up to 240 s of cumulative budget with a +30 s kill margin; the notebook-wide wall is 2700 s (900 s in quick mode) with `skipped_wall` rows for the remainder.

**v2 fairness changelog (vs the v1 campaign; every row carries its own `ts`)**

- One shot count and one budget per MCM job class on every lane. v1: teleport m=4 shots were sf 500 / aer 1000 / pl 200 / cirq 200 with budgets 60/60/120/120 s, MBQC budgets were 240 s (pl) and 150 s (cirq), and the n=24 wall rung (teleport m=8, 500 shots, 90 s) ran on the sf lanes only. v2: teleport m=4 = 500 shots / 120 s on all seven lanes; MBQC N=17 = 200 shots / 120 s on all lanes; the wall rung now runs on all seven lanes (same 500 shots, same 90 s budget).
- The rep-code row now runs on every feed-forward lane; qulacs gains not_offered rows for MBQC and rep-code so every lane has the same grid shape.
- The MPS+MCM scale lane now covers all three sf builds (v1: sf_optimized only) and aer gains the m=4 mirror row next to its m=10/20/40 rows.
- v1 rows whose spec this changed were deleted from the jsonl and re-measured on this host in the v2 window; all other rows are the v1 measurements (their `ts` fields show the v1 window -- the cross-window composition stays disclosed in the audit below).
- Numbers are from this host session (no thread-pinning variance study here; `SF_THREADS` is fixed for all children).

**Same-window audit of the disputed rows (read before quoting any margin)**

The grid above is a *cross-window composition*: each lane ran in its own tight pass, hours apart (the `ts` field of every row carries its exact window). Cross-lane margins therefore mix engine differences with host drift, so every disputed headline row was re-measured **interleaved ABBA inside a single child process** (`_fair_probe.py` / `_fair_probe2.py`; reducer `_fair_verdict.py`; raw rows ship next to this notebook):

| claim | grid (cross-window) | same-window ABBA | verdict |
|---|---|---|---|
| teleport m=4, equal 500 shots, one process | sf 0.049 s vs aer 0.462 / cirq 2.15 / pl 3.83 s | same rows, no aggregation across windows | robust: 9.4x / ~44x / ~78x per shot |
| teleport_mps m=40 vs aer scale_teleport m=40 | 0.318 vs 1.015 s | 0.36 vs 0.57 s medians, ranges disjoint | robust: ~1.6x fair margin |
| stress brick12 n=1000 / 500 / 200 | sf 18% / 33% / 44% faster than aer | sf -2.5% / -9.8% / tie (0.431 vs 0.437 s) | direction stable; grid magnitudes are drift |
| mbqc N=17 vs cirq | sf 2.01 vs 2.61 s | warm: sf 1.28 vs cirq 1.81 (3/3 cycles); cold sf first-in-process: 3.3-3.4 vs cirq 2.24 | **not stable** -- host-state dependent |

Warm-up policy is symmetric across lanes (non-MCM rows: warm pass + median of reps; MCM rows: one timed run, no warm pass on *every* lane) -- but sf's mbqc path is far more cold-sensitive (2.0-3.4 s first-in-process vs 1.28 s warm; cirq's path pays only ~10%), which is what the mbqc flip tracks. Correctness was stable across all windows (cross-window expval parity <= 1.1e-11; every MCM row `all_correct` in every window).
''')


code(r'''# Colab setup: install there; the local env already has everything pinned.
import importlib.util
import datetime
import json
import os
import platform
import socket
import subprocess
import sys
import time
from pathlib import Path

IN_COLAB = importlib.util.find_spec("google.colab") is not None
if IN_COLAB:
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "-q",
         "superfermion", "pennylane", "quimb", "cirq-core", "qiskit-aer", "qulacs"],
        check=False,
    )

import numpy as np
import pandas as pd
from IPython.display import display, Markdown

pd.set_option("display.width", 220)
HERE = Path.cwd()
MACHINE = socket.gethostname().split(".")[0].lower()
print("python :", platform.python_version(), "|", platform.system(), platform.machine())
print("cpus   :", os.cpu_count(), "| colab:", IN_COLAB, "| host:", MACHINE)
print("nb dir :", HERE)''')


# ---- embed the worker (self-contained notebook) --------------------------
worker_src = (HERE / "_mps_bench8_worker.py").read_text(encoding="utf-8")
code("%%writefile _mps_bench8_worker.py\n" + worker_src)


code(r'''# ==== config: pinned lane sites with graceful fallback + child env sandbox ====
_candidates = [
    Path(r"D:\sf_runs\v8_local\sites"),     # this desktop: three pinned builds
    Path(r"C:\sf_runs\v8_local\sites"),
    Path(r"D:\sf_runs\vqc_v8_lap\sites"),   # laptop layout (bench7 sites)
    HERE / "sites",                          # Colab: absent -> env fallback
]
_site_root = next((p for p in _candidates if p.exists()), None)


def _site(name):
    p = _site_root / name if _site_root else None
    return str(p) if p and p.exists() else ""


CONFIG = {
    "python": sys.executable,          # children use the same interpreter as this kernel
    "worker": str(HERE / "_mps_bench8_worker.py"),
    "threads": 4,                      # same budget for every lane
    "out_dir": str(HERE / "mps_bench8_out"),
    "tag": "",                         # quick mode sets "quick" in the grid cell
    "sites": {
        "sf_optimized": _site("superfermion_optimized"),
        "sf_wheel": _site("superfermion_wheel"),
        "sf_source": _site("superfermion_source_baseline"),
    },
}

LANES = ["sf_optimized", "sf_wheel", "sf_source", "aer", "pl", "cirq", "qulacs"]


def child_env(lane):
    env = os.environ.copy()
    for k in ["PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONWARNINGS"]:
        env.pop(k, None)
    # NOTE: do NOT set PYTHONNOUSERSITE here -- under some interpreters it hides
    # user-site quimb/qiskit and silently disables the pl/cirq/aer lanes.
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["SF_THREADS"] = str(CONFIG["threads"])
    env["SF_SITE"] = CONFIG["sites"].get(lane, "")
    return env


print(f"threads={CONFIG['threads']} | site root: {_site_root or '(none -- env fallback per lane)'}")
for k, v in CONFIG["sites"].items():
    print(f"  site[{k}] = {v or '(use environment superfermion)'}")
print("worker:", CONFIG["worker"], "exists:", Path(CONFIG["worker"]).exists())
assert Path(CONFIG["worker"]).exists(), "worker script missing next to this notebook"''')


code(r'''# ==== capability probe: one child process per lane ====
PROBE = {}
for lane in LANES:
    try:
        p = subprocess.run([CONFIG["python"], "-X", "utf8", CONFIG["worker"], "--probe", lane],
                           capture_output=True, text=True, encoding="utf-8", errors="replace",
                           env=child_env(lane), cwd=str(HERE), timeout=180)
        line = next((l for l in p.stdout.splitlines() if l.strip().startswith("{")), None)
        PROBE[lane] = (json.loads(line) if line
                       else {"lane": lane, "status": "error", "version": "", "engine_md5": "",
                             "mps_api": "", "mcm_api": "", "notes": (p.stderr or "no output")[-240:]})
    except subprocess.TimeoutExpired:
        PROBE[lane] = {"lane": lane, "status": "error", "version": "", "engine_md5": "",
                       "mps_api": "", "mcm_api": "", "notes": "probe hard-timeout at 180s"}
    print(f"probed {lane:12s} {PROBE[lane]['status']:12s} mps={PROBE[lane].get('mps_api','')[:44]:44s} "
          f"mcm={PROBE[lane].get('mcm_api','')[:44]}")

probe_df = pd.DataFrame([{**PROBE[l], "lane": l} for l in LANES])
display(probe_df[["lane", "status", "version", "engine_md5", "mps_api", "mcm_api", "notes"]])
OUT = Path(CONFIG["out_dir"])
OUT.mkdir(parents=True, exist_ok=True)
(OUT / f"{MACHINE}{CONFIG['tag']}_probe.json").write_text(json.dumps(PROBE, indent=2), encoding="utf-8")''')


code(r'''# ==== job grid + budgets + resume scan ====
GRID = {
    "quick": __QUICK__,
    "suites": ["validate", "ladder", "stress", "qft", "bonds", "mcm"],
    "n_validate": [12, 16],
    "validate_circuits": ["ghz", "brick4"],
    "n_ladder": [50, 100, 200, 500, 1000],
    "ladder_circuits": ["ghz", "brick4"],
    "stress_n": [200, 500, 1000],
    "qft": {"sf_aer": [50, 100, 200], "pl_live": [20], "pl_over": [50],
            "cirq_live": [8], "cirq_err": [20, 30], "cirq_crash": [50]},
    "bonds_n16": [2, 4, 8, 64],
    "bonds_n200": [8, 16, 32, 64, 128],
    "mcm": {"teleport_m": [4], "wall_m": [8], "mbqc_N": [17], "scale_m": [10, 20, 40],
            "shots": {"sf": 500, "aer": 500, "pl": 500, "cirq": 500}},
    "reps": 3,
    "shots": 4000,
    "cirq_reps": 100,
    "cirq_sample_max_n": 200,
    "wall_cap_s": 2700,
}
if GRID["quick"]:
    GRID.update(suites=["validate", "ladder", "mcm"], n_validate=[12],
                validate_circuits=["ghz"], n_ladder=[50], ladder_circuits=["ghz"],
                reps=1, shots=200, cirq_reps=20, wall_cap_s=900)
    GRID["mcm"].update({"teleport_m": [4], "wall_m": [], "mbqc_N": [17], "scale_m": [10],
                        "shots": {"sf": 100, "aer": 200, "pl": 100, "cirq": 100}})
    CONFIG["tag"] = "quick"


def sample_policy(lane, n):
    if lane in ("pl", "qulacs"):
        return 0
    if lane == "cirq":
        return GRID["cirq_reps"] if n <= GRID["cirq_sample_max_n"] else 0
    return GRID["shots"]


def j_std(lane, circ, n, bond, method, mode, sample, budget, solo=False, tvd=False):
    return {"framework": lane, "circuit": circ,
            "layers": 0 if circ in ("ghz", "qft") else int(circ[5:]),
            "n": n, "bond": bond, "method": method, "mode": mode,
            "reps": 1 if method == "dense" else GRID["reps"],
            "sample_reps": sample, "budget_s": budget, "solo": solo, "tvd": tvd}


def j_mcm(lane, case, n, param, shots, budget, solo=False):
    return {"framework": lane, "circuit": "mcm", "layers": 0, "n": n, "bond": None,
            "method": "mcm", "mode": "mcm", "mcm_case": case, "mcm_param": param,
            "shots": shots, "reps": 1, "sample_reps": 0, "budget_s": budget, "solo": solo}


JOBS = []
if "validate" in GRID["suites"]:
    for n in GRID["n_validate"]:
        for circ in GRID["validate_circuits"]:
            for lane in LANES:
                for method in ("mps", "dense"):
                    JOBS.append(j_std(lane, circ, n, 64, method, "validate", 0, 90))
if "ladder" in GRID["suites"]:
    for n in GRID["n_ladder"]:
        for circ in GRID["ladder_circuits"]:
            for lane in LANES:
                budget = 30 if lane == "qulacs" else (180 if (n >= 1000 or lane in ("pl", "cirq")) else 120)
                JOBS.append(j_std(lane, circ, n, 64, "mps", "ladder", sample_policy(lane, n), budget))
if "stress" in GRID["suites"]:
    sb = {200: 90, 500: 150, 1000: 240}
    for n in GRID["stress_n"]:
        for lane in LANES:
            budget = 30 if lane == "qulacs" else (240 if lane in ("pl", "cirq") else sb[n])
            JOBS.append(j_std(lane, "brick12", n, 64, "mps", "stress", sample_policy(lane, n), budget))
if "qft" in GRID["suites"]:
    qf, qb = GRID["qft"], {50: 60, 100: 90, 200: 150}
    for lane in ["sf_optimized", "sf_wheel", "sf_source", "aer"]:
        for n in qf["sf_aer"]:
            JOBS.append(j_std(lane, "qft", n, 64, "mps", "qft", 0, qb[n]))
    for n in qf["pl_live"]:
        JOBS.append(j_std("pl", "qft", n, 64, "mps", "qft", 0, 150))
    for n in qf["pl_over"]:
        JOBS.append(j_std("pl", "qft", n, 64, "mps", "qft", 0, 180, solo=True))
    for n in qf["cirq_live"]:
        JOBS.append(j_std("cirq", "qft", n, 64, "mps", "qft", 0, 90))
    for n in qf["cirq_err"]:
        # measured boundary (reproduced): quimb QFT fails at n=12 (UnicodeEncodeError
        # cascade) and n>=20 (numpy 64-dim ndarray cap) in this pinned construction
        JOBS.append(j_std("cirq", "qft", n, 64, "mps", "qft", 0, 90))
    for n in qf["cirq_crash"]:
        JOBS.append(j_std("cirq", "qft", n, 64, "mps", "qft", 0, 60, solo=True))
    JOBS.append(j_std("qulacs", "qft", 50, 64, "mps", "qft", 0, 30))
if "bonds" in GRID["suites"]:
    for b in GRID["bonds_n16"]:
        for lane in ["sf_optimized", "sf_wheel", "sf_source", "aer"]:
            JOBS.append(j_std(lane, "brick4", 16, b, "mps", "bonds", 0, 90, tvd=True))
        for lane in ["pl", "cirq"]:
            JOBS.append(j_std(lane, "brick4", 16, b, "mps", "bonds", 0, 90))
    for b in GRID["bonds_n200"]:
        for lane in ["sf_optimized", "sf_wheel", "sf_source", "aer"]:
            JOBS.append(j_std(lane, "brick12", 200, b, "mps", "bonds", 0, 150))
        JOBS.append(j_std("pl", "brick12", 200, b, "mps", "bonds", 0, 180))
        JOBS.append(j_std("cirq", "brick12", 200, b, "mps", "bonds", 0, 240))
if "mcm" in GRID["suites"]:
    mm = GRID["mcm"]
    sh = mm["shots"]
    # v2 fairness grid: one shot count and one budget per job class on every lane
    # that offers the class; the wall rung runs on ALL lanes (same attempt, same
    # budget: sf re-confirms its 2^n trajectory wall, aer's sv engine finishes,
    # pl/cirq show where their trajectory simulators stand, qulacs is not_offered).
    for lane in LANES:
        sfam = "sf" if lane.startswith("sf") else lane
        shots = sh.get(sfam, 500)
        for m in mm["teleport_m"]:
            JOBS.append(j_mcm(lane, "teleport", 3 * m, m, shots, 120))
    for lane in LANES:
        for m in mm["wall_m"]:
            JOBS.append(j_mcm(lane, "teleport", 3 * m, m, 500, 90, solo=True))
    for lane in ["sf_optimized", "sf_wheel", "sf_source"]:
        # MPS+MCM on the sf builds (replaces the old mps_reject capability row)
        JOBS.append(j_mcm(lane, "teleport_mps", 12, 4, 100, 60))
    for lane in LANES:
        for N in mm["mbqc_N"]:
            # MBQC correctness rows: 200 shots on every lane (calibrated in quick
            # mode: aer 200 shots = 66.6s; 1000 shots would blow the budget);
            # one shared 120 s budget (v1 used 240 s on pl and 150 s on cirq)
            JOBS.append(j_mcm(lane, "mbqc", N, N, 200, 120))
    # MPS+MCM scale lane: every sf build + aer, same rows, same budgets (m=4 is
    # the 100-shot mirror of the sf teleport_mps m=4 row)
    for lane in ["sf_optimized", "sf_wheel", "sf_source"]:
        for m in mm["scale_m"]:
            JOBS.append(j_mcm(lane, "teleport_mps", 3 * m, m, 1000,
                              {10: 60, 20: 90, 40: 150}[m]))
    JOBS.append(j_mcm("aer", "scale_teleport", 12, 4, 100, 60))
    for m in mm["scale_m"]:
        JOBS.append(j_mcm("aer", "scale_teleport", 3 * m, m, 1000, {10: 60, 20: 90, 40: 150}[m]))
    for lane in LANES:
        # rep-code: every lane in the grid (qulacs documents not_offered)
        JOBS.append(j_mcm(lane, "repcode", 12, 0, 200, 60))

# ==== resume scan: terminal statuses are skipped; everything else re-queued ====
JSONL = OUT / f"{MACHINE}{CONFIG['tag']}_mps8.jsonl"
TERMINAL = ("ok", "not_offered", "over_budget", "unsupported")


def jkey(**kw):
    # `mode` is part of the job key: e.g. validate brick4@16 bond-64 and the bonds
    # sweep row @16 bond-64 share framework/circuit/n/bond/method and must not
    # collapse into one job entry.
    return (kw.get("framework"), kw.get("circuit"), kw.get("n_qubits", kw.get("n")),
            kw.get("bond"), kw.get("method", "mps"), kw.get("mcm_case") or "",
            kw.get("mcm_param"), kw.get("mode") or "")


def chunk_jobs(jobs):
    """Greedy pack by descending budget; `solo` jobs never share a chunk."""
    jobs = sorted(jobs, key=lambda j: -int(j.get("budget_s") or 60))
    chunks, cur, acc = [], [], 0
    for j in jobs:
        b = int(j.get("budget_s") or 60)
        # a solo job starts a chunk; nothing may JOIN it (pass-1 lesson: the sf m=8
        # wall killed its chunkmates and starved instant qft/teleport jobs)
        if cur and (j.get("solo") or acc + b > 240 or any(k.get("solo") for k in cur)):
            chunks.append(cur)
            cur, acc = [], 0
        cur.append(j)
        acc += b
    if cur:
        chunks.append(cur)
    return chunks


rows, done = [], set()
if JSONL.exists():
    for line in JSONL.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            rows.append(r)
            if r.get("status") in TERMINAL:
                done.add(jkey(**r))
TODO = [j for j in JOBS if jkey(**j) not in done]

from collections import Counter
print(f"jobs total {len(JOBS)} | cached {len(JOBS) - len(TODO)} | todo {len(TODO)}")
print("todo per lane:", dict(Counter(j["framework"] for j in TODO)))
print("todo per mode:", dict(Counter(j["mode"] for j in TODO)))
_worst = sum(sum(int(j.get("budget_s") or 60) for j in c) + 30
             for lane in LANES for c in chunk_jobs([j for j in JOBS if j["framework"] == lane]))
print(f"worst-case wall if every chunk hits its hard cap: ~{_worst}s "
      f"| notebook wall cap {GRID['wall_cap_s']}s")''')


md(r'''---
## Run

The RUN cell executes **one child process per per-lane chunk** (jobs packed up to 240 s of cumulative `budget_s`, risky jobs get their own chunk). Each child has a **hard timeout = chunk budget + 30 s**: when the deadline hits, the child is killed even if it is silent mid-computation, and every job of that chunk without a `JOBJSON` row is written out as an **`over_budget` row** (the execution-time-threshold result). A notebook-wide wall (`wall_cap_s`) stops the run with retryable `skipped_wall` rows. Completed rows stream to `mps_bench8_out/<host><tag>_mps8.jsonl`; re-running resumes: `ok` / `not_offered` / `over_budget` / `unsupported` rows are skipped (delete a row from the jsonl to force re-execution).''')

code(r'''# ==== RUN: per-lane chunks with HARD timeouts; over_budget rows synthesized ====
import json
import queue
import subprocess
import threading
import time

CHUNK_MARGIN_S = 30
WALL_CAP_S = GRID["wall_cap_s"]
BATCH_DIR = OUT / "batches"
BATCH_DIR.mkdir(exist_ok=True)

WORKER_FIELDS = ["framework", "fw_version", "engine_md5", "site", "circuit", "layers",
                 "n_qubits", "bond", "method", "mode", "mcm_case", "mcm_param", "shots",
                 "status", "expval_z0zlast", "t_expval_total_s", "trials", "t_sample_s",
                 "sample_reps", "sample_distinct", "all_correct", "quality",
                 "rss_mb", "peak_rss_mb", "budget_s", "notes", "error"]


def _now():
    return datetime.datetime.now().isoformat(timespec="seconds")


def emit(r):
    rows.append(r)
    with JSONL.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(r, default=float) + "\n")


def stub_row(J, status, why, note):
    r = {f: None for f in WORKER_FIELDS}
    r.update({"framework": J["framework"], "circuit": J["circuit"], "layers": J.get("layers"),
              "n_qubits": J["n"], "bond": J.get("bond"), "method": J.get("method", "mps"),
              "mode": J.get("mode", ""), "mcm_case": J.get("mcm_case", ""),
              "mcm_param": J.get("mcm_param"), "shots": J.get("shots") or 0,
              "budget_s": J.get("budget_s"), "status": status, "error": why, "notes": note,
              "host": MACHINE, "ts": _now()})
    return r


def run_chunk(lane, chunk, idx, nchunks):
    cap = sum(int(j.get("budget_s") or 60) for j in chunk) + CHUNK_MARGIN_S
    bfile = BATCH_DIR / f"{MACHINE}_{CONFIG['tag']}_{lane}_c{idx}.json"
    bfile.write_text(json.dumps(chunk), encoding="utf-8")
    cmd = [CONFIG["python"], "-X", "utf8", CONFIG["worker"], "--batch-file", str(bfile)]
    print(f"[{lane}] chunk {idx + 1}/{nchunks}: {len(chunk)} jobs, hard cap {cap}s", flush=True)
    t0 = time.perf_counter()
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace",
                            env=child_env(lane), cwd=str(HERE))
    q = queue.Queue()

    def reader():
        for ln in proc.stdout:
            q.put(ln)
        q.put(None)

    threading.Thread(target=reader, daemon=True).start()
    got, killed = [], False
    while True:
        rem = cap - (time.perf_counter() - t0)
        if rem <= 0:
            killed = True
            break
        try:
            ln = q.get(timeout=min(1.0, rem))
        except queue.Empty:
            continue
        if ln is None:
            break
        if ln.startswith("JOBJSON "):
            r = json.loads(ln[8:])
            r["host"] = MACHINE
            r["ts"] = _now()
            emit(r)
            got.append(jkey(**r))
            print(f"  {lane:12s} {str(r.get('mode')):8s} {str(r.get('circuit')):6s} "
                  f"n={r.get('n_qubits')} {r.get('method')} "
                  f"case={r.get('mcm_case') or '-'}:{r.get('mcm_param')} "
                  f"status={r.get('status')} exp={r.get('expval_z0zlast')} "
                  f"ok={r.get('all_correct')} t={r.get('t_expval_total_s')}", flush=True)
        elif ln.startswith("JOBSTART "):
            print("   >", ln[9:].strip()[:150], flush=True)
        elif ln.strip():
            print("   |", ln.rstrip()[:170], flush=True)
    if proc.poll() is None:
        proc.kill()
        proc.wait()
    dt = time.perf_counter() - t0
    done_set = set(got)
    for j in chunk:
        if jkey(**j) not in done_set:
            why = (f"chunk hard-killed at cap {cap}s (job budget_s={j.get('budget_s')}s)"
                   if killed else "no JOBJSON row returned")
            emit(stub_row(j, "over_budget", why,
                          "did not complete inside its execution-time budget -> over_budget row; "
                          "delete it from the jsonl to retry"))
    print(f"[{lane}] chunk {idx + 1}/{nchunks} wall {dt:.1f}s killed={killed} "
          f"rows {len(got)}/{len(chunk)}", flush=True)


wall0 = time.perf_counter()
by_lane = {}
for j in TODO:
    by_lane.setdefault(j["framework"], []).append(j)
for lane in LANES:
    lane_jobs = by_lane.get(lane, [])
    if not lane_jobs:
        continue
    chunks = chunk_jobs(lane_jobs)
    for ci, chunk in enumerate(chunks):
        if time.perf_counter() - wall0 > WALL_CAP_S:
            for j in chunk:
                emit(stub_row(j, "skipped_wall", f"global wall cap {WALL_CAP_S}s reached",
                              "not attempted this run; re-running the notebook picks these up "
                              "(skipped_wall is not terminal)"))
            continue
        run_chunk(lane, chunk, ci, len(chunks))
print(f"run window {time.perf_counter() - wall0:.1f}s | results -> {JSONL}")''')


code(r'''# ==== summary tables ====
df = pd.DataFrame(rows)
if df.empty:
    print("no rows yet -- run the RUN cell first")
else:
    df["n_qubits"] = pd.to_numeric(df["n_qubits"], errors="coerce")
    df["bond"] = pd.to_numeric(df["bond"], errors="coerce")
    # append-only jsonl: keep only the NEWEST row per job (re-runs and stale
    # skipped_wall rows from earlier passes would otherwise double-count)
    _key = ["framework", "circuit", "n_qubits", "bond", "method", "mcm_case",
            "mcm_param", "mode"]
    _kn = df[_key].where(df[_key].notna(), "")
    df = df[~_kn.duplicated(keep="last")].reset_index(drop=True)
    print(f"unique jobs: {len(df)} (rows loaded: {len(rows)})")
    print("== status per lane (all rows; over_budget/unsupported are results) ==")
    print(pd.crosstab(df["framework"], df["status"]).to_string())
    ok = df[df["status"] == "ok"].copy()
    mps = ok[(ok["method"] == "mps") & (ok["mode"] != "mcm")]
    key = ["mode", "circuit", "n_qubits", "bond"]
    ev = mps.pivot_table(index=key, columns="framework", values="expval_z0zlast", aggfunc="last")
    if not ev.empty:
        ev["spread"] = ev.max(axis=1) - ev.min(axis=1)
        print("\n== expval <Z0*Zlast> (mps rows) ==")
        print(ev.round(12).to_string())
    tm = mps.pivot_table(index=key, columns="framework", values="t_expval_total_s", aggfunc="last")
    if not tm.empty:
        print("\n== t_expval_total_s (median of reps) ==")
        print(tm.round(6).to_string())
        if "sf_optimized" in tm.columns:
            rat = tm.div(tm["sf_optimized"], axis=0).drop(columns=["sf_optimized"])
            print("\n== ratio vs sf_optimized (x = fw / sf_optimized) ==")
            print(rat.round(3).to_string())
    ladder = mps[mps["mode"] == "ladder"]
    samp = ladder[ladder["sample_reps"] > 0]
    if not samp.empty:
        print("\n== ladder sampling wall (s, one run at sample_reps shots/reps) ==")
        print(samp.pivot_table(index=["circuit", "n_qubits"], columns="framework",
                               values="t_sample_s", aggfunc="last").round(4).to_string())
    big = ok[ok["mode"].isin(["ladder", "stress"])]
    if not big.empty:
        ntop = big["n_qubits"].max()
        print(f"\n== peak RSS (MB, per child process) at n={ntop} ==")
        print(big[big["n_qubits"] == ntop].pivot_table(index="circuit", columns="framework",
                                                       values="peak_rss_mb",
                                                       aggfunc="last").round(0).to_string())
    q = mps[mps["quality"].astype(str).str.len() > 2].copy()
    if not q.empty:
        def _qget(s_, name):
            try:
                return json.loads(s_).get(name)
            except Exception:
                return None
        q["discarded_weight"] = q["quality"].map(lambda s_: _qget(s_, "discarded_weight"))
        q["tvd_vs_exact"] = q["quality"].map(lambda s_: _qget(s_, "tvd_vs_exact"))
        q["est_fidelity"] = q["quality"].map(lambda s_: _qget(s_, "estimated_fidelity"))
        print("\n== truncation quality: discarded_weight (rows that carry it) ==")
        print(q.pivot_table(index=key, columns="framework", values="discarded_weight",
                            aggfunc="last").dropna(how="all").to_string())
        n16 = q[(q["mode"] == "bonds") & (q["n_qubits"] == 16)]
        if not n16.empty:
            print("\n== bond sweep n=16 brick4: TVD of probabilities vs exact statevector ==")
            print(n16.pivot_table(index="bond", columns="framework", values="tvd_vs_exact",
                                  aggfunc="last").to_string())
        n200 = q[(q["mode"] == "bonds") & (q["n_qubits"] == 200)]
        if not n200.empty:
            print("\n== bond sweep n=200 brick12: discarded weight ==")
            print(n200.pivot_table(index="bond", columns="framework", values="discarded_weight",
                                   aggfunc="last").to_string())
            fs = n200.pivot_table(index="bond", columns="framework", values="est_fidelity",
                                  aggfunc="last").dropna(how="all")
            if not fs.empty:
                print("\n== bond sweep n=200 brick12: cirq estimated fidelity ==")
                print(fs.to_string())
    mcm = df[df["mode"] == "mcm"].copy()
    if not mcm.empty:
        mm = mcm[mcm["mcm_case"].isin(["teleport", "mbqc", "scale_teleport", "teleport_mps", "repcode"])]
        if not mm.empty:
            print("\n== MCM timing (s) per (case, qubits) ==")
            print(mm.pivot_table(index=["mcm_case", "n_qubits"], columns="framework",
                                 values="t_expval_total_s", aggfunc="last").round(4).to_string())
            print("\n== MCM correctness: all_correct == every sampled target bit 1 in every shot ==")
            print(mm.pivot_table(index=["mcm_case", "n_qubits"], columns="framework",
                                 values="all_correct", aggfunc="last").to_string())
        tm = mcm[mcm["mcm_case"] == "teleport_mps"]
        if not tm.empty:
            print("\n== sf MPS+MCM rows (teleport_mps: per-shot collapse inside the MPS) ==")
            print(tm[["framework", "mcm_param", "n_qubits", "status", "all_correct",
                      "t_expval_total_s"]].to_string())
    qft = ok[ok["mode"] == "qft"]
    if not qft.empty:
        print("\n== QFT timing (s) ==")
        print(qft.pivot_table(index="n_qubits", columns="framework", values="t_expval_total_s",
                              aggfunc="last").round(4).to_string())
    nonok = df[(df["status"] != "ok") & (df["mode"].isin(["qft", "stress", "mcm", "ladder"]))]
    if not nonok.empty:
        print("\n== non-ok rows in qft/stress/mcm/ladder (each one is a measured boundary) ==")
        print(nonok[["framework", "mode", "circuit", "n_qubits", "mcm_case", "mcm_param",
                     "budget_s", "status", "error"]].head(24).to_string())
    cov = ok.pivot_table(index="mode", columns="framework", values="t_expval_total_s",
                         aggfunc="count").fillna(0).astype(int)
    print("\n== coverage matrix: ok rows per (suite x lane) ==")
    print(cov.to_string())
    csv_path = OUT / f"{MACHINE}{CONFIG['tag']}_mps8.csv"
    df.to_csv(csv_path, index=False)
    print("\nCSV written:", csv_path)''')


code(r'''# ==== figures (saved as PNG + SVG under mps_bench8_out/figs) ====
import matplotlib.pyplot as plt

FIG = OUT / "figs"
FIG.mkdir(exist_ok=True)


def save(fig, name):
    fig.tight_layout()
    for ext in ("png", "svg"):
        fig.savefig(FIG / f"{name}.{ext}", dpi=130)
    plt.show()


if not df.empty:
    ok = df[df["status"] == "ok"]
    ladder = ok[(ok["mode"] == "ladder") & (ok["method"] == "mps")]
    for circ in ["ghz", "brick4"]:
        s = ladder[ladder["circuit"] == circ]
        if s.empty:
            continue
        fig, ax = plt.subplots(figsize=(7.5, 4.6), dpi=130)
        for lane in LANES:
            g = s[s["framework"] == lane].sort_values("n_qubits")
            if g.empty:
                continue
            ax.plot(g["n_qubits"], g["t_expval_total_s"], marker="o", label=lane)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("qubits")
        ax.set_ylabel("t_expval_total_s (median rep, s)")
        ax.set_title(f"MPS ladder | {circ} | prep + <Z0 Zlast> (bond 64)")
        ax.grid(alpha=0.3, which="both")
        ax.legend(fontsize=7)
        save(fig, f"ladder_{circ}_time")

    stress = ok[ok["mode"] == "stress"]
    if not stress.empty:
        fig, ax = plt.subplots(figsize=(7.5, 4.6), dpi=130)
        for lane in LANES:
            g = stress[stress["framework"] == lane].sort_values("n_qubits")
            if g.empty:
                continue
            ax.plot(g["n_qubits"], g["t_expval_total_s"], marker="o", label=lane)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("qubits")
        ax.set_ylabel("t_expval_total_s (median rep, s)")
        ax.set_title("brick12 stress at bond 64 (truncation becomes real)")
        ax.grid(alpha=0.3, which="both")
        ax.legend(fontsize=7)
        save(fig, "stress_brick12_time")

    top = ok[(ok["mode"].isin(["ladder", "stress"])) & (ok["n_qubits"] == ok["n_qubits"].max())]
    if not top.empty and "sf_optimized" in set(top["framework"]):
        # true "slowest circuit per lane": max over rows (NOT append-order last),
        # then ratio = lane / sf_optimized's slowest (bars were previously raw seconds)
        g = top.groupby("framework")["t_expval_total_s"].max()
        if "sf_optimized" in g.index and float(g["sf_optimized"]) > 0:
            base = float(g["sf_optimized"])
            slow = top.loc[top.groupby("framework")["t_expval_total_s"].idxmax()]
            circ = {r.framework: str(r.circuit) for r in slow.itertuples()}
            bars = (g / base).drop(index=["sf_optimized"], errors="ignore").sort_values()
            if not bars.empty:
                ntop = int(ok["n_qubits"].max())
                fig, ax = plt.subplots(figsize=(7.5, 3.8), dpi=130)
                ax.barh([f"{i} ({circ.get(i, '?')})" for i in bars.index], bars.values)
                for y, v in enumerate(bars.values):
                    ax.annotate(f"x{v:.2f}", (v, y), xytext=(4, 0), textcoords="offset points",
                                va="center", fontsize=8)
                ax.axvline(1.0, color="k", lw=0.8, ls="--")
                ax.set_xlim(left=0)
                ax.set_xlabel("x vs sf_optimized (slowest circuit per lane; higher = slower)")
                ax.set_title(f"n={ntop}: slowest circuit per lane / sf_optimized's "
                             f"slowest ({circ.get('sf_optimized', '?')})")
                save(fig, "ratio_n_top")

    def _q(s_, name):
        try:
            return json.loads(s_).get(name)
        except Exception:
            return None

    b16 = ok[(ok["mode"] == "bonds") & (ok["n_qubits"] == 16)]
    if not b16.empty:
        fig, ax = plt.subplots(figsize=(7.5, 4.4), dpi=130)
        for lane in LANES:
            g = b16[b16["framework"] == lane].sort_values("bond")
            tv = g["quality"].map(lambda s_: _q(s_, "tvd_vs_exact"))
            if tv.notna().any():
                ax.plot(g["bond"], tv, marker="o", label=lane)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("bond dimension")
        ax.set_ylabel("TVD vs exact (probabilities)")
        ax.set_title("bond sweep @ n=16 brick4: truncation error (lower = closer to exact)")
        ax.grid(alpha=0.3, which="both")
        ax.legend(fontsize=7)
        save(fig, "bonds_n16_tvd")

    b200 = ok[(ok["mode"] == "bonds") & (ok["n_qubits"] == 200)]
    if not b200.empty:
        fig, ax = plt.subplots(figsize=(7.5, 4.4), dpi=130)
        for lane in LANES:
            g = b200[b200["framework"] == lane].sort_values("bond")
            if g.empty:
                continue
            ax.plot(g["bond"], g["t_expval_total_s"], marker="o", label=lane)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("bond dimension")
        ax.set_ylabel("t_expval_total_s (median rep, s)")
        ax.set_title("bond sweep @ n=200 brick12: cost vs bond")
        ax.grid(alpha=0.3, which="both")
        ax.legend(fontsize=7)
        save(fig, "bonds_n200_time")

    mcm = ok[ok["mode"] == "mcm"]
    if not mcm.empty:
        # the wall rung adds a second ok teleport row on lanes that beat it (aer):
        # pin the comparison row to m=4 so set_index stays unique per lane
        tel = mcm[(mcm["mcm_case"] == "teleport")
                  & (mcm["mcm_param"] == 4)].set_index("framework")["t_expval_total_s"]
        mbq = mcm[mcm["mcm_case"] == "mbqc"].set_index("framework")["t_expval_total_s"]
        lanes_b = [l for l in LANES if l in tel.index or l in mbq.index]
        if lanes_b:
            xs = list(range(len(lanes_b)))
            fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=130)
            ax.bar([x - 0.2 for x in xs], [float(tel.get(l, np.nan)) for l in lanes_b],
                   width=0.38, label="teleport chain m=4 (12 q)")
            ax.bar([x + 0.2 for x in xs], [float(mbq.get(l, np.nan)) for l in lanes_b],
                   width=0.38, label="MBQC wire N=17")
            ax.set_xticks(xs)
            ax.set_xticklabels(lanes_b, fontsize=8)
            ax.set_yscale("log")
            ax.set_ylabel("wall time (s)")
            ax.set_title("mid-circuit measurement + feed-forward: run time")
            ax.grid(alpha=0.3, axis="y", which="both")
            ax.legend(fontsize=8)
            save(fig, "mcm_times")
        scale = mcm[mcm["mcm_case"] == "scale_teleport"].sort_values("n_qubits")
        if not scale.empty:
            fig, ax = plt.subplots(figsize=(7.5, 4.0), dpi=130)
            ax.plot(scale["n_qubits"], scale["t_expval_total_s"], marker="o")
            for _, r in scale.iterrows():
                ax.annotate(f"m={r['mcm_param']}", (r["n_qubits"], r["t_expval_total_s"]),
                            textcoords="offset points", xytext=(6, 6), fontsize=8)
            ax.set_xscale("log")
            ax.set_yscale("log")
            ax.set_xlabel("qubits")
            ax.set_ylabel("t (s, 1000 shots)")
            ax.set_title("Aer MPS + MCM: teleport chain inside the MPS engine")
            ax.grid(alpha=0.3, which="both")
            save(fig, "mcm_aer_mps_scale")

    qft = ok[ok["mode"] == "qft"]
    if not qft.empty:
        fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=130)
        for lane in LANES:
            g = qft[qft["framework"] == lane].sort_values("n_qubits")
            if g.empty:
                continue
            ax.plot(g["n_qubits"], g["t_expval_total_s"], marker="o", label=lane)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("qubits")
        ax.set_ylabel("t_expval_total_s (median rep, s)")
        ax.set_title("QFT (H + controlled-phase grid + reversal swaps): all lanes")
        ax.grid(alpha=0.3, which="both")
        ax.legend(fontsize=7)
        save(fig, "qft_time")

print("figures ->", FIG)''')


code(r'''# ==== coverage + honest scope ====
df = pd.DataFrame(rows)
if not df.empty:
    cov = df[df["status"] == "ok"].pivot_table(index="mode", columns="framework",
                                               values="t_expval_total_s", aggfunc="count").fillna(0)
    display(Markdown("**Coverage matrix -- ok rows per suite x lane**"))
    display(cov.astype(int))
    st = pd.crosstab(df["framework"], df["status"])
    display(Markdown("**Status per lane -- `over_budget`/`unsupported` are results, not failures**"))
    display(st)
    ob = df[df["status"] == "over_budget"]
    if not ob.empty:
        display(Markdown("**over_budget rows (execution-time threshold crossed)**"))
        display(ob[["framework", "mode", "circuit", "n_qubits", "mcm_case", "mcm_param",
                    "budget_s", "error"]])

print("""
What this notebook did NOT measure (read the rows accordingly):
1. sf lanes are three locally pinned builds (md5s in the probe table); on Colab they
   collapse to the pip superfermion build -- compare md5s, not names.
2. qulacs: no MPS engine, no classical feed-forward -> not_offered rows only.
3. PennyLane default.tensor is analytic-only: no shots/counts/TVD there; its MCM
   rows run on default.qubit trajectories.
4. Cirq (quimb): no long-range routing -> QFT works only at n=8; n=12..50 all
   error (UnicodeEncodeError cascade / numpy ndarray 64-dim cap; recorded); no
   dense extraction -> quality via estimation_stats only.
5. SuperFermion MCM runs two ways on the pinned builds: method='statevector'
   trajectory (cost ~2^n -- n=12 fine, the n=24 wall rung stays as the wall) and
   method='mps', where every shot collapses the MPS itself at bond<=64 with no
   2^n expansion: teleport_mps rows at n=12 and n=30/60/120 on all three sf
   builds, all_correct.
6. rep-code runs on every feed-forward lane (sf x3, aer, pl, cirq; construction
   ported and pre-verified on all four patterns per engine); qulacs documents
   not_offered for MBQC and rep-code like it does for teleport.
7. Ratios are from this host session; SF_THREADS=4 for every child, no thread
   variance study here.
8. Bond-sweep TVD is only possible where a dense reference exists (sf/aer at n=16);
   elsewhere truncation is reported via discarded_weight / estimated_fidelity.
9. Same-window audit (see the fairness notes above): the teleport rows are corroborated
   at equal shots in one process (9-78x per shot); the stress margins shrink to
   -2.5% / -9.8% / tie when measured same-window (the grid margins include lane
   re-measure drift); MBQC direction is host-state dependent (cold-vs-warm process
   placement) and is not resolved by this host alone.
10. Cross-window composition: each lane's rows come from one tight per-lane pass
   (timestamps in the row `ts` fields); read every small cross-lane margin together
   with the same-window ABBA numbers above.
""")''')


md(r'''### Results bundle -- one zip with everything

Right after a run, the desktop runner packs `_dist/` zips: the executed notebook with
every cell-by-cell output (the exact view when opened/uploaded in Colab), `report.md`,
csv/jsonl/probe json, all figures png+svg, a run summary. In Colab this cell builds
the same bundle live -- it embeds this notebook *with every output produced so far*
(via the Colab `get_ipynb` API), adds the raw data, figures and a bundle summary, and
offers `mps_mcm_bench8_results_<host>.zip` for download.

Honest limits: a cell cannot include its own outputs, so a bundle built from inside
the notebook omits only this last cell (a fresh Colab run also has no `report.md` --
that file is a reference-run artifact). The desktop packer has no such gap because
it runs after execution ends.
''')

code(r'''# ==== results bundle: one zip with everything (Colab download / desktop pointer) ====
import json
import zipfile
import datetime

_bundle = None
try:
    import google.colab  # noqa: F401
    _colab = True
except ImportError:
    _colab = False

if not _colab:
    print("Desktop run: the complete results zip -- THIS executed notebook (every cell-by-cell")
    print("output, exactly as shown when the ipynb is opened in Colab), report.md, csv/jsonl/probe")
    print("json, all figures png+svg and the run summary -- is packed by the runner right after")
    print("execution finishes:")
    print("  run_notebook.bat   (or: python -X utf8 _mps_bench8_pack.py)   ->   _dist/*.zip")
    print("A cell cannot embed its own outputs, so no second, incomplete zip is built here.")
else:
    _files = []
    for _pat in ("*.jsonl", "*.csv", "*_probe.json"):
        _files += [p for p in sorted(OUT.glob(_pat)) if "quick" not in p.name]
    _files += [p for p in sorted((OUT / "figs").glob("*")) if p.is_file()]
    if (HERE / "report.md").exists():
        _files.append(HERE / "report.md")
    _nb_json = None
    try:  # the live notebook WITH every cell output produced so far (Colab-only API)
        from google.colab import _message
        _reply = _message.blocking_request("get_ipynb", timeout_sec=30)
        _nb_json = (_reply if isinstance(_reply, str)
                    else _reply.get("ipynb") if isinstance(_reply, dict) else None)
    except Exception as _exc:
        print("(executed-notebook embedding skipped:", type(_exc).__name__, ")")
    _rows = []
    for _f in OUT.glob("*_mps8.jsonl"):
        _rows += [json.loads(_l) for _l in _f.read_text(encoding="utf-8").splitlines()
                  if _l.strip()]
    if _files or _nb_json:
        _bundle = OUT / f"mps_mcm_bench8_results_{MACHINE}.zip"
        _summ = {"host": MACHINE,
                 "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
                 "rows": len(_rows),
                 "statuses": {s: sum(1 for r in _rows if r.get("status") == s)
                              for s in sorted({r.get("status") for r in _rows})},
                 "notebook_embedded": _nb_json is not None,
                 "files_included": len(_files)}
        with zipfile.ZipFile(_bundle, "w", zipfile.ZIP_DEFLATED) as _z:
            if _nb_json is not None:
                _z.writestr("MPS_MCM_Benchmark_7Framework.ipynb",
                            _nb_json if isinstance(_nb_json, str) else json.dumps(_nb_json))
            for _p in _files:
                _z.write(_p, "mps_bench8_out/" + _p.relative_to(OUT).as_posix()
                         if (OUT in _p.parents or _p.parent == OUT) else _p.name)
            _z.writestr("run_bundle_summary.json", json.dumps(_summ, indent=2))
        print("bundle:", _bundle.name, _bundle.stat().st_size // 1024, "KB | rows:", len(_rows),
              "| statuses:", _summ["statuses"], "| notebook embedded:", _summ["notebook_embedded"])
        try:
            from google.colab import files
            files.download(str(_bundle))
        except Exception as _exc:
            print("(auto-download failed:", type(_exc).__name__, "- zip left at", _bundle, ")")
    else:
        print("nothing to bundle yet (no rows/figures) -- run the grid cell first")
''')

out_name = "_mps_bench8_quick.ipynb" if QUICK else "_mps_bench8.ipynb"
path = HERE / out_name
for c in cells:  # build-time substitution of the quick flag
    if c.cell_type == "code" and "__QUICK__" in c.source:
        c.source = c.source.replace("__QUICK__", "True" if QUICK else "False")
nb.cells = cells
assert len(nb.cells) == len(cells) and cells, "builder bug: cells not attached"
nbf.write(nb, str(path))
print(f"wrote {path} | cells={len(cells)} | worker embedded={len(worker_src)} chars")
